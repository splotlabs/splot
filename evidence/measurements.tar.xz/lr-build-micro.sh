set -euo pipefail
root=$(pwd)
repo="$root/../splot-1934-lr-module"
variant=$1
out="$root/lr-micro-$variant"
mkdir -p "$out/src"
cp "$repo/tests/downstream/restoration-module.rs" "$out/src/main.rs"
cat > "$out/Cargo.toml" <<'MANIFEST'
[package]
name = "lr-kernel-consumer"
version = "0.0.0"
edition = "2024"
publish = false

[dependencies]
splot-core = { path = "../../splot-1934-lr-module/crates/splot-core" }
splot-lr-kernel = { path = "../../splot-1934-lr-module/crates/splot-lr-kernel" }
splot-lr-avx2 = { path = "../../splot-1934-lr-module/crates/splot-lr-avx2" }
MANIFEST
cd "$out"
cargo +1.100.0 generate-lockfile --offline > lock.log 2>&1
opts=(env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u CARGO_BUILD_RUSTFLAGS -u RUSTC_WRAPPER)
if [[ $variant == unit ]]; then opts+=(RUSTC_WRAPPER="$repo/scripts/rustc-lr-prototype.py" SPLOT_LR_COMPILE_LOG="$out/flags.tsv"); fi
systemd-run --user --scope --quiet -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p CPUQuota=180% flock "$root/build.lock" taskset -c 6-11,14-19 "${opts[@]}" cargo +1.100.0 build --release -j1 --locked --offline > build.log 2>&1
target/release/lr-kernel-consumer 0 > parity.txt
