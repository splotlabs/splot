from pathlib import Path
import csv
import statistics
root=Path(__file__).parent
with (root/'four-way.csv').open() as f:
    rows=list(csv.DictReader(f))
assert len(rows)==96
out=['## Native AVX2 result for startup-selected coefficient decoding',
'The serial and scheduled tile parsers carry the selected backend into the same coefficient implementation at `a4c95ac9019a717344fd1d56174820bb4239d32f`. Both high-frequency and low-frequency loops now use the carried token. Auto runs on the AVX2 backend on this i7-12700H.',
'### End-to-end elapsed time',
'Each cell is the median of 12 paired ratios. Positive values mean the parser candidate took longer. The intervals are percentile bootstrap intervals over pairs. All four versions had warmup runs and each appeared in all four positions, with a Williams-balanced order. Each process decoded 40 frames on one worker pinned to logical CPU 4. Runs took place after both historical release builds finished.',
'| 1080p stream | Before parser routing (portable `2a04d218`) | Previous packaged v3 (`10279846`) | Frozen pre-epic (`b337fafe`) |\n|---|---:|---:|---:|']
import re
summary=(root/'four-way.txt').read_text()
for stream in ('WITCHER3','TunnelFlag'):
    values=[]
    for ref in ('control','shipped','frozen'):
        m=re.search(rf'{stream} parser/{ref} elapsed: ([-+.0-9]+%) (\[[^\]]+\])',summary)
        values.append(f'{m[1]} {m[2]}')
    out[-1]+='\n| '+stream+' | '+' | '.join(values)+' |'
out.extend(['### Correctness and code generation',
'All 21 complete AVM raw hashes matched across seven streams and 1, 7 and 12 threads. Strict SSE2 emulation matched the reference in all 40 CLI/C cases across ten fixtures. After the workstation reboot, the first 40 raw frames of each timed stream also matched the rebuilt shipped decoder at 1, 7 and 12 threads. The core unit suite passed 1,703 tests with one ignored; strict native Clippy and AArch64 Apple cross-Clippy passed. The comparison uses Linux, rustc 1.100.0, default release settings, and the repository CPU flags at each revision.',
'For the first three WITCHER3 frames, high-frequency coefficient instructions fell 11,527,185 (9.96%), and whole-process instructions fell 6,507,070 (0.40%). For TunnelFlag the reductions were 9,664,289 (10.00%) and 5,829,361 (0.20%). Linked high-frequency AVX2 bodies use BMI2 shifts and vector blends without CPU detection or calls. The low-frequency AVX2 loop still calls an outlined seven-entry CDF reader. Against the portable control, stripped sizes rose 232,896 bytes CLI and 245,152 bytes C shared library.',
'**Rollout decision: HOLD.** Localized instruction savings do not restore the shipped decoder throughput. The portable PR #1987 stays in draft. Parser candidate and references are preserved. The new signed commits are associated with `bartekplus` as author and committer.'])
out+=['<details><summary>Raw four-way timing (seconds)</summary>\n\n```csv\n'+(root/'four-way.csv').read_text().strip()+'\n```\n</details>']
(root/'parser-issue.md').write_text('\n\n'.join(out)+'\n')
