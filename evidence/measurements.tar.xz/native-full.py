import csv
import hashlib
import os
from pathlib import Path
import random
import statistics
import subprocess
import time
root=Path(__file__).resolve().parent
os.sched_setaffinity(0,{4})
bins={name:root/f'{name}/target/release/splot' for name in ('native','shipped')}
streams=[root/'ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf',next((root/'ci-data').glob('RitualDance*.ivf'))]
def run(binary,src):
    start=time.perf_counter()
    subprocess.run([binary,'decode',src,'--threads','1','--frame-delay','1','--output-format','null'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return time.perf_counter()-start
for src in streams:
    for binary in bins.values():
        run(binary,src)
samples={}
with (root/'native-full.csv').open('x') as f:
    w=csv.writer(f)
    w.writerow(['stream','pair','position','build','elapsed_s'])
    for i in range(8):
        for j,src in enumerate(streams if i%2==0 else reversed(streams)):
            for pos,name in enumerate(tuple(bins)[::1 if (i+streams.index(src))%2==0 else -1]):
                sample=run(bins[name],src)
                samples[src,i,name]=sample
                w.writerow([src.name,i+1,pos+1,name,sample])
                f.flush()
for src in streams:
    paired=[100*(samples[src,i,'native']/samples[src,i,'shipped']-1) for i in range(8)]
    rng=random.Random(1882)
    interval=sorted(statistics.median(rng.choices(paired,k=8)) for _ in range(10000))
    print(src.name,'paired elapsed %',*(round(x,2) for x in (statistics.median(paired),interval[250],interval[-251])),'slower',sum(p>0 for p in paired),'of 8',flush=True)
