import hashlib
from pathlib import Path
import subprocess
import sys
root=Path(__file__).parent
exe=Path(sys.argv[1]).resolve()
cases=(root/'ci-data/simd-cases.tsv').read_text().splitlines()
assert len(cases)==7
for case in cases:
    name,expected,frames,raw_bytes=case.split('\t')
    for threads in (1,7,12):
        cmd=[exe,'decode',root/'ci-data'/name,'--threads',str(threads),'--output-format','raw','-o','-']
        with subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL) as decode:
            digest=hashlib.file_digest(decode.stdout,'sha256').hexdigest()
            if decode.wait()!=0 or digest!=expected:
                raise RuntimeError((name,threads,digest,expected))
        print(name,threads,frames,digest,flush=True)
