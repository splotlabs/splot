"""Attribute sampled CPU milliseconds by the same broad Noise Ocean stages."""

from collections import Counter, defaultdict
import csv
import ctypes
from dataclasses import dataclass
from decimal import Decimal
import hashlib
from pathlib import Path
import re
from runpy import run_path
from statistics import mean, median

HERE = Path(__file__).resolve().parent
shared = run_path(str(HERE.parent / "noise-stage-breakdown.py"))
STAGES, ANCHORS, MEMORY = (shared[key] for key in ("STAGES", "ANCHORS", "MEMORY"))

TREE_LINE = re.compile(r"^\s*(\d+\.?\d*) +\d+\.?\d*   ([ |]*)\+-(.*)$")
FUNCTION_LINE = re.compile(r"^\s*(\d+\.?\d*)\s+\d+\.?\d*\s+(.*)$")
PC_LINE = re.compile(r"^\s*(\d+\.?\d*)\s+\d+:0x([0-9a-f]+)\s+(.+?) \+ 0x[0-9A-Fa-f]+$")
FAMILIES = [
    ("Filters", r"splot_(?:decode::filters|recon::(?:cdef_filter|wienerns_(?:filter|chroma_filter)|pc_wiener|lr_madd|ccso_filter|deblock_filter|gdf_filter|loop_restoration))::"),
    ("Transforms/residual math", r"splot_recon::(?:inverse_transform[^:]*|reconstruct|inverse_quant[^:]*|dequant[^:]*)::"),
    ("Entropy/parser", r"splot_(?:core::(?:headers|symbol|obu)|decode::bitstream)::"),
    ("Motion/prediction", r"splot_(?:decode::prediction|recon::(?:subpel_mc|blend_mask|warp_prediction|intra_[^:]+))::"),
    ("Output/scheduling/frame setup", r"splot_(?:decode::(?:context|pipeline|output)|recon::(?:hash_input|plane_buf|y4m)|cli)::"),
]
FAMILIES = [(label, re.compile(pattern)) for label, pattern in FAMILIES]
FILTERS = [
    ("CDEF", r"::cdef::|::cdef_filter::|::CdefPairSegment|::CdefOverlap"),
    ("Deblock", r"::deblock::|::deblock_filter::"),
    ("GDF", r"::gdf::|::gdf_filter::"),
    ("CCSO", r"::ccso::|::ccso_filter::"),
    ("Restoration/classification", r"::(?:wienerns_filter|wienerns_chroma_filter|pc_wiener|lr_madd|loop_restoration)::|::(?:apply_lr_stripe|compute_luma_lr_block|compute_chroma_lr_block|luma_lr_cell_subclasses)"),
]
FILTERS = [(label, re.compile(pattern)) for label, pattern in FILTERS]
FOCUSES = [
    ("TIP motion-field units", r"::prepare_tip_units(?:::)?<"),
    ("Temporal motion-field projection", r"::(?:project_tracked|project_temporal_motion_field)(?:::)?<"),
    ("CDEF packed chroma gather", r"::gather_with_mode(?:::)?<|::PairGather(?:::)?<|::pair_ranges(?:::)?<"),
    ("CDEF segment filter", r"::cdef_filter_segment_with(?:::)?<|::cdef_filter_rows_wide8(?:::)?<"),
    ("Luma Wiener filter", r"::wiener_ns_filter_luma_block_padded_layout_into(?:::)?<|::wienerns_filter::eight_bit::(?:avx2::)?filter_row"),
    ("Coefficient high-frequency pass", r"::hf_pass(?:::)?<"),
]
FILTERS = [
    ("CDEF", r"::cdef::|::cdef_filter::|::CdefPairSegment|::CdefOverlap"),
    ("Deblock", r"::deblock::|::deblock_filter::"),
    ("GDF", r"::gdf::|::gdf_filter::"),
    ("CCSO", r"::ccso::|::ccso_filter::"),
    ("Restoration/classification", r"::(?:wienerns_filter|wienerns_chroma_filter|pc_wiener|lr_madd|loop_restoration)::|::(?:apply_lr_stripe|compute_luma_lr_block|compute_chroma_lr_block|luma_lr_cell_subclasses)"),
]
FILTERS = [(label, re.compile(pattern)) for label, pattern in FILTERS]
FOCUSES = [(label, re.compile(pattern)) for label, pattern in FOCUSES]


@dataclass
class Node:
    inclusive: int
    exclusive: int
    path: tuple[str, ...]


def milliseconds(value):
    return int(Decimal(value) * 1000)


def read_tree(text):
    nodes = []
    stack = []
    for line in text.splitlines():
        match = TREE_LINE.fullmatch(line)
        if match is None:
            continue
        ms, indent, label = match.groups()
        levels = re.findall(r'\|  |  ', indent)
        assert ''.join(levels) == indent, line
        depth = len(levels)
        stack = stack[:depth]
        assert len(stack) == depth, (line, depth, stack)
        inclusive = milliseconds(ms)
        node = Node(inclusive, inclusive, tuple(parent.path[-1] for parent in stack) + (label,))
        if stack:
            stack[-1].exclusive -= inclusive
        nodes.append(node)
        stack.append(node)
    assert nodes[0].path == ("<Total>",), nodes[0].path
    assert all(n.exclusive >= 0 for n in nodes)
    assert sum(n.exclusive for n in nodes) == nodes[0].inclusive
    return nodes


def resolve_libc():
    libc_path = Path("/lib/x86_64-linux-gnu/libc.so.6").resolve()
    libc = ctypes.CDLL(str(libc_path))
    base = min(int(entry.split()[0].split("-")[0], 16) - int(entry.split()[2], 16)
               for entry in Path("/proc/self/maps").read_text().splitlines()
               if entry.endswith(" " + str(libc_path)))
    known = {}
    for name in ("memcpy", "memmove", "memset", "memcmp", "memchr", "memrchr", "rawmemchr"):
        address = ctypes.cast(getattr(libc, name), ctypes.c_void_p).value
        known[name] = address - base
    boundaries = (
        ("memcpy/memmove", known["memcpy"], known["memrchr"]),
        ("memset", known["memset"], known["rawmemchr"]),
    )
    assert known["memcpy"] == known["memmove"] and all(lo < hi for _, lo, hi in boundaries), known
    return boundaries, libc_path, known


def read_pcs(text, libc_ranges):
    bulk_memory = defaultdict(Counter)
    for line in text.splitlines():
        match = PC_LINE.fullmatch(line)
        if match is None:
            continue
        ms, address, name = match.groups()
        if " (<libc.so.6>)" not in name or not milliseconds(ms):
            continue
        cost = milliseconds(ms)
        for label, lo, hi in libc_ranges:
            if lo <= int(address, 16) < hi:
                bulk_memory[name][label] += cost
                break
    details = Counter()
    for counts in bulk_memory.values():
        details.update(counts)
    return {name: counts.total() for name, counts in bulk_memory.items()}, details


def symbol_stage(symbol):
    for label, _, fragment in ANCHORS:
        if fragment in symbol:
            return label.rstrip("*")
    if re.search(r"::TemporalPrelude>::run(?:::)?<", symbol):
        return "Motion/prediction"
    for label, pattern in FAMILIES:
        if pattern.search(symbol):
            return label
    return None


def stage_for_path(path):
    name = path[-1]
    if MEMORY.search(name):
        return "Memory/allocator functions"
    for index, current in reversed(list(enumerate(path))):
        if index != len(path) - 1 and any(
            label.endswith("*") and fragment in current for label, _, fragment in ANCHORS
        ):
            continue
        if stage := symbol_stage(current):
            return stage
    return "Uncategorized/shared"


def nearest_matching_group(path, groups):
    for symbol in reversed(path):
        for label, pattern in groups:
            if pattern.search(symbol):
                return label
    return None


def summarize(tree, functions, pcs, libc_ranges):
    nodes = read_tree(tree)
    profile = Counter()
    leaves = Counter()
    for line in functions.splitlines():
        if match := FUNCTION_LINE.fullmatch(line):
            profile[match[2]] += milliseconds(match[1])
    assert profile.pop("<Total>") == nodes[0].inclusive
    assert profile.total() == nodes[0].inclusive, (profile.total(), nodes[0].inclusive)

    confirmed_memory, libc_bulk = read_pcs(pcs, libc_ranges)
    stages = Counter()
    focuses = Counter()
    filters = Counter()
    libc_leaves = Counter()
    for node in nodes:
        if not node.exclusive:
            continue
        name = node.path[-1]
        leaves[name] += node.exclusive
        if name.startswith("<static>@") and " (<libc.so.6>)" in name:
            libc_leaves[name] += node.exclusive
        else:
            stage = stage_for_path(node.path)
            stages[stage] += node.exclusive
            if stage == "Filters":
                group = nearest_matching_group(node.path, FILTERS) or "Filter staging/shared"
                filters[group] += node.exclusive
        if focus := nearest_matching_group(node.path, FOCUSES):
            focuses[focus] += node.exclusive
    for name, cost in libc_leaves.items():
        confirmed = confirmed_memory.get(name, 0)
        assert confirmed <= cost, (name, cost, confirmed)
        stages["Memory/allocator functions"] += confirmed
        stages["Uncategorized/shared"] += cost - confirmed
    assert stages.total() == nodes[0].inclusive
    assert leaves == profile, (leaves - profile, profile - leaves)
    assert filters.total() == stages["Filters"]
    return stages, focuses, leaves, libc_bulk, filters


def report_unprofiled():
    with (HERE / "native-unprofiled.tsv").open() as file:
        times = {
            (int(row["pair"]), row["build"]): (float(row["elapsed_s"]), float(row["cpu_s"]))
            for row in csv.DictReader(file, delimiter="\t")
        }
    print("## Unprofiled comparison with exact shipped binary\n")
    print("| Metric | Build | Median elapsed or CPU s | Median paired change | Paired range |")
    print("|---|---|---:|---:|---:|")
    for index, metric in enumerate(("Elapsed", "CPU")):
        exact = [times[pair, "shipped-exact"][index] for pair in range(1, 4)]
        for label in ("shipped-exact", "shipped-symbols", "portable"):
            samples = [times[pair, label][index] for pair in range(1, 4)]
            changes = [(a / b - 1) * 100 for a, b in zip(samples, exact)]
            print(f"| {metric} | {label} | {median(samples):.3f} | "
                  f"{median(changes):+.2f}% | {min(changes):+.2f}% to {max(changes):+.2f}% |")


def report():
    print("# Noise Ocean native CPU profiles\n")
    print("Gprofng sampled native CPU time every millisecond. Each capture decoded the full "
          "130-frame input with one worker, frame delay one, and null output on CPU 3. "
          "A separate decode produced the same 130 frame hashes on all three binaries.")
    print()
    print("The symbolized reference is a Rust 1.100.0 rebuild of shipped `10279846` "
          "using its x86-64-v3 Cargo configuration and `CARGO_PROFILE_RELEASE_STRIP=none`. "
          "Its .text is 272 bytes larger and has a different SHA-256. The five matched "
          "hotspots have identical instruction shapes after normalizing addresses. "
          "See `verification.tsv` and `shipped-anchor-shapes.txt`.")
    print()
    print("Stage attribution assigns each exclusive CPU sample once using the closest "
          "eligible stack symbol and the stage anchors from the instruction-count analysis. "
          "The memory bucket also includes sampled libc PCs verified against runtime "
          "memcpy, memmove and memset entry-point ranges. The detailed kernel and libc "
          "tables describe subsets of these samples.")
    print()
    report_unprofiled()
    print()
    ranges, libc, symbols = resolve_libc()
    print("libc SHA-256", hashlib.sha256(libc.read_bytes()).hexdigest())
    print("Runtime libc IFUNC offsets:", " ".join(f"{name}={address:#x}" for name, address in symbols.items()))
    profiles = {}
    captured_pairs = sorted(
        int(path.stem.rsplit("-", 1)[1])
        for path in HERE.glob("shipped-symbols-*.overview")
        if (HERE / path.name.replace("shipped-symbols-", "portable-")).exists()
    )
    accepted_pairs = [pair for pair in captured_pairs if pair != 2]
    for label in ("shipped-symbols", "portable"):
        for pair in captured_pairs:
            stem = HERE / f"{label}-{pair}"
            profiles[label, pair] = summarize(
                *(stem.with_suffix(f".{suffix}").read_text() for suffix in ("tree", "functions", "pcs")),
                ranges,
            )
    print("\n| Pair | Shipped CPU ms | Portable CPU ms | Change | Included in attribution |")
    print("|---|---:|---:|---:|---|")
    increases = []
    for pair in captured_pairs:
        old, new = (profiles[label, pair][0].total() for label in ("shipped-symbols", "portable"))
        rate = (new / old - 1) * 100
        included = pair in accepted_pairs
        if included:
            increases.append(rate)
        print(f"| {pair} | {old} | {new} | {rate:+.2f}% | {'Yes' if included else 'No'} |")
    print(f"\nMedian paired sampled CPU change across included pairs {median(increases):+.2f}%.")
    print("Pair 2 is excluded because its shipped capture took 15.97 s wall time "
          "and placed 4.624 s of sampled time on two individual PCs. Raw files are retained.")

    differences = [
        profiles["portable", pair][0].total() - profiles["shipped-symbols", pair][0].total()
        for pair in accepted_pairs
    ]
    motion_filter = [
        sum(profiles["portable", pair][0][key] - profiles["shipped-symbols", pair][0][key]
            for key in ("Motion/prediction", "Filters"))
        for pair in accepted_pairs
    ]
    print(f"\nThe mean sampled CPU gap was {mean(differences):.1f} ms. Motion/prediction "
          f"and filters accounted for {mean(motion_filter):.1f} ms "
          f"({sum(motion_filter) / sum(differences):.1%}). "
          "The historical +24.32% measurement used elapsed time on CPU 4.")

    for index, heading, labels in (
        (0, "Exclusive broad stages", STAGES),
        (4, "Filter subgroups", [item[0] for item in FILTERS] + ["Filter staging/shared"]),
        (1, "Selected stack-attributed kernels", [item[0] for item in FOCUSES]),
        (3, "Libc bulk memory PCs (subset of the profiles)", ["memcpy/memmove", "memset"]),
    ):
        rows = []
        for key in labels:
            old, new = ([profiles[label, pair][index][key] for pair in accepted_pairs]
                        for label in ("shipped-symbols", "portable"))
            deltas = [b - a for a, b in zip(old, new)]
            rows.append((mean(deltas), key, mean(old), mean(new), min(deltas), max(deltas)))
        print(f"\n## {heading}\n")
        print("| Stage | Shipped mean CPU ms | Portable mean CPU ms | Mean excess ms | Pair excess range ms |")
        print("|---|---:|---:|---:|---:|")
        for difference, label, old, new, lo, hi in sorted(rows, reverse=True):
            print(f"| {label} | {old:.1f} | {new:.1f} | {difference:+.1f} | {lo:+d} to {hi:+d} |")

    for label in ("shipped-symbols", "portable"):
        totals = Counter()
        for pair in accepted_pairs:
            totals.update(profiles[label, pair][2])
        print(f"\n## {label} top exclusive symbols\n")
        for name, samples in totals.most_common(20):
            print(f"{samples / len(accepted_pairs):7.1f} ms  {name}")


if __name__ == "__main__":
    report()
