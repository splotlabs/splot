"""Collect paired native Noise Ocean clock profiles. Run under the shared build lock."""

import hashlib
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
INPUT = ROOT / "ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf"
BINARIES = {
    "shipped-exact": ROOT / "shipped/target/release/splot",
    "shipped-symbols": HERE / "ref-target/release/splot",
    "portable": ROOT / "callback/target/release/splot",
}
DECODE = ["decode", INPUT, "--threads", "1", "--frame-delay", "1"]


def text_section(binary):
    listing = subprocess.check_output(["objdump", "-h", binary], text=True)
    fields, = [row.split() for row in listing.splitlines() if re.match(r"\s+\d+\s+\.text\s", row)]
    size = int(fields[2], 16)
    with binary.open("rb") as file:
        file.seek(int(fields[5], 16))
        section = file.read(size)
    assert len(section) == size
    return size, hashlib.sha256(section).hexdigest()


def verify_binaries():
    with (HERE / "verification.tsv").open("x") as evidence:
        print("build", "text_bytes", "text_sha256", "displayed_frames", "output_sha256", sep="\t", file=evidence)
        sections = {}
        hashes = {}
        for name, binary in BINARIES.items():
            sections[name] = text_section(binary)
            with (HERE / f"{name}.hash").open("xb") as output, (HERE / f"{name}.hash.log").open("xb") as log:
                subprocess.run([binary, *DECODE, "--output-format", "hash", "-o", "-"], check=True, stdout=output, stderr=log)
            hashes[name] = (HERE / f"{name}.hash").read_bytes()
            frame_count = sum(line.startswith(b"frame.output_index: ")
                              for line in hashes[name].splitlines())
            assert frame_count == 130, (name, frame_count)
            print(name, *sections[name], frame_count,
                  hashlib.sha256(hashes[name]).hexdigest(), sep="\t", file=evidence, flush=True)
        if len(set(hashes.values())) != 1:
            raise RuntimeError("The three binaries generated different frame hash output")
        print("identical shipped and symbolized .text:",
              sections["shipped-symbols"] == sections["shipped-exact"], file=evidence)


def timed_rounds():
    sequence = tuple(BINARIES)
    with (HERE / "native-unprofiled.tsv").open("x") as file:
        print("pair", "position", "build", "elapsed_s", "cpu_s", sep="\t", file=file)
        for pair in range(1, 4):
            order = sequence if pair % 2 else sequence[::-1]
            for position, label in enumerate(order, 1):
                start_cpu = os.times()
                start = time.perf_counter()
                subprocess.run([BINARIES[label], *DECODE, "--output-format", "null"],
                               check=True, stdout=subprocess.DEVNULL)
                elapsed = time.perf_counter() - start
                end = os.times()
                cpu = (end.children_user - start_cpu.children_user +
                       end.children_system - start_cpu.children_system)
                print(pair, position, label, f"{elapsed:.6f}", f"{cpu:.3f}",
                      sep="\t", file=file, flush=True)


def collect_profiles(pairs=range(1, 4)):
    sequence = ("shipped-symbols", "portable")
    for pair in pairs:
        order = sequence if pair % 2 else sequence[::-1]
        for label in order:
            prefix = HERE / f"{label}-{pair}"
            experiment = prefix.with_suffix(".er")
            with prefix.with_suffix(".log").open("xb") as log:
                subprocess.run([
                    "/usr/bin/gprofng", "collect", "app", "-p", "1", "-h", "off", "-s", "off",
                    "-H", "off", "-j", "off", "-F", "off", "-o", experiment,
                    BINARIES[label], *DECODE, "--output-format", "null",
                ], check=True, stdout=log, stderr=subprocess.STDOUT)
            for tail, options in (
                (".functions", ["-metrics", "e.totalcpu:i.totalcpu:name", "-limit", "0", "-functions"]),
                (".tree", ["-limit", "0", "-calltree"]),
                (".pcs", ["-metrics", "e.totalcpu:address:name", "-limit", "0", "-pcs"]),
                (".overview", ["-overview", "-statistics"]),
            ):
                with prefix.with_suffix(tail).open("xb") as output:
                    subprocess.run(["/usr/bin/gprofng", "display", "text", *options, experiment],
                                   check=True, stdout=output)


if __name__ == "__main__":
    assert os.sched_getaffinity(0) == {3}, "Run pinned to CPU 3"
    verify_binaries()
    timed_rounds()
    collect_profiles()
