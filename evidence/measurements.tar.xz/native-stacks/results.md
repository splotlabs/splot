# Noise Ocean native CPU profiles

Gprofng sampled native CPU time every millisecond. Each capture decoded the full 130-frame input with one worker, frame delay one, and null output on CPU 3. A separate decode produced the same 130 frame hashes on all three binaries.

The symbolized reference is a Rust 1.100.0 rebuild of shipped `10279846` using its x86-64-v3 Cargo configuration and `CARGO_PROFILE_RELEASE_STRIP=none`. Its .text is 272 bytes larger and has a different SHA-256. The five matched hotspots have identical instruction shapes after normalizing addresses. See `verification.tsv` and `shipped-anchor-shapes.txt`.

Stage attribution assigns each exclusive CPU sample once using the closest eligible stack symbol and the stage anchors from the instruction-count analysis. The memory bucket also includes sampled libc PCs verified against runtime memcpy, memmove and memset entry-point ranges. The detailed kernel and libc tables describe subsets of these samples.

## Unprofiled comparison with exact shipped binary

| Metric | Build | Median elapsed or CPU s | Median paired change | Paired range |
|---|---|---:|---:|---:|
| Elapsed | shipped-exact | 0.780 | +0.00% | +0.00% to +0.00% |
| Elapsed | shipped-symbols | 0.775 | +1.70% | -2.73% to +4.41% |
| Elapsed | portable | 1.053 | +37.25% | +27.84% to +38.13% |
| CPU | shipped-exact | 0.770 | +0.00% | +0.00% to +0.00% |
| CPU | shipped-symbols | 0.760 | -1.30% | -3.80% to +6.49% |
| CPU | portable | 1.060 | +37.66% | +27.85% to +38.96% |

libc SHA-256 9941dc28e68bc5fd788d9cd024c69e68c791d63799e7538a97b6040dd9f50fb6
Runtime libc IFUNC offsets: memcpy=0x197a40 memmove=0x197a40 memset=0x198440 memcmp=0x1972e0 memchr=0x197040 memrchr=0x198140 rawmemchr=0x1985e0

| Pair | Shipped CPU ms | Portable CPU ms | Change | Included in attribution |
|---|---:|---:|---:|---|
| 1 | 1072 | 1285 | +19.87% | Yes |
| 2 | 6441 | 1291 | -79.96% | No |
| 3 | 1076 | 1285 | +19.42% | Yes |
| 4 | 810 | 1118 | +38.02% | Yes |

Median paired sampled CPU change across included pairs +19.87%.
Pair 2 is excluded because its shipped capture took 15.97 s wall time and placed 4.624 s of sampled time on two individual PCs. Raw files are retained.

The mean sampled CPU gap was 243.3 ms. Motion/prediction and filters accounted for 230.0 ms (94.5%). The historical +24.32% measurement used elapsed time on CPU 4.

## Exclusive broad stages

| Stage | Shipped mean CPU ms | Portable mean CPU ms | Mean excess ms | Pair excess range ms |
|---|---:|---:|---:|---:|
| Motion/prediction | 379.7 | 497.0 | +117.3 | +89 to +155 |
| Filters | 441.7 | 554.3 | +112.7 | +98 to +124 |
| Entropy/parser | 47.0 | 64.0 | +17.0 | +9 to +23 |
| Transforms/residual math | 22.7 | 25.3 | +2.7 | -2 to +6 |
| Output/scheduling/frame setup | 18.0 | 17.0 | -1.0 | -8 to +10 |
| Uncategorized/shared | 12.0 | 9.3 | -2.7 | -6 to +3 |
| Memory/allocator functions | 65.0 | 62.3 | -2.7 | -15 to +16 |

## Filter subgroups

| Stage | Shipped mean CPU ms | Portable mean CPU ms | Mean excess ms | Pair excess range ms |
|---|---:|---:|---:|---:|
| CDEF | 198.0 | 285.3 | +87.3 | +67 to +109 |
| Restoration/classification | 117.3 | 138.3 | +21.0 | +15 to +29 |
| GDF | 77.7 | 83.3 | +5.7 | +3 to +10 |
| Filter staging/shared | 16.7 | 16.7 | +0.0 | -4 to +6 |
| CCSO | 0.0 | 0.0 | +0.0 | +0 to +0 |
| Deblock | 32.0 | 30.7 | -1.3 | -8 to +3 |

## Selected stack-attributed kernels

| Stage | Shipped mean CPU ms | Portable mean CPU ms | Mean excess ms | Pair excess range ms |
|---|---:|---:|---:|---:|
| TIP motion-field units | 19.7 | 95.0 | +75.3 | +67 to +90 |
| Temporal motion-field projection | 104.0 | 144.0 | +40.0 | +34 to +47 |
| CDEF segment filter | 112.3 | 143.7 | +31.3 | +19 to +38 |
| Luma Wiener filter | 66.0 | 73.7 | +7.7 | -1 to +18 |
| Coefficient high-frequency pass | 18.3 | 25.3 | +7.0 | -2 to +13 |
| CDEF packed chroma gather | 17.0 | 22.7 | +5.7 | -6 to +18 |

## Libc bulk memory PCs (subset of the profiles)

| Stage | Shipped mean CPU ms | Portable mean CPU ms | Mean excess ms | Pair excess range ms |
|---|---:|---:|---:|---:|
| memset | 19.3 | 17.7 | -1.7 | -7 to +3 |
| memcpy/memmove | 43.0 | 41.3 | -1.7 | -10 to +15 |

## shipped-symbols top exclusive symbols

   86.3 ms  <splot_decode::prediction::inter::find_mv_stack::temporal::scan::ChunkWalk>::project_tracked::<true>
   71.7 ms  splot_recon::cdef_filter::segment::cdef_filter_segment_with::<splot_core::simd::Avx2Backend, u8>
   66.7 ms  <static>@0x197030 (<libc.so.6>)
   60.0 ms  splot_recon::wienerns_filter::wiener_ns_filter_luma_block_padded_layout_into::<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8>
   26.3 ms  splot_recon::subpel_mc::eight_bit::copy
   21.7 ms  splot_decode::prediction::inter::find_mv_stack::temporal::scan::chunk_lanes::<fearless_simd::generated::avx2::Avx2, true>
   20.0 ms  splot_decode::filters::cdef::cdef_segment::<splot_core::simd::Avx2Backend, u8>
   20.0 ms  splot_recon::pc_wiener::classify_grid_from_cache::<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, splot_recon::pc_wiener::classify_grid_padded_mapped_into<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, splot_recon::pc_wiener::classify_grid_padded_classes_with_backend<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, <splot_decode::filters::wienerns_lr::recon::StripeChain>::luma_lr_cell_subclasses<splot_core::simd::Avx2Backend, u8>::{closure#7}::{closure#0}>::{closure#1}, u8>::{closure#0}, splot_recon::pc_wiener::classify_grid_padded_classes_with_backend<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, <splot_decode::filters::wienerns_lr::recon::StripeChain>::luma_lr_cell_subclasses<splot_core::simd::Avx2Backend, u8>::{closure#7}::{closure#0}>::{closure#1}, u8>::{closure#5}
   19.7 ms  splot_decode::prediction::inter::find_mv_stack::temporal::tip_field::prepare_tip_units::<fearless_simd::generated::avx2::Avx2, 1, 1>
   19.7 ms  splot_decode::filters::gdf::simd::inlane::row_index::<splot_decode::filters::gdf::simd::TiledWindow, 0, false, true>
   19.7 ms  <splot_recon::cdef_filter::segment::TypedSegment<splot_core::simd::Avx2Backend> as splot_recon::cdef_filter::segment::SegmentSimd>::gather::<[[u16; 2]; 4], splot_recon::cdef_filter::segment::luma_bytes::LumaBytesGather>
   18.7 ms  splot_decode::filters::gdf::simd::inlane::row_index::<splot_decode::filters::gdf::simd::TiledWindow, 1, false, true>
   18.3 ms  <splot_decode::bitstream::tile_payload::coeff_loop::transform_block::LevelPass>::hf_pass::<0, true, true, false>
   17.7 ms  <splot_decode::prediction::inter::find_mv_stack::temporal::scan::ChunkWalk>::project_tracked::<false>
   17.3 ms  splot_decode::filters::gdf::simd::filter_run::<splot_core::simd::Avx2Backend, u8>
   17.0 ms  <splot_recon::cdef_filter::segment::CdefPairSegment>::gather_with_mode::<splot_recon::cdef_filter::segment::TypedSegment<splot_core::simd::Avx2Backend>, u8, true>
   14.7 ms  splot_decode::prediction::inter::mc::compound_mask::blend_plane::<splot_core::simd::Avx2Backend, u8>
   14.3 ms  <splot_decode::filters::wienerns_lr::recon::StripeChain>::apply_lr_stripe::<splot_core::simd::Avx2Backend, u8>
   13.7 ms  splot_recon::subpel_mc::eight_bit::avx2::strip_block::<0, 0, splot_recon::subpel_mc::rows::Prep<i16>>
   12.0 ms  splot_recon::pc_wiener::classify_grid_from_cache::<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, splot_recon::pc_wiener::classify_grid_padded_mapped_into<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, splot_recon::pc_wiener::classify_grid_padded_classes_with_backend<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, <splot_decode::filters::wienerns_lr::recon::StripeChain>::luma_lr_cell_subclasses<splot_core::simd::Avx2Backend, u8>::{closure#7}::{closure#0}>::{closure#1}, u8>::{closure#0}, splot_recon::pc_wiener::classify_grid_padded_classes_with_backend<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, <splot_decode::filters::wienerns_lr::recon::StripeChain>::luma_lr_cell_subclasses<splot_core::simd::Avx2Backend, u8>::{closure#7}::{closure#0}>::{closure#1}, u8>

## portable top exclusive symbols

   80.7 ms  <splot_decode::prediction::inter::find_mv_stack::temporal::scan::ChunkWalk>::project_tracked::<true>
   67.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_recon::cdef_filter::segment::cdef_filter_segment_with<splot_core::simd::Avx2Backend, u8>::{closure#0}, bool>
   60.3 ms  <static>@0x197030 (<libc.so.6>)
   52.3 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::prediction::inter::find_mv_stack::temporal::tip_field::prepare_tip_units<fearless_simd::generated::avx2::Avx2, 1, 1>::{closure#0}, core::result::Result<(), splot_decode::error::DecodeError>>
   42.0 ms  splot_recon::wienerns_filter::eight_bit::avx2::filter_row::__fearless_simd_kernel
   28.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::filters::gdf::simd::filter_run<splot_core::simd::Avx2Backend, u8>::{closure#0}, core::option::Option<()>>
   27.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::prediction::inter::find_mv_stack::temporal::scan::project_temporal_motion_field<splot_core::simd::Avx2Backend, splot_decode::prediction::inter::find_mv_stack::temporal::TemporalMotionField>::{closure#2}, ()>
   26.0 ms  splot_recon::subpel_mc::eight_bit::copy
   25.0 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<<splot_decode::bitstream::tile_payload::coeff_loop::transform_block::LevelPass<splot_core::simd::Avx2Backend>>::hf_pass<0, true, true, false>::{closure#0}, ()>
   23.0 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::filters::gdf::simd::inlane::row_index<splot_decode::filters::gdf::simd::TiledWindow, 0, false, true>::{closure#0}, [u16; 16]>
   22.3 ms  splot_recon::wienerns_filter::wiener_ns_filter_luma_block_padded_layout_into::<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8>
   21.7 ms  <splot_decode::prediction::inter::find_mv_stack::temporal::scan::ChunkWalk>::project_tracked::<false>
   19.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend> as splot_recon::lr_madd::LrBackend>::run<(), splot_recon::pc_wiener::PooledLanesOp<u8, 34>>::{closure#0}, ()>
   19.0 ms  splot_decode::filters::cdef::cdef_segment::<splot_core::simd::Avx2Backend, u8>
   17.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<<splot_recon::cdef_filter::segment::TypedSegment<splot_core::simd::Avx2Backend> as splot_recon::cdef_filter::segment::SegmentSimd>::gather<[[u16; 2]; 4], splot_recon::cdef_filter::segment::luma_bytes::LumaBytesGather>::{closure#0}, core::option::Option<[[u16; 2]; 4]>>
   16.3 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::split_i32x8::kernel::__fearless_simd_kernel
   16.3 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::add_i32x8::kernel::__fearless_simd_kernel
   15.3 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_recon::cdef_filter::segment::byte_filter::cdef_filter_rows_wide8<fearless_simd::generated::avx2::Avx2, splot_recon::cdef_filter::segment::InLane, u8, 16, 4, 4, 64, 319, 2, true, false>::{closure#0}, core::option::Option<()>>
   14.3 ms  splot_recon::subpel_mc::eight_bit::avx2::strip_block::<0, 0, splot_recon::subpel_mc::rows::Prep<i16>>
   14.3 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<<splot_recon::cdef_filter::segment::TypedSegment<splot_core::simd::Avx2Backend> as splot_recon::cdef_filter::segment::SegmentSimd>::gather<[u16; 4], splot_recon::cdef_filter::segment::PairGather<u8, true>>::{closure#0}, core::option::Option<[u16; 4]>>
