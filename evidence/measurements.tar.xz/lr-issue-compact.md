## Shared luma Wiener restoration experiment

**Rollout decision: keep the standalone restoration crates and compiler wrapper on the experiment branch.** Ordinary Cargo successfully reaches the concrete kernel in a downstream application. Its 600-frame RitualDance elapsed median improved by 0.49% against control, with a 95% paired interval spanning −1.13% to +10.32%. The extra compiler flags saved another 0.084% of whole-application instructions and the full-stream unit-vs-plain interval also includes zero. The ordinary release CLI was faster in the short RitualDance prefix (−8.89%, interval −17.72% to −0.17%), but remained slower than shipped on that prefix and the downstream full stream did not establish a repeatable improvement. That evidence does not justify two extra crates or a wrapper in the release. [Measured source](https://github.com/splotlabs/splot/commit/9b8a8b639dae69a3fd6a4ea04b3b5acddbf0a969) · [Signed lint-only follow-up](https://github.com/splotlabs/splot/commit/deba2c412167159ad56a767bbe463ad37c50b5ef).

The measured control is `07cdddce`. The experiment uses `9b8a8b63` on `experiment/simd-1934-lr-module`. The decoder hands the startup-selected AVX2 token, borrowed 10-bit rows, class weights, and output slice to one concrete luma Wiener run. PC-Wiener and luma retain their respective taps. The traversal and the AVX2 tap arithmetic are shared with existing code. SSE2 and NEON retain their own entries. The tested restoration scope is the 10-bit luma Wiener run, previously called 46,794 times in the 16-frame RitualDance control.

**Control** is the previous in-tree implementation. **Ordinary Cargo** builds the extracted code through normal path dependencies. **AVX2 unit flags** builds the same source with the optional experiment wrapper applying the Fearless SIMD 1.2.0 feature contract only to `splot_lr_avx2`. The main decoder and other crates build at baseline. The external program has no checkout Cargo configuration or custom release profile. Its release settings differ from the workspace CLI, so comparisons are paired within each program.

### External decoder playback

Twelve paired rounds per input, one pinned worker, frame delay one, null output, after warmup. Each of the six three-build launch orders appears twice. Changes are paired median elapsed time with 95% paired bootstrap intervals. Negative elapsed changes are faster.

```text
RitualDance 16 plain/control: -1.64% [-3.88, +0.62]
RitualDance 16 unit/plain: +0.82% [-1.39, +1.74]
RitualDance 16 unit/control: -1.08% [-3.89, +0.75]
RitualDance 600 plain/control: -0.49% [-1.13, +10.32]
RitualDance 600 unit/plain: -0.39% [-2.67, +0.60]
RitualDance 600 unit/control: -1.09% [-2.49, +5.58]
TunnelFlag 40 plain/control: +0.06% [-1.11, +4.72]
TunnelFlag 40 unit/plain: -1.49% [-4.93, -0.24]
TunnelFlag 40 unit/control: -0.26% [-1.92, +2.02]
```

### Linked release CLI playback

Four builds, 12 balanced rounds, one worker and null output. WITCHER3 and TunnelFlag use 40 frames. RitualDance and Noise_Ocean use 16. Shipped v3 is `10279846`.

| Input | Ordinary vs separately compiled unit | Ordinary vs control | Ordinary vs shipped v3 |
|---|---:|---:|---:|
| WITCHER3 | +3.44% [-2.80, +15.86] | +5.63% [-5.41, +11.51] | +13.48% [+2.63, +16.09] |
| TunnelFlag | +2.62% [-28.99, +16.62] | -5.37% [-24.63, +3.61] | +10.69% [-15.07, +16.60] |
| RitualDance | -6.15% [-8.69, +2.10] | -8.89% [-17.72, -0.17] | +9.90% [+3.40, +19.38] |
| Noise_Ocean | +1.15% [-3.78, +11.37] | +2.35% [-4.10, +12.93] | +29.04% [+24.90, +44.70] |

### Kernel and instruction measurements

The separate plain-Cargo kernel driver measured the same 64 input cases under both compiler settings. Median timings were plain 374.15 ns/run, unit 382.10 ns/run.

```text
luma runs unit/plain: -3.01% [-5.60, +6.70]
```

Callgrind guest instructions on the same 16 displayed RitualDance frames.

| Program | Control | Ordinary Cargo | AVX2 unit flags | Ordinary vs control | Unit vs ordinary |
|---|---:|---:|---:|---:|---:|
| External consumer | 5,941,939,319 | 5,927,148,604 | 5,922,192,122 | -0.249% | -0.084% |
| Release CLI | 5,331,986,361 | 5,312,934,008 | 5,307,982,422 | -0.357% | -0.093% |

| Stripped release artifact | Control | Ordinary Cargo | AVX2 unit flags |
|---|---:|---:|---:|
| splot | 16,869,232 | 16,865,088 | 16,864,560 |
| libsplot_capi.so | 13,159,816 | 13,156,024 | 13,155,992 |

The external application called the concrete luma run 46,794 times in the 16-frame trace. The in-tree control spent 191,465,491 guest instructions inside that call edge. The plain Cargo prototype spent 175,852,024 (8.15% fewer). Both ran the same 46,794 calls. The linked ordinary-Cargo AVX2 body in the external application contained 644 instructions, including 116 vector mnemonics and no CPUID. The explicitly compiled unit reduced the linked body to 573 instructions and 2,933 bytes and used 170,900,392 guest instructions across the same 46,794 calls. These instruction counts describe that function and do not measure application wall time.

### Hardware and source revisions

The native Intel Xeon 6975P-C passed all 63 full-stream comparisons on the measured prototype (21 Auto selecting AVX2, 21 forced AVX2 and 21 forced AVX-512) and four backend lifecycle tests. The first hosted VM lacked the required AVX-512 features and the hardware precondition rejected it. [Native run, attempt 2](https://github.com/splotlabs/splot/actions/runs/45634575719/attempts/2). Apple ARM64 cross-compilation passed for the reconstruction crate and its test targets. Native M2 Max first-picture timing remains tracked in [#1993](https://github.com/splotlabs/splot/issues/1993). The follow-up `deba2c41` removes an unused Clippy expectation while retaining the inlining attribute. Native all-target checks, Apple ARM64 cross-checks, and Clippy with `-D warnings` passed for the checked crates. The two prototype builds use identical kernel arithmetic.

### Correctness and reproducibility

Both variants matched the independent 64-case scalar oracle for signed tap weights, rounding, clipping, uniform and mixed classes, padded strides, partial multiples of 16, 1–8 rows and untouched output guards. Each external decoder matched the AVM raw hashes for all seven complete streams on native AVX2, and all four 8/10-bit Wiener and PC-Wiener fixtures on native AVX2 and strict emulated SSE2. Each release CLI matched 21/21 full AVM hashes across 1, 7 and 12 workers. Each CLI and C shared library matched 40/40 strict SSE2 comparisons.

Build a standalone Rust consumer with path dependencies on `splot-core` and `splot-decode` using `cargo build --release`. The standalone kernel driver is in `tests/downstream/restoration-module.rs`. The alternate comparison uses `RUSTC_WRAPPER=/absolute/path/to/scripts/rustc-lr-prototype.py` and a fresh target directory. Build the release CLI and C library with `CARGO_PROFILE_RELEASE_STRIP=none cargo build --release --locked -p splot-cli -p splot-capi`; strip the linked artifacts for size comparison. CPU 4 on i7-12700H, Linux x86-64, Rust 1.100.0, LLVM 23.1.5. Compilers and timed processes were serialized.

<details><summary>Reproduce the external Rust consumer</summary>

With the prototype checkout and consumer directory as siblings, adjust the dependency paths in this manifest. The control used the same program with its two paths pointing at its own checkout.

```toml
[package]
name = "lr-consumer"
version = "0.0.0"
edition = "2024"
publish = false

[dependencies]
splot-core = { path = "../../splot-1934-lr-module/crates/splot-core" }
splot-decode = { path = "../../splot-1934-lr-module/crates/splot-decode" }
```

```rust
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// SPDX-FileCopyrightText: 2026 Bartosz Tomczyk <bartekplus@gmail.com>

use std::io::Write;

use splot_core::stream_reader::{StreamUnit, TemporalUnitReader};
use splot_decode::{
    DataProps, DecodeError, Decoder, DecoderSettings, FrameDelay, PictureSamples, PlaneId,
    SendStatus, SimdPolicy, ThreadCount,
};

fn assert_unsupported(settings: DecoderSettings, policy: SimdPolicy) {
    let error = Decoder::new(settings.with_simd_policy(policy)).unwrap_err();
    assert!(
        matches!(error, DecodeError::UnsupportedBackend { source } if source.requested() == policy),
        "{policy}: {error}"
    );
}

fn write_ready_pictures(
    decoder: &mut Decoder,
    output: &mut impl Write,
    raw: bool,
    pictures: &mut usize,
    limit: usize,
) {
    while let Some(picture) = decoder.get_picture().unwrap() {
        *pictures += 1;
        if *pictures > limit {
            return;
        }
        if !raw {
            std::hint::black_box(&picture);
            continue;
        }
        for plane in [PlaneId::Y, PlaneId::U, PlaneId::V] {
            match picture.plane(plane).unwrap() {
                PictureSamples::Eight(plane) => {
                    for row in plane.visible_rows() {
                        output.write_all(row).unwrap();
                    }
                }
                PictureSamples::Ten(plane) => {
                    for sample in plane.visible_rows().flatten() {
                        output.write_all(&sample.to_le_bytes()).unwrap();
                    }
                }
            }
        }
    }
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let [_, expected_backend, filename, mode, limit] = args.as_slice() else {
        panic!("expected backend, IVF filename, output mode and picture limit");
    };
    assert!(
        !cfg!(target_feature = "avx2"),
        "consumer requires default compiler flags"
    );
    assert_eq!(
        std::arch::is_x86_feature_detected!("avx2"),
        expected_backend == "avx2",
        "unexpected emulated CPU"
    );
    if expected_backend == "sse2" {
        assert!(!std::arch::is_x86_feature_detected!("sse3"));
    }

    let settings = DecoderSettings::default()
        .with_threads(ThreadCount::from(1))
        .with_frame_delay(FrameDelay::from(1usize));
    let raw = match mode.as_str() {
        "raw" => true,
        "null" => false,
        _ => panic!("unknown output mode"),
    };
    let limit: usize = limit.parse().unwrap();
    let mut pictures = 0;
    let mut decoder = Decoder::new(settings).unwrap();
    assert_eq!(decoder.selected_backend().as_str(), expected_backend);
    assert_unsupported(settings, SimdPolicy::Neon);
    assert_unsupported(settings, SimdPolicy::Avx512);
    if expected_backend == "sse2" {
        assert_unsupported(settings, SimdPolicy::Avx2);
    }

    let input = std::fs::read(filename).unwrap();
    let mut reader = TemporalUnitReader::new(input.as_slice());
    let mut output = std::io::BufWriter::new(std::io::stdout().lock());
    while let Some(unit) = reader.next_unit().unwrap() {
        let StreamUnit::IvfFrame { payload, .. } = unit else {
            panic!("expected IVF frame");
        };
        while decoder.send_data(payload, DataProps::default()).unwrap() == SendStatus::Full {
            write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);
            if pictures >= limit {
                break;
            }
        }
        write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);
        if pictures >= limit {
            break;
        }
    }
    if pictures < limit {
        decoder.drain();
        write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);
    }
    eprintln!("{} displayed pictures", pictures.min(limit));
    output.flush().unwrap();
}
```

The command line is `lr-consumer avx2 INPUT.ivf null FRAME_LIMIT`. The executable asserts the startup choice before it reads the input. For raw parity pass `raw 99999`.
</details>

