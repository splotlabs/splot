from pathlib import Path
import re
import subprocess
q=Path(__file__).resolve().parent
def count(p):
    return int(re.search(r'^summary: (\d+)',p.read_text(),re.M)[1])
streams=['DOTA2','RitualDance','Slides1','Noise_Ocean','old_town_cross']
totals=[0]*4
table=['| CI input | Earlier portable kernels | Before callback fix | Final portable kernels | Shipped v3 | New vs previous | New vs shipped |','|---|---:|---:|---:|---:|---:|---:|']
def row(label,cs):
    return '| '+label+' | '+' | '.join(f'{c:,}' for c in cs) + f' | {100*(cs[2]/cs[0]-1):+.2f}% | {100*(cs[2]/cs[3]-1):+.2f}% |'
for stream in streams:
    name=stream+'_qp135' if stream=='Noise_Ocean' else stream
    shipped=q/'shipped-Noise_Ocean_qp135.cg' if stream=='Noise_Ocean' else q/'shipped-matrix'/f'{stream}.cg'
    cs=[count(p) for p in (q/f'kernels-{stream}.cg',q/'native'/f'{stream}.cg',q/'callback'/f'{stream}.cg',shipped)]
    totals=[a+b for a,b in zip(totals,cs)]
    table.append(row(stream,cs))
table.append(row('All five',totals))
times=(q/'callback-four-way.txt').read_text()
wall=['| Workload | Final vs before callback fix | Final vs earlier scoped kernels | New vs shipped v3 |','|---|---:|---:|---:|']
for stream in ('WITCHER3','TunnelFlag','Noise','RitualDance'):
    cells=[]
    for base in ('native','kernels','shipped'):
        m=re.search(rf'^{stream} callback/{base} elapsed: (.*?), slower',times,re.M)
        cells.append(m[1])
    wall.append('| '+('Noise_Ocean' if stream=='Noise' else stream)+' | '+' | '.join(cells)+' |')
sizes=[]
for artifact in ('splot','libsplot_capi.so'):
    exe=q/'callback/target/release'/artifact
    path=q/'callback'/(artifact+'.stripped')
    subprocess.run(['strip','-o',path,exe],check=True)
    sizes.append(f'{artifact} {path.stat().st_size:,} bytes')
assert len((q/'callback/avm.txt').read_text().splitlines())==21
assert (q/'callback/sse2.txt').read_text().count('PASS ')==10
out=['## Ordinary Cargo follow-up on native AVX2','The one-implementation decoder at `07cdddce` builds on `d67efd2d`. It keeps 8-bit chroma range widening, 10-bit CDEF quad filtering and difference-weighted compound blending inside their SIMD target scopes. The intermediate `5b5167a1` still outlined the weighted pixel callback once per eight-lane block. On Noise_Ocean that meant 372,880 calls. The final revision inlines that callback. Both the CLI and C library were built with Rust 1.100.0 using `CARGO_PROFILE_RELEASE_STRIP=none cargo build --release --locked -j1 -p splot-cli -p splot-capi`. The release retains CPU-selected SIMD at runtime. The build uses ordinary Cargo without an ISA wrapper, added crates or checkout-wide target-CPU/AVX-512 switches. Feature areas include DECODE-MINIMAL-RAW-RUNTIME-OUTPUT and inter compound prediction.','### Native playback','Each result is the median paired elapsed-time change from 12 warm, counterbalanced four-build rounds on CPU 4, with a paired 95% bootstrap interval. WITCHER3 and TunnelFlag use 40 frames, Noise_Ocean and RitualDance use 16. All use one worker and null output. A positive percentage is slower.','\n'.join(wall),'''### Full stream elapsed time

Each complete stream was warmed up on all three binaries, followed by 12 balanced rounds on CPU 4 with one worker, one frame of delay and null output. `shipped` is `10279846` and `frozen` is the pre-epic reference `b337fafe`. The values are the paired median percentage, then the lower and upper 95% bootstrap limits.

```text
'''+(q/'callback-full.txt').read_text().strip()+'\n```','### Guest instructions','All four binaries decoded the same official CI prefixes on this host under Callgrind. These values use a different instruction counter from GitHub CI. The shipped reference is `10279846`.','\n'.join(table),'### Parity and size','All 21 full AVM raw output hashes on seven streams at 1, 7 and 12 workers matched. The CLI at 1, 3 and 8 workers and external C consumer matched the shipped output on all ten strict SSE2-emulated streams (40 comparisons). Stripped Linux x86-64 artifacts: '+', '.join(sizes)+'.','<details><summary>Raw playback timings</summary>\n\n```csv\n'+(q/'callback-four-way.csv').read_text().strip()+'\n```\n\n```csv\n'+(q/'callback-full.csv').read_text().strip()+'\n```\n</details>']
(q/'callback-issue.md').write_text('\n\n'.join(out)+'\n')
print('\n'.join(wall+['']+table+sizes))
