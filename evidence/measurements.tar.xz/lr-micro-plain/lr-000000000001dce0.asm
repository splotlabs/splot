
<WORKTREES>/qualification-1882/lr-micro-plain/target/release/lr-kernel-consumer:     file format elf64-x86-64


Disassembly of section .text:

000000000001dce0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run>:
   1dce0:	sub    $0x78,%rsp
   1dce4:	mov    0x80(%rsp),%rax
   1dcec:	mov    %rdx,0x10(%rsp)
   1dcf1:	mov    %rcx,0x18(%rsp)
   1dcf6:	mov    %r8,0x20(%rsp)
   1dcfb:	mov    %rdi,0x28(%rsp)
   1dd00:	mov    %rsi,0x30(%rsp)
   1dd05:	lea    0x10(%rsp),%rcx
   1dd0a:	mov    %rcx,0x38(%rsp)
   1dd0f:	lea    0x18(%rsp),%rcx
   1dd14:	mov    %rcx,0x40(%rsp)
   1dd19:	mov    %r9,0x48(%rsp)
   1dd1e:	movups (%rax),%xmm0
   1dd21:	movups %xmm0,0x50(%rsp)
   1dd26:	mov    0x10(%rax),%rax
   1dd2a:	mov    %rax,0x60(%rsp)
   1dd2f:	lea    0xf(%rsp),%rax
   1dd34:	mov    %rax,0x68(%rsp)
   1dd39:	lea    0x88(%rsp),%rax
   1dd41:	mov    %rax,0x70(%rsp)
   1dd46:	lea    0x28(%rsp),%rdi
   1dd4b:	call   1cfd0 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_>
   1dd50:	add    $0x78,%rsp
   1dd54:	ret
