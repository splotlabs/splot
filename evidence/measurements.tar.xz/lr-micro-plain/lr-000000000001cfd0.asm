
<WORKTREES>/qualification-1882/lr-micro-plain/target/release/lr-kernel-consumer:     file format elf64-x86-64


Disassembly of section .text:

000000000001cfd0 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_>:
   1cfd0:	push   %rbp
   1cfd1:	push   %r15
   1cfd3:	push   %r14
   1cfd5:	push   %r13
   1cfd7:	push   %r12
   1cfd9:	push   %rbx
   1cfda:	sub    $0x7b8,%rsp
   1cfe1:	mov    (%rdi),%rsi
   1cfe4:	mov    0x8(%rdi),%r10
   1cfe8:	mov    0x10(%rdi),%rax
   1cfec:	mov    (%rax),%r13
   1cfef:	mov    0x18(%rdi),%rax
   1cff3:	mov    (%rax),%r8
   1cff6:	mov    0x8(%rax),%rax
   1cffa:	mov    0x20(%rdi),%rcx
   1cffe:	vmovdqu (%rcx),%ymm0
   1d002:	xor    %ebp,%ebp
   1d004:	sub    %r8,%rax
   1d007:	cmovae %rax,%rbp
   1d00b:	vmovdqu %ymm0,0x2b0(%rsp)
   1d014:	mov    %rbp,%rcx
   1d017:	and    $0xfffffffffffffff0,%rcx
   1d01b:	sete   %dl
   1d01e:	test   %r13,%r13
   1d021:	sete   %al
   1d024:	or     %dl,%al
   1d026:	cmp    $0x8,%r13
   1d02a:	ja     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d02c:	test   %al,%al
   1d02e:	jne    1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d030:	mov    %rcx,%r9
   1d033:	xor    %eax,%eax
   1d035:	add    %r8,%r9
   1d038:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d03a:	test   %r10,%r10
   1d03d:	je     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d03f:	cmp    $0xfffffffffffffff7,%r9
   1d043:	ja     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d045:	add    $0x8,%r9
   1d049:	mov    %r9,%r14
   1d04c:	sub    %r8,%r14
   1d04f:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d051:	cmp    0x8(%rsi),%r9
   1d055:	ja     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d057:	lea    0x8(%r13),%r12
   1d05b:	cmp    %r12,%r10
   1d05e:	jae    1d077 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0xa7>
   1d060:	xor    %eax,%eax
   1d062:	add    $0x7b8,%rsp
   1d069:	pop    %rbx
   1d06a:	pop    %r12
   1d06c:	pop    %r13
   1d06e:	pop    %r14
   1d070:	pop    %r15
   1d072:	pop    %rbp
   1d073:	vzeroupper
   1d076:	ret
   1d077:	mov    0x28(%rdi),%rax
   1d07b:	mov    0x30(%rdi),%r11
   1d07f:	mov    0x38(%rdi),%rdx
   1d083:	mov    0x48(%rdi),%rdi
   1d087:	mov    %rdi,0x128(%rsp)
   1d08f:	mov    (%rsi),%rdi
   1d092:	lea    (%rdi,%r8,2),%rdi
   1d096:	mov    %rdi,0x10(%rsp)
   1d09b:	mov    %r14,0x18(%rsp)
   1d0a0:	mov    %rdi,0x20(%rsp)
   1d0a5:	mov    %r14,0x28(%rsp)
   1d0aa:	mov    %rdi,0x30(%rsp)
   1d0af:	mov    %r14,0x38(%rsp)
   1d0b4:	mov    %rdi,0x40(%rsp)
   1d0b9:	mov    %r14,0x48(%rsp)
   1d0be:	mov    %rdi,0x50(%rsp)
   1d0c3:	mov    %r14,0x58(%rsp)
   1d0c8:	mov    %rdi,0x60(%rsp)
   1d0cd:	mov    %r14,0x68(%rsp)
   1d0d2:	mov    %rdi,0x70(%rsp)
   1d0d7:	mov    %r14,0x78(%rsp)
   1d0dc:	mov    %rdi,0x80(%rsp)
   1d0e4:	mov    %r14,0x88(%rsp)
   1d0ec:	mov    %rdi,0x90(%rsp)
   1d0f4:	mov    %r14,0x98(%rsp)
   1d0fc:	mov    %rdi,0xa0(%rsp)
   1d104:	mov    %r14,0xa8(%rsp)
   1d10c:	mov    %rdi,0xb0(%rsp)
   1d114:	mov    %r14,0xb8(%rsp)
   1d11c:	mov    %rdi,0xc0(%rsp)
   1d124:	mov    %r14,0xc8(%rsp)
   1d12c:	mov    %rdi,0xd0(%rsp)
   1d134:	mov    %r14,0xd8(%rsp)
   1d13c:	mov    %rdi,0xe0(%rsp)
   1d144:	mov    %r14,0xe8(%rsp)
   1d14c:	mov    %rdi,0xf0(%rsp)
   1d154:	mov    %r14,0xf8(%rsp)
   1d15c:	mov    %rdi,0x120(%rsp)
   1d164:	mov    %rdi,0x100(%rsp)
   1d16c:	cmp    $0x10,%r10
   1d170:	mov    $0x10,%edi
   1d175:	cmovb  %r10,%rdi
   1d179:	mov    %r14,0x108(%rsp)
   1d181:	shl    $0x4,%edi
   1d184:	xor    %r10d,%r10d
   1d187:	lea    (%r8,%r8,1),%r15
   1d18b:	nopl   0x0(%rax,%rax,1)
   1d190:	cmp    %r10,%rdi
   1d193:	je     1d1bd <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x1ed>
   1d195:	cmp    0x8(%rsi,%r10,1),%r9
   1d19a:	ja     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d1a0:	dec    %r12
   1d1a3:	mov    (%rsi,%r10,1),%rbx
   1d1a7:	add    %r15,%rbx
   1d1aa:	mov    %rbx,0x10(%rsp,%r10,1)
   1d1af:	mov    %r14,0x18(%rsp,%r10,1)
   1d1b4:	add    $0x10,%r10
   1d1b8:	test   %r12,%r12
   1d1bb:	jne    1d190 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x1c0>
   1d1bd:	vbroadcasti128 -0x17236(%rip),%ymm0        # 5f90 <__abi_tag+0x5c94>
   1d1c6:	vmovdqu %ymm0,0x1b0(%rsp)
   1d1cf:	vmovdqu %ymm0,0x1d0(%rsp)
   1d1d8:	vmovdqu %ymm0,0x1f0(%rsp)
   1d1e1:	vmovdqu %ymm0,0x210(%rsp)
   1d1ea:	vmovdqu %ymm0,0x230(%rsp)
   1d1f3:	vmovdqu %ymm0,0x250(%rsp)
   1d1fc:	vmovdqu %ymm0,0x270(%rsp)
   1d205:	vmovdqu %ymm0,0x290(%rsp)
   1d20e:	mov    %r11,%rsi
   1d211:	sub    %r8,%rsi
   1d214:	cmp    %rcx,%rdx
   1d217:	jae    1d24f <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x27f>
   1d219:	cmp    %r8,%r11
   1d21c:	setb   %dl
   1d21f:	cmp    %rcx,%rsi
   1d222:	setb   %sil
   1d226:	or     %dl,%sil
   1d229:	jne    1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d22f:	lea    (%rax,%r8,2),%rax
   1d233:	mov    %rax,0x1b0(%rsp)
   1d23b:	mov    %rcx,0x1b8(%rsp)
   1d243:	cmp    $0x1,%r13
   1d247:	jne    1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d24d:	jmp    1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1d24f:	cmp    %r8,%r11
   1d252:	setb   %dil
   1d256:	cmp    %rcx,%rsi
   1d259:	setb   %r9b
   1d25d:	or     %dil,%r9b
   1d260:	jne    1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d266:	lea    (%rax,%r8,2),%rdi
   1d26a:	mov    %rdi,0x1b0(%rsp)
   1d272:	mov    %rcx,0x1b8(%rsp)
   1d27a:	cmp    $0x1,%r13
   1d27e:	jne    1d97a <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x9aa>
   1d284:	mov    0x2b0(%rsp),%rbx
   1d28c:	test   %rbx,%rbx
   1d28f:	jne    1d2bc <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2ec>
   1d291:	vpbroadcastq 0x2b8(%rsp),%ymm0
   1d29b:	vmovdqu %ymm0,0x330(%rsp)
   1d2a4:	lea    0x578(%rsp),%rdi
   1d2ac:	lea    0x330(%rsp),%rsi
   1d2b4:	vzeroupper
   1d2b7:	call   1de60 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
   1d2bc:	shr    $0x4,%rbp
   1d2c0:	mov    $0x1,%al
   1d2c2:	je     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d2c8:	lea    0x578(%rsp),%rax
   1d2d0:	xor    %r15d,%r15d
   1d2d3:	movq   $0x0,(%rsp)
   1d2db:	mov    %rbx,0x118(%rsp)
   1d2e3:	mov    %rax,0x8(%rsp)
   1d2e8:	test   %rbx,%rbx
   1d2eb:	je     1d335 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x365>
   1d2ed:	lea    0x2d0(%rsp),%rdi
   1d2f5:	lea    0x2b0(%rsp),%rsi
   1d2fd:	mov    (%rsp),%rdx
   1d301:	vzeroupper
   1d304:	call   1dd60 <_RNvMCs3HZP85FyIZE_15splot_lr_kernelNtB2_7Classes5group>
   1d309:	cmpq   $0x0,0x2d0(%rsp)
   1d312:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d318:	lea    0x330(%rsp),%r12
   1d320:	mov    %r12,%rdi
   1d323:	lea    0x2d0(%rsp),%rsi
   1d32b:	call   1de60 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
   1d330:	mov    %r12,0x8(%rsp)
   1d335:	mov    %r14,%rcx
   1d338:	sub    %r15,%rcx
   1d33b:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d341:	cmp    $0x18,%rcx
   1d345:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d34b:	mov    0x120(%rsp),%rcx
   1d353:	lea    (%rcx,%r15,2),%rcx
   1d357:	vmovq  %rcx,%xmm0
   1d35c:	vpbroadcastq %xmm0,%ymm0
   1d361:	vmovdqu %ymm0,0x178(%rsp)
   1d36a:	mov    %rcx,0x198(%rsp)
   1d372:	mov    %rcx,0x1a0(%rsp)
   1d37a:	mov    %rcx,0x1a8(%rsp)
   1d382:	mov    0x18(%rsp),%rcx
   1d387:	sub    %r15,%rcx
   1d38a:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d390:	cmp    $0x18,%rcx
   1d394:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d39a:	lea    (%r15,%r15,1),%rcx
   1d39e:	mov    0x10(%rsp),%rdx
   1d3a3:	add    %rcx,%rdx
   1d3a6:	mov    %rdx,0x130(%rsp)
   1d3ae:	mov    0x28(%rsp),%rdx
   1d3b3:	sub    %r15,%rdx
   1d3b6:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d3bc:	cmp    $0x18,%rdx
   1d3c0:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d3c6:	mov    0x20(%rsp),%rdx
   1d3cb:	add    %rcx,%rdx
   1d3ce:	mov    %rdx,0x138(%rsp)
   1d3d6:	mov    0x38(%rsp),%rdx
   1d3db:	sub    %r15,%rdx
   1d3de:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d3e4:	cmp    $0x18,%rdx
   1d3e8:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d3ee:	mov    0x30(%rsp),%rdx
   1d3f3:	add    %rcx,%rdx
   1d3f6:	mov    %rdx,0x140(%rsp)
   1d3fe:	mov    0x48(%rsp),%rdx
   1d403:	sub    %r15,%rdx
   1d406:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d40c:	cmp    $0x18,%rdx
   1d410:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d416:	mov    0x40(%rsp),%rdx
   1d41b:	add    %rcx,%rdx
   1d41e:	mov    %rdx,0x148(%rsp)
   1d426:	mov    0x58(%rsp),%rdx
   1d42b:	sub    %r15,%rdx
   1d42e:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d434:	cmp    $0x18,%rdx
   1d438:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d43e:	mov    0x50(%rsp),%rdx
   1d443:	add    %rcx,%rdx
   1d446:	mov    %rdx,0x150(%rsp)
   1d44e:	mov    0x68(%rsp),%rdx
   1d453:	sub    %r15,%rdx
   1d456:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d45c:	cmp    $0x18,%rdx
   1d460:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d466:	mov    0x60(%rsp),%rdx
   1d46b:	add    %rcx,%rdx
   1d46e:	mov    %rdx,0x158(%rsp)
   1d476:	mov    0x78(%rsp),%rdx
   1d47b:	sub    %r15,%rdx
   1d47e:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d484:	cmp    $0x18,%rdx
   1d488:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d48e:	mov    0x70(%rsp),%rdx
   1d493:	add    %rcx,%rdx
   1d496:	mov    %rdx,0x160(%rsp)
   1d49e:	mov    0x88(%rsp),%rdx
   1d4a6:	sub    %r15,%rdx
   1d4a9:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d4af:	cmp    $0x18,%rdx
   1d4b3:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d4b9:	mov    0x80(%rsp),%rdx
   1d4c1:	add    %rcx,%rdx
   1d4c4:	mov    %rdx,0x168(%rsp)
   1d4cc:	mov    0x98(%rsp),%rdx
   1d4d4:	sub    %r15,%rdx
   1d4d7:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d4dd:	cmp    $0x18,%rdx
   1d4e1:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d4e7:	mov    0x90(%rsp),%rdx
   1d4ef:	add    %rcx,%rdx
   1d4f2:	mov    %rdx,0x170(%rsp)
   1d4fa:	cmp    $0x1,%r13
   1d4fe:	je     1d677 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
   1d504:	mov    0xa8(%rsp),%rdx
   1d50c:	sub    %r15,%rdx
   1d50f:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d515:	cmp    $0x18,%rdx
   1d519:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d51f:	mov    0xa0(%rsp),%rdx
   1d527:	add    %rcx,%rdx
   1d52a:	mov    %rdx,0x178(%rsp)
   1d532:	cmp    $0x2,%r13
   1d536:	je     1d677 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
   1d53c:	mov    0xb8(%rsp),%rdx
   1d544:	sub    %r15,%rdx
   1d547:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d54d:	cmp    $0x18,%rdx
   1d551:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d557:	mov    0xb0(%rsp),%rdx
   1d55f:	add    %rcx,%rdx
   1d562:	mov    %rdx,0x180(%rsp)
   1d56a:	cmp    $0x3,%r13
   1d56e:	je     1d677 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
   1d574:	mov    0xc8(%rsp),%rdx
   1d57c:	sub    %r15,%rdx
   1d57f:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d585:	cmp    $0x18,%rdx
   1d589:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d58f:	mov    0xc0(%rsp),%rdx
   1d597:	add    %rcx,%rdx
   1d59a:	mov    %rdx,0x188(%rsp)
   1d5a2:	cmp    $0x4,%r13
   1d5a6:	je     1d677 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
   1d5ac:	mov    0xd8(%rsp),%rdx
   1d5b4:	sub    %r15,%rdx
   1d5b7:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d5bd:	cmp    $0x18,%rdx
   1d5c1:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d5c7:	mov    0xd0(%rsp),%rdx
   1d5cf:	add    %rcx,%rdx
   1d5d2:	mov    %rdx,0x190(%rsp)
   1d5da:	cmp    $0x5,%r13
   1d5de:	je     1d677 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
   1d5e4:	mov    0xe8(%rsp),%rdx
   1d5ec:	sub    %r15,%rdx
   1d5ef:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d5f5:	cmp    $0x18,%rdx
   1d5f9:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d5ff:	mov    0xe0(%rsp),%rdx
   1d607:	add    %rcx,%rdx
   1d60a:	mov    %rdx,0x198(%rsp)
   1d612:	cmp    $0x6,%r13
   1d616:	je     1d677 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
   1d618:	mov    0xf8(%rsp),%rdx
   1d620:	sub    %r15,%rdx
   1d623:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d629:	cmp    $0x18,%rdx
   1d62d:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d633:	mov    0xf0(%rsp),%rdx
   1d63b:	add    %rcx,%rdx
   1d63e:	mov    %rdx,0x1a0(%rsp)
   1d646:	cmp    $0x7,%r13
   1d64a:	je     1d677 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
   1d64c:	mov    0x108(%rsp),%rdx
   1d654:	sub    %r15,%rdx
   1d657:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d65d:	cmp    $0x18,%rdx
   1d661:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d667:	add    0x100(%rsp),%rcx
   1d66f:	mov    %rcx,0x1a8(%rsp)
   1d677:	lea    0x10(%r15),%rax
   1d67b:	mov    %rax,0x110(%rsp)
   1d683:	dec    %rbp
   1d686:	incq   (%rsp)
   1d68a:	lea    0x1b8(%rsp),%rdx
   1d692:	xor    %esi,%esi
   1d694:	mov    (%rdx),%rdi
   1d697:	sub    %r15,%rdi
   1d69a:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d6a0:	cmp    $0x10,%rdi
   1d6a4:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d6aa:	cmp    $0x7,%rsi
   1d6ae:	ja     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1d6b4:	mov    0x158(%rsp,%rsi,8),%r8
   1d6bc:	mov    0x148(%rsp,%rsi,8),%r9
   1d6c4:	mov    0x150(%rsp,%rsi,8),%rdi
   1d6cc:	vmovdqu (%rdi),%ymm4
   1d6d0:	vmovdqu 0x2(%rdi),%ymm7
   1d6d5:	mov    0x160(%rsp,%rsi,8),%r10
   1d6dd:	mov    0x140(%rsp,%rsi,8),%r11
   1d6e5:	vmovups 0x6(%r8),%ymm0
   1d6eb:	vmovups %ymm0,0x310(%rsp)
   1d6f4:	vmovdqu 0x6(%r11),%ymm8
   1d6fa:	vmovdqu 0xa(%r11),%ymm9
   1d700:	vmovdqu 0x4(%r9),%ymm10
   1d706:	vmovdqu 0x6(%r9),%ymm6
   1d70c:	mov    %r15,%rax
   1d70f:	mov    0x168(%rsp,%rsi,8),%r15
   1d717:	mov    0x130(%rsp,%rsi,8),%rcx
   1d71f:	mov    0x138(%rsp,%rsi,8),%r12
   1d727:	mov    0x170(%rsp,%rsi,8),%rbx
   1d72f:	vmovdqu 0x2(%r12),%ymm1
   1d736:	vmovdqu 0xe(%r12),%ymm2
   1d73d:	vpaddw 0xe(%r15),%ymm1,%ymm0
   1d743:	vmovdqu %ymm0,0x2f0(%rsp)
   1d74c:	vpaddw 0x2(%r15),%ymm2,%ymm2
   1d752:	vmovdqu 0x8(%rcx),%ymm3
   1d757:	vpunpckhwd %ymm2,%ymm0,%ymm5
   1d75b:	mov    0x8(%rsp),%rcx
   1d760:	vpmaddwd 0x1e0(%rcx),%ymm5,%ymm12
   1d768:	vpaddw 0x8(%rbx),%ymm3,%ymm3
   1d76d:	vpaddw 0x10(%rdi),%ymm4,%ymm4
   1d772:	vmovdqu 0x8(%r12),%ymm5
   1d779:	vpunpckhwd %ymm4,%ymm3,%ymm11
   1d77d:	vpmaddwd 0x1a0(%rcx),%ymm11,%ymm13
   1d785:	vpaddw 0x8(%r15),%ymm5,%ymm5
   1d78b:	mov    %rax,%r15
   1d78e:	vpaddw 0xe(%rdi),%ymm7,%ymm7
   1d793:	vmovdqu 0xc(%r9),%ymm11
   1d799:	vpunpckhwd %ymm7,%ymm5,%ymm14
   1d79d:	vpmaddwd 0x160(%rcx),%ymm14,%ymm14
   1d7a5:	vpaddw 0xc(%r8),%ymm10,%ymm10
   1d7ab:	vpaddw 0x4(%r8),%ymm11,%ymm11
   1d7b1:	vpaddd %ymm12,%ymm13,%ymm15
   1d7b6:	vpunpckhwd %ymm11,%ymm10,%ymm12
   1d7bb:	vpmaddwd 0x120(%rcx),%ymm12,%ymm12
   1d7c3:	vpaddw 0xa(%r10),%ymm8,%ymm8
   1d7c9:	vpaddw 0x6(%r10),%ymm9,%ymm9
   1d7cf:	vpaddd %ymm12,%ymm14,%ymm14
   1d7d4:	vpunpckhwd %ymm9,%ymm8,%ymm12
   1d7d9:	vpmaddwd 0xe0(%rcx),%ymm12,%ymm0
   1d7e1:	vpaddw 0xa(%r8),%ymm6,%ymm12
   1d7e7:	vmovdqu 0x310(%rsp),%ymm1
   1d7f0:	vpaddw 0xa(%r9),%ymm1,%ymm13
   1d7f6:	vpaddd %ymm14,%ymm15,%ymm15
   1d7fb:	vpunpckhwd %ymm13,%ymm12,%ymm6
   1d800:	vpmaddwd 0xa0(%rcx),%ymm6,%ymm6
   1d808:	vmovdqu 0x8(%r11),%ymm14
   1d80e:	vpaddd %ymm6,%ymm0,%ymm0
   1d812:	vpaddw 0x8(%r10),%ymm14,%ymm6
   1d818:	vmovdqu 0x4(%rdi),%ymm14
   1d81d:	vpaddw 0xc(%rdi),%ymm14,%ymm14
   1d822:	vpunpckhwd %ymm14,%ymm6,%ymm1
   1d827:	vpmaddwd 0x60(%rcx),%ymm1,%ymm1
   1d82c:	vpaddd %ymm1,%ymm0,%ymm0
   1d830:	vpaddd %ymm0,%ymm15,%ymm0
   1d834:	vmovdqu 0x2f0(%rsp),%ymm1
   1d83d:	vpunpcklwd %ymm2,%ymm1,%ymm1
   1d841:	vpunpcklwd %ymm4,%ymm3,%ymm2
   1d845:	vpunpcklwd %ymm7,%ymm5,%ymm3
   1d849:	vpunpcklwd %ymm11,%ymm10,%ymm4
   1d84e:	vpmaddwd 0x1c0(%rcx),%ymm1,%ymm1
   1d856:	vpmaddwd 0x180(%rcx),%ymm2,%ymm2
   1d85e:	vpmaddwd 0x140(%rcx),%ymm3,%ymm3
   1d866:	vpmaddwd 0x100(%rcx),%ymm4,%ymm4
   1d86e:	vpaddd %ymm1,%ymm2,%ymm1
   1d872:	vpaddd %ymm4,%ymm3,%ymm2
   1d876:	vpaddd %ymm2,%ymm1,%ymm1
   1d87a:	vpunpcklwd %ymm9,%ymm8,%ymm2
   1d87f:	vpunpcklwd %ymm13,%ymm12,%ymm3
   1d884:	vmovdqu 0x6(%rdi),%ymm4
   1d889:	vpmaddwd 0xc0(%rcx),%ymm2,%ymm2
   1d891:	vpmaddwd 0x80(%rcx),%ymm3,%ymm3
   1d899:	vpaddd %ymm3,%ymm2,%ymm2
   1d89d:	vmovdqu 0x8(%r9),%ymm3
   1d8a3:	vpaddw 0x8(%r8),%ymm3,%ymm3
   1d8a9:	vpaddw 0xa(%rdi),%ymm4,%ymm4
   1d8ae:	vpunpcklwd %ymm14,%ymm6,%ymm5
   1d8b3:	vpmaddwd 0x40(%rcx),%ymm5,%ymm5
   1d8b8:	vpaddd %ymm5,%ymm2,%ymm2
   1d8bc:	vpunpckhwd %ymm4,%ymm3,%ymm5
   1d8c0:	vpunpcklwd %ymm4,%ymm3,%ymm3
   1d8c4:	vpmaddwd (%rcx),%ymm3,%ymm3
   1d8c8:	vpaddd %ymm2,%ymm1,%ymm1
   1d8cc:	vmovdqu 0x8(%rdi),%ymm2
   1d8d1:	vpunpcklwd -0x17619(%rip),%ymm2,%ymm4        # 62c0 <__abi_tag+0x5fc4>
   1d8d9:	vpshufb -0x175e2(%rip),%ymm4,%ymm4        # 6300 <__abi_tag+0x6004>
   1d8e2:	vpmaddwd 0x200(%rcx),%ymm4,%ymm4
   1d8ea:	vpaddd %ymm4,%ymm3,%ymm3
   1d8ee:	vpaddd %ymm3,%ymm1,%ymm1
   1d8f2:	vpmaddwd 0x20(%rcx),%ymm5,%ymm3
   1d8f7:	vpunpckhwd -0x175bf(%rip),%ymm2,%ymm2        # 6340 <__abi_tag+0x6044>
   1d8ff:	vpshufb -0x17668(%rip),%ymm2,%ymm2        # 62a0 <__abi_tag+0x5fa4>
   1d908:	vpmaddwd 0x220(%rcx),%ymm2,%ymm2
   1d910:	vpaddd %ymm2,%ymm3,%ymm2
   1d914:	vpaddd %ymm2,%ymm0,%ymm0
   1d918:	vpsrad $0x7,%ymm1,%ymm1
   1d91d:	vpsrad $0x7,%ymm0,%ymm0
   1d922:	mov    0x128(%rsp),%rcx
   1d92a:	vpbroadcastw (%rcx),%ymm2
   1d92f:	vpackusdw %ymm0,%ymm1,%ymm0
   1d934:	vpminuw %ymm2,%ymm0,%ymm0
   1d939:	mov    -0x8(%rdx),%rcx
   1d93d:	vmovdqu %ymm0,(%rcx,%rax,2)
   1d942:	inc    %rsi
   1d945:	add    $0x10,%rdx
   1d949:	cmp    %rsi,%r13
   1d94c:	jne    1d694 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6c4>
   1d952:	mov    0x110(%rsp),%r15
   1d95a:	test   %rbp,%rbp
   1d95d:	mov    0x118(%rsp),%rbx
   1d965:	lea    0x578(%rsp),%rax
   1d96d:	jne    1d2e3 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x313>
   1d973:	mov    $0x1,%al
   1d975:	jmp    1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d97a:	xor    %eax,%eax
   1d97c:	sub    %rdx,%rsi
   1d97f:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d985:	cmp    %rcx,%rsi
   1d988:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d98e:	lea    (%rdi,%rdx,2),%rdi
   1d992:	mov    %rdi,0x1c0(%rsp)
   1d99a:	mov    %rcx,0x1c8(%rsp)
   1d9a2:	cmp    $0x2,%r13
   1d9a6:	je     1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1d9ac:	xor    %eax,%eax
   1d9ae:	sub    %rdx,%rsi
   1d9b1:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d9b7:	cmp    %rcx,%rsi
   1d9ba:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d9c0:	lea    (%rdi,%rdx,2),%rdi
   1d9c4:	mov    %rdi,0x1d0(%rsp)
   1d9cc:	mov    %rcx,0x1d8(%rsp)
   1d9d4:	cmp    $0x3,%r13
   1d9d8:	je     1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1d9de:	xor    %eax,%eax
   1d9e0:	sub    %rdx,%rsi
   1d9e3:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d9e9:	cmp    %rcx,%rsi
   1d9ec:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1d9f2:	lea    (%rdi,%rdx,2),%rdi
   1d9f6:	mov    %rdi,0x1e0(%rsp)
   1d9fe:	mov    %rcx,0x1e8(%rsp)
   1da06:	cmp    $0x4,%r13
   1da0a:	je     1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1da10:	sub    %rdx,%rsi
   1da13:	jb     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1da19:	cmp    %rcx,%rsi
   1da1c:	mov    $0x0,%eax
   1da21:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1da27:	lea    (%rdi,%rdx,2),%rax
   1da2b:	mov    %rax,0x1f0(%rsp)
   1da33:	mov    %rcx,0x1f8(%rsp)
   1da3b:	cmp    $0x5,%r13
   1da3f:	je     1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1da45:	sub    %rdx,%rsi
   1da48:	lea    (%rax,%rdx,2),%rdi
   1da4c:	mov    $0x0,%r8d
   1da52:	cmovae %rdi,%r8
   1da56:	test   %r8,%r8
   1da59:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1da5f:	cmp    %rcx,%rsi
   1da62:	mov    $0x0,%eax
   1da67:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1da6d:	mov    %r8,0x200(%rsp)
   1da75:	mov    %rcx,0x208(%rsp)
   1da7d:	cmp    $0x6,%r13
   1da81:	je     1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1da87:	sub    %rdx,%rsi
   1da8a:	lea    (%rdi,%rdx,2),%rdi
   1da8e:	mov    $0x0,%r8d
   1da94:	cmovae %rdi,%r8
   1da98:	test   %r8,%r8
   1da9b:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1daa1:	cmp    %rcx,%rsi
   1daa4:	mov    $0x0,%eax
   1daa9:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1daaf:	mov    %r8,0x210(%rsp)
   1dab7:	mov    %rcx,0x218(%rsp)
   1dabf:	cmp    $0x7,%r13
   1dac3:	je     1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1dac9:	sub    %rdx,%rsi
   1dacc:	lea    (%rdi,%rdx,2),%rdi
   1dad0:	mov    $0x0,%r8d
   1dad6:	cmovae %rdi,%r8
   1dada:	test   %r8,%r8
   1dadd:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1dae3:	cmp    %rcx,%rsi
   1dae6:	mov    $0x0,%eax
   1daeb:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1daf1:	mov    %r8,0x220(%rsp)
   1daf9:	mov    %rcx,0x228(%rsp)
   1db01:	cmp    $0x8,%r13
   1db05:	je     1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
   1db0b:	sub    %rdx,%rsi
   1db0e:	lea    (%rdi,%rdx,2),%rdi
   1db12:	mov    $0x0,%r8d
   1db18:	cmovae %rdi,%r8
   1db1c:	test   %r8,%r8
   1db1f:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1db25:	cmp    %rcx,%rsi
   1db28:	mov    $0x0,%eax
   1db2d:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1db33:	mov    %r8,0x230(%rsp)
   1db3b:	mov    %rcx,0x238(%rsp)
   1db43:	sub    %rdx,%rsi
   1db46:	lea    (%rdi,%rdx,2),%rdi
   1db4a:	mov    $0x0,%r8d
   1db50:	cmovae %rdi,%r8
   1db54:	test   %r8,%r8
   1db57:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1db5d:	cmp    %rcx,%rsi
   1db60:	mov    $0x0,%eax
   1db65:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1db6b:	mov    %r8,0x240(%rsp)
   1db73:	mov    %rcx,0x248(%rsp)
   1db7b:	sub    %rdx,%rsi
   1db7e:	lea    (%rdi,%rdx,2),%rdi
   1db82:	mov    $0x0,%r8d
   1db88:	cmovae %rdi,%r8
   1db8c:	test   %r8,%r8
   1db8f:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1db95:	cmp    %rcx,%rsi
   1db98:	mov    $0x0,%eax
   1db9d:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1dba3:	mov    %r8,0x250(%rsp)
   1dbab:	mov    %rcx,0x258(%rsp)
   1dbb3:	sub    %rdx,%rsi
   1dbb6:	lea    (%rdi,%rdx,2),%rdi
   1dbba:	mov    $0x0,%r8d
   1dbc0:	cmovae %rdi,%r8
   1dbc4:	test   %r8,%r8
   1dbc7:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1dbcd:	cmp    %rcx,%rsi
   1dbd0:	mov    $0x0,%eax
   1dbd5:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1dbdb:	mov    %r8,0x260(%rsp)
   1dbe3:	mov    %rcx,0x268(%rsp)
   1dbeb:	sub    %rdx,%rsi
   1dbee:	lea    (%rdi,%rdx,2),%rdi
   1dbf2:	mov    $0x0,%r8d
   1dbf8:	cmovae %rdi,%r8
   1dbfc:	test   %r8,%r8
   1dbff:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1dc05:	cmp    %rcx,%rsi
   1dc08:	mov    $0x0,%eax
   1dc0d:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1dc13:	mov    %r8,0x270(%rsp)
   1dc1b:	mov    %rcx,0x278(%rsp)
   1dc23:	sub    %rdx,%rsi
   1dc26:	lea    (%rdi,%rdx,2),%rdi
   1dc2a:	mov    $0x0,%r8d
   1dc30:	cmovae %rdi,%r8
   1dc34:	test   %r8,%r8
   1dc37:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1dc3d:	cmp    %rcx,%rsi
   1dc40:	mov    $0x0,%eax
   1dc45:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1dc4b:	mov    %r8,0x280(%rsp)
   1dc53:	mov    %rcx,0x288(%rsp)
   1dc5b:	sub    %rdx,%rsi
   1dc5e:	lea    (%rdi,%rdx,2),%rdi
   1dc62:	mov    $0x0,%r8d
   1dc68:	cmovae %rdi,%r8
   1dc6c:	test   %r8,%r8
   1dc6f:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1dc75:	cmp    %rcx,%rsi
   1dc78:	mov    $0x0,%eax
   1dc7d:	jb     1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1dc83:	mov    %r8,0x290(%rsp)
   1dc8b:	mov    %rcx,0x298(%rsp)
   1dc93:	xor    %eax,%eax
   1dc95:	sub    %rdx,%rsi
   1dc98:	lea    (%rdi,%rdx,2),%rdx
   1dc9c:	cmovb  %rax,%rdx
   1dca0:	setae  %al
   1dca3:	cmp    %rcx,%rsi
   1dca6:	setb   %sil
   1dcaa:	test   %rdx,%rdx
   1dcad:	je     1d060 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
   1dcb3:	and    %sil,%al
   1dcb6:	mov    $0x0,%eax
   1dcbb:	jne    1d062 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
   1dcc1:	mov    %rdx,0x2a0(%rsp)
   1dcc9:	mov    %rcx,0x2a8(%rsp)
   1dcd1:	jmp    1d284 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
