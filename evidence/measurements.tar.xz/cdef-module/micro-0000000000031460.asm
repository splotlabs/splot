
<WORKTREES>/qualification-1882/cdef-module/micro-target/release/cdef-micro:     file format elf64-x86-64


Disassembly of section .text:

0000000000031460 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed>:
   31460:	push   %rbp
   31461:	push   %r15
   31463:	push   %r14
   31465:	push   %rbx
   31466:	mov    %rdx,%r8
   31469:	mov    (%rsi),%r9
   3146c:	mov    0x8(%rsi),%r10
   31470:	mov    0x10(%rsi),%r11
   31474:	mov    0x18(%rsi),%rbx
   31478:	add    $0x180,%rcx
   3147f:	vpcmpeqd %ymm2,%ymm2,%ymm2
   31483:	vpxor  %xmm0,%xmm0,%xmm0
   31487:	xor    %esi,%esi
   31489:	vmovdqa -0x2a1c1(%rip),%xmm3        # 72d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1c0>
   31491:	vpxor  %xmm1,%xmm1,%xmm1
   31495:	vpcmpeqd %ymm4,%ymm4,%ymm4
   31499:	nopl   0x0(%rax)
   314a0:	mov    %rsi,%rax
   314a3:	mul    %r8
   314a6:	jo     316d4 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed+0x274>
   314ac:	mov    %rbx,%r14
   314af:	sub    %rax,%r14
   314b2:	setb   %bpl
   314b6:	xor    %edx,%edx
   314b8:	mov    %r10,%r15
   314bb:	sub    %rax,%r15
   314be:	jb     316c4 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed+0x264>
   314c4:	cmp    $0x14,%r15
   314c8:	jb     316c4 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed+0x264>
   314ce:	test   %bpl,%bpl
   314d1:	jne    316c4 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed+0x264>
   314d7:	cmp    $0x14,%r14
   314db:	jb     316c4 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed+0x264>
   314e1:	inc    %rsi
   314e4:	vmovdqu (%r9,%rax,1),%xmm5
   314ea:	vmovdqu (%r11,%rax,1),%xmm6
   314f0:	vpunpckhbw %xmm6,%xmm5,%xmm7
   314f4:	vpunpcklbw %xmm6,%xmm5,%xmm8
   314f8:	vpxor  %xmm3,%xmm8,%xmm8
   314fc:	vmovdqu %xmm8,-0x180(%rcx)
   31504:	vpxor  %xmm3,%xmm7,%xmm7
   31508:	vmovdqu %xmm7,-0x80(%rcx)
   3150d:	vmovdqu 0x4(%r11,%rax,1),%xmm7
   31514:	vmovdqu 0x4(%r9,%rax,1),%xmm8
   3151b:	vinserti128 $0x1,%xmm8,%ymm5,%ymm5
   31521:	vpminub %ymm5,%ymm4,%ymm4
   31525:	vpmaxub %ymm5,%ymm1,%ymm1
   31529:	vinserti128 $0x1,%xmm7,%ymm6,%ymm5
   3152f:	vpminub %ymm5,%ymm2,%ymm2
   31533:	vpmaxub %ymm5,%ymm0,%ymm0
   31537:	vpunpckhbw %xmm7,%xmm8,%xmm5
   3153b:	vpunpcklbw %xmm7,%xmm8,%xmm6
   3153f:	vpxor  %xmm3,%xmm6,%xmm6
   31543:	vmovdqu %xmm6,-0x100(%rcx)
   3154b:	vpxor  %xmm3,%xmm5,%xmm5
   3154f:	vmovdqu %xmm5,(%rcx)
   31553:	add    $0x10,%rcx
   31557:	cmp    $0x8,%rsi
   3155b:	jne    314a0 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed+0x40>
   31561:	vpmovzxbw %xmm4,%ymm7
   31566:	vpermq $0xe9,%ymm7,%ymm6
   3156c:	vextracti128 $0x1,%ymm4,%xmm3
   31572:	vpxor  %xmm4,%xmm4,%xmm4
   31576:	vpunpckhbw %xmm4,%xmm3,%xmm3
   3157a:	vpmovzxbw %xmm2,%ymm5
   3157f:	vpermq $0xe9,%ymm5,%ymm8
   31585:	vextracti128 $0x1,%ymm2,%xmm2
   3158b:	vpunpckhbw %xmm4,%xmm2,%xmm2
   3158f:	vpmovzxbw %xmm1,%ymm10
   31594:	vpermq $0xe9,%ymm10,%ymm11
   3159a:	vextracti128 $0x1,%ymm1,%xmm1
   315a0:	vpunpckhbw %xmm4,%xmm1,%xmm1
   315a4:	vpmovzxbw %xmm0,%ymm9
   315a9:	vpermq $0xe9,%ymm9,%ymm12
   315af:	vextracti128 $0x1,%ymm0,%xmm0
   315b5:	vpunpckhbw %xmm4,%xmm0,%xmm4
   315b9:	vphminposuw %xmm7,%xmm13
   315be:	vpcmpeqd %xmm0,%xmm0,%xmm0
   315c2:	vphminposuw %xmm6,%xmm6
   315c7:	vpunpcklwd %xmm6,%xmm13,%xmm6
   315cb:	vpxor  %xmm0,%xmm10,%xmm13
   315cf:	vphminposuw %xmm13,%xmm13
   315d4:	vpxor  %xmm0,%xmm11,%xmm11
   315d8:	vphminposuw %xmm11,%xmm11
   315dd:	vpunpcklwd %xmm11,%xmm13,%xmm11
   315e2:	vphminposuw %xmm5,%xmm13
   315e7:	vphminposuw %xmm8,%xmm8
   315ec:	vpunpcklwd %xmm8,%xmm13,%xmm8
   315f1:	vpxor  %xmm0,%xmm9,%xmm13
   315f5:	vphminposuw %xmm13,%xmm13
   315fa:	vpxor  %xmm0,%xmm12,%xmm12
   315fe:	vphminposuw %xmm12,%xmm12
   31603:	vpunpcklwd %xmm12,%xmm13,%xmm12
   31608:	vextracti128 $0x1,%ymm7,%xmm7
   3160e:	vphminposuw %xmm7,%xmm7
   31613:	vmovd  %xmm7,%eax
   31617:	vextracti128 $0x1,%ymm10,%xmm7
   3161d:	vpxor  %xmm0,%xmm7,%xmm7
   31621:	vphminposuw %xmm7,%xmm7
   31626:	vmovd  %xmm7,%ecx
   3162a:	vextracti128 $0x1,%ymm5,%xmm5
   31630:	vphminposuw %xmm5,%xmm5
   31635:	vmovd  %xmm5,%edx
   31639:	vextracti128 $0x1,%ymm9,%xmm5
   3163f:	vpxor  %xmm0,%xmm5,%xmm5
   31643:	vphminposuw %xmm5,%xmm5
   31648:	vmovd  %xmm5,%esi
   3164c:	vphminposuw %xmm3,%xmm3
   31651:	vmovd  %xmm3,%r8d
   31656:	vpxor  %xmm0,%xmm1,%xmm1
   3165a:	vphminposuw %xmm1,%xmm1
   3165f:	vmovd  %xmm1,%r9d
   31664:	vphminposuw %xmm2,%xmm1
   31669:	vmovd  %xmm1,%r10d
   3166e:	vpxor  %xmm0,%xmm4,%xmm1
   31672:	vphminposuw %xmm1,%xmm1
   31677:	vpinsrw $0x2,%ecx,%xmm11,%xmm2
   3167c:	vpinsrw $0x3,%r9d,%xmm2,%xmm2
   31682:	vmovd  %xmm1,%ecx
   31686:	vpxor  %xmm0,%xmm2,%xmm1
   3168a:	vpinsrw $0x2,%eax,%xmm6,%xmm2
   3168f:	vpinsrw $0x3,%r8d,%xmm2,%xmm2
   31695:	vpinsrw $0x2,%esi,%xmm12,%xmm3
   3169a:	vpsubw %xmm2,%xmm1,%xmm1
   3169e:	vpinsrw $0x3,%ecx,%xmm3,%xmm2
   316a3:	vpxor  %xmm0,%xmm2,%xmm0
   316a7:	vpinsrw $0x2,%edx,%xmm8,%xmm2
   316ac:	vpinsrw $0x3,%r10d,%xmm2,%xmm2
   316b2:	vpsubw %xmm2,%xmm0,%xmm0
   316b6:	vpmaxuw %xmm0,%xmm1,%xmm0
   316bb:	vmovq  %xmm0,0x2(%rdi)
   316c0:	mov    $0x1,%dx
   316c4:	mov    %dx,(%rdi)
   316c7:	mov    %rdi,%rax
   316ca:	pop    %rbx
   316cb:	pop    %r14
   316cd:	pop    %r15
   316cf:	pop    %rbp
   316d0:	vzeroupper
   316d3:	ret
   316d4:	xor    %edx,%edx
   316d6:	jmp    316c4 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed+0x264>
