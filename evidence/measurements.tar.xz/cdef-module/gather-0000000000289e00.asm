
<WORKTREES>/qualification-1882/cdef-module/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000289e00 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed>:
  289e00:	push   %rbp
  289e01:	push   %r15
  289e03:	push   %r14
  289e05:	push   %rbx
  289e06:	mov    %rdx,%r8
  289e09:	mov    (%rsi),%r9
  289e0c:	mov    0x8(%rsi),%r10
  289e10:	mov    0x10(%rsi),%r11
  289e14:	mov    0x18(%rsi),%rbx
  289e18:	add    $0x180,%rcx
  289e1f:	vpcmpeqd %ymm2,%ymm2,%ymm2
  289e23:	vpxor  %xmm0,%xmm0,%xmm0
  289e27:	xor    %esi,%esi
  289e29:	vmovdqa -0x273a31(%rip),%xmm3        # 16400 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2560>
  289e31:	vpxor  %xmm1,%xmm1,%xmm1
  289e35:	vpcmpeqd %ymm4,%ymm4,%ymm4
  289e39:	nopl   0x0(%rax)
  289e40:	mov    %rsi,%rax
  289e43:	mul    %r8
  289e46:	jo     28a074 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed+0x274>
  289e4c:	mov    %rbx,%r14
  289e4f:	sub    %rax,%r14
  289e52:	setb   %bpl
  289e56:	xor    %edx,%edx
  289e58:	mov    %r10,%r15
  289e5b:	sub    %rax,%r15
  289e5e:	jb     28a064 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed+0x264>
  289e64:	cmp    $0x14,%r15
  289e68:	jb     28a064 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed+0x264>
  289e6e:	test   %bpl,%bpl
  289e71:	jne    28a064 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed+0x264>
  289e77:	cmp    $0x14,%r14
  289e7b:	jb     28a064 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed+0x264>
  289e81:	inc    %rsi
  289e84:	vmovdqu (%r9,%rax,1),%xmm5
  289e8a:	vmovdqu (%r11,%rax,1),%xmm6
  289e90:	vpunpckhbw %xmm6,%xmm5,%xmm7
  289e94:	vpunpcklbw %xmm6,%xmm5,%xmm8
  289e98:	vpxor  %xmm3,%xmm8,%xmm8
  289e9c:	vmovdqu %xmm8,-0x180(%rcx)
  289ea4:	vpxor  %xmm3,%xmm7,%xmm7
  289ea8:	vmovdqu %xmm7,-0x80(%rcx)
  289ead:	vmovdqu 0x4(%r11,%rax,1),%xmm7
  289eb4:	vmovdqu 0x4(%r9,%rax,1),%xmm8
  289ebb:	vinserti128 $0x1,%xmm8,%ymm5,%ymm5
  289ec1:	vpminub %ymm5,%ymm4,%ymm4
  289ec5:	vpmaxub %ymm5,%ymm1,%ymm1
  289ec9:	vinserti128 $0x1,%xmm7,%ymm6,%ymm5
  289ecf:	vpminub %ymm5,%ymm2,%ymm2
  289ed3:	vpmaxub %ymm5,%ymm0,%ymm0
  289ed7:	vpunpckhbw %xmm7,%xmm8,%xmm5
  289edb:	vpunpcklbw %xmm7,%xmm8,%xmm6
  289edf:	vpxor  %xmm3,%xmm6,%xmm6
  289ee3:	vmovdqu %xmm6,-0x100(%rcx)
  289eeb:	vpxor  %xmm3,%xmm5,%xmm5
  289eef:	vmovdqu %xmm5,(%rcx)
  289ef3:	add    $0x10,%rcx
  289ef7:	cmp    $0x8,%rsi
  289efb:	jne    289e40 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed+0x40>
  289f01:	vpmovzxbw %xmm4,%ymm7
  289f06:	vpermq $0xe9,%ymm7,%ymm6
  289f0c:	vextracti128 $0x1,%ymm4,%xmm3
  289f12:	vpxor  %xmm4,%xmm4,%xmm4
  289f16:	vpunpckhbw %xmm4,%xmm3,%xmm3
  289f1a:	vpmovzxbw %xmm2,%ymm5
  289f1f:	vpermq $0xe9,%ymm5,%ymm8
  289f25:	vextracti128 $0x1,%ymm2,%xmm2
  289f2b:	vpunpckhbw %xmm4,%xmm2,%xmm2
  289f2f:	vpmovzxbw %xmm1,%ymm10
  289f34:	vpermq $0xe9,%ymm10,%ymm11
  289f3a:	vextracti128 $0x1,%ymm1,%xmm1
  289f40:	vpunpckhbw %xmm4,%xmm1,%xmm1
  289f44:	vpmovzxbw %xmm0,%ymm9
  289f49:	vpermq $0xe9,%ymm9,%ymm12
  289f4f:	vextracti128 $0x1,%ymm0,%xmm0
  289f55:	vpunpckhbw %xmm4,%xmm0,%xmm4
  289f59:	vphminposuw %xmm7,%xmm13
  289f5e:	vpcmpeqd %xmm0,%xmm0,%xmm0
  289f62:	vphminposuw %xmm6,%xmm6
  289f67:	vpunpcklwd %xmm6,%xmm13,%xmm6
  289f6b:	vpxor  %xmm0,%xmm10,%xmm13
  289f6f:	vphminposuw %xmm13,%xmm13
  289f74:	vpxor  %xmm0,%xmm11,%xmm11
  289f78:	vphminposuw %xmm11,%xmm11
  289f7d:	vpunpcklwd %xmm11,%xmm13,%xmm11
  289f82:	vphminposuw %xmm5,%xmm13
  289f87:	vphminposuw %xmm8,%xmm8
  289f8c:	vpunpcklwd %xmm8,%xmm13,%xmm8
  289f91:	vpxor  %xmm0,%xmm9,%xmm13
  289f95:	vphminposuw %xmm13,%xmm13
  289f9a:	vpxor  %xmm0,%xmm12,%xmm12
  289f9e:	vphminposuw %xmm12,%xmm12
  289fa3:	vpunpcklwd %xmm12,%xmm13,%xmm12
  289fa8:	vextracti128 $0x1,%ymm7,%xmm7
  289fae:	vphminposuw %xmm7,%xmm7
  289fb3:	vmovd  %xmm7,%eax
  289fb7:	vextracti128 $0x1,%ymm10,%xmm7
  289fbd:	vpxor  %xmm0,%xmm7,%xmm7
  289fc1:	vphminposuw %xmm7,%xmm7
  289fc6:	vmovd  %xmm7,%ecx
  289fca:	vextracti128 $0x1,%ymm5,%xmm5
  289fd0:	vphminposuw %xmm5,%xmm5
  289fd5:	vmovd  %xmm5,%edx
  289fd9:	vextracti128 $0x1,%ymm9,%xmm5
  289fdf:	vpxor  %xmm0,%xmm5,%xmm5
  289fe3:	vphminposuw %xmm5,%xmm5
  289fe8:	vmovd  %xmm5,%esi
  289fec:	vphminposuw %xmm3,%xmm3
  289ff1:	vmovd  %xmm3,%r8d
  289ff6:	vpxor  %xmm0,%xmm1,%xmm1
  289ffa:	vphminposuw %xmm1,%xmm1
  289fff:	vmovd  %xmm1,%r9d
  28a004:	vphminposuw %xmm2,%xmm1
  28a009:	vmovd  %xmm1,%r10d
  28a00e:	vpxor  %xmm0,%xmm4,%xmm1
  28a012:	vphminposuw %xmm1,%xmm1
  28a017:	vpinsrw $0x2,%ecx,%xmm11,%xmm2
  28a01c:	vpinsrw $0x3,%r9d,%xmm2,%xmm2
  28a022:	vmovd  %xmm1,%ecx
  28a026:	vpxor  %xmm0,%xmm2,%xmm1
  28a02a:	vpinsrw $0x2,%eax,%xmm6,%xmm2
  28a02f:	vpinsrw $0x3,%r8d,%xmm2,%xmm2
  28a035:	vpinsrw $0x2,%esi,%xmm12,%xmm3
  28a03a:	vpsubw %xmm2,%xmm1,%xmm1
  28a03e:	vpinsrw $0x3,%ecx,%xmm3,%xmm2
  28a043:	vpxor  %xmm0,%xmm2,%xmm0
  28a047:	vpinsrw $0x2,%edx,%xmm8,%xmm2
  28a04c:	vpinsrw $0x3,%r10d,%xmm2,%xmm2
  28a052:	vpsubw %xmm2,%xmm0,%xmm0
  28a056:	vpmaxuw %xmm0,%xmm1,%xmm0
  28a05b:	vmovq  %xmm0,0x2(%rdi)
  28a060:	mov    $0x1,%dx
  28a064:	mov    %dx,(%rdi)
  28a067:	mov    %rdi,%rax
  28a06a:	pop    %rbx
  28a06b:	pop    %r14
  28a06d:	pop    %r15
  28a06f:	pop    %rbp
  28a070:	vzeroupper
  28a073:	ret
  28a074:	xor    %edx,%edx
  28a076:	jmp    28a064 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed+0x264>
