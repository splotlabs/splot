import bench
import csv
import os
from pathlib import Path
root=Path(__file__).resolve().parent
bench.variants.update({name:root/f'lr-product-{name}/target/release/splot' for name in ('plain','unit')})
bench.streams.extend([next((root/'ci-data').glob('RitualDance*.ivf')),root/'ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf'])
os.sched_setaffinity(0,{4})
names=('plain','unit','callback','shipped')
for src in bench.streams:
    for name in names:
        bench.timed(name,src)
rows=[]
with (root/'lr-product-paired.csv').open('x') as file:
    writer=csv.writer(file)
    writer.writerow(['stream','round','position','build','elapsed','CPU'])
    for r in range(12):
        for j,src in enumerate(bench.streams if r%2==0 else reversed(bench.streams)):
            for pos,offset in enumerate((0,1,3,2)):
                name=names[(r+offset+bench.streams.index(src)*2)%4]
                row=(src.name,r+1,pos+1,name,*bench.timed(name,src))
                writer.writerow(row)
                file.flush()
                rows.append(row)
bench.summaries(rows,names)
