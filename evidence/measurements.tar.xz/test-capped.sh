set -eu
workspace=$(pwd)
for pair in 'splot-1934-parser splot-decode' 'splot-1934-tip-overlap splot-recon'; do
  read -r checkout crate <<< "$pair"
  (cd "$workspace/../$checkout" && systemd-run --user --scope --quiet -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p CPUQuota=180% flock "$workspace/build.lock" taskset -c 6-11,14-19 env CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_TEST_INCREMENTAL=false cargo test -j1 --locked --offline -p "$crate" --lib -- --test-threads=2) > "$workspace/$crate-unit.log" 2>&1
done
