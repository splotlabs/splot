from pathlib import Path
import re
root=Path(__file__).parent
names=('DOTA2','RitualDance','Slides1','Noise_Ocean','old_town_cross')
lines=['## AVX2 follow-up on subpel prediction and CDEF filtering',
'The signed experiment `d67efd2d666c82f8fb8f290530fb553b80f6a1b4` contains the two scoped changes on top of the parser branch `a4c95ac9`. The first forty raw frames of WITCHER3 and TunnelFlag matched the historical release SHA-256 at 1, 7 and 12 workers.',
'Using 12 warm, counterbalanced pairs on a pinned i7-12700H P-core, elapsed time decreased relative to the parser branch by 6.65% on WITCHER3 (paired bootstrap interval −9.15% to −1.23%) and 2.68% on TunnelFlag (−8.00% to −0.25%). Against the shipped v3 reference in the same run, elapsed time was still 13.58% higher (+9.81% to +14.93%) and 18.31% higher (+16.74% to +19.68%). Against the pre-epic reference the corresponding medians were +14.57% and +13.35%.',
'### Official CI inputs measured locally',
'Single-thread Callgrind guest-instruction counts use the corpus, frame limits and frame delay from `xtask perf`. The control is the same integrated portable source before parser and kernel experiments (`2a04d218`).',
'| Stream | Portable control | Experiment | Change |\n|---|---:|---:|---:|']
total=[0,0]
for name in names:
    values=[]
    for i,v in enumerate(('control','kernels')):
        value=int(re.search(r'^summary: (\d+)',(root/f'{v}-{name}.cg').read_text(),re.M)[1])
        values.append(value)
        total[i]+=value
    lines[-1]+=f'\n| {name} | {values[0]:,} | {values[1]:,} | {(values[1]/values[0]-1)*100:+.2f}% |'
lines[-1]+=f'\n| **Total** | {total[0]:,} | {total[1]:,} | {(total[1]/total[0]-1)*100:+.2f}% |'
lines+=['The two package-size checks now pass on #1987. The five-stream GitHub CI gate for the draft records +22.79% aggregate instructions versus the current main baseline. The new experiments remain separate from the release draft while throughput qualification is open. [CI comparison](https://github.com/splotlabs/splot/actions/runs/45612969867/job/139200983768)',
'<details><summary>Raw comparative timing in seconds</summary>\n\n```csv\n'+(root/'kernels-four-way.csv').read_text().strip()+'\n```\n</details>']
(root/'kernels-issue.md').write_text('\n\n'.join(lines)+'\n')
