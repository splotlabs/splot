
<WORKTREES>/qualification-1882/lr-product-unit/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000da71a0 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run>:
  da71a0:	push   %rbp
  da71a1:	push   %r15
  da71a3:	push   %r14
  da71a5:	push   %r13
  da71a7:	push   %r12
  da71a9:	push   %rbx
  da71aa:	sub    $0x798,%rsp
  da71b1:	xor    %r12d,%r12d
  da71b4:	sub    %rcx,%r8
  da71b7:	cmovae %r8,%r12
  da71bb:	mov    %r12,%r8
  da71be:	and    $0xfffffffffffffff0,%r8
  da71c2:	sete   %r10b
  da71c6:	test   %rdx,%rdx
  da71c9:	sete   %al
  da71cc:	or     %r10b,%al
  da71cf:	cmp    $0x9,%rdx
  da71d3:	setae  %r10b
  da71d7:	or     %al,%r10b
  da71da:	jne    da7210 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x70>
  da71dc:	mov    %r8,%r11
  da71df:	add    %rcx,%r11
  da71e2:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da71e4:	sub    $0xfffffffffffffff8,%r11
  da71e8:	setae  %al
  da71eb:	test   %rsi,%rsi
  da71ee:	sete   %r10b
  da71f2:	or     %al,%r10b
  da71f5:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da71f7:	mov    %r11,%r13
  da71fa:	sub    %rcx,%r13
  da71fd:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da71ff:	cmp    0x8(%rdi),%r11
  da7203:	ja     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7205:	lea    0x8(%rdx),%r15
  da7209:	cmp    %r15,%rsi
  da720c:	jae    da7225 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x85>
  da720e:	xor    %eax,%eax
  da7210:	add    $0x798,%rsp
  da7217:	pop    %rbx
  da7218:	pop    %r12
  da721a:	pop    %r13
  da721c:	pop    %r14
  da721e:	pop    %r15
  da7220:	pop    %rbp
  da7221:	vzeroupper
  da7224:	ret
  da7225:	mov    0x7d0(%rsp),%r10
  da722d:	mov    (%r10),%rax
  da7230:	mov    0x8(%r10),%r14
  da7234:	mov    0x10(%r10),%r10
  da7238:	mov    %r10,0x1b0(%rsp)
  da7240:	mov    (%rdi),%r10
  da7243:	lea    (%r10,%rcx,2),%r10
  da7247:	mov    %r10,0x18(%rsp)
  da724c:	mov    %r13,0x20(%rsp)
  da7251:	mov    %r10,0x28(%rsp)
  da7256:	mov    %r13,0x30(%rsp)
  da725b:	mov    %r10,0x38(%rsp)
  da7260:	mov    %r13,0x40(%rsp)
  da7265:	mov    %r10,0x48(%rsp)
  da726a:	mov    %r13,0x50(%rsp)
  da726f:	mov    %r10,0x58(%rsp)
  da7274:	mov    %r13,0x60(%rsp)
  da7279:	mov    %r10,0x68(%rsp)
  da727e:	mov    %r13,0x70(%rsp)
  da7283:	mov    %r10,0x78(%rsp)
  da7288:	mov    %r13,0x80(%rsp)
  da7290:	mov    %r10,0x88(%rsp)
  da7298:	mov    %r13,0x90(%rsp)
  da72a0:	mov    %r10,0x98(%rsp)
  da72a8:	mov    %r13,0xa0(%rsp)
  da72b0:	mov    %r10,0xa8(%rsp)
  da72b8:	mov    %r13,0xb0(%rsp)
  da72c0:	mov    %r10,0xb8(%rsp)
  da72c8:	mov    %r13,0xc0(%rsp)
  da72d0:	mov    %r10,0xc8(%rsp)
  da72d8:	mov    %r13,0xd0(%rsp)
  da72e0:	mov    %r10,0xd8(%rsp)
  da72e8:	mov    %r13,0xe0(%rsp)
  da72f0:	mov    %r10,0xe8(%rsp)
  da72f8:	mov    %r13,0xf0(%rsp)
  da7300:	mov    %r10,0xf8(%rsp)
  da7308:	mov    %r13,0x100(%rsp)
  da7310:	mov    %r10,0x128(%rsp)
  da7318:	mov    %r10,0x108(%rsp)
  da7320:	cmp    $0x10,%rsi
  da7324:	mov    $0x10,%ebx
  da7329:	cmovb  %rsi,%rbx
  da732d:	mov    %r13,0x110(%rsp)
  da7335:	shl    $0x4,%ebx
  da7338:	xor    %esi,%esi
  da733a:	lea    (%rcx,%rcx,1),%r10
  da733e:	xchg   %ax,%ax
  da7340:	cmp    %rsi,%rbx
  da7343:	je     da736d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x1cd>
  da7345:	cmp    0x8(%rdi,%rsi,1),%r11
  da734a:	ja     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7350:	dec    %r15
  da7353:	mov    (%rdi,%rsi,1),%rbp
  da7357:	add    %r10,%rbp
  da735a:	mov    %rbp,0x18(%rsp,%rsi,1)
  da735f:	mov    %r13,0x20(%rsp,%rsi,1)
  da7364:	add    $0x10,%rsi
  da7368:	test   %r15,%r15
  da736b:	jne    da7340 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x1a0>
  da736d:	vbroadcasti128 -0xd92306(%rip),%ymm0        # 15070 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1230>
  da7376:	vmovdqu %ymm0,0x1d0(%rsp)
  da737f:	vmovdqu %ymm0,0x1f0(%rsp)
  da7388:	vmovdqu %ymm0,0x210(%rsp)
  da7391:	vmovdqu %ymm0,0x230(%rsp)
  da739a:	vmovdqu %ymm0,0x250(%rsp)
  da73a3:	vmovdqu %ymm0,0x270(%rsp)
  da73ac:	vmovdqu %ymm0,0x290(%rsp)
  da73b5:	vmovdqu %ymm0,0x2b0(%rsp)
  da73be:	mov    %r14,%rsi
  da73c1:	sub    %rcx,%rsi
  da73c4:	mov    0x1b0(%rsp),%r11
  da73cc:	cmp    %r8,%r11
  da73cf:	jae    da7408 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x268>
  da73d1:	cmp    %rcx,%r14
  da73d4:	setb   %dil
  da73d8:	cmp    %r8,%rsi
  da73db:	setb   %sil
  da73df:	or     %dil,%sil
  da73e2:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da73e8:	lea    (%rax,%rcx,2),%rax
  da73ec:	mov    %rax,0x1d0(%rsp)
  da73f4:	mov    %r8,0x1d8(%rsp)
  da73fc:	cmp    $0x1,%rdx
  da7400:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7406:	jmp    da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
  da7408:	cmp    %rcx,%r14
  da740b:	setb   %dil
  da740f:	cmp    %r8,%rsi
  da7412:	setb   %r10b
  da7416:	or     %dil,%r10b
  da7419:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da741f:	lea    (%rax,%rcx,2),%rax
  da7423:	mov    %rax,0x1d0(%rsp)
  da742b:	mov    %r8,0x1d8(%rsp)
  da7433:	cmp    $0x1,%rdx
  da7437:	jne    da7b46 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x9a6>
  da743d:	mov    (%r9),%r14
  da7440:	test   %r14,%r14
  da7443:	jne    da7478 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x2d8>
  da7445:	vpbroadcastq 0x8(%r9),%ymm0
  da744b:	vmovdqu %ymm0,0x310(%rsp)
  da7454:	lea    0x558(%rsp),%rdi
  da745c:	lea    0x310(%rsp),%rsi
  da7464:	mov    %r9,%rbx
  da7467:	mov    %rdx,%r15
  da746a:	vzeroupper
  da746d:	call   da7e20 <_RNvNvNvNtCsilixuIrojZt_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  da7472:	mov    %r15,%rdx
  da7475:	mov    %rbx,%r9
  da7478:	shr    $0x4,%r12
  da747c:	mov    $0x1,%al
  da747e:	je     da7210 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x70>
  da7484:	mov    %rdx,(%rsp)
  da7488:	lea    0x558(%rsp),%rax
  da7490:	movzwl 0x7d8(%rsp),%ecx
  da7498:	vmovd  %ecx,%xmm0
  da749c:	vpbroadcastw %xmm0,%ymm0
  da74a1:	vmovdqu %ymm0,0x2f0(%rsp)
  da74aa:	xor    %ebx,%ebx
  da74ac:	movq   $0x0,0x8(%rsp)
  da74b5:	mov    %r14,0x120(%rsp)
  da74bd:	mov    %rax,0x10(%rsp)
  da74c2:	test   %r14,%r14
  da74c5:	je     da7511 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x371>
  da74c7:	lea    0x2d0(%rsp),%rdi
  da74cf:	mov    %r9,%rsi
  da74d2:	mov    0x8(%rsp),%rdx
  da74d7:	mov    %r9,%r15
  da74da:	vzeroupper
  da74dd:	call   da7d20 <_RNvMCsilixuIrojZt_15splot_lr_kernelNtB2_7Classes5group>
  da74e2:	cmpq   $0x0,0x2d0(%rsp)
  da74eb:	je     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da74f1:	lea    0x310(%rsp),%rbp
  da74f9:	mov    %rbp,%rdi
  da74fc:	lea    0x2d0(%rsp),%rsi
  da7504:	call   da7e20 <_RNvNvNvNtCsilixuIrojZt_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  da7509:	mov    %r15,%r9
  da750c:	mov    %rbp,0x10(%rsp)
  da7511:	mov    %r13,%rcx
  da7514:	sub    %rbx,%rcx
  da7517:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da751d:	cmp    $0x18,%rcx
  da7521:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7527:	mov    0x128(%rsp),%rcx
  da752f:	lea    (%rcx,%rbx,2),%rcx
  da7533:	vmovq  %rcx,%xmm0
  da7538:	vpbroadcastq %xmm0,%ymm0
  da753d:	vmovdqu %ymm0,0x178(%rsp)
  da7546:	mov    %rcx,0x198(%rsp)
  da754e:	mov    %rcx,0x1a0(%rsp)
  da7556:	mov    %rcx,0x1a8(%rsp)
  da755e:	mov    0x20(%rsp),%rdx
  da7563:	sub    %rbx,%rdx
  da7566:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da756c:	cmp    $0x18,%rdx
  da7570:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7576:	lea    (%rbx,%rbx,1),%rdx
  da757a:	mov    0x18(%rsp),%rcx
  da757f:	add    %rdx,%rcx
  da7582:	mov    %rcx,0x130(%rsp)
  da758a:	mov    0x30(%rsp),%rsi
  da758f:	sub    %rbx,%rsi
  da7592:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7598:	cmp    $0x18,%rsi
  da759c:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da75a2:	mov    0x28(%rsp),%rcx
  da75a7:	add    %rdx,%rcx
  da75aa:	mov    %rcx,0x138(%rsp)
  da75b2:	mov    0x40(%rsp),%rsi
  da75b7:	sub    %rbx,%rsi
  da75ba:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da75c0:	cmp    $0x18,%rsi
  da75c4:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da75ca:	mov    0x38(%rsp),%rcx
  da75cf:	add    %rdx,%rcx
  da75d2:	mov    %rcx,0x140(%rsp)
  da75da:	mov    0x50(%rsp),%rsi
  da75df:	sub    %rbx,%rsi
  da75e2:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da75e8:	cmp    $0x18,%rsi
  da75ec:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da75f2:	mov    0x48(%rsp),%rcx
  da75f7:	add    %rdx,%rcx
  da75fa:	mov    %rcx,0x148(%rsp)
  da7602:	mov    0x60(%rsp),%rsi
  da7607:	sub    %rbx,%rsi
  da760a:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7610:	cmp    $0x18,%rsi
  da7614:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da761a:	mov    0x58(%rsp),%rcx
  da761f:	add    %rdx,%rcx
  da7622:	mov    %rcx,0x150(%rsp)
  da762a:	mov    0x70(%rsp),%rsi
  da762f:	sub    %rbx,%rsi
  da7632:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7638:	cmp    $0x18,%rsi
  da763c:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7642:	mov    0x68(%rsp),%rcx
  da7647:	add    %rdx,%rcx
  da764a:	mov    %rcx,0x158(%rsp)
  da7652:	mov    0x80(%rsp),%rsi
  da765a:	sub    %rbx,%rsi
  da765d:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7663:	cmp    $0x18,%rsi
  da7667:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da766d:	mov    0x78(%rsp),%rcx
  da7672:	add    %rdx,%rcx
  da7675:	mov    %rcx,0x160(%rsp)
  da767d:	mov    0x90(%rsp),%rsi
  da7685:	sub    %rbx,%rsi
  da7688:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da768e:	cmp    $0x18,%rsi
  da7692:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7698:	mov    0x88(%rsp),%rcx
  da76a0:	add    %rdx,%rcx
  da76a3:	mov    %rcx,0x168(%rsp)
  da76ab:	mov    0xa0(%rsp),%rsi
  da76b3:	sub    %rbx,%rsi
  da76b6:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da76bc:	cmp    $0x18,%rsi
  da76c0:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da76c6:	mov    0x98(%rsp),%rcx
  da76ce:	add    %rdx,%rcx
  da76d1:	mov    %rcx,0x170(%rsp)
  da76d9:	cmpq   $0x1,(%rsp)
  da76de:	je     da785d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6bd>
  da76e4:	mov    0xb0(%rsp),%rsi
  da76ec:	sub    %rbx,%rsi
  da76ef:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da76f5:	cmp    $0x18,%rsi
  da76f9:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da76ff:	mov    0xa8(%rsp),%rcx
  da7707:	add    %rdx,%rcx
  da770a:	mov    %rcx,0x178(%rsp)
  da7712:	cmpq   $0x2,(%rsp)
  da7717:	je     da785d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6bd>
  da771d:	mov    0xc0(%rsp),%rsi
  da7725:	sub    %rbx,%rsi
  da7728:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da772e:	cmp    $0x18,%rsi
  da7732:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7738:	mov    0xb8(%rsp),%rcx
  da7740:	add    %rdx,%rcx
  da7743:	mov    %rcx,0x180(%rsp)
  da774b:	cmpq   $0x3,(%rsp)
  da7750:	je     da785d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6bd>
  da7756:	mov    0xd0(%rsp),%rsi
  da775e:	sub    %rbx,%rsi
  da7761:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7767:	cmp    $0x18,%rsi
  da776b:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7771:	mov    0xc8(%rsp),%rcx
  da7779:	add    %rdx,%rcx
  da777c:	mov    %rcx,0x188(%rsp)
  da7784:	cmpq   $0x4,(%rsp)
  da7789:	je     da785d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6bd>
  da778f:	mov    0xe0(%rsp),%rsi
  da7797:	sub    %rbx,%rsi
  da779a:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da77a0:	cmp    $0x18,%rsi
  da77a4:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da77aa:	mov    0xd8(%rsp),%rcx
  da77b2:	add    %rdx,%rcx
  da77b5:	mov    %rcx,0x190(%rsp)
  da77bd:	cmpq   $0x5,(%rsp)
  da77c2:	je     da785d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6bd>
  da77c8:	mov    0xf0(%rsp),%rsi
  da77d0:	sub    %rbx,%rsi
  da77d3:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da77d9:	cmp    $0x18,%rsi
  da77dd:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da77e3:	mov    0xe8(%rsp),%rcx
  da77eb:	add    %rdx,%rcx
  da77ee:	mov    %rcx,0x198(%rsp)
  da77f6:	cmpq   $0x6,(%rsp)
  da77fb:	je     da785d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6bd>
  da77fd:	mov    0x100(%rsp),%rsi
  da7805:	sub    %rbx,%rsi
  da7808:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da780e:	cmp    $0x18,%rsi
  da7812:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7818:	mov    0xf8(%rsp),%rcx
  da7820:	add    %rdx,%rcx
  da7823:	mov    %rcx,0x1a0(%rsp)
  da782b:	cmpq   $0x7,(%rsp)
  da7830:	je     da785d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6bd>
  da7832:	mov    0x110(%rsp),%rsi
  da783a:	sub    %rbx,%rsi
  da783d:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7843:	cmp    $0x18,%rsi
  da7847:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da784d:	add    0x108(%rsp),%rdx
  da7855:	mov    %rdx,0x1a8(%rsp)
  da785d:	lea    0x10(%rbx),%rax
  da7861:	mov    %rax,0x118(%rsp)
  da7869:	dec    %r12
  da786c:	incq   0x8(%rsp)
  da7871:	lea    0x1d8(%rsp),%rsi
  da7879:	xor    %edi,%edi
  da787b:	mov    (%rsi),%rdx
  da787e:	sub    %rbx,%rdx
  da7881:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7887:	cmp    $0x10,%rdx
  da788b:	jb     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7891:	cmp    $0x7,%rdi
  da7895:	ja     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da789b:	mov    0x158(%rsp,%rdi,8),%r10
  da78a3:	mov    0x148(%rsp,%rdi,8),%r11
  da78ab:	mov    0x150(%rsp,%rdi,8),%r8
  da78b3:	vmovdqu (%r8),%ymm4
  da78b8:	vmovdqu 0x2(%r8),%ymm6
  da78be:	mov    0x160(%rsp,%rdi,8),%rdx
  da78c6:	mov    0x140(%rsp,%rdi,8),%r15
  da78ce:	vmovdqu 0x6(%r15),%ymm11
  da78d4:	vmovdqu 0xa(%r15),%ymm10
  da78da:	mov    0x168(%rsp,%rdi,8),%r14
  da78e2:	mov    0x130(%rsp,%rdi,8),%rcx
  da78ea:	mov    %rbx,%rax
  da78ed:	mov    0x138(%rsp,%rdi,8),%rbx
  da78f5:	mov    0x170(%rsp,%rdi,8),%rbp
  da78fd:	vmovdqu 0x8(%rcx),%ymm2
  da7902:	vmovdqu 0x2(%rbx),%ymm0
  da7907:	vpaddw 0xe(%r14),%ymm0,%ymm0
  da790d:	vmovdqu %ymm0,0x1b0(%rsp)
  da7916:	vmovdqu 0xe(%rbx),%ymm1
  da791b:	vpaddw 0x2(%r14),%ymm1,%ymm1
  da7921:	vpunpckhwd %ymm1,%ymm0,%ymm5
  da7925:	mov    0x10(%rsp),%rcx
  da792a:	vpmaddwd 0x1e0(%rcx),%ymm5,%ymm13
  da7932:	vpaddw 0x8(%rbp),%ymm2,%ymm2
  da7937:	vmovdqu 0x8(%rbx),%ymm5
  da793c:	mov    %rax,%rbx
  da793f:	vpaddw 0x10(%r8),%ymm4,%ymm4
  da7945:	vpunpckhwd %ymm4,%ymm2,%ymm7
  da7949:	vpmaddwd 0x1a0(%rcx),%ymm7,%ymm14
  da7951:	vpaddw 0x8(%r14),%ymm5,%ymm5
  da7957:	vmovdqu 0x4(%r11),%ymm7
  da795d:	vpaddw 0xe(%r8),%ymm6,%ymm6
  da7963:	vpunpckhwd %ymm6,%ymm5,%ymm8
  da7967:	vpmaddwd 0x160(%rcx),%ymm8,%ymm15
  da796f:	vpaddw 0xc(%r10),%ymm7,%ymm7
  da7975:	vmovdqu 0xc(%r11),%ymm8
  da797b:	vpaddw 0x4(%r10),%ymm8,%ymm8
  da7981:	vpunpckhwd %ymm8,%ymm7,%ymm9
  da7986:	vpmaddwd 0x120(%rcx),%ymm9,%ymm3
  da798e:	vpaddw 0xa(%rdx),%ymm11,%ymm9
  da7993:	vmovdqu 0x6(%r11),%ymm11
  da7999:	vpaddw 0x6(%rdx),%ymm10,%ymm10
  da799e:	vpunpckhwd %ymm10,%ymm9,%ymm12
  da79a3:	vpmaddwd 0xe0(%rcx),%ymm12,%ymm0
  da79ab:	vpaddw 0xa(%r10),%ymm11,%ymm11
  da79b1:	vmovdqu 0x6(%r10),%ymm12
  da79b7:	vpaddw 0xa(%r11),%ymm12,%ymm12
  da79bd:	vpaddd %ymm13,%ymm14,%ymm14
  da79c2:	vpunpckhwd %ymm12,%ymm11,%ymm13
  da79c7:	vpmaddwd 0xa0(%rcx),%ymm13,%ymm13
  da79cf:	vpaddd %ymm3,%ymm15,%ymm3
  da79d3:	vmovdqu 0x8(%r15),%ymm15
  da79d9:	vpaddw 0x8(%rdx),%ymm15,%ymm15
  da79de:	vpaddd %ymm3,%ymm14,%ymm3
  da79e2:	vmovdqu 0x4(%r8),%ymm14
  da79e8:	vpaddw 0xc(%r8),%ymm14,%ymm14
  da79ee:	vpaddd %ymm0,%ymm13,%ymm0
  da79f2:	vpunpckhwd %ymm14,%ymm15,%ymm13
  da79f7:	vpmaddwd 0x60(%rcx),%ymm13,%ymm13
  da79fc:	vpaddd %ymm0,%ymm13,%ymm0
  da7a00:	vpaddd %ymm0,%ymm3,%ymm3
  da7a04:	vmovdqu 0x1b0(%rsp),%ymm0
  da7a0d:	vpunpcklwd %ymm1,%ymm0,%ymm0
  da7a11:	vpunpcklwd %ymm4,%ymm2,%ymm1
  da7a15:	vpmaddwd 0x1c0(%rcx),%ymm0,%ymm0
  da7a1d:	vpmaddwd 0x180(%rcx),%ymm1,%ymm1
  da7a25:	vpaddd %ymm0,%ymm1,%ymm0
  da7a29:	vpunpcklwd %ymm6,%ymm5,%ymm1
  da7a2d:	vpmaddwd 0x140(%rcx),%ymm1,%ymm1
  da7a35:	vpunpcklwd %ymm8,%ymm7,%ymm2
  da7a3a:	vpmaddwd 0x100(%rcx),%ymm2,%ymm2
  da7a42:	vpaddd %ymm2,%ymm1,%ymm1
  da7a46:	vpaddd %ymm1,%ymm0,%ymm0
  da7a4a:	vpunpcklwd %ymm10,%ymm9,%ymm1
  da7a4f:	vpunpcklwd %ymm12,%ymm11,%ymm2
  da7a54:	vmovdqu 0x6(%r8),%ymm4
  da7a5a:	vpunpcklwd %ymm14,%ymm15,%ymm5
  da7a5f:	vmovdqu 0x8(%r11),%ymm6
  da7a65:	vpaddw 0x8(%r10),%ymm6,%ymm6
  da7a6b:	vpaddw 0xa(%r8),%ymm4,%ymm4
  da7a71:	vpmaddwd 0xc0(%rcx),%ymm1,%ymm1
  da7a79:	vpmaddwd 0x80(%rcx),%ymm2,%ymm2
  da7a81:	vpmaddwd 0x40(%rcx),%ymm5,%ymm5
  da7a86:	vpaddd %ymm2,%ymm1,%ymm1
  da7a8a:	vpaddd %ymm5,%ymm1,%ymm1
  da7a8e:	vpunpckhwd %ymm4,%ymm6,%ymm2
  da7a92:	vpaddd %ymm1,%ymm0,%ymm0
  da7a96:	vpunpcklwd %ymm4,%ymm6,%ymm1
  da7a9a:	vpmaddwd (%rcx),%ymm1,%ymm1
  da7a9e:	vmovdqu 0x8(%r8),%ymm4
  da7aa4:	vpunpcklwd -0xd8d18c(%rip),%ymm4,%ymm5        # 1a920 <anon.d0b4188290527594ec9c3077380d8c05.2236.llvm.18078306828565754329+0x260>
  da7aac:	vpshufb -0xd8c2b5(%rip),%ymm5,%ymm5        # 1b800 <anon.46faa55fc0c0e7039c2263dc0e03ad74.181.llvm.15643780285783194673+0x540>
  da7ab5:	vpmaddwd 0x200(%rcx),%ymm5,%ymm5
  da7abd:	vpaddd %ymm5,%ymm1,%ymm1
  da7ac1:	vpaddd %ymm1,%ymm0,%ymm0
  da7ac5:	vpmaddwd 0x20(%rcx),%ymm2,%ymm1
  da7aca:	vpunpckhwd -0xd8bd72(%rip),%ymm4,%ymm2        # 1bd60 <anon.dfffc8809c62f00655f8db48cb5f601e.1518.llvm.287868192297488560+0x1c0>
  da7ad2:	vpshufb -0xd8d71b(%rip),%ymm2,%ymm2        # 1a3c0 <anon.46faa55fc0c0e7039c2263dc0e03ad74.183.llvm.15643780285783194673+0x1a0>
  da7adb:	vpmaddwd 0x220(%rcx),%ymm2,%ymm2
  da7ae3:	vpaddd %ymm2,%ymm1,%ymm1
  da7ae7:	vpaddd %ymm1,%ymm3,%ymm1
  da7aeb:	vpsrad $0x7,%ymm0,%ymm0
  da7af0:	vpsrad $0x7,%ymm1,%ymm1
  da7af5:	vpackusdw %ymm1,%ymm0,%ymm0
  da7afa:	mov    -0x8(%rsi),%rcx
  da7afe:	vpminuw 0x2f0(%rsp),%ymm0,%ymm0
  da7b08:	vmovdqu %ymm0,(%rcx,%rax,2)
  da7b0d:	inc    %rdi
  da7b10:	add    $0x10,%rsi
  da7b14:	cmp    %rdi,(%rsp)
  da7b18:	jne    da787b <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6db>
  da7b1e:	mov    0x118(%rsp),%rbx
  da7b26:	test   %r12,%r12
  da7b29:	mov    0x120(%rsp),%r14
  da7b31:	lea    0x558(%rsp),%rax
  da7b39:	jne    da74bd <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x31d>
  da7b3f:	mov    $0x1,%al
  da7b41:	jmp    da7210 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x70>
  da7b46:	sub    %r11,%rsi
  da7b49:	setb   %cl
  da7b4c:	cmp    %r8,%rsi
  da7b4f:	setb   %dil
  da7b53:	or     %cl,%dil
  da7b56:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7b5c:	lea    (%rax,%r11,2),%rax
  da7b60:	mov    %rax,0x1e0(%rsp)
  da7b68:	mov    %r8,0x1e8(%rsp)
  da7b70:	cmp    $0x2,%rdx
  da7b74:	je     da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
  da7b7a:	sub    %r11,%rsi
  da7b7d:	setb   %cl
  da7b80:	cmp    %r8,%rsi
  da7b83:	setb   %dil
  da7b87:	or     %cl,%dil
  da7b8a:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7b90:	lea    (%rax,%r11,2),%rax
  da7b94:	mov    %rax,0x1f0(%rsp)
  da7b9c:	mov    %r8,0x1f8(%rsp)
  da7ba4:	cmp    $0x3,%rdx
  da7ba8:	je     da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
  da7bae:	sub    %r11,%rsi
  da7bb1:	setb   %cl
  da7bb4:	cmp    %r8,%rsi
  da7bb7:	setb   %dil
  da7bbb:	or     %cl,%dil
  da7bbe:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7bc4:	lea    (%rax,%r11,2),%rax
  da7bc8:	mov    %rax,0x200(%rsp)
  da7bd0:	mov    %r8,0x208(%rsp)
  da7bd8:	cmp    $0x4,%rdx
  da7bdc:	je     da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
  da7be2:	mov    %rdx,%rcx
  da7be5:	mov    %r9,%rdi
  da7be8:	sub    %r11,%rsi
  da7beb:	setb   %dl
  da7bee:	cmp    %r8,%rsi
  da7bf1:	setb   %r9b
  da7bf5:	or     %dl,%r9b
  da7bf8:	jne    da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7bfe:	mov    0x1b0(%rsp),%r11
  da7c06:	lea    (%rax,%r11,2),%r10
  da7c0a:	mov    %r10,0x210(%rsp)
  da7c12:	mov    %r8,0x218(%rsp)
  da7c1a:	mov    %rcx,%rdx
  da7c1d:	cmp    $0x5,%rcx
  da7c21:	mov    %rdi,%r9
  da7c24:	je     da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
  da7c2a:	xor    %eax,%eax
  da7c2c:	sub    %r11,%rsi
  da7c2f:	lea    (%r10,%r11,2),%r10
  da7c33:	mov    $0x0,%edx
  da7c38:	cmovae %r10,%rdx
  da7c3c:	test   %rdx,%rdx
  da7c3f:	sete   %r9b
  da7c43:	cmp    %r8,%rsi
  da7c46:	setb   %r11b
  da7c4a:	or     %r9b,%r11b
  da7c4d:	jne    da7210 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x70>
  da7c53:	mov    %rdx,0x220(%rsp)
  da7c5b:	mov    %r8,0x228(%rsp)
  da7c63:	mov    %rcx,%rdx
  da7c66:	cmp    $0x6,%rcx
  da7c6a:	mov    %rdi,%r9
  da7c6d:	mov    0x1b0(%rsp),%r11
  da7c75:	je     da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
  da7c7b:	xor    %eax,%eax
  da7c7d:	sub    %r11,%rsi
  da7c80:	lea    (%r10,%r11,2),%r10
  da7c84:	mov    $0x0,%edx
  da7c89:	cmovae %r10,%rdx
  da7c8d:	test   %rdx,%rdx
  da7c90:	sete   %r9b
  da7c94:	cmp    %r8,%rsi
  da7c97:	setb   %r11b
  da7c9b:	or     %r9b,%r11b
  da7c9e:	jne    da7210 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x70>
  da7ca4:	mov    %rdx,0x230(%rsp)
  da7cac:	mov    %r8,0x238(%rsp)
  da7cb4:	mov    %rcx,%rdx
  da7cb7:	cmp    $0x7,%rcx
  da7cbb:	mov    %rdi,%r9
  da7cbe:	mov    0x1b0(%rsp),%r11
  da7cc6:	je     da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
  da7ccc:	xor    %eax,%eax
  da7cce:	sub    %r11,%rsi
  da7cd1:	lea    (%r10,%r11,2),%rdx
  da7cd5:	cmovb  %rax,%rdx
  da7cd9:	setae  %al
  da7cdc:	cmp    %r8,%rsi
  da7cdf:	setb   %sil
  da7ce3:	test   %rdx,%rdx
  da7ce6:	je     da720e <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x6e>
  da7cec:	and    %sil,%al
  da7cef:	mov    $0x0,%eax
  da7cf4:	jne    da7210 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x70>
  da7cfa:	mov    %rdx,0x240(%rsp)
  da7d02:	mov    %r8,0x248(%rsp)
  da7d0a:	mov    %rdi,%r9
  da7d0d:	mov    %rcx,%rdx
  da7d10:	jmp    da743d <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run+0x29d>
