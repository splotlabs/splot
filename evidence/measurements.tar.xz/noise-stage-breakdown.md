# Noise_Ocean AVX2 instruction attribution

The paired playback median for `f03b06e2` was 23.98% slower than shipped `10279846`, with a 95% paired interval of +4.91% to +34.77%. The matched Callgrind traces count guest instructions for the same 16 official 8-bit frames, one worker, frame delay one, and null output. They measure an instruction increase of 18.95%. The traces cannot assign the difference between these two percentages to native cycles or hardware events.

Both release binaries were stripped. The stage column uses the closest available fully symbolized profile, `07cdddce`, which is 0.227% below the exact `f03b06e2` total. These revisions differ in source as well as code generation. Selected rows below verify identical or near-identical costs for the major CDEF and TIP call paths and quantify the difference on coefficient parsing directly. There is no text-identical unstripped shipped binary in the available artifacts.

Regenerate with `python3 qualification-1882/noise-stage-breakdown.py`. The script matches stripped stage roots to the symbolized call graph using caller structure and matching call counts. It then walks the graph and assigns each function's exclusive instructions once. Semantic transform roots and known library memory/allocator functions receive separate labels. Functions with conflicting reachable stages or insufficient evidence remain uncategorized. Inline memory work stays in the stage containing it. Both stage-column totals are asserted against their respective trace summaries.

## Exclusive stage and matched edge counts

| Stage | Shipped 10279846 | Symbolized 07cdddce | Excess Ir |
|---|---:|---:|---:|
| Entropy/parser | 156,594,950 | 170,691,212 | +14,096,262 |
| Motion/prediction | 440,954,627 | 546,814,608 | +105,859,981 |
| Transforms/residual math | 35,189,724 | 39,157,279 | +3,967,555 |
| Filters | 554,765,410 | 652,282,209 | +97,516,799 |
| Memory/allocator functions | 101,076,809 | 102,095,436 | +1,018,627 |
| Output/scheduling/frame setup | 7,281,943 | 7,447,688 | +165,745 |
| Uncategorized/shared | 10,296,180 | 31,670,245 | +21,374,065 |
| Total | 1,306,159,643 | 1,550,158,677 | +243,999,034 |

Exact stripped f03 total: 1,553,670,804 (+247,511,161, +18.95% versus shipped; +3,512,127, +0.227% versus symbolized 07cdddce).

These are inclusive call edges in separate branches of the profile. The costs are already represented in the exclusive stage totals above.

| Selected call edge | Calls in each trace | Shipped | Symbolized 07cdddce | Exact f03 | f03 excess Ir |
|---|---:|---:|---:|---:|---:|
| TIP motion-field units | 14 | 25,127,545 | 91,474,414 | 91,474,414 | +66,346,869 |
| CDEF segment filter | 88,876 | 173,025,432 | 187,305,879 | 187,305,879 | +14,280,447 |
| CDEF packed chroma gather | 88,876 | 31,017,724 | 48,792,924 | 48,792,924 | +17,775,200 |
| Luma Wiener filter | 1,151 | 126,600,630 | 142,593,483 | 142,593,077 | +15,992,447 |
| Coefficient high-frequency pass | 7,651 | 48,694,513 | 55,285,219 | 61,474,026 | +12,779,513 |

## Where the instructions go

- Motion/prediction and filters account for 83.3% of the symbolized gap. The 14 TIP field entries alone account for 66.35M of the exact f03 excess. The symbolized candidate calls the cross-stencil closure 170,100 times for 33.85M inclusive instructions and the scaling array helper 113,400 times for 26.65M. Both callees call narrow AVX2 primitives out of line. Their counts and costs persist at corresponding stripped addresses in f03. The shipped TIP leaf spends 24.98M instructions in its own body. The ordinary-build TIP field experiment in `tip-field/noise16.cg` later recovers 64.15M overall instructions from f03, down to 1,489,522,483.
- The candidate CDEF segment filter's `cdef_filter_rows_wide8` variant for clamped, primary-only filtering grew from 14.54M to 20.32M at 94,692 calls. The candidate splits each call between a shim and vectorized body. The packed chroma gather still calls the `pair_ranges` callback 177,752 times for 8.89M inclusive instructions. These cases contribute to the measured filter gap alongside luma restoration.
- The coefficient high-frequency pass accounts for 12.78M extra instructions at the same 7,651 calls in f03. The symbolized proxy attributes 6.59M to this edge. Use the exact edge to interpret this branch instead of equating the proxy's entropy total with f03's.
- Recognized memory and allocator functions and identified output/scheduling/setup account for 1.18M extra instructions combined in the stage table. Known shared vector helpers remain in the uncategorized bucket. This comparison alone does not measure cache behavior or native stall cycles and excludes output-formatting work because the invocation uses null output.

The measured TIP improvement demonstrates that the ordinary portable build can remove a high-cost repeated boundary. The data supports retaining startup dispatch while fixing named kernels with matched evidence. A wider architecture change would need its own paired native-time and instruction evidence across multiple kernels and streams.
