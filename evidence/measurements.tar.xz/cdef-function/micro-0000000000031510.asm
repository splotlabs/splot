
<WORKTREES>/qualification-1882/cdef-function/micro-target/release/cdef-micro:     file format elf64-x86-64


Disassembly of section .text:

0000000000031510 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAAINtNtNtCs9DW4HO7zhlu_13fearless_simd9generated10simd_types5u8x16NtNtBE_4avx24Avx2Ej2_B1T_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitAINtBC_5u16x8B1B_Ej3_ENCINvMB2b_B28_10wrap_mut_1By_NCINvCs9K6TmCzReAo_15splot_cdef_base11gather_withB1B_NCNCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed00NCINvB3J_18gather_packed_withB1B_B4v_E0Es0_0E0EB4B_>:
   31510:	push   %rbp
   31511:	mov    %rsp,%rbp
   31514:	push   %r15
   31516:	push   %r14
   31518:	push   %r13
   3151a:	push   %r12
   3151c:	push   %rbx
   3151d:	and    $0xffffffffffffffe0,%rsp
   31521:	sub    $0x280,%rsp
   31528:	mov    %rdi,%rbx
   3152b:	movaps (%rsi),%xmm0
   3152e:	movaps 0x10(%rsi),%xmm1
   31532:	movaps %xmm1,0xe0(%rsp)
   3153a:	movaps 0x20(%rsi),%xmm1
   3153e:	movaps %xmm1,0xf0(%rsp)
   31546:	movaps 0x30(%rsi),%xmm1
   3154a:	movaps %xmm1,0x100(%rsp)
   31552:	lea    0x1c0(%rsp),%r14
   3155a:	mov    %r14,%rdi
   3155d:	movaps %xmm0,%xmm1
   31560:	call   31bf0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
   31565:	lea    0x1e0(%rsp),%r15
   3156d:	mov    %r15,%rdi
   31570:	mov    %r14,%rsi
   31573:	call   31bc0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
   31578:	lea    0xc0(%rsp),%rdi
   31580:	mov    %r15,%rsi
   31583:	call   31be0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
   31588:	lea    0x1c0(%rsp),%r12
   31590:	mov    %r12,%rdi
   31593:	movaps 0xe0(%rsp),%xmm0
   3159b:	movaps %xmm0,%xmm1
   3159e:	call   31bf0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
   315a3:	lea    0x220(%rsp),%r13
   315ab:	mov    %r13,%rdi
   315ae:	mov    %r12,%rsi
   315b1:	call   31bc0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
   315b6:	lea    0x1a0(%rsp),%rdi
   315be:	mov    %r13,%rsi
   315c1:	call   31be0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
   315c6:	movaps 0xc0(%rsp),%xmm0
   315ce:	movaps 0xd0(%rsp),%xmm1
   315d6:	movaps %xmm0,0x170(%rsp)
   315de:	movaps %xmm1,0x180(%rsp)
   315e6:	movaps 0x1b0(%rsp),%xmm2
   315ee:	movaps %xmm2,0x190(%rsp)
   315f6:	movaps %xmm0,0x60(%rsp)
   315fb:	movaps %xmm1,0x70(%rsp)
   31600:	movaps %xmm2,0x80(%rsp)
   31608:	movaps 0x60(%rsp),%xmm0
   3160d:	movaps 0x70(%rsp),%xmm1
   31612:	movaps 0x80(%rsp),%xmm2
   3161a:	movaps %xmm2,0x50(%rsp)
   3161f:	movaps %xmm1,0x40(%rsp)
   31624:	movaps %xmm0,0x30(%rsp)
   31629:	movaps 0x30(%rsp),%xmm0
   3162e:	movaps 0x40(%rsp),%xmm1
   31633:	movaps 0x50(%rsp),%xmm2
   31638:	movaps %xmm2,0x20(%rsp)
   3163d:	movaps %xmm1,0x10(%rsp)
   31642:	movaps %xmm0,(%rsp)
   31646:	movaps (%rsp),%xmm0
   3164a:	movaps 0x10(%rsp),%xmm1
   3164f:	movaps 0x20(%rsp),%xmm2
   31654:	movaps %xmm2,0xb0(%rsp)
   3165c:	movaps %xmm1,0xa0(%rsp)
   31664:	movaps %xmm0,0x90(%rsp)
   3166c:	movaps 0x90(%rsp),%xmm0
   31674:	movaps 0xa0(%rsp),%xmm1
   3167c:	movaps 0xb0(%rsp),%xmm2
   31684:	movaps %xmm2,0x130(%rsp)
   3168c:	movaps %xmm1,0x120(%rsp)
   31694:	movaps %xmm0,0x110(%rsp)
   3169c:	mov    %r14,%rdi
   3169f:	movaps 0xf0(%rsp),%xmm0
   316a7:	movaps %xmm0,%xmm1
   316aa:	call   31bf0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
   316af:	mov    %r15,%rdi
   316b2:	mov    %r14,%rsi
   316b5:	call   31bc0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
   316ba:	lea    0xc0(%rsp),%rdi
   316c2:	mov    %r15,%rsi
   316c5:	call   31be0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
   316ca:	mov    %r12,%rdi
   316cd:	movaps 0x100(%rsp),%xmm0
   316d5:	movaps %xmm0,%xmm1
   316d8:	call   31bf0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
   316dd:	mov    %r13,%rdi
   316e0:	mov    %r12,%rsi
   316e3:	call   31bc0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
   316e8:	lea    0x1a0(%rsp),%rdi
   316f0:	mov    %r13,%rsi
   316f3:	call   31be0 <_RNvNvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
   316f8:	movaps 0xc0(%rsp),%xmm0
   31700:	movaps 0xd0(%rsp),%xmm1
   31708:	movaps %xmm0,0x170(%rsp)
   31710:	movaps %xmm1,0x180(%rsp)
   31718:	movaps 0x1b0(%rsp),%xmm2
   31720:	movaps %xmm2,0x190(%rsp)
   31728:	movaps %xmm0,0x60(%rsp)
   3172d:	movaps %xmm1,0x70(%rsp)
   31732:	movaps %xmm2,0x80(%rsp)
   3173a:	movaps 0x60(%rsp),%xmm0
   3173f:	movaps 0x70(%rsp),%xmm1
   31744:	movaps 0x80(%rsp),%xmm2
   3174c:	movaps %xmm2,0x50(%rsp)
   31751:	movaps %xmm1,0x40(%rsp)
   31756:	movaps %xmm0,0x30(%rsp)
   3175b:	movaps 0x30(%rsp),%xmm0
   31760:	movaps 0x40(%rsp),%xmm1
   31765:	movaps 0x50(%rsp),%xmm2
   3176a:	movaps %xmm2,0x20(%rsp)
   3176f:	movaps %xmm1,0x10(%rsp)
   31774:	movaps %xmm0,(%rsp)
   31778:	movaps (%rsp),%xmm0
   3177c:	movaps 0x10(%rsp),%xmm1
   31781:	movaps 0x20(%rsp),%xmm2
   31786:	movaps %xmm2,0xb0(%rsp)
   3178e:	movaps %xmm1,0xa0(%rsp)
   31796:	movaps %xmm0,0x90(%rsp)
   3179e:	movaps 0x90(%rsp),%xmm0
   317a6:	movaps 0xa0(%rsp),%xmm1
   317ae:	movaps 0xb0(%rsp),%xmm2
   317b6:	movaps %xmm2,0x160(%rsp)
   317be:	movaps %xmm1,0x150(%rsp)
   317c6:	movaps %xmm0,0x140(%rsp)
   317ce:	movaps 0x160(%rsp),%xmm0
   317d6:	movaps %xmm0,0x50(%rbx)
   317da:	movaps 0x150(%rsp),%xmm0
   317e2:	movaps %xmm0,0x40(%rbx)
   317e6:	movaps 0x110(%rsp),%xmm0
   317ee:	movaps 0x120(%rsp),%xmm1
   317f6:	movaps 0x130(%rsp),%xmm2
   317fe:	movaps 0x140(%rsp),%xmm3
   31806:	movaps %xmm3,0x30(%rbx)
   3180a:	movaps %xmm2,0x20(%rbx)
   3180e:	movaps %xmm1,0x10(%rbx)
   31812:	movaps %xmm0,(%rbx)
   31815:	lea    -0x28(%rbp),%rsp
   31819:	pop    %rbx
   3181a:	pop    %r12
   3181c:	pop    %r13
   3181e:	pop    %r14
   31820:	pop    %r15
   31822:	pop    %rbp
   31823:	ret
