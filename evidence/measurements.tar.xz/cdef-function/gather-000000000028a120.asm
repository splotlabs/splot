
<WORKTREES>/qualification-1882/cdef-function/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

000000000028a120 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_>:
  28a120:	push   %rbp
  28a121:	push   %r15
  28a123:	push   %r14
  28a125:	push   %rbx
  28a126:	sub    $0x148,%rsp
  28a12d:	mov    %rdi,%rbx
  28a130:	mov    0x8(%rsi),%rax
  28a134:	mov    0x10(%rsi),%rcx
  28a138:	mov    (%rax),%rdi
  28a13b:	mov    0x8(%rax),%r8
  28a13f:	mov    0x10(%rax),%r9
  28a143:	mov    0x18(%rax),%r10
  28a147:	mov    (%rcx),%r11
  28a14a:	mov    $0x180,%r14d
  28a150:	add    0x18(%rsi),%r14
  28a154:	vpcmpeqd %xmm1,%xmm1,%xmm1
  28a158:	vpxor  %xmm0,%xmm0,%xmm0
  28a15c:	xor    %ecx,%ecx
  28a15e:	vmovdqa -0x273d66(%rip),%xmm4        # 16400 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2560>
  28a166:	vpxor  %xmm2,%xmm2,%xmm2
  28a16a:	vpcmpeqd %xmm3,%xmm3,%xmm3
  28a16e:	vpxor  %xmm5,%xmm5,%xmm5
  28a172:	vpcmpeqd %xmm6,%xmm6,%xmm6
  28a176:	vpxor  %xmm7,%xmm7,%xmm7
  28a17a:	vpcmpeqd %xmm8,%xmm8,%xmm8
  28a17f:	nop
  28a180:	mov    %rcx,%rax
  28a183:	mul    %r11
  28a186:	jo     28a461 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x341>
  28a18c:	mov    %r10,%rsi
  28a18f:	sub    %rax,%rsi
  28a192:	setb   %bpl
  28a196:	xor    %edx,%edx
  28a198:	mov    %r8,%r15
  28a19b:	sub    %rax,%r15
  28a19e:	jb     28a450 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
  28a1a4:	cmp    $0x14,%r15
  28a1a8:	jb     28a450 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
  28a1ae:	test   %bpl,%bpl
  28a1b1:	jne    28a450 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
  28a1b7:	cmp    $0x14,%rsi
  28a1bb:	jb     28a450 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
  28a1c1:	inc    %rcx
  28a1c4:	vmovdqu (%rdi,%rax,1),%xmm9
  28a1c9:	vmovdqu (%r9,%rax,1),%xmm10
  28a1cf:	vpminub %xmm9,%xmm8,%xmm8
  28a1d4:	vpmaxub %xmm7,%xmm9,%xmm7
  28a1d8:	vpminub %xmm6,%xmm10,%xmm6
  28a1dc:	vpmaxub %xmm5,%xmm10,%xmm5
  28a1e0:	vpunpckhbw %xmm10,%xmm9,%xmm11
  28a1e5:	vpunpcklbw %xmm10,%xmm9,%xmm9
  28a1ea:	vpxor  %xmm4,%xmm9,%xmm9
  28a1ee:	vmovdqu %xmm9,-0x180(%r14)
  28a1f7:	vpxor  %xmm4,%xmm11,%xmm9
  28a1fb:	vmovdqu %xmm9,-0x80(%r14)
  28a201:	vmovdqu 0x4(%r9,%rax,1),%xmm9
  28a208:	vmovdqu 0x4(%rdi,%rax,1),%xmm10
  28a20e:	vpminub %xmm3,%xmm10,%xmm3
  28a212:	vpmaxub %xmm2,%xmm10,%xmm2
  28a216:	vpminub %xmm1,%xmm9,%xmm1
  28a21a:	vpmaxub %xmm0,%xmm9,%xmm0
  28a21e:	vpunpckhbw %xmm9,%xmm10,%xmm11
  28a223:	vpunpcklbw %xmm9,%xmm10,%xmm9
  28a228:	vpxor  %xmm4,%xmm9,%xmm9
  28a22c:	vmovdqu %xmm9,-0x100(%r14)
  28a235:	vpxor  %xmm4,%xmm11,%xmm9
  28a239:	vmovdqu %xmm9,(%r14)
  28a23e:	add    $0x10,%r14
  28a242:	cmp    $0x8,%rcx
  28a246:	jne    28a180 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x60>
  28a24c:	vmovdqa %xmm8,0xc0(%rsp)
  28a255:	vmovdqa %xmm7,0x100(%rsp)
  28a25e:	vmovdqa %xmm6,0xe0(%rsp)
  28a267:	vmovdqa %xmm5,0x120(%rsp)
  28a270:	vmovdqa %xmm3,0xd0(%rsp)
  28a279:	vmovdqa %xmm2,0x110(%rsp)
  28a282:	vmovdqa %xmm1,0xf0(%rsp)
  28a28b:	vmovdqa %xmm0,0x130(%rsp)
  28a294:	mov    %rsp,%rdi
  28a297:	lea    0xc0(%rsp),%rsi
  28a29f:	call   289e00 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAAINtNtNtCscIM9z48VHAb_13fearless_simd9generated10simd_types5u8x16NtNtBE_4avx24Avx2Ej2_B1T_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitAINtBC_5u16x8B1B_Ej3_ENCINvMB2b_B28_10wrap_mut_1By_NCINvCs6Qq1kSfbcoV_15splot_cdef_base11gather_withB1B_NCNCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed00NCINvB3J_18gather_packed_withB1B_B4v_E0Es0_0E0EB4B_>
  28a2a4:	vmovaps (%rsp),%xmm0
  28a2a9:	vmovaps %xmm0,0x60(%rsp)
  28a2af:	vmovaps 0x10(%rsp),%xmm0
  28a2b5:	vmovaps %xmm0,0x70(%rsp)
  28a2bb:	vmovaps 0x30(%rsp),%xmm0
  28a2c1:	vmovaps %xmm0,0x80(%rsp)
  28a2ca:	vmovaps 0x40(%rsp),%xmm0
  28a2d0:	vmovaps %xmm0,0x90(%rsp)
  28a2d9:	vphminposuw 0x20(%rsp),%xmm0
  28a2e0:	vmovdqa %xmm0,0xa0(%rsp)
  28a2e9:	vphminposuw 0x50(%rsp),%xmm0
  28a2f0:	vmovdqa %xmm0,0xb0(%rsp)
  28a2f9:	mov    %rsp,%rdi
  28a2fc:	lea    0x100(%rsp),%rsi
  28a304:	call   289e00 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAAINtNtNtCscIM9z48VHAb_13fearless_simd9generated10simd_types5u8x16NtNtBE_4avx24Avx2Ej2_B1T_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitAINtBC_5u16x8B1B_Ej3_ENCINvMB2b_B28_10wrap_mut_1By_NCINvCs6Qq1kSfbcoV_15splot_cdef_base11gather_withB1B_NCNCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed00NCINvB3J_18gather_packed_withB1B_B4v_E0Es0_0E0EB4B_>
  28a309:	vmovdqa (%rsp),%xmm3
  28a30e:	vmovdqa 0x10(%rsp),%xmm4
  28a314:	vmovdqa 0x30(%rsp),%xmm6
  28a31a:	vmovdqa 0x40(%rsp),%xmm2
  28a320:	vpcmpeqd %xmm0,%xmm0,%xmm0
  28a324:	vmovdqa 0x60(%rsp),%xmm5
  28a32a:	vphminposuw %xmm5,%xmm1
  28a32f:	vmovdqa 0x70(%rsp),%xmm9
  28a335:	vpalignr $0x8,%xmm5,%xmm9,%xmm5
  28a33b:	vphminposuw %xmm5,%xmm5
  28a340:	vpunpcklwd %xmm5,%xmm1,%xmm1
  28a344:	vpxor  %xmm0,%xmm3,%xmm5
  28a348:	vphminposuw %xmm5,%xmm5
  28a34d:	vpalignr $0x8,%xmm3,%xmm4,%xmm3
  28a353:	vpxor  %xmm0,%xmm3,%xmm3
  28a357:	vphminposuw %xmm3,%xmm3
  28a35c:	vpunpcklwd %xmm3,%xmm5,%xmm5
  28a360:	vmovdqa 0x80(%rsp),%xmm7
  28a369:	vphminposuw %xmm7,%xmm3
  28a36e:	vmovdqa 0x90(%rsp),%xmm8
  28a377:	vpalignr $0x8,%xmm7,%xmm8,%xmm7
  28a37d:	vphminposuw %xmm7,%xmm7
  28a382:	vpunpcklwd %xmm7,%xmm3,%xmm3
  28a386:	vpxor  %xmm0,%xmm6,%xmm7
  28a38a:	vphminposuw %xmm7,%xmm7
  28a38f:	vpalignr $0x8,%xmm6,%xmm2,%xmm6
  28a395:	vpxor  %xmm0,%xmm6,%xmm6
  28a399:	vphminposuw %xmm6,%xmm6
  28a39e:	vpunpcklwd %xmm6,%xmm7,%xmm6
  28a3a2:	vphminposuw %xmm9,%xmm7
  28a3a7:	vmovd  %xmm7,%eax
  28a3ab:	vpxor  %xmm0,%xmm4,%xmm4
  28a3af:	vphminposuw %xmm4,%xmm4
  28a3b4:	vmovd  %xmm4,%ecx
  28a3b8:	vphminposuw %xmm8,%xmm4
  28a3bd:	vmovd  %xmm4,%edx
  28a3c1:	vpxor  %xmm0,%xmm2,%xmm2
  28a3c5:	vphminposuw %xmm2,%xmm2
  28a3ca:	vmovd  %xmm2,%esi
  28a3ce:	vmovdqa 0xa0(%rsp),%xmm2
  28a3d7:	vmovd  %xmm2,%edi
  28a3db:	vpxor  0x20(%rsp),%xmm0,%xmm2
  28a3e1:	vphminposuw %xmm2,%xmm2
  28a3e6:	vmovd  %xmm2,%r8d
  28a3eb:	vmovdqa 0xb0(%rsp),%xmm2
  28a3f4:	vmovd  %xmm2,%r9d
  28a3f9:	vpxor  0x50(%rsp),%xmm0,%xmm2
  28a3ff:	vphminposuw %xmm2,%xmm2
  28a404:	vpinsrw $0x2,%ecx,%xmm5,%xmm4
  28a409:	vpinsrw $0x3,%r8d,%xmm4,%xmm4
  28a40f:	vmovd  %xmm2,%ecx
  28a413:	vpxor  %xmm0,%xmm4,%xmm2
  28a417:	vpinsrw $0x2,%eax,%xmm1,%xmm1
  28a41c:	vpinsrw $0x3,%edi,%xmm1,%xmm1
  28a421:	vpinsrw $0x2,%esi,%xmm6,%xmm4
  28a426:	vpsubw %xmm1,%xmm2,%xmm1
  28a42a:	vpinsrw $0x3,%ecx,%xmm4,%xmm2
  28a42f:	vpxor  %xmm0,%xmm2,%xmm0
  28a433:	vpinsrw $0x2,%edx,%xmm3,%xmm2
  28a438:	vpinsrw $0x3,%r9d,%xmm2,%xmm2
  28a43e:	vpsubw %xmm2,%xmm0,%xmm0
  28a442:	vpmaxuw %xmm0,%xmm1,%xmm0
  28a447:	vmovq  %xmm0,0x2(%rbx)
  28a44c:	mov    $0x1,%dx
  28a450:	mov    %dx,(%rbx)
  28a453:	add    $0x148,%rsp
  28a45a:	pop    %rbx
  28a45b:	pop    %r14
  28a45d:	pop    %r15
  28a45f:	pop    %rbp
  28a460:	ret
  28a461:	xor    %edx,%edx
  28a463:	jmp    28a450 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
