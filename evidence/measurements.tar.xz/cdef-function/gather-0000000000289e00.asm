
<WORKTREES>/qualification-1882/cdef-function/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000289e00 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAAINtNtNtCscIM9z48VHAb_13fearless_simd9generated10simd_types5u8x16NtNtBE_4avx24Avx2Ej2_B1T_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitAINtBC_5u16x8B1B_Ej3_ENCINvMB2b_B28_10wrap_mut_1By_NCINvCs6Qq1kSfbcoV_15splot_cdef_base11gather_withB1B_NCNCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed00NCINvB3J_18gather_packed_withB1B_B4v_E0Es0_0E0EB4B_>:
  289e00:	push   %rbp
  289e01:	mov    %rsp,%rbp
  289e04:	push   %r15
  289e06:	push   %r14
  289e08:	push   %r13
  289e0a:	push   %r12
  289e0c:	push   %rbx
  289e0d:	and    $0xffffffffffffffe0,%rsp
  289e11:	sub    $0x280,%rsp
  289e18:	mov    %rdi,%rbx
  289e1b:	movaps (%rsi),%xmm0
  289e1e:	movaps 0x10(%rsi),%xmm1
  289e22:	movaps %xmm1,0xe0(%rsp)
  289e2a:	movaps 0x20(%rsi),%xmm1
  289e2e:	movaps %xmm1,0xf0(%rsp)
  289e36:	movaps 0x30(%rsi),%xmm1
  289e3a:	movaps %xmm1,0x100(%rsp)
  289e42:	lea    0x1c0(%rsp),%r14
  289e4a:	mov    %r14,%rdi
  289e4d:	movaps %xmm0,%xmm1
  289e50:	call   28a4e0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
  289e55:	lea    0x1e0(%rsp),%r15
  289e5d:	mov    %r15,%rdi
  289e60:	mov    %r14,%rsi
  289e63:	call   28a4b0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
  289e68:	lea    0xc0(%rsp),%rdi
  289e70:	mov    %r15,%rsi
  289e73:	call   28a4d0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
  289e78:	lea    0x1c0(%rsp),%r12
  289e80:	mov    %r12,%rdi
  289e83:	movaps 0xe0(%rsp),%xmm0
  289e8b:	movaps %xmm0,%xmm1
  289e8e:	call   28a4e0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
  289e93:	lea    0x220(%rsp),%r13
  289e9b:	mov    %r13,%rdi
  289e9e:	mov    %r12,%rsi
  289ea1:	call   28a4b0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
  289ea6:	lea    0x1a0(%rsp),%rdi
  289eae:	mov    %r13,%rsi
  289eb1:	call   28a4d0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
  289eb6:	movaps 0xc0(%rsp),%xmm0
  289ebe:	movaps 0xd0(%rsp),%xmm1
  289ec6:	movaps %xmm0,0x170(%rsp)
  289ece:	movaps %xmm1,0x180(%rsp)
  289ed6:	movaps 0x1b0(%rsp),%xmm2
  289ede:	movaps %xmm2,0x190(%rsp)
  289ee6:	movaps %xmm0,0x60(%rsp)
  289eeb:	movaps %xmm1,0x70(%rsp)
  289ef0:	movaps %xmm2,0x80(%rsp)
  289ef8:	movaps 0x60(%rsp),%xmm0
  289efd:	movaps 0x70(%rsp),%xmm1
  289f02:	movaps 0x80(%rsp),%xmm2
  289f0a:	movaps %xmm2,0x50(%rsp)
  289f0f:	movaps %xmm1,0x40(%rsp)
  289f14:	movaps %xmm0,0x30(%rsp)
  289f19:	movaps 0x30(%rsp),%xmm0
  289f1e:	movaps 0x40(%rsp),%xmm1
  289f23:	movaps 0x50(%rsp),%xmm2
  289f28:	movaps %xmm2,0x20(%rsp)
  289f2d:	movaps %xmm1,0x10(%rsp)
  289f32:	movaps %xmm0,(%rsp)
  289f36:	movaps (%rsp),%xmm0
  289f3a:	movaps 0x10(%rsp),%xmm1
  289f3f:	movaps 0x20(%rsp),%xmm2
  289f44:	movaps %xmm2,0xb0(%rsp)
  289f4c:	movaps %xmm1,0xa0(%rsp)
  289f54:	movaps %xmm0,0x90(%rsp)
  289f5c:	movaps 0x90(%rsp),%xmm0
  289f64:	movaps 0xa0(%rsp),%xmm1
  289f6c:	movaps 0xb0(%rsp),%xmm2
  289f74:	movaps %xmm2,0x130(%rsp)
  289f7c:	movaps %xmm1,0x120(%rsp)
  289f84:	movaps %xmm0,0x110(%rsp)
  289f8c:	mov    %r14,%rdi
  289f8f:	movaps 0xf0(%rsp),%xmm0
  289f97:	movaps %xmm0,%xmm1
  289f9a:	call   28a4e0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
  289f9f:	mov    %r15,%rdi
  289fa2:	mov    %r14,%rsi
  289fa5:	call   28a4b0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
  289faa:	lea    0xc0(%rsp),%rdi
  289fb2:	mov    %r15,%rsi
  289fb5:	call   28a4d0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
  289fba:	mov    %r12,%rdi
  289fbd:	movaps 0x100(%rsp),%xmm0
  289fc5:	movaps %xmm0,%xmm1
  289fc8:	call   28a4e0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13combine_u8x166kernel22___fearless_simd_kernel>
  289fcd:	mov    %r13,%rdi
  289fd0:	mov    %r12,%rsi
  289fd3:	call   28a4b0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11widen_u8x326kernel22___fearless_simd_kernel>
  289fd8:	lea    0x1a0(%rsp),%rdi
  289fe0:	mov    %r13,%rsi
  289fe3:	call   28a4d0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12split_u16x166kernel22___fearless_simd_kernel>
  289fe8:	movaps 0xc0(%rsp),%xmm0
  289ff0:	movaps 0xd0(%rsp),%xmm1
  289ff8:	movaps %xmm0,0x170(%rsp)
  28a000:	movaps %xmm1,0x180(%rsp)
  28a008:	movaps 0x1b0(%rsp),%xmm2
  28a010:	movaps %xmm2,0x190(%rsp)
  28a018:	movaps %xmm0,0x60(%rsp)
  28a01d:	movaps %xmm1,0x70(%rsp)
  28a022:	movaps %xmm2,0x80(%rsp)
  28a02a:	movaps 0x60(%rsp),%xmm0
  28a02f:	movaps 0x70(%rsp),%xmm1
  28a034:	movaps 0x80(%rsp),%xmm2
  28a03c:	movaps %xmm2,0x50(%rsp)
  28a041:	movaps %xmm1,0x40(%rsp)
  28a046:	movaps %xmm0,0x30(%rsp)
  28a04b:	movaps 0x30(%rsp),%xmm0
  28a050:	movaps 0x40(%rsp),%xmm1
  28a055:	movaps 0x50(%rsp),%xmm2
  28a05a:	movaps %xmm2,0x20(%rsp)
  28a05f:	movaps %xmm1,0x10(%rsp)
  28a064:	movaps %xmm0,(%rsp)
  28a068:	movaps (%rsp),%xmm0
  28a06c:	movaps 0x10(%rsp),%xmm1
  28a071:	movaps 0x20(%rsp),%xmm2
  28a076:	movaps %xmm2,0xb0(%rsp)
  28a07e:	movaps %xmm1,0xa0(%rsp)
  28a086:	movaps %xmm0,0x90(%rsp)
  28a08e:	movaps 0x90(%rsp),%xmm0
  28a096:	movaps 0xa0(%rsp),%xmm1
  28a09e:	movaps 0xb0(%rsp),%xmm2
  28a0a6:	movaps %xmm2,0x160(%rsp)
  28a0ae:	movaps %xmm1,0x150(%rsp)
  28a0b6:	movaps %xmm0,0x140(%rsp)
  28a0be:	movaps 0x160(%rsp),%xmm0
  28a0c6:	movaps %xmm0,0x50(%rbx)
  28a0ca:	movaps 0x150(%rsp),%xmm0
  28a0d2:	movaps %xmm0,0x40(%rbx)
  28a0d6:	movaps 0x110(%rsp),%xmm0
  28a0de:	movaps 0x120(%rsp),%xmm1
  28a0e6:	movaps 0x130(%rsp),%xmm2
  28a0ee:	movaps 0x140(%rsp),%xmm3
  28a0f6:	movaps %xmm3,0x30(%rbx)
  28a0fa:	movaps %xmm2,0x20(%rbx)
  28a0fe:	movaps %xmm1,0x10(%rbx)
  28a102:	movaps %xmm0,(%rbx)
  28a105:	lea    -0x28(%rbp),%rsp
  28a109:	pop    %rbx
  28a10a:	pop    %r12
  28a10c:	pop    %r13
  28a10e:	pop    %r14
  28a110:	pop    %r15
  28a112:	pop    %rbp
  28a113:	ret
