
<WORKTREES>/qualification-1882/cdef-function/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

000000000028a470 <_RNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed>:
  28a470:	push   %rbx
  28a471:	sub    $0x30,%rsp
  28a475:	mov    %rdi,%rbx
  28a478:	mov    %rdx,0x8(%rsp)
  28a47d:	lea    0x7(%rsp),%rax
  28a482:	mov    %rax,0x10(%rsp)
  28a487:	mov    %rsi,0x18(%rsp)
  28a48c:	lea    0x8(%rsp),%rax
  28a491:	mov    %rax,0x20(%rsp)
  28a496:	mov    %rcx,0x28(%rsp)
  28a49b:	lea    0x10(%rsp),%rsi
  28a4a0:	call   28a120 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5CFpXzcpdQ2_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_>
  28a4a5:	mov    %rbx,%rax
  28a4a8:	add    $0x30,%rsp
  28a4ac:	pop    %rbx
  28a4ad:	ret
