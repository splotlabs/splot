
<WORKTREES>/qualification-1882/cdef-function/micro-target/release/cdef-micro:     file format elf64-x86-64


Disassembly of section .text:

0000000000031b80 <_RNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed>:
   31b80:	push   %rbx
   31b81:	sub    $0x30,%rsp
   31b85:	mov    %rdi,%rbx
   31b88:	mov    %rdx,0x8(%rsp)
   31b8d:	lea    0x7(%rsp),%rax
   31b92:	mov    %rax,0x10(%rsp)
   31b97:	mov    %rsi,0x18(%rsp)
   31b9c:	lea    0x8(%rsp),%rax
   31ba1:	mov    %rax,0x20(%rsp)
   31ba6:	mov    %rcx,0x28(%rsp)
   31bab:	lea    0x10(%rsp),%rsi
   31bb0:	call   31830 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_>
   31bb5:	mov    %rbx,%rax
   31bb8:	add    $0x30,%rsp
   31bbc:	pop    %rbx
   31bbd:	ret
