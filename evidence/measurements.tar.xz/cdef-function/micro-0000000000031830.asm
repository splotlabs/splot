
<WORKTREES>/qualification-1882/cdef-function/micro-target/release/cdef-micro:     file format elf64-x86-64


Disassembly of section .text:

0000000000031830 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_>:
   31830:	push   %rbp
   31831:	push   %r15
   31833:	push   %r14
   31835:	push   %rbx
   31836:	sub    $0x148,%rsp
   3183d:	mov    %rdi,%rbx
   31840:	mov    0x8(%rsi),%rax
   31844:	mov    0x10(%rsi),%rcx
   31848:	mov    (%rax),%rdi
   3184b:	mov    0x8(%rax),%r8
   3184f:	mov    0x10(%rax),%r9
   31853:	mov    0x18(%rax),%r10
   31857:	mov    (%rcx),%r11
   3185a:	mov    $0x180,%r14d
   31860:	add    0x18(%rsi),%r14
   31864:	vpcmpeqd %xmm1,%xmm1,%xmm1
   31868:	vpxor  %xmm0,%xmm0,%xmm0
   3186c:	xor    %ecx,%ecx
   3186e:	vmovdqa -0x2a5a6(%rip),%xmm4        # 72d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1c0>
   31876:	vpxor  %xmm2,%xmm2,%xmm2
   3187a:	vpcmpeqd %xmm3,%xmm3,%xmm3
   3187e:	vpxor  %xmm5,%xmm5,%xmm5
   31882:	vpcmpeqd %xmm6,%xmm6,%xmm6
   31886:	vpxor  %xmm7,%xmm7,%xmm7
   3188a:	vpcmpeqd %xmm8,%xmm8,%xmm8
   3188f:	nop
   31890:	mov    %rcx,%rax
   31893:	mul    %r11
   31896:	jo     31b71 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x341>
   3189c:	mov    %r10,%rsi
   3189f:	sub    %rax,%rsi
   318a2:	setb   %bpl
   318a6:	xor    %edx,%edx
   318a8:	mov    %r8,%r15
   318ab:	sub    %rax,%r15
   318ae:	jb     31b60 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
   318b4:	cmp    $0x14,%r15
   318b8:	jb     31b60 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
   318be:	test   %bpl,%bpl
   318c1:	jne    31b60 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
   318c7:	cmp    $0x14,%rsi
   318cb:	jb     31b60 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
   318d1:	inc    %rcx
   318d4:	vmovdqu (%rdi,%rax,1),%xmm9
   318d9:	vmovdqu (%r9,%rax,1),%xmm10
   318df:	vpminub %xmm9,%xmm8,%xmm8
   318e4:	vpmaxub %xmm7,%xmm9,%xmm7
   318e8:	vpminub %xmm6,%xmm10,%xmm6
   318ec:	vpmaxub %xmm5,%xmm10,%xmm5
   318f0:	vpunpckhbw %xmm10,%xmm9,%xmm11
   318f5:	vpunpcklbw %xmm10,%xmm9,%xmm9
   318fa:	vpxor  %xmm4,%xmm9,%xmm9
   318fe:	vmovdqu %xmm9,-0x180(%r14)
   31907:	vpxor  %xmm4,%xmm11,%xmm9
   3190b:	vmovdqu %xmm9,-0x80(%r14)
   31911:	vmovdqu 0x4(%r9,%rax,1),%xmm9
   31918:	vmovdqu 0x4(%rdi,%rax,1),%xmm10
   3191e:	vpminub %xmm3,%xmm10,%xmm3
   31922:	vpmaxub %xmm2,%xmm10,%xmm2
   31926:	vpminub %xmm1,%xmm9,%xmm1
   3192a:	vpmaxub %xmm0,%xmm9,%xmm0
   3192e:	vpunpckhbw %xmm9,%xmm10,%xmm11
   31933:	vpunpcklbw %xmm9,%xmm10,%xmm9
   31938:	vpxor  %xmm4,%xmm9,%xmm9
   3193c:	vmovdqu %xmm9,-0x100(%r14)
   31945:	vpxor  %xmm4,%xmm11,%xmm9
   31949:	vmovdqu %xmm9,(%r14)
   3194e:	add    $0x10,%r14
   31952:	cmp    $0x8,%rcx
   31956:	jne    31890 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x60>
   3195c:	vmovdqa %xmm8,0xc0(%rsp)
   31965:	vmovdqa %xmm7,0x100(%rsp)
   3196e:	vmovdqa %xmm6,0xe0(%rsp)
   31977:	vmovdqa %xmm5,0x120(%rsp)
   31980:	vmovdqa %xmm3,0xd0(%rsp)
   31989:	vmovdqa %xmm2,0x110(%rsp)
   31992:	vmovdqa %xmm1,0xf0(%rsp)
   3199b:	vmovdqa %xmm0,0x130(%rsp)
   319a4:	mov    %rsp,%rdi
   319a7:	lea    0xc0(%rsp),%rsi
   319af:	call   31510 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAAINtNtNtCs9DW4HO7zhlu_13fearless_simd9generated10simd_types5u8x16NtNtBE_4avx24Avx2Ej2_B1T_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitAINtBC_5u16x8B1B_Ej3_ENCINvMB2b_B28_10wrap_mut_1By_NCINvCs9K6TmCzReAo_15splot_cdef_base11gather_withB1B_NCNCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed00NCINvB3J_18gather_packed_withB1B_B4v_E0Es0_0E0EB4B_>
   319b4:	vmovaps (%rsp),%xmm0
   319b9:	vmovaps %xmm0,0x60(%rsp)
   319bf:	vmovaps 0x10(%rsp),%xmm0
   319c5:	vmovaps %xmm0,0x70(%rsp)
   319cb:	vmovaps 0x30(%rsp),%xmm0
   319d1:	vmovaps %xmm0,0x80(%rsp)
   319da:	vmovaps 0x40(%rsp),%xmm0
   319e0:	vmovaps %xmm0,0x90(%rsp)
   319e9:	vphminposuw 0x20(%rsp),%xmm0
   319f0:	vmovdqa %xmm0,0xa0(%rsp)
   319f9:	vphminposuw 0x50(%rsp),%xmm0
   31a00:	vmovdqa %xmm0,0xb0(%rsp)
   31a09:	mov    %rsp,%rdi
   31a0c:	lea    0x100(%rsp),%rsi
   31a14:	call   31510 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAAINtNtNtCs9DW4HO7zhlu_13fearless_simd9generated10simd_types5u8x16NtNtBE_4avx24Avx2Ej2_B1T_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitAINtBC_5u16x8B1B_Ej3_ENCINvMB2b_B28_10wrap_mut_1By_NCINvCs9K6TmCzReAo_15splot_cdef_base11gather_withB1B_NCNCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed00NCINvB3J_18gather_packed_withB1B_B4v_E0Es0_0E0EB4B_>
   31a19:	vmovdqa (%rsp),%xmm3
   31a1e:	vmovdqa 0x10(%rsp),%xmm4
   31a24:	vmovdqa 0x30(%rsp),%xmm6
   31a2a:	vmovdqa 0x40(%rsp),%xmm2
   31a30:	vpcmpeqd %xmm0,%xmm0,%xmm0
   31a34:	vmovdqa 0x60(%rsp),%xmm5
   31a3a:	vphminposuw %xmm5,%xmm1
   31a3f:	vmovdqa 0x70(%rsp),%xmm9
   31a45:	vpalignr $0x8,%xmm5,%xmm9,%xmm5
   31a4b:	vphminposuw %xmm5,%xmm5
   31a50:	vpunpcklwd %xmm5,%xmm1,%xmm1
   31a54:	vpxor  %xmm0,%xmm3,%xmm5
   31a58:	vphminposuw %xmm5,%xmm5
   31a5d:	vpalignr $0x8,%xmm3,%xmm4,%xmm3
   31a63:	vpxor  %xmm0,%xmm3,%xmm3
   31a67:	vphminposuw %xmm3,%xmm3
   31a6c:	vpunpcklwd %xmm3,%xmm5,%xmm5
   31a70:	vmovdqa 0x80(%rsp),%xmm7
   31a79:	vphminposuw %xmm7,%xmm3
   31a7e:	vmovdqa 0x90(%rsp),%xmm8
   31a87:	vpalignr $0x8,%xmm7,%xmm8,%xmm7
   31a8d:	vphminposuw %xmm7,%xmm7
   31a92:	vpunpcklwd %xmm7,%xmm3,%xmm3
   31a96:	vpxor  %xmm0,%xmm6,%xmm7
   31a9a:	vphminposuw %xmm7,%xmm7
   31a9f:	vpalignr $0x8,%xmm6,%xmm2,%xmm6
   31aa5:	vpxor  %xmm0,%xmm6,%xmm6
   31aa9:	vphminposuw %xmm6,%xmm6
   31aae:	vpunpcklwd %xmm6,%xmm7,%xmm6
   31ab2:	vphminposuw %xmm9,%xmm7
   31ab7:	vmovd  %xmm7,%eax
   31abb:	vpxor  %xmm0,%xmm4,%xmm4
   31abf:	vphminposuw %xmm4,%xmm4
   31ac4:	vmovd  %xmm4,%ecx
   31ac8:	vphminposuw %xmm8,%xmm4
   31acd:	vmovd  %xmm4,%edx
   31ad1:	vpxor  %xmm0,%xmm2,%xmm2
   31ad5:	vphminposuw %xmm2,%xmm2
   31ada:	vmovd  %xmm2,%esi
   31ade:	vmovdqa 0xa0(%rsp),%xmm2
   31ae7:	vmovd  %xmm2,%edi
   31aeb:	vpxor  0x20(%rsp),%xmm0,%xmm2
   31af1:	vphminposuw %xmm2,%xmm2
   31af6:	vmovd  %xmm2,%r8d
   31afb:	vmovdqa 0xb0(%rsp),%xmm2
   31b04:	vmovd  %xmm2,%r9d
   31b09:	vpxor  0x50(%rsp),%xmm0,%xmm2
   31b0f:	vphminposuw %xmm2,%xmm2
   31b14:	vpinsrw $0x2,%ecx,%xmm5,%xmm4
   31b19:	vpinsrw $0x3,%r8d,%xmm4,%xmm4
   31b1f:	vmovd  %xmm2,%ecx
   31b23:	vpxor  %xmm0,%xmm4,%xmm2
   31b27:	vpinsrw $0x2,%eax,%xmm1,%xmm1
   31b2c:	vpinsrw $0x3,%edi,%xmm1,%xmm1
   31b31:	vpinsrw $0x2,%esi,%xmm6,%xmm4
   31b36:	vpsubw %xmm1,%xmm2,%xmm1
   31b3a:	vpinsrw $0x3,%ecx,%xmm4,%xmm2
   31b3f:	vpxor  %xmm0,%xmm2,%xmm0
   31b43:	vpinsrw $0x2,%edx,%xmm3,%xmm2
   31b48:	vpinsrw $0x3,%r9d,%xmm2,%xmm2
   31b4e:	vpsubw %xmm2,%xmm0,%xmm0
   31b52:	vpmaxuw %xmm0,%xmm1,%xmm0
   31b57:	vmovq  %xmm0,0x2(%rbx)
   31b5c:	mov    $0x1,%dx
   31b60:	mov    %dx,(%rbx)
   31b63:	add    $0x148,%rsp
   31b6a:	pop    %rbx
   31b6b:	pop    %r14
   31b6d:	pop    %r15
   31b6f:	pop    %rbp
   31b70:	ret
   31b71:	xor    %edx,%edx
   31b73:	jmp    31b60 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCseT2pkIVUam5_15splot_cdef_avx213gather_packed0INtNtCs8uuN1nrGffB_4core6option6OptionAtj4_EEB1W_+0x330>
