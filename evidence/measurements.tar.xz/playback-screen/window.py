"""Time a verified artifact with exclusive access to the native playback core."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

q=Path(__file__).resolve().parents[1]
out=q/sys.argv[1]
assert out in (q/'playback-screen',q/'v3-screen')
assert (out/'oracle.txt').exists()
def inspect_locks():
    records=json.loads(subprocess.check_output(['lslocks','--json','-o','PID,PATH,MODE']))['locks']
    return [v['pid'] for v in records if v['path']==str(q/'build.lock') and v['mode']=='WRITE']
def signal_exit(sig,frame):
    raise SystemExit(128+sig)
signal.signal(signal.SIGTERM,signal_exit)
def call_control(action,unit):
    subprocess.run(['systemctl','--user',action,unit],check=True)
def run():
    with (out/'paired.txt').open('w') as f:
        subprocess.run(['taskset','-c','4','python3','bench.py'],cwd=out,stdout=f,timeout=800,check=True)
with (q/'playback-window.lock').open('a') as serial, (q/'build.lock').open('a') as gate:
    fcntl.flock(serial,fcntl.LOCK_EX)
    while True:
        try:
            fcntl.flock(gate,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            owners=inspect_locks()
            if len(owners)==1:
                proc=Path('/proc')/str(owners[0])
                try:
                    argv=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode()
                    unit=(proc/'cgroup').read_text().strip().split('/')[-1]
                except FileNotFoundError:
                    continue
                # Borrow only a confirmed, owned compile reservation. No unrelated
                # scope or timing process is eligible.
                known=('cdef-fallback/target','known-mask/target','deblock-pass/target')
                if unit.startswith('run-p') and unit.endswith('.scope') and any(x in argv for x in known):
                    status=subprocess.check_output(['systemctl','--user','show',unit,'-p','FreezerState','--value'],text=True).strip()
                    if status=='running':
                        try:
                            call_control('freeze',unit)
                            if inspect_locks()==owners:
                                print('exclusive measurement while compiler is paused',unit,flush=True)
                                run()
                                break
                        finally:
                            call_control('thaw',unit)
            time.sleep(5)
        else:
            run()
            break
