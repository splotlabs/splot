from hashlib import sha256
from pathlib import Path
import os
import subprocess
import sys

out = Path(__file__).resolve().parent
q = out.parent
manifest = [row.split('\t') for row in (q/'ci-data/simd-cases.tsv').read_text().splitlines()]
variants = ('shipped', 'draft', 'candidate')
revisions = ('102798461d19a98b6e04b935538fb24f7b339701','29e001679265816c1e0fed9e09a5e32efe1a2d47','edff2502')
for name, revision in zip(variants,revisions):
    root = out/f'playback-{name}'
    assert (root/'revision.txt').read_text().strip().startswith(revision)
    assert (root/'toolchain.txt').read_text() == (out/'playback-draft/toolchain.txt').read_text()
    subprocess.run(['sha256sum','--quiet','-c','SHA256SUMS'],cwd=root,check=True)
    bin = root/'splot'
    bin.chmod(0o755)
    for file in (bin,root/'libsplot_capi.so'):
        stripped = root/(file.name+'.stripped')
        subprocess.run(['strip','-o',stripped,file],check=True)
        print(name,file.name,stripped.stat().st_size,flush=True)
    for stem in ('Noise_Ocean_1920x1080_60fps_qp135_','RitualDance'):
        [item] = [row for row in manifest if row[0].startswith(stem)]
        fname,sha,frames,expected_size = item
        args=[bin,'decode',q/'ci-data'/fname,'--threads','1','--frame-delay','1']
        with subprocess.Popen([*args,'--output-format','raw','-o','-'],stdout=subprocess.PIPE) as proc:
            digest = sha256()
            size=0
            for chunk in iter(lambda:proc.stdout.read(2**20),b''):
                digest.update(chunk)
                size+=len(chunk)
            assert proc.wait()==0 and size==int(expected_size) and digest.hexdigest()==sha
        print(name,fname,frames,size,sha,flush=True)
        if name!='shipped':
            cg=root/(stem.split('_1920')[0]+'.cg')
            subprocess.run(['valgrind','--tool=callgrind',f'--callgrind-out-file={cg}',f'--log-file={cg}.log',*args,'--output-format','null','--limit','16'],check=True)
