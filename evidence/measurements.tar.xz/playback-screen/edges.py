from pathlib import Path
import runpy
out=Path(__file__).resolve().parent
q=out.parent
read=runpy.run_path(str(q/'noise-stage-breakdown.py'))['read']
edges=[
 ('TIP refinement','::tip::predict_block','::tip_units::refine_tip_units'),
 ('Compound blend','::mc::predict_inter_block','compound_mask::blend_plane'),
 ('Deblocking passes','::FrameDeblock>::advance_source','::PassEdges>::apply'),
 ('CDEF padded chroma','::compute_cdef_chroma_pair','cdef_filter_block_chroma_pair_with'),
]
for stream in ('Noise_Ocean','RitualDance'):
    for label in ('draft','candidate'):
        path=out/f'playback-{label}'/(stream+'.cg')
        if not path.exists() or not path.stat().st_size: continue
        own,ir,calls=read(path)
        print(stream,label,'whole',own.total())
        for group,parent,child in edges:
            matches=[edge for edge in ir if parent in edge[0] and child in edge[1]]
            print(group,'calls',sum(calls[e] for e in matches),'Ir',sum(ir[e] for e in matches))
