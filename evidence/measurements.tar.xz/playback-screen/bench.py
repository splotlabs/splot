import csv
from itertools import permutations
import os
from pathlib import Path
import random
import resource
from statistics import median
import subprocess
import time

OUTPUT = Path(__file__).resolve().parent
QUALIFICATION = OUTPUT.parent
BINARIES = {name: OUTPUT / f"playback-{name}" / "splot"
            for name in ("candidate", "draft", "shipped")}
CASES = [
    ("WITCHER3", QUALIFICATION / "data", 40),
    ("TunnelFlag", QUALIFICATION / "data", 40),
    ("Noise_Ocean_1920x1080_60fps_qp135_", QUALIFICATION / "ci-data", 64),
    ("RitualDance", QUALIFICATION / "ci-data", 64),
]
STREAMS = [(next(directory.glob(f"{prefix}*.ivf")), frames) for prefix, directory, frames in CASES]
ORDERS = list(permutations(BINARIES))

def child_cpu():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return usage.ru_utime + usage.ru_stime

def playback(variant, stream, frames):
    command = [
        BINARIES[variant], "decode", stream, "--threads", "1",
        "--frame-delay", "1", "--limit", str(frames), "--output-format", "null",
    ]
    cpu_start = child_cpu()
    wall_start = time.perf_counter()
    result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    wall = time.perf_counter() - wall_start
    cpu = child_cpu() - cpu_start
    if result.returncode:
        raise RuntimeError((command, result.returncode, result.stderr.decode(errors="replace")))
    return wall, cpu

def summarize(rows):
    for stream, _ in STREAMS:
        records = {(row[1], row[3]): row[4:] for row in rows if row[0] == stream.name}
        for reference in ("draft", "shipped"):
            for col, metric in enumerate(("wall", "CPU")):
                ratios = [records[r, "candidate"][col] / records[r, reference][col] for r in range(1, 13)]
                randomizer = random.Random(1882)
                bootstraps = sorted(median(randomizer.choices(ratios, k=12)) for _ in range(10000))
                center = 100 * (median(ratios) - 1)
                low, high = [100 * (bootstraps[i] - 1) for i in (250, 9749)]
                slower = sum(ratio > 1 for ratio in ratios)
                print(f"{stream.name} | candidate/{reference} | {metric} | {center:+.2f}% "
                      f"[{low:+.2f}%, {high:+.2f}%] | slower {slower}/12", flush=True)

def main():
    if os.sched_getaffinity(0) != {4}:
        raise RuntimeError("Run the playback benchmark on CPU 4.")
    for stream, frames in STREAMS:
        for variant in BINARIES:
            playback(variant, stream, frames)

    rows = []
    with (OUTPUT / "paired.csv").open("x", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(("stream", "round", "position", "variant", "wall_s", "cpu_s"))
        for round_index in range(12):
            # Rotate stream order and offset decoder order for adjacent streams.
            for offset in range(len(STREAMS)):
                stream_index = (round_index + offset) % len(STREAMS)
                stream, frames = STREAMS[stream_index]
                for position, variant in enumerate(ORDERS[(round_index + stream_index) % 6], 1):
                    row = (stream.name, round_index + 1, position, variant,
                           *playback(variant, stream, frames))
                    rows.append(row)
                    writer.writerow(row)
                file.flush()
            print(f"Completed round {round_index + 1}/12", flush=True)
    summarize(rows)

if __name__ == "__main__":
    main()
