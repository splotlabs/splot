from pathlib import Path
import sys
root=Path(__file__).resolve().parent
label,repo=sys.argv[1:]
out=root/f'lr-external-{label}'
(out/'src').mkdir(exist_ok=True,parents=True)
template=(root/'standalone-decoder/src/main.rs').read_text()
template=template.replace('DecoderSettings, PictureSamples','DecoderSettings, FrameDelay, PictureSamples')
template=template.replace('fn write_ready_pictures(decoder: &mut Decoder, output: &mut impl Write) {','fn write_ready_pictures(decoder: &mut Decoder, output: &mut impl Write, raw: bool, pictures: &mut usize, limit: usize) {').replace('        for plane in [','        *pictures += 1;\n        if *pictures > limit { return; }\n        if !raw { std::hint::black_box(&picture); continue; }\n        for plane in [',1)
template=template.replace('let [_, expected_backend, filename]','let [_, expected_backend, filename, mode, limit]').replace('panic!("expected backend and IVF filename");','panic!("expected backend, IVF filename, output mode and picture limit");')
template=template.replace('let settings = DecoderSettings::default().with_threads(ThreadCount::from(3));','let settings = DecoderSettings::default().with_threads(ThreadCount::from(1)).with_frame_delay(FrameDelay::from(1usize));\n    let raw = match mode.as_str() { "raw" => true, "null" => false, _ => panic!("unknown output mode") };\n    let limit: usize=limit.parse().unwrap();\n    let mut pictures=0;')
template=template.replace('write_ready_pictures(&mut decoder, &mut output);','write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);\n        if pictures >= limit { break; }',2)
template=template.replace('    decoder.drain();\n    write_ready_pictures(&mut decoder, &mut output);','    if pictures < limit {\n        decoder.drain();\n        write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);\n    }\n    eprintln!("{} displayed pictures", pictures.min(limit));')
(out/'src/main.rs').write_text(template)
(out/'Cargo.toml').write_text(f'''[package]
name = "lr-consumer"
version = "0.0.0"
edition = "2024"
publish = false

[dependencies]
splot-core = {{ path = "../../{repo}/crates/splot-core" }}
splot-decode = {{ path = "../../{repo}/crates/splot-decode" }}
''')
