set -euo pipefail
root=$(pwd)
repo="$root/../splot-1934-blend-callback"
out="$root/callback"
cd "$repo"
cargo clippy --locked --offline -j1 -p splot-recon --all-targets -- -D warnings > "$out/clippy.log" 2>&1
common=(--locked --offline -j1 --config 'profile.test.package.splot-recon.opt-level=0' --config 'profile.test.package.splot-recon.debug=0' -p splot-recon --lib)
cargo test "${common[@]}" -- blend_mask::tests --test-threads=2 > "$out/blend-tests.log" 2>&1
cargo test "${common[@]}" -- u8_quad_matches_the_per_sample_filter --test-threads=2 > "$out/quad-tests.log" 2>&1
