"""Count exclusive callgrind instructions and recover attributed helper costs."""
import argparse
from collections import Counter
from pathlib import Path
import re

def counters(path):
    names={}
    self_cost=Counter()
    target=None
    edge=False
    detail=False
    for raw in path.read_text().splitlines():
        label=re.match(r'^(c?fn)=\((\d+)\)(?: (.*))?$',raw)
        if label:
            kind,number,name=label.groups()
            if name: names[number]=name
            if kind=='fn':
                target=number
                edge=False
        elif raw.startswith('calls='):
            edge=True
        elif re.fullmatch(r'[-+*0-9]+\s+\d+',raw):
            if not edge:
                self_cost[target]+=int(raw.split()[1])
            edge=False
    families=Counter()
    for address,count in self_cost.items():
        name=names.get(address,'unknown')
        for match in ('cdef_filter','subpel_mc','gdf::','coeff_loop','fearless_simd'):
            if match in name:
                families[match]+=count
                break
        else:
            families['other']+=count
    return families
if __name__=='__main__':
    import sys
    for arg in sys.argv[1:]:
        path=Path(arg)
        c=counters(path)
        print(path.name,c.total(),dict(c))
