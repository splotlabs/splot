## Shared CDEF module experiment on native AVX2

The measured source is `31028cc8` on `experiment/simd-1934-cdef-module`. The prototype moves the existing two-plane, 8-bit CDEF chroma gather into a shared Rust implementation and gives it concrete SSE2 and AVX2 entry points. The decoder and tile parsers each retain one implementation. Both units are linked into the CLI and C shared library. The AVX2 entry requires the capability token from the startup-selected backend.

The **function** and **module** builds use identical sources. The former uses normal portable release compilation. The latter applies the exact CPU-feature contract of Fearless SIMD 1.2.0 only to the AVX2 kernel unit, retaining the baseline target for the decoder. The previous **in-tree** build is `d67efd2d` before extraction, and **shipped** is the v3 reference `10279846`. An external Cargo consumer must opt into the prototype wrapper to get the separate compiler settings.

### Kernel results

On the i7-12700H (CPU 4), 12 alternating pairs from a standalone Rust consumer, each measuring one million gathers over 128 inputs, gave these results. Positive elapsed changes mean slower. Native SSE2, AVX2 and Auto matched an independent scalar oracle for all packed-output bytes and all four computed ranges, including partial writes on short input. Strict x86-64 emulation selected SSE2 and rejected forced AVX2.

```text
sse2 ns/call function 35.365 module 34.675 paired delta percent -1.65 95% interval -3.38 2.23
avx2 ns/call function 56.415 module 23.87 paired delta percent -58.39 95% interval -59.98 -57.06
auto ns/call function 56.9 module 23.445 paired delta percent -58.77 95% interval -59.82 -58.09
```

The module microbenchmark links the AVX2 loop as a 632-byte leaf with zero calls or CPUID instructions. The function-scoped reference has a separate vectorization wrapper and an outlined array helper. Both binaries retain a 1,662-byte SSE2 entry. The hardware dispatch policy is identical.

### End-to-end elapsed time

Twelve paired samples per workload and comparator, balanced across all four launch positions, with one pinned worker after a warmup. WITCHER3 and TunnelFlag use 40 frames each. Noise_Ocean uses its 16-frame CI prefix. The reported intervals are paired 95% bootstrap intervals.

| Input | Module vs function | Module vs in-tree | Module vs shipped v3 |
|---|---:|---:|---:|
| WITCHER3 | -1.88% [-5.26, +0.78] | -3.32% [-7.99, -0.66] | +13.41% [+6.89, +16.17] |
| TunnelFlag | -0.78% [-3.56, +1.46] | -0.17% [-3.41, +1.67] | +17.08% [+11.78, +18.68] |
| Noise_Ocean | -4.34% [-7.06, -3.25] | -2.23% [-10.82, +0.79] | +37.78% [+28.91, +43.80] |

The AVX2 gather improved and the Noise_Ocean playback interval excludes zero. The other two same-source playback intervals include zero. Against the shipped decoder all three regressions exceed the release target. #1987 remains a draft. Measured revision `31028cc8` is preserved. Follow-up `1c862590` cleans up the wrapper’s handling of test targets and refreshes the fuzz lockfile.

### Guest instructions and artifacts

Both columns use the same invocation and the same machine. This separates code generation from wall-clock variation.

| Input | Function instructions | Module instructions | Change |
|---|---:|---:|---:|
| Noise_Ocean | 1,675,810,357 | 1,635,551,782 | -2.402% |
| WITCHER3 | 1,576,749,857 | 1,575,859,699 | -0.056% |
| TunnelFlag | 2,928,646,057 | 2,928,648,343 | +0.000% |

| Stripped artifact | Function | Module | Change |
|---|---:|---:|---:|
| splot | 16,868,320 | 16,867,184 | -1,136 |
| libsplot_capi.so | 13,162,840 | 13,161,400 | -1,440 |

The module build matched all 21 complete AVM hashes across seven streams at 1, 7 and 12 workers. Its CLI and C library matched the historical release in all 40 strict SSE2-emulated comparisons. Rust 1.100.0, Linux x86-64, ThinLTO, one codegen unit, default features, preserved symbols for disassembly.

Build the module variant from the experiment worktree with `RUSTC_WRAPPER="$PWD/scripts/rustc-cdef-prototype.py" CARGO_PROFILE_RELEASE_STRIP=none cargo build --release --locked -p splot-cli -p splot-capi`. Build the function variant in a fresh target directory with the same command and no wrapper. `tests/downstream/cdef-module.rs` provides the scalar parity and timing harness.

### Follow-up with ordinary Cargo

An external Rust decoder built with default flags selected AVX2 on the i7 and SSE2 under strict x86-64 emulation. Both 8-bit and 10-bit outputs matched the frozen hashes through both routes. The two new kernel crates passed Clippy on all targets.

In follow-up `4cffa001`, writing the two range-widening operations explicitly lets the compiler retain the AVX2 arithmetic inside its target-feature entry with ordinary Cargo. Its 648-byte AVX2 loop has zero calls and zero CPU probes. Native Auto, AVX2, SSE2 and strict emulation again match the independent scalar oracle. In 12 pinned, interleaved three-build rounds, the new default-build Auto kernel took 56.26% less time than the original ordinary build (95% paired interval 51.85%–58.46% faster) and 7.63% more than the original separately compiled module (4.22%–18.79% slower). An unrelated memory-limited build used other cores during the three-way microbenchmark. The ordinary-Cargo full-decoder experiment uses the corresponding in-tree source change.

<details><summary>Raw follow-up gather timings</summary>

```csv
round,order,build,policy,ns_per_call
1,1,function,sse2,49.36
1,1,function,avx2,68.22
1,1,function,auto,65.57
1,2,module,sse2,39.17
1,2,module,avx2,25.84
1,2,module,auto,26.06
1,3,direct,sse2,39.07
1,3,direct,avx2,29.41
1,3,direct,auto,28.35
2,1,function,sse2,42.72
2,1,function,avx2,78.90
2,1,function,auto,67.11
2,2,direct,sse2,38.64
2,2,direct,avx2,28.29
2,2,direct,auto,27.65
2,3,module,sse2,38.87
2,3,module,avx2,26.16
2,3,module,auto,25.76
3,1,module,sse2,38.21
3,1,module,avx2,25.92
3,1,module,auto,26.00
3,2,function,sse2,38.47
3,2,function,avx2,69.54
3,2,function,auto,71.21
3,3,direct,sse2,38.52
3,3,direct,avx2,27.88
3,3,direct,auto,28.06
4,1,module,sse2,38.27
4,1,module,avx2,25.82
4,1,module,auto,27.02
4,2,direct,sse2,40.71
4,2,direct,avx2,27.82
4,2,direct,auto,28.20
4,3,function,sse2,40.95
4,3,function,avx2,68.55
4,3,function,auto,86.06
5,1,direct,sse2,48.40
5,1,direct,avx2,30.75
5,1,direct,auto,28.82
5,2,function,sse2,38.78
5,2,function,avx2,63.32
5,2,function,auto,64.65
5,3,module,sse2,42.04
5,3,module,avx2,28.27
5,3,module,auto,27.69
6,1,direct,sse2,44.71
6,1,direct,avx2,34.01
6,1,direct,auto,32.30
6,2,module,sse2,41.53
6,2,module,avx2,27.04
6,2,module,auto,27.91
6,3,function,sse2,42.17
6,3,function,avx2,69.70
6,3,function,auto,67.33
7,1,function,sse2,41.90
7,1,function,avx2,65.56
7,1,function,auto,71.94
7,2,module,sse2,48.45
7,2,module,avx2,28.92
7,2,module,auto,28.74
7,3,direct,sse2,42.32
7,3,direct,avx2,30.21
7,3,direct,auto,30.13
8,1,function,sse2,39.49
8,1,function,avx2,63.42
8,1,function,auto,63.14
8,2,direct,sse2,39.94
8,2,direct,avx2,30.12
8,2,direct,auto,32.02
8,3,module,sse2,43.28
8,3,module,avx2,26.70
8,3,module,auto,26.28
9,1,module,sse2,39.24
9,1,module,avx2,26.06
9,1,module,auto,26.44
9,2,function,sse2,39.26
9,2,function,avx2,65.58
9,2,function,auto,69.98
9,3,direct,sse2,41.12
9,3,direct,avx2,31.28
9,3,direct,auto,36.80
10,1,module,sse2,52.46
10,1,module,avx2,33.70
10,1,module,auto,31.14
10,2,direct,sse2,42.28
10,2,direct,avx2,30.21
10,2,direct,auto,30.16
10,3,function,sse2,41.94
10,3,function,avx2,68.76
10,3,function,auto,70.88
11,1,direct,sse2,43.09
11,1,direct,avx2,32.48
11,1,direct,auto,32.99
11,2,function,sse2,45.61
11,2,function,avx2,72.71
11,2,function,auto,68.27
11,3,module,sse2,40.50
11,3,module,avx2,26.30
11,3,module,auto,26.97
12,1,direct,sse2,40.68
12,1,direct,avx2,28.20
12,1,direct,auto,27.85
12,2,module,sse2,37.89
12,2,module,avx2,25.42
12,2,module,auto,27.01
12,3,function,sse2,46.05
12,3,function,avx2,66.30
12,3,function,auto,62.95
```
</details>

<details><summary>Raw paired process and kernel timings</summary>

```csv
stream,round,order,version,elapsed_s,cpu_s
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,1,module,0.8396909619996222,0.8392559999999989
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,2,function,0.8356421779999437,0.8352190000000004
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,3,shipped,0.6614347840004484,0.66099
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,4,kernels,0.8999172479998379,0.8995370000000005
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,1,kernels,1.544299222000518,1.5436779999999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,2,shipped,1.3272091939998063,1.3267399999999991
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,3,function,1.5071050669994293,1.5065650000000037
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,4,module,1.5655960169997343,1.5651399999999995
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,1,module,0.16185769999992772,0.16157600000000016
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,2,function,0.1686289660001421,0.16841499999999598
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,3,shipped,0.13065250999989075,0.13042000000000087
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,4,kernels,0.15961038100067526,0.1594149999999992
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,1,function,0.16274741899997025,0.16254900000000205
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,2,kernels,0.16092337099962606,0.1606430000000003
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,3,module,0.1565345700000762,0.15631699999999782
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,4,shipped,0.12130067899943242,0.12112300000000076
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,1,shipped,1.3022863460000735,1.3018080000000012
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,2,module,1.5295453410008122,1.529003999999997
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,3,kernels,1.4999968390002323,1.49953
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,4,function,1.518597901999783,1.518021000000001
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,1,function,0.9085416390007595,0.9081470000000031
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,2,kernels,0.8022661370005153,0.8018630000000009
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,3,module,0.7825013900001068,0.7821129999999954
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,4,shipped,0.6895528639997792,0.6892309999999995
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,1,kernels,0.7903095080000639,0.7897750000000023
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,2,shipped,0.7586690250000174,0.7583340000000014
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,3,function,0.7995407130001695,0.799118
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,4,module,0.7853405310006565,0.7849690000000002
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,1,module,1.4796085159996437,1.4789769999999933
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,2,function,1.550652011999773,1.5501390000000086
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,3,shipped,1.2835254619994885,1.2829689999999943
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,4,kernels,1.5250848489995406,1.524585000000009
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,1,kernels,0.2668705140004022,0.2664819999999892
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,2,shipped,0.13670228499995574,0.13644300000000698
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,3,function,0.17144565699982195,0.17118899999999826
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,4,module,0.15919845400003396,0.15896100000000501
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,1,shipped,0.1161977689998821,0.11599599999999555
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,2,module,0.17305165900052089,0.17279699999999565
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,3,kernels,0.15844223499971122,0.15813100000000446
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,4,function,0.1675107900000512,0.1673150000000021
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,1,function,1.5104091479997805,1.5098579999999941
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,2,kernels,1.6250792040000306,1.6243189999999998
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,3,module,1.5437368339999011,1.5430080000000004
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,4,shipped,1.2928584640003464,1.2923710000000028
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,1,shipped,0.7356003619997864,0.735320999999999
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,2,module,0.8098619490001511,0.8094679999999954
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,3,kernels,0.7850307860007888,0.7846910000000022
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,4,function,0.8012580039994646,0.8009230000000045
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,1,module,0.7959057869993558,0.7955619999999968
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,2,function,0.8931354040005317,0.8925920000000005
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,3,shipped,0.8046143020001182,0.8041550000000015
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,4,kernels,0.9295104479997462,0.928955000000002
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,1,kernels,1.4789498410000306,1.4782809999999955
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,2,shipped,1.482797820000087,1.4822960000000052
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,3,function,1.53674822999983,1.5361309999999975
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,4,module,1.4923162280001634,1.491786999999995
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,1,module,0.15583618300024682,0.15563800000000327
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,2,function,0.16366831100003765,0.16345500000000612
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,3,shipped,0.11596107799960009,0.11573199999999417
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,4,kernels,0.17257353799959674,0.1722469999999987
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,1,function,0.1818074640004852,0.18158800000000497
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,2,kernels,0.20350666800004547,0.20322799999999575
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,3,module,0.17332146399985504,0.1731060000000042
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,4,shipped,0.12330694299998868,0.1230860000000007
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,1,shipped,1.322093548000339,1.3216149999999942
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,2,module,1.4913119270004245,1.4907930000000036
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,3,kernels,1.5509755100001712,1.5504279999999966
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,4,function,1.5220927569998821,1.521599000000002
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,1,function,0.785157834000529,0.7848569999999881
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,2,kernels,0.8215747650001504,0.8209230000000076
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,3,module,0.8158179580004798,0.8154700000000048
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,4,shipped,0.698371823999878,0.6981159999999988
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,1,kernels,0.8117602789998273,0.811436999999998
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,2,shipped,0.6864960180000708,0.6860210000000109
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,3,function,0.8120705649998854,0.8116849999999829
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,4,module,0.8762263149992577,0.8758720000000153
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,1,module,1.5057234510004491,1.5052159999999901
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,2,function,1.4986889780002457,1.4981669999999951
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,3,shipped,1.359548888000063,1.3590489999999988
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,4,kernels,1.4928837759998714,1.492322999999999
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,1,kernels,0.16053879700029938,0.1603280000000069
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,2,shipped,0.11388595900007203,0.11367600000001232
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,3,function,0.164246293999895,0.16400199999998222
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,4,module,0.16699886700007482,0.16676200000000563
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,1,shipped,0.11367550600061804,0.11345399999999017
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,2,module,0.16024530399954529,0.16001900000000546
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,3,kernels,0.18196881099993334,0.181705000000008
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,4,function,0.1798953759998767,0.17967099999999903
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,1,function,1.5534471900000426,1.552892
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,2,kernels,1.4802160010003718,1.4796319999999952
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,3,module,1.5529805719997967,1.5524330000000077
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,4,shipped,1.2809692089995224,1.280574999999999
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,1,shipped,0.7070627949997288,0.7067109999999985
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,2,module,0.7891619510000965,0.7887819999999977
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,3,kernels,0.8658833830004369,0.865493000000015
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,4,function,0.8076451999995697,0.8073099999999869
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,1,module,0.7749887310001213,0.7746410000000026
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,2,function,0.7907058739992863,0.7903049999999894
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,3,shipped,0.6770487339999818,0.6767420000000186
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,4,kernels,0.8344161659997553,0.8340119999999871
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,1,kernels,1.5078034970001681,1.5073280000000011
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,2,shipped,1.2761950040003285,1.2757059999999996
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,3,function,1.5738616210001055,1.5733239999999995
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,4,module,1.4896986410003592,1.489215999999999
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,1,module,0.15898864499922638,0.15878299999999967
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,2,function,0.17188081199947192,0.1716250000000059
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,3,shipped,0.11490804700042645,0.11469499999999755
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,4,kernels,0.1587255920003372,0.15848200000000645
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,1,function,0.16081119699992996,0.16061399999999537
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,2,kernels,0.16066545899957418,0.16045800000000554
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,3,module,0.1553587680000419,0.15512699999999313
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,4,shipped,0.12064554200060229,0.12039300000000708
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,1,shipped,1.3652916900000491,1.36469799999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,2,module,1.4880918709995967,1.487487999999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,3,kernels,1.5112558259997968,1.5106679999999955
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,4,function,1.5538180279991138,1.5533360000000158
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,1,function,0.7782849949999218,0.7778799999999961
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,2,kernels,0.8030589079999118,0.8027079999999955
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,3,module,0.7804353060000722,0.7801130000000143
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,4,shipped,0.7526328479998483,0.7522479999999803
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,1,kernels,0.8234034560000509,0.823007000000004
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,2,shipped,0.6854997440004809,0.6851400000000041
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,3,function,0.8458720210001047,0.8454559999999987
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,4,module,0.7918526379999093,0.7914689999999922
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,1,module,1.568985961999715,1.5684520000000077
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,2,function,1.4745804240001235,1.4740970000000004
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,3,shipped,1.3360430279999491,1.3355829999999997
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,4,kernels,1.673705721999795,1.6730479999999943
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,1,kernels,0.16129740999986097,0.16107600000000843
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,2,shipped,0.11554343300031178,0.11518900000000087
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,3,function,0.16362081699935516,0.16340600000000904
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,4,module,0.15851829500024905,0.15824799999998618
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,1,shipped,0.1201872479996382,0.1199670000000026
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,2,module,0.17672879899964755,0.17647600000000807
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,3,kernels,0.17901197599985608,0.17880299999998783
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,4,function,0.18999957599953632,0.1896860000000089
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,1,function,1.560845275000247,1.5602099999999837
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,2,kernels,1.4727813500003322,1.4723610000000065
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,3,module,1.5368271980005375,1.536361999999997
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,4,shipped,1.272085923999839,1.271653999999998
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,1,shipped,0.6777598099997704,0.6774340000000052
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,2,module,0.7682055620007304,0.7678420000000017
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,3,kernels,0.8695449670003654,0.845168000000001
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,4,function,0.801334671999939,0.8010129999999975
```

```csv
round,order,build,backend,ns_per_call
1,1,function,sse2,43.24
1,1,function,avx2,61.75
1,1,function,auto,57.76
1,2,module,sse2,37.94
1,2,module,avx2,24.36
1,2,module,auto,23.4
2,1,module,sse2,33.63
2,1,module,avx2,22.74
2,1,module,auto,22.72
2,2,function,sse2,33.49
2,2,function,avx2,54.33
2,2,function,auto,55.0
3,1,function,sse2,34.57
3,1,function,avx2,54.49
3,1,function,auto,55.04
3,2,module,sse2,34.09
3,2,module,avx2,22.57
3,2,module,auto,22.78
4,1,module,sse2,33.29
4,1,module,avx2,22.21
4,1,module,auto,22.61
4,2,function,sse2,34.28
4,2,function,avx2,57.86
4,2,function,auto,59.73
5,1,function,sse2,35.95
5,1,function,avx2,57.94
5,1,function,auto,62.21
5,2,module,sse2,37.4
5,2,module,avx2,24.76
5,2,module,auto,25.06
6,1,module,sse2,42.36
6,1,module,avx2,32.22
6,1,module,auto,28.11
6,2,function,sse2,37.29
6,2,function,avx2,58.53
6,2,function,auto,58.57
7,1,function,sse2,35.95
7,1,function,avx2,61.7
7,1,function,auto,60.63
7,2,module,sse2,35.26
7,2,module,avx2,23.97
7,2,module,auto,24.3
8,1,module,sse2,36.06
8,1,module,avx2,24.15
8,1,module,auto,23.49
8,2,function,sse2,34.14
8,2,function,avx2,55.96
8,2,function,auto,58.67
9,1,function,sse2,35.34
9,1,function,avx2,56.87
9,1,function,auto,56.04
9,2,module,sse2,35.33
9,2,module,avx2,23.77
9,2,module,auto,23.68
10,1,module,sse2,33.71
10,1,module,avx2,24.41
10,1,module,auto,27.76
10,2,function,sse2,37.69
10,2,function,avx2,54.66
10,2,function,auto,55.83
11,1,function,sse2,35.39
11,1,function,avx2,55.82
11,1,function,auto,55.92
11,2,module,sse2,34.02
11,2,module,avx2,22.66
11,2,module,auto,23.01
12,1,module,sse2,33.83
12,1,module,avx2,22.69
12,1,module,auto,22.74
12,2,function,sse2,34.82
12,2,function,avx2,55.25
12,2,function,auto,54.72
```
</details>
