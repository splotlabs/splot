from pathlib import Path
import subprocess
q=Path(__file__).resolve().parent
for m,exe in [('external','lr-consumer'),('product','splot'),('micro','lr-kernel-consumer')]:
    for v in ('plain','unit'):
        d=q/f'lr-{m}-{v}'
        if (d/f'target/release/{exe}').exists() and not (d/'codegen.tsv').is_file():
            subprocess.run(['python3',q/'lr-audit.py',m,v],check=True)
        cg=d/'ritual16.cg'
        if cg.exists() and '\ntotals: ' in cg.read_text() and not (d/'calls.txt').is_file():
            with (d/'calls.txt').open('w') as out:
                subprocess.run(['python3',q/'noise-callgrind.py',cg,'splot_lr_avx2::filter_luma_run'],stdout=out,check=True)
        if (d/'codegen.tsv').is_file():
            print(m,v,'audited','trace' if (d/'calls.txt').is_file() else '')
