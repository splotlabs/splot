import csv
import itertools
import os
from pathlib import Path
import random
import re
import statistics
import subprocess
import sys
import time
root=Path(__file__).resolve().parent
os.sched_setaffinity(0,{4})
mode=sys.argv[1]
if mode=='kernel':
    variants=['plain','unit']
    cases=[('luma runs',None,100000)]
else:
    variants=['control','plain','unit']
    cases=[('RitualDance 16',next((root/'ci-data').glob('RitualDance*.ivf')),16),
           ('RitualDance 600',next((root/'ci-data').glob('RitualDance*.ivf')),600),
           ('TunnelFlag 40',next((root/'data').glob('TunnelFlag*.ivf')),40)]
def measure(name,case):
    if mode=='kernel':
        exe=root/f'lr-micro-{name}/target/release/lr-kernel-consumer'
        text=subprocess.check_output([exe,str(case[2])],text=True)
        m=re.search(r'ns/run ([0-9.]+) checksum (\d+)',text)
        return float(m[1]),m[2]
    exe=root/f'lr-external-{name}/target/release/lr-consumer'
    start=time.perf_counter()
    res=subprocess.run([exe,'avx2',case[1],'null',str(case[2])],stderr=subprocess.PIPE,stdout=subprocess.DEVNULL,text=True,check=True)
    duration=time.perf_counter()-start
    assert f'{case[2]} displayed pictures' in res.stderr,res.stderr
    return duration,str(case[2])
orders=list(itertools.permutations(variants))
data={}
for c in cases:
    for name in variants: measure(name,c)
with (root/f'lr-{mode}-paired.csv').open('x') as file:
    writer=csv.writer(file)
    writer.writerow(['case','round','position','build','ns_per_run' if mode=='kernel' else 'elapsed_s','checksum_or_frames'])
    for i in range(12):
        for j,c in enumerate(cases if i%2==0 else reversed(cases)):
            result_checks=[]
            for pos,label in enumerate(orders[(i+cases.index(c)*2)%len(orders)]):
                duration,check=measure(label,c)
                result_checks.append(check)
                data[i,c[0],label]=duration
                writer.writerow([c[0],i+1,pos+1,label,duration,check])
                file.flush()
            assert len(set(result_checks))==1
for cname,_,_ in cases:
    for name,base in ([('unit','plain')] if mode=='kernel' else [('plain','control'),('unit','plain'),('unit','control')]):
        ratios=[100*(data[i,cname,name]/data[i,cname,base]-1) for i in range(12)]
        rng=random.Random(1882)
        boot=sorted(statistics.median(rng.choices(ratios,k=12)) for _ in range(10000))
        print(f'{cname} {name}/{base}: {statistics.median(ratios):+.2f}% [{boot[250]:+.2f}, {boot[-251]:+.2f}]',flush=True)
