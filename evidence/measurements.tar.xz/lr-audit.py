from pathlib import Path
import re
import subprocess
import sys
root=Path(__file__).resolve().parent
mode,label=sys.argv[1:]
out=root/f'lr-{mode}-{label}'
binary=out/'target/release'/({'micro':'lr-kernel-consumer','external':'lr-consumer','product':'splot'}[mode])
functions=subprocess.check_output(['nm','-S','-n','--demangle=rust',binary],text=True)
keep=[]
for line in functions.splitlines():
    parts=line.split(None,3)
    if len(parts)!=4: continue
    address,size,kind,symbol=parts
    if kind.lower()!='t' or not any(k in symbol for k in ('splot_lr_avx2::filter_luma_run','splot_lr_avx2::word_row')): continue
    a,n=int(address,16),int(size,16)
    assembly=subprocess.check_output(['objdump','-d','--no-show-raw-insn',f'--start-address={a}',f'--stop-address={a+n}',binary],text=True)
    ops=[m[1] for row in assembly.splitlines() if (m:=re.match(r'^\s*[0-9a-f]+:\s+(\S+)',row))]
    (out/f'lr-{address}.asm').write_text(assembly)
    keep.append((address,n,len(ops),sum(op.startswith('v') for op in ops),ops.count('call'),ops.count('cpuid'),symbol))
assert keep
with (out/'codegen.tsv').open('w') as file:
    print('address','bytes','instructions','vector mnemonics','call','cpuid','symbol',sep='\t',file=file)
    for row in keep:print(*row,sep='\t',file=file)
if label=='unit':
    flags=(out/'flags.tsv').read_text().splitlines()
    assert any(row.startswith('splot_lr_avx2\t') and '+avx2' in row for row in flags)
    assert all(row.startswith('splot_lr_avx2\t') or '-Ctarget-' not in row for row in flags)
