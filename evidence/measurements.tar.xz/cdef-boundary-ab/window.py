"""Take a short native timing window while the identified compiler keeps the resource lock."""
import json
import subprocess
import os
from pathlib import Path
import signal

q=Path(__file__).resolve().parents[1]
scope='run-p462842-i428458.scope'
pid=462842
def owner():
    locks=json.loads(subprocess.check_output(['lslocks','--json','-o','PID,PATH,MODE']))['locks']
    owners=[v['pid'] for v in locks if v['path']==str(q/'build.lock') and v['mode']=='WRITE']
    return owners == [pid]
def control(action):
    subprocess.run(['systemctl','--user',action,scope],check=True)
def interrupt(n,frame):
    raise KeyboardInterrupt
signal.signal(signal.SIGTERM,interrupt)
assert owner() and 'cdef-fallback' in Path(f'/proc/{pid}/cmdline').read_text()
jobs=[(478818,q/'cdef-boundary-ab',['python3','table.py','wall','../final-integration/splot.full','../cdef-context/target/release/splot','context'],'context/paired.txt'),(501826,q/'dav2d-native',['python3','measure.py'],'results.txt')]
try:
    control('freeze')
    assert owner()
    for waiter,work,argv,_ in jobs:
        proc=Path('/proc')/str(waiter)
        assert (proc/'cwd').resolve()==work
        assert (proc/'cmdline').read_bytes().split(b'\0')[2:-1]==[os.fsencode(a) for a in argv]
        assert not (proc/f'task/{waiter}/children').read_text().strip()
    for waiter,work,argv,out in jobs:
        os.kill(waiter,signal.SIGTERM)
        with (work/out).open('w') as f:
            result=subprocess.run(argv,cwd=work,stdout=f,timeout=240)
            print(work.name,result.returncode,flush=True)
finally:
    control('thaw')
