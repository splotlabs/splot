"""Compare matched production decoders on CDEF's byte and word paths."""
from pathlib import Path
import csv
import hashlib
import os
import random
import resource
import statistics
import subprocess
import sys
import time

q = Path(__file__).resolve().parents[1]
mode, label, base_path, new_path = sys.argv[1:]
out = Path(__file__).parent / label
out.mkdir(exist_ok=True)
binaries = {'base': Path(base_path).resolve(), 'new': Path(new_path).resolve()}
streams = {'Noise_Ocean': q/'ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf',
           'RitualDance': next((q/'ci-data').glob('RitualDance*ivf'))}

def command(variant, stream, frames):
    return [binaries[variant], 'decode', stream, '--threads', '1', '--frame-delay', '1',
            '--output-format', 'null', '--limit', str(frames)]

if mode in ('trace', 'tracebase'):
    os.sched_setaffinity(0, {2})
    for stem, stream in streams.items():
        for variant in (['base'] if mode == 'tracebase' else binaries):
            dest = out / f'{stem}-{variant}.cg'
            if dest.exists() and '\ntotals:' in dest.read_text():
                continue
            subprocess.run(['valgrind', '--tool=callgrind', f'--callgrind-out-file={dest}',
                            f'--log-file={dest}.log', *command(variant,stream,16)],check=True)
    sys.exit(0)

assert mode == 'wall'
os.sched_setaffinity(0, {4})
# Sixty-four frames amortize startup and give both tested hot routes ample work.
frames = 64
def run(variant, stream):
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.monotonic_ns()
    subprocess.run(command(variant, stream, frames),stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
    elapsed = (time.monotonic_ns()-start)/1e9
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    cpu = after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime
    return elapsed, cpu

for variant, exe in binaries.items():
    with exe.open('rb') as data:
        print(variant, hashlib.file_digest(data, 'sha256').hexdigest(), flush=True)
    for stream in streams.values():
        run(variant,stream)

results = {(stem,metric): [] for stem in streams for metric in ('wall','CPU')}
with (out/'timings.csv').open('x',newline='') as data:
    writer=csv.writer(data)
    writer.writerow(['stream','frames','round','position','variant','elapsed_s','cpu_s'])
    for r in range(12):
        sequence = list(streams.items())
        if r%2: sequence.reverse()
        for j,(stem,stream) in enumerate(sequence):
            variants = list(binaries)
            if (r + list(streams).index(stem))%2: variants.reverse()
            current={}
            for i,v in enumerate(variants):
                current[v]=run(v,stream)
                writer.writerow([stem,frames,r+1,i+1,v,*current[v]])
                data.flush()
            for column,metric in enumerate(('wall','CPU')):
                results[stem,metric].append(100*(current['new'][column]/current['base'][column]-1))
for (stem,metric),ratios in results.items():
    rng=random.Random(1882)
    boot=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
    print(f'{stem}, new vs base, paired {metric} {statistics.median(ratios):+.2f}% [{boot[250]:+.2f}, {boot[-251]:+.2f}], slower {sum(v>0 for v in ratios)}/{len(ratios)}',flush=True)
