set -euo pipefail
q=$(cd .. && pwd)
label=$1
base=$2
candidate=$3
mkdir -p "$label"
python3 compare.py trace "$label" "$base" "$candidate" > "$label/trace.log" 2>&1
flock "$q/build.lock" python3 compare.py wall "$label" "$base" "$candidate" > "$label/paired.txt" 2>&1
