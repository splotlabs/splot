import re
import csv
import subprocess
import os
import statistics as st
import random
from pathlib import Path
root=Path(__file__).resolve().parent
os.sched_setaffinity(0,{4})
bins={n:root/f'cdef-{n}/micro-target/release/cdef-micro' for n in ('function','module')}
pat=re.compile(r'^(sse2|avx2|auto).*?ns_per_call=([\d.]+)',re.M)
rows=[]
for exe in bins.values():
    subprocess.run([exe,'--iterations','30000'],check=True,stdout=subprocess.DEVNULL)
with (root/'micro-times.csv').open('w') as file:
    writer=csv.writer(file)
    writer.writerow(['round','order','build','backend','ns_per_call'])
    for i in range(12):
        for pos,name in enumerate(tuple(bins)[::1 if i%2==0 else -1]):
            raw=subprocess.check_output([bins[name],'--iterations','1000000'],text=True)
            vals=pat.findall(raw)
            if len(vals)!=3:
                raise RuntimeError(raw)
            for backend,timing in vals:
                row=(i+1,pos+1,name,backend,float(timing))
                rows.append(row)
                writer.writerow(row)
            file.flush()
for backend in ('sse2','avx2','auto'):
    vals={name:[r[-1] for r in rows if r[2]==name and r[3]==backend] for name in bins}
    ratios=[m/b for m,b in zip(vals['module'],vals['function'])]
    rand=random.Random(1882); boot=sorted(st.median(rand.choices(ratios,k=12)) for _ in range(5000))
    print(backend,'ns/call function',st.median(vals['function']),'module',st.median(vals['module']),'paired delta percent',round(100*(st.median(ratios)-1),2),'95% interval',*(round(100*(boot[i]-1),2) for i in (125,-126)),flush=True)
