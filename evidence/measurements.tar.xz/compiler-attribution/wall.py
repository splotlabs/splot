"""Compare the portable draft, two crate-local compiler diagnostics, and the shipped decoder."""
from pathlib import Path
import csv
import hashlib
import os
import random
import resource
import statistics
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1]
out=Path(__file__).resolve().parent
variants={'shipped':root/'shipped/target/release/splot','original':root/'final-integration/splot.full','recon':out/'recon/target/release/splot','decoder':out/'decoder/target/release/splot'}
streams={'Noise_Ocean':root/'ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf','RitualDance':next((root/'ci-data').glob('RitualDance*.ivf'))}
def env_for(label):return os.environ.copy()
def args(label,path,frames):
    return [variants[label],'decode',path,'--threads','1','--frame-delay','1',
            '--output-format','null','--limit',str(frames)]

os.sched_setaffinity(0,{4})
def run(label,path):
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    start=time.monotonic_ns()
    subprocess.run(args(label,path,64),stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,env=env_for(label),check=True)
    elapsed=(time.monotonic_ns()-start)/1e9
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    return elapsed,after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime

for label,exe in variants.items():
    with exe.open('rb') as data:
        print(label,hashlib.file_digest(data,'sha256').hexdigest(),flush=True)
    for path in streams.values():run(label,path)
names = tuple(variants)
# Four-period Williams design balances launch position and predecessor.
orders = [tuple(names[(offset + i) % 4] for i in (0, 1, 3, 2)) for offset in range(4)]
records={}
with (out/'timings.csv').open('x',newline='') as f:
    w=csv.writer(f);w.writerow(['stream','frames','round','position','mode','elapsed_s','cpu_s'])
    for r in range(12):
        sequence=list(streams.items())
        if r%2:sequence.reverse()
        for stem,path in sequence:
            order=orders[(r+list(streams).index(stem)*2)%len(orders)]
            for i,label in enumerate(order):
                values=run(label,path);records[r,stem,label]=values
                w.writerow([stem,64,r+1,i+1,label,*values]);f.flush()
for stem in streams:
    for label,base in [('recon','original'),('decoder','recon'),('decoder','original'),('original','shipped'),('recon','shipped'),('decoder','shipped')]:
        for i,metric in enumerate(('wall','CPU')):
            ratios=[100*(records[r,stem,label][i]/records[r,stem,base][i]-1) for r in range(12)]
            rng=random.Random(1882);boot=sorted(statistics.median(rng.choices(ratios,k=12)) for _ in range(10000))
            print(f'{stem} {label}/{base} {metric}: {statistics.median(ratios):+.2f}% [{boot[250]:+.2f}, {boot[-251]:+.2f}], slower {sum(x>0 for x in ratios)}/12',flush=True)
