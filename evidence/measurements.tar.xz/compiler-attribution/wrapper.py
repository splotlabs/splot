#!/usr/bin/env python3
"""Native-only diagnostic: select the compiler target for explicitly named decoder crates."""
import os
import sys

rustc, *args = sys.argv[1:]
unit = args[args.index('--crate-name')+1] if '--crate-name' in args else None
allowed = set(os.environ['SPLOT_DIAGNOSTIC_CRATES'].split(','))
flags = ['-Ctarget-cpu=x86-64-v3'] if unit in allowed else []
if unit and any(arg.startswith('--emit') for arg in args):
    with open(os.environ['SPLOT_DIAGNOSTIC_LOG'],'a') as out:
        print(unit,*flags,sep='\t',file=out)
os.execvp(rustc,[rustc,*args,*flags])
