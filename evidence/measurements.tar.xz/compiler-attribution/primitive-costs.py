"""Aggregate disjoint self instructions in out-of-line Fearless primitives."""
import collections
from pathlib import Path
import runpy

out = Path(__file__).resolve().parent
q = out.parent
read = runpy.run_path(str(q / 'noise-stage-breakdown.py'))['read']
inputs = {
    'Noise_Ocean': (q/'current-native/shipped-symbols-16.cg', q/'cdef-boundary-ab/direct/Noise_Ocean-base.cg'),
    'RitualDance': (out/'ritual-shipped-symbols.cg', q/'cdef-boundary-ab/direct/RitualDance-base.cg'),
}
for workload, paths in inputs.items():
    for build, path in zip(('shipped', 'portable'), paths):
        own, edges, calls = read(path)
        # Limit classification to primitive implementations; exclude application
        # vectorization entry points (which legitimately contain complete loops).
        def primitive(fn):
            return fn.startswith(('<fearless_simd::','fearless_simd::')) and 'splot_' not in fn and '::vectorize::vectorize_' not in fn
        total = sum(v for fn,v in own.items() if primitive(fn))
        print(f'{workload} {build} {own.total():,} total, {total:,} disjoint primitive self Ir')
        callers = collections.Counter()
        for (caller,callee), count in calls.items():
            if not primitive(caller) and primitive(callee):
                callers[caller] += count
        for caller, count in callers.most_common(8):
            print(f'  {count:>10,} calls from {caller[:220]}')
