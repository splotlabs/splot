set -euo pipefail
out=$(pwd -P)
q=$(dirname "$out")
repo=$q/../splot-1987-budget
base=$q/final-integration/splot.full
[[ $(git -C "$repo" rev-parse HEAD) == 6387bf3f0dcfe12ca23408d79b56de1565592ee1 ]]
git -C "$repo" diff --quiet
for variant in recon decoder; do
 dir=$out/$variant; mkdir -p "$dir/target"
 crates=splot_recon
 if [[ $variant == decoder ]]; then crates=splot_core,splot_parallel,splot_tables,splot_recon,splot_decode; fi
 (
  flock -x 9
  rsync -a --exclude='*splot*' --exclude='*xtask*' --exclude='.cargo-*lock' "$q/final-integration/target/" "$dir/target/"
  cd "$repo"
  taskset -c 6-11,14-19 env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u CARGO_BUILD_RUSTFLAGS CARGO_PROFILE_RELEASE_STRIP=none CARGO_TARGET_DIR="$dir/target" RUSTC_WRAPPER="$out/wrapper.py" SPLOT_DIAGNOSTIC_CRATES="$crates" SPLOT_DIAGNOSTIC_LOG="$dir/units.tsv" cargo build --locked --offline --release -j1 -p splot-cli
 ) 9>"$q/build.lock" > "$dir/build.log" 2>&1
 bin=$dir/target/release/splot
 sha256sum "$bin" > "$dir/sha256.txt"
 python3 "$out/validate.py" "$variant" > "$dir/oracle.txt"
 for name in Noise_Ocean RitualDance; do
  if [[ $name == Noise_Ocean ]]; then ivf=$q/ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf; else files=("$q/ci-data/RitualDance"*.ivf); ivf=${files[0]}; fi
  taskset -c 2 valgrind --tool=callgrind --callgrind-out-file="$dir/$name.cg" --log-file="$dir/$name.cg.log" "$bin" decode "$ivf" --threads 1 --frame-delay 1 --output-format null --limit 16
 done
done
flock "$q/build.lock" python3 "$out/wall.py" > "$out/paired.txt"
