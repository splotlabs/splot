from pathlib import Path
import sys, os, subprocess, hashlib
p=Path(__file__).resolve().parent; v=sys.argv[1]; d=p/v
observed={row.split('\t')[0] for row in (d/'units.tsv').read_text().splitlines() if '-Ctarget-cpu=x86-64-v3' in row}
expected={'splot_recon'} if v=='recon' else {'splot_recon','splot_decode','splot_core','splot_tables','splot_parallel'}
assert expected==observed,(expected,observed)
os.sched_setaffinity(0,{3})
for row in (p.parent/'ci-data/simd-cases.tsv').read_text().splitlines():
    name,sha,frames,size=row.split('\t');
    if not name.startswith(('Noise_Ocean_1920x1080_60fps_qp135_','RitualDance')):continue
    n=0;h=hashlib.sha256()
    with subprocess.Popen([d/'target/release/splot','decode',p.parent/'ci-data'/name,'--threads','1','--frame-delay','1','--output-format','raw','-o','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE) as proc:
        while block:=proc.stdout.read(1024*1024):h.update(block);n+=len(block)
        assert proc.wait()==0,proc.stderr.read()
    assert h.hexdigest()==sha and n==int(size); print(name,n,sha,flush=True)
