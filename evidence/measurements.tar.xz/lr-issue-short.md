## Shared luma Wiener restoration experiment

**Rollout decision: keep the standalone restoration crates and compiler wrapper on the experiment branch.** Ordinary Cargo successfully reaches the concrete kernel in a downstream application. Its 600-frame RitualDance elapsed median improved by 0.49% against control, with a 95% paired interval spanning −1.13% to +10.32%. The extra compiler flags saved another 0.084% of whole-application instructions and the full-stream unit-vs-plain interval also includes zero. The ordinary release CLI was faster in the short RitualDance prefix (−8.89%, interval −17.72% to −0.17%), but remained slower than shipped on that prefix and the downstream full stream did not establish a repeatable improvement. That evidence does not justify two extra crates or a wrapper in the release. [Measured source](https://github.com/splotlabs/splot/commit/9b8a8b639dae69a3fd6a4ea04b3b5acddbf0a969) · [Signed lint-only follow-up](https://github.com/splotlabs/splot/commit/deba2c412167159ad56a767bbe463ad37c50b5ef).

The measured control is `07cdddce`. The experiment uses `9b8a8b63` on `experiment/simd-1934-lr-module`. The decoder hands the startup-selected AVX2 token, borrowed 10-bit rows, class weights, and output slice to one concrete luma Wiener run. PC-Wiener and luma retain their respective taps. The traversal and the AVX2 tap arithmetic are shared with existing code. SSE2 and NEON retain their own entries. The tested restoration scope is the 10-bit luma Wiener run, previously called 46,794 times in the 16-frame RitualDance control.

**Control** is the previous in-tree implementation. **Ordinary Cargo** builds the extracted code through normal path dependencies. **AVX2 unit flags** builds the same source with the optional experiment wrapper applying the Fearless SIMD 1.2.0 feature contract only to `splot_lr_avx2`. The main decoder and other crates build at baseline. The external program has no checkout Cargo configuration or custom release profile. Its release settings differ from the workspace CLI, so comparisons are paired within each program.

### External decoder playback

Twelve paired rounds per input, one pinned worker, frame delay one, null output, after warmup. Each of the six three-build launch orders appears twice. Changes are paired median elapsed time with 95% paired bootstrap intervals. Negative elapsed changes are faster.

```text
RitualDance 16 plain/control: -1.64% [-3.88, +0.62]
RitualDance 16 unit/plain: +0.82% [-1.39, +1.74]
RitualDance 16 unit/control: -1.08% [-3.89, +0.75]
RitualDance 600 plain/control: -0.49% [-1.13, +10.32]
RitualDance 600 unit/plain: -0.39% [-2.67, +0.60]
RitualDance 600 unit/control: -1.09% [-2.49, +5.58]
TunnelFlag 40 plain/control: +0.06% [-1.11, +4.72]
TunnelFlag 40 unit/plain: -1.49% [-4.93, -0.24]
TunnelFlag 40 unit/control: -0.26% [-1.92, +2.02]
```

### Linked release CLI playback

Four builds, 12 balanced rounds, one worker and null output. WITCHER3 and TunnelFlag use 40 frames. RitualDance and Noise_Ocean use 16. Shipped v3 is `10279846`.

| Input | Ordinary vs separately compiled unit | Ordinary vs control | Ordinary vs shipped v3 |
|---|---:|---:|---:|
| WITCHER3 | +3.44% [-2.80, +15.86] | +5.63% [-5.41, +11.51] | +13.48% [+2.63, +16.09] |
| TunnelFlag | +2.62% [-28.99, +16.62] | -5.37% [-24.63, +3.61] | +10.69% [-15.07, +16.60] |
| RitualDance | -6.15% [-8.69, +2.10] | -8.89% [-17.72, -0.17] | +9.90% [+3.40, +19.38] |
| Noise_Ocean | +1.15% [-3.78, +11.37] | +2.35% [-4.10, +12.93] | +29.04% [+24.90, +44.70] |

### Kernel and instruction measurements

The separate plain-Cargo kernel driver measured the same 64 input cases under both compiler settings. Median timings were plain 374.15 ns/run, unit 382.10 ns/run.

```text
luma runs unit/plain: -3.01% [-5.60, +6.70]
```

Callgrind guest instructions on the same 16 displayed RitualDance frames.

| Program | Control | Ordinary Cargo | AVX2 unit flags | Ordinary vs control | Unit vs ordinary |
|---|---:|---:|---:|---:|---:|
| External consumer | 5,941,939,319 | 5,927,148,604 | 5,922,192,122 | -0.249% | -0.084% |
| Release CLI | 5,331,986,361 | 5,312,934,008 | 5,307,982,422 | -0.357% | -0.093% |

| Stripped release artifact | Control | Ordinary Cargo | AVX2 unit flags |
|---|---:|---:|---:|
| splot | 16,869,232 | 16,865,088 | 16,864,560 |
| libsplot_capi.so | 13,159,816 | 13,156,024 | 13,155,992 |

The external application called the concrete luma run 46,794 times in the 16-frame trace. The in-tree control spent 191,465,491 guest instructions inside that call edge. The plain Cargo prototype spent 175,852,024 (8.15% fewer). Both ran the same 46,794 calls. The linked ordinary-Cargo AVX2 body in the external application contained 644 instructions, including 116 vector mnemonics and no CPUID. The explicitly compiled unit reduced the linked body to 573 instructions and 2,933 bytes and used 170,900,392 guest instructions across the same 46,794 calls. These instruction counts describe that function and do not measure application wall time.

### Hardware and source revisions

The native Intel Xeon 6975P-C passed all 63 full-stream comparisons on the measured prototype (21 Auto selecting AVX2, 21 forced AVX2 and 21 forced AVX-512) and four backend lifecycle tests. The first hosted VM lacked the required AVX-512 features and the hardware precondition rejected it. [Native run, attempt 2](https://github.com/splotlabs/splot/actions/runs/45634575719/attempts/2). Apple ARM64 cross-compilation passed for the reconstruction crate and its test targets. Native M2 Max first-picture timing remains tracked in [#1993](https://github.com/splotlabs/splot/issues/1993). The follow-up `deba2c41` removes an unused Clippy expectation while retaining the inlining attribute. Native all-target checks, Apple ARM64 cross-checks, and Clippy with `-D warnings` passed for the checked crates. The two prototype builds use identical kernel arithmetic.


Both prototype builds passed 64 independent scalar cases, 21 complete AVM hashes and 40 strict SSE2 CLI/C comparisons each. The three independent Rust applications each passed 15 full/fixture output checks. External Cargo used default release settings. The CLI used the repository release profile. The optional unit wrapper only changed compiler flags for `splot_lr_avx2`. Host i7-12700H, Rust 1.100.0, one worker pinned to CPU 4.
