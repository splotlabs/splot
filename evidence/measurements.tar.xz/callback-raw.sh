set -euo pipefail
root=$(pwd)
repo="$root/../splot-1934-blend-callback"
out="$root/callback"
cli="$out/target/release/splot"
qemu="$root/qemu/usr/bin/qemu-x86_64"
cpu=qemu64,-pni,-sse4a,-ssse3,-sse4.1,-sse4.2
cc -O2 -march=x86-64 -I "$repo/crates/splot-capi/include" "$repo/crates/splot-capi/examples/decode.c" -L "$out/target/release" -lsplot_capi -Wl,-rpath,"$out/target/release" -o "$out/c-example"
fixtures=(
syn-3frame-multiref-64x64
syn-8frame-opfl-refine-all-64x64-q120
syn-3frame-deblock-subpu-chroma-64x32-10bit-q90
syn-filmgrain-intra-64x64
syn-bru-lr-stripe-wienerns-8bit
syn-bru-lr-stripe-wienerns-10bit
syn-bru-lr-stripe-pcwiener-8bit
syn-bru-lr-stripe-pcwiener-10bit
syn-bru-lr-multitile-cross-8bit
syn-bru-gdf-block-10bit
)
for name in "${fixtures[@]}"; do
 ivf="$repo/tests/conformance/vectors/valid/$name.ivf"
 "$root/shipped/target/release/splot" decode "$ivf" --threads 1 --output-format raw -o "$out/reference.yuv"
 for threads in 1 3 8; do
  "$qemu" -cpu "$cpu" "$cli" decode "$ivf" --threads "$threads" --output-format raw -o "$out/output.yuv"
  cmp "$out/reference.yuv" "$out/output.yuv"
 done
 "$qemu" -cpu "$cpu" "$out/c-example" "$ivf" "$out/output.yuv"
 cmp "$out/reference.yuv" "$out/output.yuv"
 echo "PASS $name"
done
python3 -u avm.py "$cli" > "$out/avm.txt"
