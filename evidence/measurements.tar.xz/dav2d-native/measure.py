from pathlib import Path
import csv, hashlib, json, os, random, resource, statistics, subprocess, time
p=Path(__file__).resolve().parent
q=p.parent
binaries={'ordinary':Path('<LOCAL_PATH>'),'v3':p/'build-v3/tools/dav2d'}
streams={'Noise_Ocean':q/'ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf','RitualDance':next((q/'ci-data').glob('RitualDance*.ivf'))}
expected={name:(sha,int(size)) for name,sha,frames,size in (row.split('\t') for row in (q/'ci-data/simd-cases.tsv').read_text().splitlines())}
opts=[]
for binary in binaries.values():
    b=binary.parents[1];opts.append({v['name']:v['value'] for v in json.loads((b/'meson-info/intro-buildoptions.json').read_text())})
    assert (b/'include/vcs_version.h').read_text().strip().endswith('0.0.1-690-g9dc084b6"')
assert opts[0]['c_args']==[] and opts[1]['c_args']==['-march=x86-64-v3']
assert all(opts[0][key]==opts[1][key] for key in ('enable_asm','enable_tests','enable_tools','bitdepths','optimization','buildtype','b_lto','default_library'))
print('Meson option differences',[(k,v,opts[1].get(k)) for k,v in opts[0].items() if v!=opts[1].get(k)],flush=True)
for name in ('cdef_avx2', 'cdef16_avx2'):
    digests = []
    for label, binary in binaries.items():
        obj = binary.parents[1] / 'src/libdav2d.so.1.0.0.p' / (name + '.obj')
        section = p / f'{name}-{label}.text'
        subprocess.run(['objcopy', '-O', 'binary', '--only-section=.text', obj, section], check=True)
        data = section.read_bytes()
        assert len(data) > 0
        digests.append(hashlib.sha256(data).hexdigest())
        print(label, name, len(data), digests[-1], flush=True)
    assert digests[0] == digests[1], (name, digests)
def cmd(label,path,mux,limit=None):
    return [str(binaries[label]),'--quiet','--threads','1','--framedelay','1','--muxer',mux,'-i',str(path),'-o','-' if mux=='yuv' else '/dev/null']+([] if limit is None else ['--limit',str(limit)])
os.sched_setaffinity(0,{3})
for label in binaries:
    for name,path in streams.items():
        h=hashlib.sha256();size=0
        with subprocess.Popen(cmd(label,path,'yuv'),stdout=subprocess.PIPE,stderr=subprocess.PIPE) as proc:
            while block:=proc.stdout.read(1024*1024): h.update(block);size+=len(block)
            assert proc.wait()==0, proc.stderr.read()
        print(label,name,h.hexdigest(),size,flush=True)
        assert (h.hexdigest(),size)==expected[path.name]
os.sched_setaffinity(0,{4})
def measure(label,path):
    start=time.monotonic_ns();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    subprocess.run(cmd(label,path,'null',64),stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=True)
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    return (time.monotonic_ns()-start)/1e9,after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
for label in binaries:
    for path in streams.values():measure(label,path)
rows={}
with (p/'timings.csv').open('x',newline='') as f:
    w=csv.writer(f);w.writerow(['stream','frames','round','position','build','elapsed_s','cpu_s'])
    for r in range(12):
        for name,path in list(streams.items())[::1 if not r%2 else -1]:
            labels=list(binaries)[::1 if not (r+list(streams).index(name))%2 else -1]
            for i,label in enumerate(labels):
                vals=measure(label,path);rows[r,name,label]=vals;w.writerow([name,64,r+1,i+1,label,*vals]);f.flush()
for name in streams:
    for i,m in enumerate(('wall','CPU')):
        deltas=[100*(rows[r,name,'ordinary'][i]/rows[r,name,'v3'][i]-1) for r in range(12)]
        rng=random.Random(1882);z=sorted(statistics.median(rng.choices(deltas,k=12)) for _ in range(10000));print(f'{name} ordinary/v3 {m} {statistics.median(deltas):+.2f}% [{z[250]:+.2f},{z[-251]:+.2f}]',flush=True)
