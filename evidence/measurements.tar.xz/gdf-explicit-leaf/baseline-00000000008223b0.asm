
<WORKTREES>/splot-1934-tip-overlap/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

00000000008223b0 <_RINvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane9row_indexNtB4_11TiledWindowKj0_Kb0_Kb1_EBa_>:
  8223b0:	push   rbx
  8223b1:	sub    rsp,0x30
  8223b5:	mov    rbx,rdi
  8223b8:	lea    rax,[rsp+0x7]
  8223bd:	mov    QWORD PTR [rsp+0x8],rax
  8223c2:	mov    QWORD PTR [rsp+0x10],rsi
  8223c7:	mov    QWORD PTR [rsp+0x18],rdx
  8223cc:	mov    QWORD PTR [rsp+0x20],r8
  8223d1:	mov    QWORD PTR [rsp+0x28],rcx
  8223d6:	lea    rsi,[rsp+0x8]
  8223db:	call   945740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane9row_indexNtB1Z_11TiledWindowKj0_Kb0_Kb1_E0Atj10_EB25_>
  8223e0:	mov    rax,rbx
  8223e3:	add    rsp,0x30
  8223e7:	pop    rbx
  8223e8:	ret
