from collections import Counter
from pathlib import Path
import re
import subprocess
import sys

for case, binary in (argument.split("=", 1) for argument in sys.argv[1:]):
    binary = Path(binary).resolve()
    symbols = subprocess.check_output(["nm", "-n", "-S", "--demangle=rust", binary], text=True)
    for symbol in symbols.splitlines():
        fields = symbol.split(None, 3)
        if len(fields) != 4:
            continue
        addr, size, kind, name = fields
        original = "gdf::simd::inlane::row_index" in name and re.search(r"TiledWindow, [01], false, true", name)
        candidate = "gdf::simd::inlane::tiled_transposed_" in name
        if not (original or candidate):
            continue
        start = int(addr, 16)
        asm = subprocess.check_output(
            [
                "objdump", "-d", "--no-show-raw-insn", "-Mintel",
                f"--start-address={start}", f"--stop-address={start + int(size, 16)}", binary,
            ], text=True
        )
        Path(f"{case}-{addr}.asm").write_text(asm)
        rows = [match[1] for line in asm.splitlines() if (match := re.match(r"\s*[a-f0-9]+:\s+(.+)", line))]
        mnemonics = Counter(row.split()[0] for row in rows)
        frame = [row for row in rows if row.startswith("sub    rsp,")]
        spills = sum("rsp" in row and row.startswith(("vmov", "vp")) for row in rows)
        print(case, addr, len(rows), frame, f"stack SIMD {spills}", {op: mnemonics[op] for op in ("vmovdqu", "vpxor", "vpand", "vpmaddwd", "call")}, name)
