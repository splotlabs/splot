
<WORKTREES>/splot-1934-tip-overlap/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000945740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane9row_indexNtB1Z_11TiledWindowKj0_Kb0_Kb1_E0Atj10_EB25_>:
  945740:	sub    rsp,0x328
  945747:	mov    rax,QWORD PTR [rsi+0x8]
  94574b:	mov    rdx,QWORD PTR [rsi+0x10]
  94574f:	mov    rcx,QWORD PTR [rax]
  945752:	vmovdqu ymm0,YMMWORD PTR [rcx+0xd8c]
  94575a:	vmovdqa ymm6,YMMWORD PTR [rdx]
  94575e:	vpaddw ymm7,ymm0,YMMWORD PTR [rip+0xffffffffff6d6c5a]        # 1c3c0 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xa0>
  945766:	vpsubw ymm1,ymm7,YMMWORD PTR [rcx+0xd88]
  94576e:	vpsubw ymm2,ymm7,YMMWORD PTR [rcx+0x90c]
  945776:	mov    rax,QWORD PTR [rsi+0x18]
  94577a:	vpxor  ymm3,ymm1,ymm2
  94577e:	vpand  ymm3,ymm3,ymm6
  945782:	vpxor  ymm2,ymm2,ymm3
  945786:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x2a0]
  94578f:	vpminuw ymm2,ymm2,YMMWORD PTR [rax+0x2c0]
  945798:	vpaddw ymm8,ymm0,YMMWORD PTR [rip+0xffffffffff6d70c0]        # 1c860 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0x540>
  9457a0:	vpsubw ymm4,ymm8,YMMWORD PTR [rcx+0xd90]
  9457a8:	vmovdqa ymm14,YMMWORD PTR [rax+0x9a0]
  9457b0:	vmovdqu YMMWORD PTR [rsp-0x80],ymm14
  9457b6:	vpsubw ymm5,ymm8,YMMWORD PTR [rcx+0x120c]
  9457be:	vpxor  ymm9,ymm4,ymm5
  9457c2:	vpand  ymm9,ymm9,ymm6
  9457c6:	vpxor  ymm5,ymm9,ymm5
  9457ca:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x2e0]
  9457d3:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x300]
  9457dc:	vpaddusw ymm2,ymm2,ymm5
  9457e0:	vpxor  ymm1,ymm1,ymm3
  9457e4:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x820]
  9457ed:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x840]
  9457f6:	vpbroadcastw ymm0,WORD PTR [rip+0xffffffffff70021b]        # 45a1a <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18ae>
  9457ff:	vpxor  ymm3,ymm9,ymm4
  945803:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x860]
  94580c:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x880]
  945815:	vpsubw ymm5,ymm7,YMMWORD PTR [rcx+0xd86]
  94581d:	vpmaxuw ymm2,ymm2,ymm0
  945822:	vpsubw ymm4,ymm7,YMMWORD PTR [rcx+0x6cc]
  94582a:	vpxor  ymm9,ymm5,ymm4
  94582e:	vpand  ymm9,ymm9,ymm6
  945832:	vpxor  ymm4,ymm9,ymm4
  945836:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x1a0]
  94583f:	vpminuw ymm10,ymm4,YMMWORD PTR [rax+0x1c0]
  945848:	vpsubw ymm12,ymm8,YMMWORD PTR [rcx+0xd92]
  945850:	vpaddusw ymm1,ymm1,ymm3
  945854:	vpsubw ymm3,ymm8,YMMWORD PTR [rcx+0x144c]
  94585c:	vpxor  ymm4,ymm12,ymm3
  945860:	vpand  ymm13,ymm4,ymm6
  945864:	vpxor  ymm3,ymm13,ymm3
  945868:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x1e0]
  945871:	vpmaxuw ymm4,ymm1,ymm0
  945876:	vpminuw ymm1,ymm3,YMMWORD PTR [rax+0x200]
  94587f:	vpxor  ymm3,ymm9,ymm5
  945883:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x7a0]
  94588c:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x7c0]
  945895:	vpaddusw ymm1,ymm10,ymm1
  945899:	vpxor  ymm5,ymm12,ymm13
  94589e:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x7e0]
  9458a7:	vpmaxuw ymm11,ymm1,ymm0
  9458ac:	vpminuw ymm1,ymm5,YMMWORD PTR [rax+0x800]
  9458b5:	vpaddusw ymm1,ymm3,ymm1
  9458b9:	vpsubw ymm3,ymm7,YMMWORD PTR [rcx+0xd8a]
  9458c1:	vpsubw ymm5,ymm7,YMMWORD PTR [rcx+0xb4c]
  9458c9:	vpmaxuw ymm0,ymm1,ymm0
  9458ce:	vmovdqu YMMWORD PTR [rsp-0x20],ymm0
  9458d4:	vpxor  ymm1,ymm3,ymm5
  9458d8:	vpand  ymm1,ymm1,ymm6
  9458dc:	vpxor  ymm5,ymm5,ymm1
  9458e0:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x4a0]
  9458e9:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x4c0]
  9458f2:	vpsubw ymm9,ymm8,YMMWORD PTR [rcx+0xd8e]
  9458fa:	vpsubw ymm10,ymm8,YMMWORD PTR [rcx+0xfcc]
  945902:	vpunpckhwd ymm12,ymm11,ymm0
  945906:	vmovdqu YMMWORD PTR [rsp+0x300],ymm11
  94590f:	vpxor  ymm13,ymm9,ymm10
  945914:	vpand  ymm13,ymm13,ymm6
  945918:	vpxor  ymm10,ymm10,ymm13
  94591d:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rax+0x4e0]
  945926:	vpminuw ymm10,ymm10,YMMWORD PTR [rax+0x500]
  94592f:	vpmaddwd ymm12,ymm12,ymm14
  945934:	vmovdqa ymm14,YMMWORD PTR [rax+0xae0]
  94593c:	vpunpckhwd ymm0,ymm2,ymm4
  945940:	vmovdqu YMMWORD PTR [rsp],ymm0
  945945:	vpmaddwd ymm15,ymm14,ymm0
  945949:	vpaddd ymm12,ymm15,ymm12
  94594e:	vpaddusw ymm5,ymm10,ymm5
  945952:	vpxor  ymm1,ymm3,ymm1
  945956:	vpxor  ymm9,ymm9,ymm13
  94595b:	vmovdqa ymm3,YMMWORD PTR [rax+0xa80]
  945963:	vpbroadcastw ymm0,WORD PTR [rip+0xffffffffff7000ae]        # 45a1a <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18ae>
  94596c:	vpmaxuw ymm5,ymm5,ymm0
  945971:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x8a0]
  94597a:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x8c0]
  945983:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rax+0x8e0]
  94598c:	vpminuw ymm9,ymm9,YMMWORD PTR [rax+0x900]
  945995:	vpaddusw ymm1,ymm9,ymm1
  945999:	vpmaxuw ymm9,ymm1,ymm0
  94599e:	vpunpckhwd ymm1,ymm5,ymm9
  9459a3:	vmovdqu YMMWORD PTR [rsp+0x40],ymm1
  9459a9:	vpmaddwd ymm1,ymm1,ymm3
  9459ad:	vpaddd ymm1,ymm12,ymm1
  9459b1:	mov    rsi,QWORD PTR [rsi+0x20]
  9459b5:	vmovdqa ymm10,YMMWORD PTR [rsi+0x20]
  9459ba:	vpsubd ymm0,ymm10,ymm1
  9459be:	vmovdqu YMMWORD PTR [rsp-0x40],ymm0
  9459c4:	vpunpcklwd ymm2,ymm2,ymm4
  9459c8:	vmovdqu YMMWORD PTR [rsp+0x20],ymm2
  9459ce:	vpmaddwd ymm2,ymm14,ymm2
  9459d2:	vmovdqu ymm15,YMMWORD PTR [rsp-0x20]
  9459d8:	vpunpcklwd ymm4,ymm11,ymm15
  9459dd:	vpmaddwd ymm0,ymm4,YMMWORD PTR [rsp-0x80]
  9459e3:	vpaddd ymm0,ymm2,ymm0
  9459e7:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  9459ed:	vpunpcklwd ymm2,ymm5,ymm9
  9459f2:	vmovdqu YMMWORD PTR [rsp-0x80],ymm2
  9459f8:	vpsubw ymm5,ymm7,YMMWORD PTR [rcx+0xb50]
  945a00:	vpsubw ymm4,ymm7,YMMWORD PTR [rcx+0xb48]
  945a08:	vmovdqa ymm11,YMMWORD PTR [rdx+0x20]
  945a0d:	vpxor  ymm9,ymm5,ymm4
  945a11:	vpand  ymm9,ymm11,ymm9
  945a16:	vpxor  ymm4,ymm9,ymm4
  945a1a:	vpsubw ymm10,ymm7,YMMWORD PTR [rcx+0x90e]
  945a22:	vpsubw ymm12,ymm7,YMMWORD PTR [rcx+0x90a]
  945a2a:	vpxor  ymm9,ymm9,ymm5
  945a2e:	vpxor  ymm5,ymm10,ymm12
  945a33:	vpand  ymm5,ymm11,ymm5
  945a37:	vpxor  ymm14,ymm12,ymm5
  945a3b:	vmovdqu YMMWORD PTR [rsp+0x2e0],ymm14
  945a44:	vpsubw ymm12,ymm8,YMMWORD PTR [rcx+0xfc8]
  945a4c:	vpsubw ymm13,ymm8,YMMWORD PTR [rcx+0xfd0]
  945a54:	vpxor  ymm1,ymm10,ymm5
  945a58:	vmovdqu YMMWORD PTR [rsp+0x2a0],ymm1
  945a61:	vpxor  ymm5,ymm12,ymm13
  945a66:	vpand  ymm5,ymm11,ymm5
  945a6a:	vpxor  ymm10,ymm13,ymm5
  945a6e:	vpxor  ymm12,ymm12,ymm5
  945a72:	vpxor  ymm5,ymm14,ymm4
  945a76:	vpand  ymm5,ymm5,ymm6
  945a7a:	vmovdqu YMMWORD PTR [rsp+0x2c0],ymm5
  945a83:	vpxor  ymm4,ymm5,ymm4
  945a87:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x3a0]
  945a90:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0x3c0]
  945a99:	vpsubw ymm5,ymm8,YMMWORD PTR [rcx+0x120a]
  945aa1:	vpsubw ymm13,ymm8,YMMWORD PTR [rcx+0x120e]
  945aa9:	vpxor  ymm14,ymm13,ymm5
  945aad:	vpand  ymm14,ymm11,ymm14
  945ab2:	vpxor  ymm0,ymm14,ymm13
  945ab7:	vmovdqu YMMWORD PTR [rsp+0x280],ymm0
  945ac0:	vpxor  ymm13,ymm10,ymm0
  945ac4:	vpand  ymm0,ymm13,ymm6
  945ac8:	vmovdqu YMMWORD PTR [rsp+0x220],ymm0
  945ad1:	vpxor  ymm10,ymm10,ymm0
  945ad5:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rax+0x3e0]
  945ade:	vpxor  ymm13,ymm14,ymm5
  945ae2:	vmovdqu YMMWORD PTR [rsp+0x240],ymm13
  945aeb:	vpminuw ymm5,ymm10,YMMWORD PTR [rax+0x400]
  945af4:	vpxor  ymm10,ymm9,ymm1
  945af8:	vpand  ymm0,ymm10,ymm6
  945afc:	vmovdqu YMMWORD PTR [rsp+0x260],ymm0
  945b05:	vpxor  ymm9,ymm9,ymm0
  945b09:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rax+0x5a0]
  945b12:	vpmaddwd ymm10,ymm2,ymm3
  945b16:	vpminuw ymm3,ymm9,YMMWORD PTR [rax+0x5c0]
  945b1f:	vpxor  ymm9,ymm12,ymm13
  945b24:	vpand  ymm0,ymm9,ymm6
  945b28:	vmovdqu YMMWORD PTR [rsp+0x200],ymm0
  945b31:	vpxor  ymm9,ymm12,ymm0
  945b35:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rax+0x5e0]
  945b3e:	vpaddd ymm10,ymm10,YMMWORD PTR [rsp-0x60]
  945b44:	vpminuw ymm2,ymm9,YMMWORD PTR [rax+0x600]
  945b4d:	vmovdqa ymm9,YMMWORD PTR [rsi]
  945b51:	vpsubw ymm12,ymm7,YMMWORD PTR [rcx+0xd80]
  945b59:	vpsubw ymm0,ymm7,YMMWORD PTR [rcx+0xc]
  945b5e:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  945b64:	vpsubd ymm9,ymm9,ymm10
  945b69:	vpxor  ymm10,ymm12,ymm0
  945b6d:	vpand  ymm0,ymm10,ymm6
  945b71:	vmovdqu YMMWORD PTR [rsp+0x1e0],ymm0
  945b7a:	vpxor  ymm10,ymm12,ymm0
  945b7e:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rax+0x620]
  945b87:	vpminuw ymm10,ymm10,YMMWORD PTR [rax+0x640]
  945b90:	vpsubw ymm12,ymm8,YMMWORD PTR [rcx+0xd98]
  945b98:	vpsubw ymm1,ymm8,YMMWORD PTR [rcx+0x1b0c]
  945ba0:	vmovdqu YMMWORD PTR [rsp+0x1a0],ymm1
  945ba9:	vpackssdw ymm0,ymm9,YMMWORD PTR [rsp-0x40]
  945baf:	vmovdqu YMMWORD PTR [rsp-0x40],ymm0
  945bb5:	vpxor  ymm1,ymm12,ymm1
  945bb9:	vpand  ymm0,ymm1,ymm6
  945bbd:	vmovdqu YMMWORD PTR [rsp+0x160],ymm0
  945bc6:	vpxor  ymm1,ymm12,ymm0
  945bca:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x660]
  945bd3:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x680]
  945bdc:	vpsubw ymm9,ymm7,YMMWORD PTR [rcx+0xd82]
  945be4:	vpsubw ymm0,ymm7,YMMWORD PTR [rcx+0x24c]
  945bec:	vmovdqu YMMWORD PTR [rsp+0x1c0],ymm0
  945bf5:	vpaddusw ymm4,ymm4,ymm5
  945bf9:	vmovdqu YMMWORD PTR [rsp+0x60],ymm4
  945bff:	vpxor  ymm4,ymm9,ymm0
  945c03:	vpand  ymm0,ymm4,ymm6
  945c07:	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
  945c10:	vpxor  ymm4,ymm9,ymm0
  945c14:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x6a0]
  945c1d:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0x6c0]
  945c26:	vpsubw ymm5,ymm8,YMMWORD PTR [rcx+0xd96]
  945c2e:	vpsubw ymm0,ymm8,YMMWORD PTR [rcx+0x18cc]
  945c36:	vmovdqu YMMWORD PTR [rsp+0x140],ymm0
  945c3f:	vpaddusw ymm13,ymm3,ymm2
  945c43:	vpxor  ymm2,ymm5,ymm0
  945c47:	vpand  ymm0,ymm2,ymm6
  945c4b:	vmovdqu YMMWORD PTR [rsp+0x120],ymm0
  945c54:	vpxor  ymm2,ymm5,ymm0
  945c58:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x6e0]
  945c61:	vpminuw ymm2,ymm2,YMMWORD PTR [rax+0x700]
  945c6a:	vpaddusw ymm1,ymm10,ymm1
  945c6e:	vpaddusw ymm2,ymm4,ymm2
  945c72:	vpbroadcastw ymm14,WORD PTR [rip+0xffffffffff6ffd9f]        # 45a1a <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18ae>
  945c7b:	vpmaxuw ymm12,ymm1,ymm14
  945c80:	vpmaxuw ymm9,ymm2,ymm14
  945c85:	vmovdqa ymm10,YMMWORD PTR [rax+0x940]
  945c8d:	vpunpckhwd ymm1,ymm12,ymm9
  945c92:	vpsubw ymm2,ymm7,YMMWORD PTR [rcx+0xd84]
  945c9a:	vpmaddwd ymm1,ymm10,ymm1
  945c9e:	vpsubw ymm0,ymm7,YMMWORD PTR [rcx+0x48c]
  945ca6:	vmovdqu YMMWORD PTR [rsp+0x100],ymm0
  945caf:	vpxor  ymm3,ymm2,ymm0
  945cb3:	vpand  ymm0,ymm3,ymm6
  945cb7:	vmovdqu YMMWORD PTR [rsp+0xe0],ymm0
  945cc0:	vpxor  ymm2,ymm2,ymm0
  945cc4:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x720]
  945ccd:	vmovdqa ymm5,YMMWORD PTR [rax+0xac0]
  945cd5:	vpmaddwd ymm3,ymm5,YMMWORD PTR [rsp]
  945cda:	vpsubw ymm0,ymm8,YMMWORD PTR [rcx+0xd94]
  945ce2:	vpaddd ymm3,ymm3,ymm1
  945ce6:	vpsubw ymm1,ymm8,YMMWORD PTR [rcx+0x168c]
  945cee:	vmovdqu YMMWORD PTR [rsp+0xc0],ymm1
  945cf7:	vpxor  ymm1,ymm0,ymm1
  945cfb:	vpand  ymm4,ymm1,ymm6
  945cff:	vmovdqu YMMWORD PTR [rsp+0xa0],ymm4
  945d08:	vpminuw ymm1,ymm2,YMMWORD PTR [rax+0x740]
  945d11:	vpxor  ymm0,ymm0,ymm4
  945d15:	vpmaxuw ymm0,ymm0,YMMWORD PTR [rax+0x760]
  945d1e:	vpminuw ymm0,ymm0,YMMWORD PTR [rax+0x780]
  945d27:	vpaddusw ymm0,ymm1,ymm0
  945d2b:	vpmaxuw ymm2,ymm0,ymm14
  945d30:	vmovdqa ymm6,ymm14
  945d34:	vmovdqa ymm4,YMMWORD PTR [rax+0x980]
  945d3c:	vpunpckhwd ymm0,ymm2,ymm15
  945d41:	vpmaddwd ymm0,ymm0,ymm4
  945d45:	vpaddd ymm3,ymm3,ymm0
  945d49:	vpsubw ymm1,ymm7,YMMWORD PTR [rcx+0xb4e]
  945d51:	vpsubw ymm7,ymm7,YMMWORD PTR [rcx+0xb4a]
  945d59:	vpxor  ymm14,ymm1,ymm7
  945d5d:	vpand  ymm14,ymm14,ymm11
  945d62:	vpsubw ymm0,ymm8,YMMWORD PTR [rcx+0xfca]
  945d6a:	vpsubw ymm8,ymm8,YMMWORD PTR [rcx+0xfce]
  945d72:	vpxor  ymm15,ymm8,ymm0
  945d76:	vpand  ymm11,ymm15,ymm11
  945d7b:	vpxor  ymm7,ymm14,ymm7
  945d7f:	vpxor  ymm1,ymm14,ymm1
  945d83:	vpxor  ymm8,ymm8,ymm11
  945d88:	vpxor  ymm0,ymm11,ymm0
  945d8c:	vpmaxuw ymm7,ymm7,YMMWORD PTR [rax+0x420]
  945d95:	vpminuw ymm7,ymm7,YMMWORD PTR [rax+0x440]
  945d9e:	vpmaxuw ymm8,ymm8,YMMWORD PTR [rax+0x460]
  945da7:	vpminuw ymm8,ymm8,YMMWORD PTR [rax+0x480]
  945db0:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x520]
  945db9:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x540]
  945dc2:	vpmaxuw ymm0,ymm0,YMMWORD PTR [rax+0x560]
  945dcb:	vpaddusw ymm7,ymm8,ymm7
  945dcf:	vpminuw ymm0,ymm0,YMMWORD PTR [rax+0x580]
  945dd8:	vpaddusw ymm0,ymm1,ymm0
  945ddc:	vpmaxuw ymm1,ymm7,ymm6
  945de1:	vpmaxuw ymm0,ymm0,ymm6
  945de6:	vmovdqa ymm11,YMMWORD PTR [rax+0xa20]
  945dee:	vpunpckhwd ymm7,ymm1,ymm0
  945df2:	vmovdqu YMMWORD PTR [rsp+0x80],ymm7
  945dfb:	vpmaddwd ymm8,ymm11,ymm7
  945dff:	vpaddd ymm3,ymm8,ymm3
  945e03:	vpmaxuw ymm8,ymm6,YMMWORD PTR [rsp+0x60]
  945e0a:	vpmaxuw ymm13,ymm13,ymm6
  945e0f:	vmovdqa ymm7,ymm6
  945e13:	vmovdqa ymm14,YMMWORD PTR [rax+0x9e0]
  945e1b:	vpunpckhwd ymm15,ymm8,ymm13
  945e20:	vpmaddwd ymm15,ymm15,ymm14
  945e25:	vpaddd ymm3,ymm15,ymm3
  945e29:	vmovdqa ymm15,YMMWORD PTR [rax+0xa60]
  945e31:	vpmaddwd ymm6,ymm15,YMMWORD PTR [rsp+0x40]
  945e37:	vpaddd ymm3,ymm3,ymm6
  945e3b:	vpunpcklwd ymm6,ymm8,ymm13
  945e40:	vpmaddwd ymm6,ymm14,ymm6
  945e44:	vpunpcklwd ymm8,ymm12,ymm9
  945e49:	vpmaddwd ymm8,ymm8,ymm10
  945e4e:	vpmaddwd ymm5,ymm5,YMMWORD PTR [rsp+0x20]
  945e54:	vpaddd ymm5,ymm8,ymm5
  945e58:	vpunpcklwd ymm2,ymm2,YMMWORD PTR [rsp-0x20]
  945e5e:	vpmaddwd ymm2,ymm2,ymm4
  945e62:	vpaddd ymm2,ymm5,ymm2
  945e66:	vpunpcklwd ymm8,ymm1,ymm0
  945e6a:	vpmaddwd ymm0,ymm8,ymm11
  945e6f:	vpaddd ymm0,ymm2,ymm0
  945e73:	vpaddd ymm0,ymm0,ymm6
  945e77:	vpmaddwd ymm1,ymm15,YMMWORD PTR [rsp-0x80]
  945e7d:	vpaddd ymm0,ymm0,ymm1
  945e81:	vpbroadcastd ymm1,DWORD PTR [rax+0xb08]
  945e8a:	vpsubd ymm2,ymm1,ymm3
  945e8e:	vpsubd ymm0,ymm1,ymm0
  945e92:	vmovdqu ymm1,YMMWORD PTR [rsp+0x2c0]
  945e9b:	vpxor  ymm1,ymm1,YMMWORD PTR [rsp+0x2e0]
  945ea4:	vmovdqu ymm3,YMMWORD PTR [rsp+0x220]
  945ead:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x280]
  945eb6:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x220]
  945ebf:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x240]
  945ec8:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x260]
  945ed1:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x280]
  945eda:	vpackssdw ymm0,ymm0,ymm2
  945ede:	vpaddusw ymm1,ymm1,ymm3
  945ee2:	vmovdqu ymm2,YMMWORD PTR [rsp+0x260]
  945eeb:	vpxor  ymm2,ymm2,YMMWORD PTR [rsp+0x2a0]
  945ef4:	vmovdqu ymm3,YMMWORD PTR [rsp+0x200]
  945efd:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x240]
  945f06:	vmovdqu ymm4,YMMWORD PTR [rsp+0x1e0]
  945f0f:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp-0x60]
  945f15:	vmovdqu ymm5,YMMWORD PTR [rsp+0x160]
  945f1e:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x1a0]
  945f27:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x320]
  945f30:	vpminuw ymm2,ymm2,YMMWORD PTR [rax+0x340]
  945f39:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x360]
  945f42:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x380]
  945f4b:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x20]
  945f51:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0x40]
  945f57:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x60]
  945f5d:	vpaddusw ymm2,ymm2,ymm3
  945f61:	vpminuw ymm3,ymm5,YMMWORD PTR [rax+0x80]
  945f6a:	vpaddusw ymm3,ymm4,ymm3
  945f6e:	vmovdqu ymm4,YMMWORD PTR [rsp+0x180]
  945f77:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp+0x1c0]
  945f80:	vmovdqu ymm5,YMMWORD PTR [rsp+0x120]
  945f89:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x140]
  945f92:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0xa0]
  945f9b:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0xc0]
  945fa4:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0xe0]
  945fad:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x100]
  945fb6:	vpaddusw ymm4,ymm4,ymm5
  945fba:	vmovdqu ymm5,YMMWORD PTR [rsp+0xe0]
  945fc3:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x100]
  945fcc:	vmovdqu ymm6,YMMWORD PTR [rsp+0xa0]
  945fd5:	vpxor  ymm6,ymm6,YMMWORD PTR [rsp+0xc0]
  945fde:	vmovdqa ymm9,YMMWORD PTR [rax+0xaa0]
  945fe6:	vpmaddwd ymm10,ymm9,YMMWORD PTR [rsp]
  945feb:	vpmaxuw ymm3,ymm3,ymm7
  945ff0:	vpmaxuw ymm4,ymm4,ymm7
  945ff5:	vmovdqa ymm11,YMMWORD PTR [rax+0x920]
  945ffd:	vpunpckhwd ymm12,ymm3,ymm4
  946001:	vpmaddwd ymm12,ymm12,ymm11
  946006:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x120]
  94600f:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x140]
  946018:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rax+0x160]
  946021:	vpminuw ymm6,ymm6,YMMWORD PTR [rax+0x180]
  94602a:	vpaddd ymm10,ymm10,ymm12
  94602f:	vpaddusw ymm5,ymm5,ymm6
  946033:	vpmaxuw ymm1,ymm1,ymm7
  946038:	vpmaxuw ymm2,ymm2,ymm7
  94603d:	vpmaxuw ymm5,ymm5,ymm7
  946042:	vmovdqa ymm6,YMMWORD PTR [rax+0x960]
  94604a:	vmovdqu ymm15,YMMWORD PTR [rsp+0x300]
  946053:	vpunpckhwd ymm12,ymm5,ymm15
  946058:	vpmaddwd ymm12,ymm12,ymm6
  94605c:	vpaddd ymm10,ymm10,ymm12
  946061:	vmovdqa ymm12,YMMWORD PTR [rax+0xa00]
  946069:	vpmaddwd ymm7,ymm12,YMMWORD PTR [rsp+0x80]
  946072:	vpaddd ymm7,ymm10,ymm7
  946076:	vmovdqa ymm10,YMMWORD PTR [rax+0x9c0]
  94607e:	vpunpckhwd ymm13,ymm1,ymm2
  946082:	vpmaddwd ymm13,ymm13,ymm10
  946087:	vpaddd ymm7,ymm13,ymm7
  94608b:	vmovdqa ymm13,YMMWORD PTR [rax+0xa40]
  946093:	vpmaddwd ymm14,ymm13,YMMWORD PTR [rsp+0x40]
  946099:	vpaddd ymm7,ymm14,ymm7
  94609d:	vpmaddwd ymm9,ymm9,YMMWORD PTR [rsp+0x20]
  9460a3:	vpunpcklwd ymm1,ymm1,ymm2
  9460a7:	vpmaddwd ymm1,ymm10,ymm1
  9460ab:	vpunpcklwd ymm2,ymm3,ymm4
  9460af:	vpmaddwd ymm2,ymm11,ymm2
  9460b3:	vpaddd ymm2,ymm9,ymm2
  9460b7:	vpunpcklwd ymm3,ymm5,ymm15
  9460bc:	vpmaddwd ymm3,ymm3,ymm6
  9460c0:	vpaddd ymm2,ymm2,ymm3
  9460c4:	vpmaddwd ymm3,ymm8,ymm12
  9460c9:	vpaddd ymm2,ymm2,ymm3
  9460cd:	vpaddd ymm1,ymm2,ymm1
  9460d1:	vpmaddwd ymm2,ymm13,YMMWORD PTR [rsp-0x80]
  9460d7:	vpaddd ymm1,ymm1,ymm2
  9460db:	vpbroadcastd ymm2,DWORD PTR [rax+0xb04]
  9460e4:	vpsubd ymm3,ymm2,ymm7
  9460e8:	vpsubd ymm1,ymm2,ymm1
  9460ec:	vpackssdw ymm1,ymm1,ymm3
  9460f0:	mov    ecx,DWORD PTR [rax+0xd6c]
  9460f6:	vmovd  xmm2,ecx
  9460fa:	vpbroadcastw ymm2,xmm2
  9460ff:	vpsignw ymm3,ymm2,ymm1
  946104:	vpmulhrsw ymm3,ymm3,ymm1
  946109:	vpsignw ymm1,ymm3,ymm1
  94610e:	vpsignw ymm3,ymm2,ymm0
  946113:	vpmulhrsw ymm3,ymm3,ymm0
  946118:	vpsignw ymm0,ymm3,ymm0
  94611d:	dec    ecx
  94611f:	vmovdqu ymm3,YMMWORD PTR [rsp-0x40]
  946125:	vpsignw ymm2,ymm2,ymm3
  94612a:	vpmulhrsw ymm2,ymm2,ymm3
  94612f:	vpsignw ymm2,ymm2,ymm3
  946134:	vmovd  xmm3,ecx
  946138:	vpbroadcastw ymm3,xmm3
  94613d:	vpminsw ymm1,ymm1,ymm3
  946141:	vpminsw ymm0,ymm0,ymm3
  946145:	vpminsw ymm2,ymm2,ymm3
  946149:	vpbroadcastw ymm3,WORD PTR [rax+0xb12]
  946152:	vpmullw ymm1,ymm3,ymm1
  946156:	vpaddw ymm1,ymm1,ymm2
  94615a:	vpbroadcastw ymm2,WORD PTR [rax+0xb10]
  946163:	vpbroadcastw ymm3,WORD PTR [rax+0xb14]
  94616c:	vpmullw ymm0,ymm2,ymm0
  946170:	vpaddw ymm0,ymm0,ymm3
  946174:	vpaddw ymm0,ymm1,ymm0
  946178:	vmovdqu YMMWORD PTR [rdi],ymm0
  94617c:	add    rsp,0x328
  946183:	vzeroupper
  946186:	ret
