
<WORKTREES>/splot-1934-tip-overlap/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000822470 <_RINvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane9row_indexNtB4_11TiledWindowKj1_Kb0_Kb1_EBa_>:
  822470:	push   rbx
  822471:	sub    rsp,0x30
  822475:	mov    rbx,rdi
  822478:	lea    rax,[rsp+0x7]
  82247d:	mov    QWORD PTR [rsp+0x8],rax
  822482:	mov    QWORD PTR [rsp+0x10],rsi
  822487:	mov    QWORD PTR [rsp+0x18],rdx
  82248c:	mov    QWORD PTR [rsp+0x20],r8
  822491:	mov    QWORD PTR [rsp+0x28],rcx
  822496:	lea    rsi,[rsp+0x8]
  82249b:	call   946f80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane9row_indexNtB1Z_11TiledWindowKj1_Kb0_Kb1_E0Atj10_EB25_>
  8224a0:	mov    rax,rbx
  8224a3:	add    rsp,0x30
  8224a7:	pop    rbx
  8224a8:	ret
