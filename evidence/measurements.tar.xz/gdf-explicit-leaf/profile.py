from collections import Counter
from pathlib import Path
import re
import sys

for profile in map(Path, sys.argv[1:]):
    names = {}
    self_cost = Counter()
    edge_calls = Counter()
    edge_cost = Counter()
    function = callee = calls = None
    for line in profile.read_text().splitlines():
        if label := re.fullmatch(r"(c?fn)=\((\d+)\)(?: (.*))?", line):
            op, number, name = label.groups()
            if name:
                names[number] = name
            if op == "fn":
                function = number
                callee = calls = None
            else:
                callee = number
        elif label := re.match(r"calls=(\d+)", line):
            calls = int(label[1])
        elif label := re.fullmatch(r"[-+*\d]+\s+(\d+)", line):
            ir = int(label[1])
            if calls is None:
                self_cost[function] += ir
            else:
                edge_calls[function, callee] += calls
                edge_cost[function, callee] += ir
            calls = None
        elif label := re.match(r"summary: (\d+)", line):
            total = int(label[1])
    print(f"{profile.name}: {total:,} Ir total")
    for (caller, callee), cost in sorted(edge_cost.items(), key=lambda entry: -entry[1]):
        name = names.get(callee, "")
        old = "row_index::<" in name and re.search(r"TiledWindow, [01], false, true", name)
        candidate = "tiled_transposed_" in name
        if "filter_run" in names.get(caller, "") and (old or candidate):
            count = edge_calls[caller, callee]
            print(f"  {count:,} calls, {cost:,} Ir, {cost/count:.2f} Ir/call, {name}")
