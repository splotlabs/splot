
<WORKTREES>/splot-1934-gdf-leaf/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000c2c190 <_RNvNvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane20tiled_transposed_top22___fearless_simd_kernel>:
  c2c190:	sub    rsp,0x348
  c2c197:	vmovups YMMWORD PTR [rsp-0x40],ymm3
  c2c19d:	vmovups YMMWORD PTR [rsp+0x20],ymm2
  c2c1a3:	vmovdqu ymm2,YMMWORD PTR [rsi+0xd8c]
  c2c1ab:	vpaddw ymm9,ymm2,YMMWORD PTR [rip+0xffffffffff3f020d]        # 1c3c0 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xa0>
  c2c1b3:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0xd88]
  c2c1bb:	vmovdqa ymm7,ymm0
  c2c1bf:	vpsubw ymm5,ymm9,YMMWORD PTR [rsi+0x90c]
  c2c1c7:	vpxor  ymm6,ymm4,ymm5
  c2c1cb:	vpand  ymm6,ymm6,ymm0
  c2c1cf:	vpxor  ymm5,ymm5,ymm6
  c2c1d3:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x2a0]
  c2c1dc:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x2c0]
  c2c1e5:	vpaddw ymm10,ymm2,YMMWORD PTR [rip+0xffffffffff3f0673]        # 1c860 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0x540>
  c2c1ed:	vpsubw ymm11,ymm10,YMMWORD PTR [rsi+0xd90]
  c2c1f5:	vpsubw ymm2,ymm10,YMMWORD PTR [rsi+0x120c]
  c2c1fd:	vmovups YMMWORD PTR [rsp-0x80],ymm1
  c2c203:	vpxor  ymm1,ymm11,ymm2
  c2c207:	vpand  ymm1,ymm1,ymm0
  c2c20b:	vpxor  ymm2,ymm2,ymm1
  c2c20f:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x2e0]
  c2c218:	vpminuw ymm2,ymm2,YMMWORD PTR [rdx+0x300]
  c2c221:	vpaddusw ymm2,ymm5,ymm2
  c2c225:	vpbroadcastw ymm3,WORD PTR [rip+0xffffffffff41983a]        # 45a68 <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18fc>
  c2c22e:	vpxor  ymm4,ymm4,ymm6
  c2c232:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x820]
  c2c23b:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0x840]
  c2c244:	vpmaxuw ymm8,ymm2,ymm3
  c2c249:	vpxor  ymm1,ymm11,ymm1
  c2c24d:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x860]
  c2c256:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x880]
  c2c25f:	vpsubw ymm5,ymm9,YMMWORD PTR [rsi+0xd86]
  c2c267:	vpaddusw ymm1,ymm4,ymm1
  c2c26b:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0x6cc]
  c2c273:	vpxor  ymm6,ymm5,ymm4
  c2c277:	vpand  ymm6,ymm6,ymm0
  c2c27b:	vpxor  ymm4,ymm4,ymm6
  c2c27f:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x1a0]
  c2c288:	vpminuw ymm11,ymm4,YMMWORD PTR [rdx+0x1c0]
  c2c291:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0xd92]
  c2c299:	vpmaxuw ymm4,ymm1,ymm3
  c2c29e:	vmovdqu YMMWORD PTR [rsp],ymm4
  c2c2a3:	vpsubw ymm1,ymm10,YMMWORD PTR [rsi+0x144c]
  c2c2ab:	vpxor  ymm13,ymm12,ymm1
  c2c2af:	vpand  ymm13,ymm13,ymm0
  c2c2b3:	vpxor  ymm1,ymm13,ymm1
  c2c2b7:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x1e0]
  c2c2c0:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x200]
  c2c2c9:	vpaddusw ymm1,ymm11,ymm1
  c2c2cd:	vpxor  ymm5,ymm5,ymm6
  c2c2d1:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x7a0]
  c2c2da:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x7c0]
  c2c2e3:	vpmaxuw ymm2,ymm1,ymm3
  c2c2e8:	vpxor  ymm1,ymm12,ymm13
  c2c2ed:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x7e0]
  c2c2f6:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x800]
  c2c2ff:	vpsubw ymm6,ymm9,YMMWORD PTR [rsi+0xd8a]
  c2c307:	vpaddusw ymm1,ymm5,ymm1
  c2c30b:	vpsubw ymm5,ymm9,YMMWORD PTR [rsi+0xb4c]
  c2c313:	vpxor  ymm11,ymm6,ymm5
  c2c317:	vpand  ymm11,ymm11,ymm0
  c2c31b:	vpxor  ymm5,ymm11,ymm5
  c2c31f:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x4a0]
  c2c328:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x4c0]
  c2c331:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0xd8e]
  c2c339:	vpmaxuw ymm0,ymm1,ymm3
  c2c33e:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  c2c344:	vpsubw ymm1,ymm10,YMMWORD PTR [rsi+0xfcc]
  c2c34c:	vpxor  ymm13,ymm12,ymm1
  c2c350:	vpand  ymm13,ymm13,ymm7
  c2c354:	vpxor  ymm1,ymm13,ymm1
  c2c358:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x4e0]
  c2c361:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x500]
  c2c36a:	vmovdqa ymm15,YMMWORD PTR [rdx+0x9a0]
  c2c372:	vmovdqu YMMWORD PTR [rsp-0x20],ymm15
  c2c378:	vpunpckhwd ymm14,ymm2,ymm0
  c2c37c:	vmovdqu YMMWORD PTR [rsp+0x320],ymm2
  c2c385:	vpmaddwd ymm14,ymm14,ymm15
  c2c38a:	vmovdqa ymm15,YMMWORD PTR [rdx+0xae0]
  c2c392:	vpunpckhwd ymm0,ymm8,ymm4
  c2c396:	vmovdqa ymm4,ymm8
  c2c39a:	vpmaddwd ymm8,ymm15,ymm0
  c2c39e:	vmovdqu YMMWORD PTR [rsp+0x120],ymm0
  c2c3a7:	vpaddd ymm8,ymm8,ymm14
  c2c3ac:	vpaddusw ymm1,ymm5,ymm1
  c2c3b0:	vpxor  ymm5,ymm11,ymm6
  c2c3b4:	vpxor  ymm6,ymm12,ymm13
  c2c3b9:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x8a0]
  c2c3c2:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x8c0]
  c2c3cb:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rdx+0x8e0]
  c2c3d4:	vpminuw ymm6,ymm6,YMMWORD PTR [rdx+0x900]
  c2c3dd:	vpaddusw ymm5,ymm5,ymm6
  c2c3e1:	vpmaxuw ymm6,ymm1,ymm3
  c2c3e6:	vpmaxuw ymm5,ymm5,ymm3
  c2c3eb:	vmovdqa ymm11,YMMWORD PTR [rdx+0xa80]
  c2c3f3:	vpunpckhwd ymm1,ymm6,ymm5
  c2c3f7:	vmovdqu YMMWORD PTR [rsp+0x40],ymm1
  c2c3fd:	vpmaddwd ymm1,ymm11,ymm1
  c2c401:	vpaddd ymm1,ymm8,ymm1
  c2c405:	vmovdqu ymm3,YMMWORD PTR [rsp-0x40]
  c2c40b:	vpsubd ymm1,ymm3,ymm1
  c2c40f:	vpunpcklwd ymm4,ymm4,YMMWORD PTR [rsp]
  c2c414:	vmovdqu YMMWORD PTR [rsp],ymm4
  c2c419:	vpunpcklwd ymm3,ymm2,YMMWORD PTR [rsp-0x60]
  c2c41f:	vpmaddwd ymm3,ymm3,YMMWORD PTR [rsp-0x20]
  c2c425:	vpmaddwd ymm2,ymm15,ymm4
  c2c429:	vpaddd ymm2,ymm2,ymm3
  c2c42d:	vpunpcklwd ymm3,ymm6,ymm5
  c2c431:	vmovdqu YMMWORD PTR [rsp-0x40],ymm3
  c2c437:	vpmaddwd ymm3,ymm11,ymm3
  c2c43b:	vpaddd ymm2,ymm2,ymm3
  c2c43f:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0xb50]
  c2c447:	vpsubw ymm3,ymm9,YMMWORD PTR [rsi+0xb48]
  c2c44f:	vpxor  ymm5,ymm4,ymm3
  c2c453:	vmovdqu ymm14,YMMWORD PTR [rsp-0x80]
  c2c459:	vpand  ymm5,ymm14,ymm5
  c2c45d:	vpxor  ymm3,ymm5,ymm3
  c2c461:	vpxor  ymm5,ymm5,ymm4
  c2c465:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0x90e]
  c2c46d:	vpsubw ymm6,ymm9,YMMWORD PTR [rsi+0x90a]
  c2c475:	vpxor  ymm8,ymm4,ymm6
  c2c479:	vpand  ymm8,ymm14,ymm8
  c2c47e:	vpxor  ymm6,ymm8,ymm6
  c2c482:	vmovdqu YMMWORD PTR [rsp-0x20],ymm6
  c2c488:	vpxor  ymm6,ymm3,ymm6
  c2c48c:	vpand  ymm6,ymm6,ymm7
  c2c490:	vmovdqu YMMWORD PTR [rsp+0x300],ymm6
  c2c499:	vpxor  ymm3,ymm6,ymm3
  c2c49d:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rdx+0x3a0]
  c2c4a6:	vpminuw ymm3,ymm3,YMMWORD PTR [rdx+0x3c0]
  c2c4af:	vpsubw ymm6,ymm10,YMMWORD PTR [rsi+0xfc8]
  c2c4b7:	vpxor  ymm15,ymm8,ymm4
  c2c4bb:	vmovdqu YMMWORD PTR [rsp+0x2a0],ymm15
  c2c4c4:	vpsubw ymm4,ymm10,YMMWORD PTR [rsi+0xfd0]
  c2c4cc:	vpxor  ymm8,ymm6,ymm4
  c2c4d0:	vpand  ymm8,ymm14,ymm8
  c2c4d5:	vpxor  ymm4,ymm8,ymm4
  c2c4d9:	vpsubw ymm11,ymm10,YMMWORD PTR [rsi+0x120a]
  c2c4e1:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0x120e]
  c2c4e9:	vpxor  ymm13,ymm11,ymm12
  c2c4ee:	vpand  ymm13,ymm14,ymm13
  c2c4f3:	vpxor  ymm12,ymm13,ymm12
  c2c4f8:	vmovdqu YMMWORD PTR [rsp+0x2e0],ymm12
  c2c501:	vpxor  ymm12,ymm12,ymm4
  c2c505:	vpand  ymm12,ymm12,ymm7
  c2c509:	vmovdqu YMMWORD PTR [rsp+0x2c0],ymm12
  c2c512:	vpxor  ymm4,ymm12,ymm4
  c2c516:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x3e0]
  c2c51f:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0x400]
  c2c528:	vpxor  ymm6,ymm8,ymm6
  c2c52c:	vpxor  ymm8,ymm15,ymm5
  c2c530:	vpand  ymm8,ymm8,ymm7
  c2c534:	vmovdqu YMMWORD PTR [rsp+0x280],ymm8
  c2c53d:	vpxor  ymm5,ymm8,ymm5
  c2c541:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x5a0]
  c2c54a:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x5c0]
  c2c553:	vpxor  ymm8,ymm13,ymm11
  c2c558:	vmovdqu YMMWORD PTR [rsp+0x260],ymm8
  c2c561:	vpxor  ymm8,ymm8,ymm6
  c2c565:	vpand  ymm8,ymm8,ymm7
  c2c569:	vmovdqu YMMWORD PTR [rsp+0x240],ymm8
  c2c572:	vpxor  ymm6,ymm8,ymm6
  c2c576:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rdx+0x5e0]
  c2c57f:	vpminuw ymm6,ymm6,YMMWORD PTR [rdx+0x600]
  c2c588:	vpsubw ymm8,ymm9,YMMWORD PTR [rsi+0xd80]
  c2c590:	vpsubw ymm12,ymm9,YMMWORD PTR [rsi+0xc]
  c2c595:	vmovdqu YMMWORD PTR [rsp+0x220],ymm12
  c2c59e:	vmovdqu ymm11,YMMWORD PTR [rsp+0x20]
  c2c5a4:	vpsubd ymm2,ymm11,ymm2
  c2c5a8:	vpxor  ymm11,ymm8,ymm12
  c2c5ad:	vpand  ymm11,ymm11,ymm7
  c2c5b1:	vmovdqu YMMWORD PTR [rsp+0x200],ymm11
  c2c5ba:	vpxor  ymm8,ymm8,ymm11
  c2c5bf:	vpmaxuw ymm8,ymm8,YMMWORD PTR [rdx+0x620]
  c2c5c8:	vpminuw ymm8,ymm8,YMMWORD PTR [rdx+0x640]
  c2c5d1:	vpsubw ymm11,ymm10,YMMWORD PTR [rsi+0xd98]
  c2c5d9:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0x1b0c]
  c2c5e1:	vmovdqu YMMWORD PTR [rsp+0x1c0],ymm12
  c2c5ea:	vpackssdw ymm1,ymm2,ymm1
  c2c5ee:	vmovdqu YMMWORD PTR [rsp+0x20],ymm1
  c2c5f4:	vpxor  ymm1,ymm11,ymm12
  c2c5f9:	vpand  ymm1,ymm1,ymm7
  c2c5fd:	vmovdqu YMMWORD PTR [rsp+0x180],ymm1
  c2c606:	vpxor  ymm1,ymm11,ymm1
  c2c60a:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x660]
  c2c613:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x680]
  c2c61c:	vpsubw ymm2,ymm9,YMMWORD PTR [rsi+0xd82]
  c2c624:	vpsubw ymm11,ymm9,YMMWORD PTR [rsi+0x24c]
  c2c62c:	vmovdqu YMMWORD PTR [rsp+0x1e0],ymm11
  c2c635:	vpaddusw ymm3,ymm3,ymm4
  c2c639:	vmovdqu YMMWORD PTR [rsp+0x80],ymm3
  c2c642:	vpxor  ymm3,ymm11,ymm2
  c2c646:	vpand  ymm3,ymm3,ymm7
  c2c64a:	vmovdqu YMMWORD PTR [rsp+0x1a0],ymm3
  c2c653:	vpxor  ymm2,ymm2,ymm3
  c2c657:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x6a0]
  c2c660:	vpminuw ymm2,ymm2,YMMWORD PTR [rdx+0x6c0]
  c2c669:	vpsubw ymm3,ymm10,YMMWORD PTR [rsi+0xd96]
  c2c671:	vpsubw ymm4,ymm10,YMMWORD PTR [rsi+0x18cc]
  c2c679:	vmovdqu YMMWORD PTR [rsp+0x160],ymm4
  c2c682:	vpaddusw ymm11,ymm5,ymm6
  c2c686:	vpxor  ymm4,ymm3,ymm4
  c2c68a:	vpand  ymm4,ymm4,ymm7
  c2c68e:	vmovdqu YMMWORD PTR [rsp+0x140],ymm4
  c2c697:	vpxor  ymm3,ymm3,ymm4
  c2c69b:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rdx+0x6e0]
  c2c6a4:	vpminuw ymm3,ymm3,YMMWORD PTR [rdx+0x700]
  c2c6ad:	vpaddusw ymm1,ymm8,ymm1
  c2c6b1:	vpaddusw ymm2,ymm2,ymm3
  c2c6b5:	vpbroadcastw ymm12,WORD PTR [rip+0xffffffffff4193aa]        # 45a68 <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18fc>
  c2c6be:	vpmaxuw ymm1,ymm1,ymm12
  c2c6c3:	vmovdqu YMMWORD PTR [rsp+0x60],ymm1
  c2c6c9:	vpmaxuw ymm6,ymm2,ymm12
  c2c6ce:	vmovdqa ymm5,YMMWORD PTR [rdx+0x940]
  c2c6d6:	vpunpckhwd ymm1,ymm1,ymm6
  c2c6da:	vpsubw ymm2,ymm9,YMMWORD PTR [rsi+0xd84]
  c2c6e2:	vpmaddwd ymm1,ymm1,ymm5
  c2c6e6:	vpsubw ymm3,ymm9,YMMWORD PTR [rsi+0x48c]
  c2c6ee:	vmovdqu YMMWORD PTR [rsp+0x100],ymm3
  c2c6f7:	vpxor  ymm3,ymm2,ymm3
  c2c6fb:	vpand  ymm3,ymm3,ymm7
  c2c6ff:	vmovdqu YMMWORD PTR [rsp+0xe0],ymm3
  c2c708:	vpxor  ymm2,ymm2,ymm3
  c2c70c:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x720]
  c2c715:	vmovdqa ymm4,YMMWORD PTR [rdx+0xac0]
  c2c71d:	vpmaddwd ymm8,ymm0,ymm4
  c2c721:	vpsubw ymm14,ymm10,YMMWORD PTR [rsi+0xd94]
  c2c729:	vpaddd ymm8,ymm8,ymm1
  c2c72d:	vpsubw ymm0,ymm10,YMMWORD PTR [rsi+0x168c]
  c2c735:	vmovdqu YMMWORD PTR [rsp+0xc0],ymm0
  c2c73e:	vpxor  ymm1,ymm14,ymm0
  c2c742:	vpand  ymm1,ymm1,ymm7
  c2c746:	vmovdqu YMMWORD PTR [rsp+0xa0],ymm1
  c2c74f:	vpminuw ymm0,ymm2,YMMWORD PTR [rdx+0x740]
  c2c758:	vpxor  ymm1,ymm14,ymm1
  c2c75c:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x760]
  c2c765:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x780]
  c2c76e:	vpaddusw ymm0,ymm0,ymm1
  c2c772:	vpmaxuw ymm1,ymm0,ymm12
  c2c777:	vmovdqa ymm3,YMMWORD PTR [rdx+0x980]
  c2c77f:	vmovdqu ymm7,YMMWORD PTR [rsp-0x60]
  c2c785:	vpunpckhwd ymm2,ymm1,ymm7
  c2c789:	vpmaddwd ymm2,ymm2,ymm3
  c2c78d:	vpaddd ymm2,ymm8,ymm2
  c2c791:	vpsubw ymm8,ymm9,YMMWORD PTR [rsi+0xb4e]
  c2c799:	vpsubw ymm9,ymm9,YMMWORD PTR [rsi+0xb4a]
  c2c7a1:	vpxor  ymm14,ymm8,ymm9
  c2c7a6:	vmovdqu ymm13,YMMWORD PTR [rsp-0x80]
  c2c7ac:	vpand  ymm14,ymm14,ymm13
  c2c7b1:	vpsubw ymm0,ymm10,YMMWORD PTR [rsi+0xfca]
  c2c7b9:	vpsubw ymm10,ymm10,YMMWORD PTR [rsi+0xfce]
  c2c7c1:	vpxor  ymm15,ymm10,ymm0
  c2c7c5:	vpand  ymm15,ymm15,ymm13
  c2c7ca:	vpxor  ymm9,ymm9,ymm14
  c2c7cf:	vpxor  ymm8,ymm8,ymm14
  c2c7d4:	vpxor  ymm10,ymm10,ymm15
  c2c7d9:	vpxor  ymm0,ymm15,ymm0
  c2c7dd:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rdx+0x420]
  c2c7e6:	vpminuw ymm9,ymm9,YMMWORD PTR [rdx+0x440]
  c2c7ef:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rdx+0x460]
  c2c7f8:	vpminuw ymm10,ymm10,YMMWORD PTR [rdx+0x480]
  c2c801:	vpmaxuw ymm8,ymm8,YMMWORD PTR [rdx+0x520]
  c2c80a:	vpminuw ymm8,ymm8,YMMWORD PTR [rdx+0x540]
  c2c813:	vpmaxuw ymm0,ymm0,YMMWORD PTR [rdx+0x560]
  c2c81c:	vpaddusw ymm9,ymm9,ymm10
  c2c821:	vpminuw ymm0,ymm0,YMMWORD PTR [rdx+0x580]
  c2c82a:	vpaddusw ymm0,ymm8,ymm0
  c2c82e:	vpmaxuw ymm8,ymm9,ymm12
  c2c833:	vpmaxuw ymm0,ymm0,ymm12
  c2c838:	vmovdqa ymm14,YMMWORD PTR [rdx+0xa20]
  c2c840:	vpunpckhwd ymm9,ymm8,ymm0
  c2c844:	vmovdqu YMMWORD PTR [rsp-0x80],ymm9
  c2c84a:	vpmaddwd ymm10,ymm9,ymm14
  c2c84f:	vpaddd ymm2,ymm10,ymm2
  c2c853:	vpmaxuw ymm10,ymm12,YMMWORD PTR [rsp+0x80]
  c2c85d:	vpmaxuw ymm11,ymm11,ymm12
  c2c862:	vmovdqa ymm9,ymm12
  c2c867:	vmovdqa ymm15,YMMWORD PTR [rdx+0x9e0]
  c2c86f:	vpunpckhwd ymm13,ymm10,ymm11
  c2c874:	vpmaddwd ymm13,ymm13,ymm15
  c2c879:	vpaddd ymm2,ymm13,ymm2
  c2c87d:	vmovdqa ymm13,YMMWORD PTR [rdx+0xa60]
  c2c885:	vpmaddwd ymm12,ymm13,YMMWORD PTR [rsp+0x40]
  c2c88b:	vpaddd ymm2,ymm12,ymm2
  c2c88f:	vpunpcklwd ymm10,ymm10,ymm11
  c2c894:	vpmaddwd ymm11,ymm10,ymm15
  c2c899:	vmovdqu ymm10,YMMWORD PTR [rsp+0x60]
  c2c89f:	vpunpcklwd ymm6,ymm10,ymm6
  c2c8a3:	vpmaddwd ymm5,ymm6,ymm5
  c2c8a7:	vmovdqu ymm10,YMMWORD PTR [rsp]
  c2c8ac:	vpmaddwd ymm4,ymm10,ymm4
  c2c8b0:	vpaddd ymm4,ymm4,ymm5
  c2c8b4:	vpunpcklwd ymm1,ymm1,ymm7
  c2c8b8:	vpmaddwd ymm1,ymm1,ymm3
  c2c8bc:	vpaddd ymm1,ymm4,ymm1
  c2c8c0:	vpunpcklwd ymm0,ymm8,ymm0
  c2c8c4:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  c2c8ca:	vpmaddwd ymm0,ymm14,ymm0
  c2c8ce:	vpaddd ymm0,ymm1,ymm0
  c2c8d2:	vpaddd ymm0,ymm11,ymm0
  c2c8d6:	vpmaddwd ymm1,ymm13,YMMWORD PTR [rsp-0x40]
  c2c8dc:	vpaddd ymm0,ymm0,ymm1
  c2c8e0:	vpbroadcastd ymm1,DWORD PTR [rdx+0xb08]
  c2c8e9:	vpsubd ymm2,ymm1,ymm2
  c2c8ed:	vpsubd ymm0,ymm1,ymm0
  c2c8f1:	vmovdqu ymm1,YMMWORD PTR [rsp+0x300]
  c2c8fa:	vpxor  ymm1,ymm1,YMMWORD PTR [rsp-0x20]
  c2c900:	vmovdqu ymm3,YMMWORD PTR [rsp+0x2c0]
  c2c909:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x2e0]
  c2c912:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x220]
  c2c91b:	vpminuw ymm4,ymm1,YMMWORD PTR [rdx+0x240]
  c2c924:	vpmaxuw ymm1,ymm3,YMMWORD PTR [rdx+0x260]
  c2c92d:	vpminuw ymm3,ymm1,YMMWORD PTR [rdx+0x280]
  c2c936:	vpackssdw ymm1,ymm0,ymm2
  c2c93a:	vpaddusw ymm0,ymm4,ymm3
  c2c93e:	vmovdqu ymm2,YMMWORD PTR [rsp+0x280]
  c2c947:	vpxor  ymm2,ymm2,YMMWORD PTR [rsp+0x2a0]
  c2c950:	vmovdqu ymm3,YMMWORD PTR [rsp+0x240]
  c2c959:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x260]
  c2c962:	vmovdqu ymm4,YMMWORD PTR [rsp+0x200]
  c2c96b:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp+0x220]
  c2c974:	vmovdqu ymm5,YMMWORD PTR [rsp+0x180]
  c2c97d:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x1c0]
  c2c986:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x320]
  c2c98f:	vpminuw ymm2,ymm2,YMMWORD PTR [rdx+0x340]
  c2c998:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rdx+0x360]
  c2c9a1:	vpminuw ymm3,ymm3,YMMWORD PTR [rdx+0x380]
  c2c9aa:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x20]
  c2c9b0:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0x40]
  c2c9b6:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x60]
  c2c9bc:	vpaddusw ymm2,ymm2,ymm3
  c2c9c0:	vpminuw ymm3,ymm5,YMMWORD PTR [rdx+0x80]
  c2c9c9:	vpaddusw ymm3,ymm4,ymm3
  c2c9cd:	vmovdqu ymm4,YMMWORD PTR [rsp+0x1a0]
  c2c9d6:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp+0x1e0]
  c2c9df:	vmovdqu ymm5,YMMWORD PTR [rsp+0x140]
  c2c9e8:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x160]
  c2c9f1:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0xa0]
  c2c9fa:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0xc0]
  c2ca03:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0xe0]
  c2ca0c:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x100]
  c2ca15:	vpaddusw ymm4,ymm4,ymm5
  c2ca19:	vmovdqu ymm5,YMMWORD PTR [rsp+0xe0]
  c2ca22:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x100]
  c2ca2b:	vmovdqu ymm6,YMMWORD PTR [rsp+0xa0]
  c2ca34:	vpxor  ymm6,ymm6,YMMWORD PTR [rsp+0xc0]
  c2ca3d:	vmovdqa ymm7,YMMWORD PTR [rdx+0xaa0]
  c2ca45:	vpmaddwd ymm8,ymm7,YMMWORD PTR [rsp+0x120]
  c2ca4e:	vpmaxuw ymm3,ymm3,ymm9
  c2ca53:	vpmaxuw ymm4,ymm4,ymm9
  c2ca58:	vmovdqa ymm11,YMMWORD PTR [rdx+0x920]
  c2ca60:	vpunpckhwd ymm12,ymm3,ymm4
  c2ca64:	vpmaddwd ymm12,ymm12,ymm11
  c2ca69:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x120]
  c2ca72:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x140]
  c2ca7b:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rdx+0x160]
  c2ca84:	vpminuw ymm6,ymm6,YMMWORD PTR [rdx+0x180]
  c2ca8d:	vpaddd ymm8,ymm8,ymm12
  c2ca92:	vpaddusw ymm5,ymm5,ymm6
  c2ca96:	vpmaxuw ymm0,ymm0,ymm9
  c2ca9b:	vpmaxuw ymm2,ymm2,ymm9
  c2caa0:	vpmaxuw ymm5,ymm5,ymm9
  c2caa5:	vmovdqa ymm6,YMMWORD PTR [rdx+0x960]
  c2caad:	vmovdqu ymm15,YMMWORD PTR [rsp+0x320]
  c2cab6:	vpunpckhwd ymm12,ymm5,ymm15
  c2cabb:	vpmaddwd ymm12,ymm12,ymm6
  c2cabf:	vpaddd ymm8,ymm8,ymm12
  c2cac4:	vmovdqa ymm12,YMMWORD PTR [rdx+0xa00]
  c2cacc:	vpmaddwd ymm9,ymm12,YMMWORD PTR [rsp-0x80]
  c2cad2:	vpaddd ymm8,ymm8,ymm9
  c2cad7:	vmovdqa ymm9,YMMWORD PTR [rdx+0x9c0]
  c2cadf:	vpunpckhwd ymm13,ymm0,ymm2
  c2cae3:	vpmaddwd ymm13,ymm13,ymm9
  c2cae8:	vpaddd ymm8,ymm8,ymm13
  c2caed:	vmovdqa ymm13,YMMWORD PTR [rdx+0xa40]
  c2caf5:	vpmaddwd ymm14,ymm13,YMMWORD PTR [rsp+0x40]
  c2cafb:	vpaddd ymm8,ymm8,ymm14
  c2cb00:	vpmaddwd ymm7,ymm10,ymm7
  c2cb04:	vpunpcklwd ymm0,ymm0,ymm2
  c2cb08:	vpmaddwd ymm0,ymm9,ymm0
  c2cb0c:	vpunpcklwd ymm2,ymm3,ymm4
  c2cb10:	vpmaddwd ymm2,ymm11,ymm2
  c2cb14:	vpaddd ymm2,ymm7,ymm2
  c2cb18:	vpunpcklwd ymm3,ymm5,ymm15
  c2cb1d:	vpmaddwd ymm3,ymm3,ymm6
  c2cb21:	vpaddd ymm2,ymm2,ymm3
  c2cb25:	vpmaddwd ymm3,ymm12,YMMWORD PTR [rsp-0x60]
  c2cb2b:	vpaddd ymm2,ymm2,ymm3
  c2cb2f:	vpaddd ymm0,ymm2,ymm0
  c2cb33:	vpmaddwd ymm2,ymm13,YMMWORD PTR [rsp-0x40]
  c2cb39:	vpaddd ymm0,ymm0,ymm2
  c2cb3d:	vpbroadcastd ymm2,DWORD PTR [rdx+0xb04]
  c2cb46:	vpsubd ymm3,ymm2,ymm8
  c2cb4b:	vpsubd ymm0,ymm2,ymm0
  c2cb4f:	vpackssdw ymm0,ymm0,ymm3
  c2cb53:	mov    eax,DWORD PTR [rdx+0xd6c]
  c2cb59:	vmovd  xmm2,eax
  c2cb5d:	vpbroadcastw ymm2,xmm2
  c2cb62:	vpsignw ymm3,ymm2,ymm0
  c2cb67:	vpmulhrsw ymm3,ymm3,ymm0
  c2cb6c:	vpsignw ymm0,ymm3,ymm0
  c2cb71:	vpsignw ymm3,ymm2,ymm1
  c2cb76:	vpmulhrsw ymm3,ymm3,ymm1
  c2cb7b:	vpsignw ymm1,ymm3,ymm1
  c2cb80:	dec    eax
  c2cb82:	vmovdqu ymm3,YMMWORD PTR [rsp+0x20]
  c2cb88:	vpsignw ymm2,ymm2,ymm3
  c2cb8d:	vpmulhrsw ymm2,ymm2,ymm3
  c2cb92:	vpsignw ymm2,ymm2,ymm3
  c2cb97:	vmovd  xmm3,eax
  c2cb9b:	vpbroadcastw ymm3,xmm3
  c2cba0:	vpminsw ymm0,ymm0,ymm3
  c2cba4:	vpminsw ymm1,ymm1,ymm3
  c2cba8:	vpminsw ymm2,ymm2,ymm3
  c2cbac:	vpbroadcastw ymm3,WORD PTR [rdx+0xb12]
  c2cbb5:	vpmullw ymm0,ymm3,ymm0
  c2cbb9:	vpaddw ymm0,ymm0,ymm2
  c2cbbd:	vpbroadcastw ymm2,WORD PTR [rdx+0xb10]
  c2cbc6:	vpbroadcastw ymm3,WORD PTR [rdx+0xb14]
  c2cbcf:	vpmullw ymm1,ymm2,ymm1
  c2cbd3:	vpaddw ymm1,ymm1,ymm3
  c2cbd7:	vpaddw ymm0,ymm0,ymm1
  c2cbdb:	vmovdqu YMMWORD PTR [rdi],ymm0
  c2cbdf:	add    rsp,0x348
  c2cbe6:	vzeroupper
  c2cbe9:	ret
