
<WORKTREES>/splot-1934-gdf-leaf/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000c2cbf0 <_RNvNvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane23tiled_transposed_bottom22___fearless_simd_kernel>:
  c2cbf0:	sub    rsp,0x348
  c2cbf7:	vmovups YMMWORD PTR [rsp-0x40],ymm3
  c2cbfd:	vmovups YMMWORD PTR [rsp+0x20],ymm2
  c2cc03:	vmovdqu ymm2,YMMWORD PTR [rsi+0xfcc]
  c2cc0b:	vpaddw ymm9,ymm2,YMMWORD PTR [rip+0xffffffffff3ef7ad]        # 1c3c0 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xa0>
  c2cc13:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0xfc8]
  c2cc1b:	vmovdqa ymm7,ymm0
  c2cc1f:	vpsubw ymm5,ymm9,YMMWORD PTR [rsi+0xb4c]
  c2cc27:	vpxor  ymm6,ymm4,ymm5
  c2cc2b:	vpand  ymm6,ymm6,ymm0
  c2cc2f:	vpxor  ymm5,ymm5,ymm6
  c2cc33:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x2a0]
  c2cc3c:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x2c0]
  c2cc45:	vpaddw ymm10,ymm2,YMMWORD PTR [rip+0xffffffffff3efc13]        # 1c860 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0x540>
  c2cc4d:	vpsubw ymm11,ymm10,YMMWORD PTR [rsi+0xfd0]
  c2cc55:	vpsubw ymm2,ymm10,YMMWORD PTR [rsi+0x144c]
  c2cc5d:	vmovups YMMWORD PTR [rsp-0x80],ymm1
  c2cc63:	vpxor  ymm1,ymm11,ymm2
  c2cc67:	vpand  ymm1,ymm1,ymm0
  c2cc6b:	vpxor  ymm2,ymm2,ymm1
  c2cc6f:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x2e0]
  c2cc78:	vpminuw ymm2,ymm2,YMMWORD PTR [rdx+0x300]
  c2cc81:	vpaddusw ymm2,ymm5,ymm2
  c2cc85:	vpbroadcastw ymm3,WORD PTR [rip+0xffffffffff418ddc]        # 45a6a <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18fe>
  c2cc8e:	vpxor  ymm4,ymm4,ymm6
  c2cc92:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x820]
  c2cc9b:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0x840]
  c2cca4:	vpmaxuw ymm8,ymm2,ymm3
  c2cca9:	vpxor  ymm1,ymm11,ymm1
  c2ccad:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x860]
  c2ccb6:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x880]
  c2ccbf:	vpsubw ymm5,ymm9,YMMWORD PTR [rsi+0xfc6]
  c2ccc7:	vpaddusw ymm1,ymm4,ymm1
  c2cccb:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0x90c]
  c2ccd3:	vpxor  ymm6,ymm5,ymm4
  c2ccd7:	vpand  ymm6,ymm6,ymm0
  c2ccdb:	vpxor  ymm4,ymm4,ymm6
  c2ccdf:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x1a0]
  c2cce8:	vpminuw ymm11,ymm4,YMMWORD PTR [rdx+0x1c0]
  c2ccf1:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0xfd2]
  c2ccf9:	vpmaxuw ymm4,ymm1,ymm3
  c2ccfe:	vmovdqu YMMWORD PTR [rsp],ymm4
  c2cd03:	vpsubw ymm1,ymm10,YMMWORD PTR [rsi+0x168c]
  c2cd0b:	vpxor  ymm13,ymm12,ymm1
  c2cd0f:	vpand  ymm13,ymm13,ymm0
  c2cd13:	vpxor  ymm1,ymm13,ymm1
  c2cd17:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x1e0]
  c2cd20:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x200]
  c2cd29:	vpaddusw ymm1,ymm11,ymm1
  c2cd2d:	vpxor  ymm5,ymm5,ymm6
  c2cd31:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x7a0]
  c2cd3a:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x7c0]
  c2cd43:	vpmaxuw ymm2,ymm1,ymm3
  c2cd48:	vpxor  ymm1,ymm12,ymm13
  c2cd4d:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x7e0]
  c2cd56:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x800]
  c2cd5f:	vpsubw ymm6,ymm9,YMMWORD PTR [rsi+0xfca]
  c2cd67:	vpaddusw ymm1,ymm5,ymm1
  c2cd6b:	vpsubw ymm5,ymm9,YMMWORD PTR [rsi+0xd8c]
  c2cd73:	vpxor  ymm11,ymm6,ymm5
  c2cd77:	vpand  ymm11,ymm11,ymm0
  c2cd7b:	vpxor  ymm5,ymm11,ymm5
  c2cd7f:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x4a0]
  c2cd88:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x4c0]
  c2cd91:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0xfce]
  c2cd99:	vpmaxuw ymm0,ymm1,ymm3
  c2cd9e:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  c2cda4:	vpsubw ymm1,ymm10,YMMWORD PTR [rsi+0x120c]
  c2cdac:	vpxor  ymm13,ymm12,ymm1
  c2cdb0:	vpand  ymm13,ymm13,ymm7
  c2cdb4:	vpxor  ymm1,ymm13,ymm1
  c2cdb8:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x4e0]
  c2cdc1:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x500]
  c2cdca:	vmovdqa ymm15,YMMWORD PTR [rdx+0x9a0]
  c2cdd2:	vmovdqu YMMWORD PTR [rsp-0x20],ymm15
  c2cdd8:	vpunpckhwd ymm14,ymm2,ymm0
  c2cddc:	vmovdqu YMMWORD PTR [rsp+0x320],ymm2
  c2cde5:	vpmaddwd ymm14,ymm14,ymm15
  c2cdea:	vmovdqa ymm15,YMMWORD PTR [rdx+0xae0]
  c2cdf2:	vpunpckhwd ymm0,ymm8,ymm4
  c2cdf6:	vmovdqa ymm4,ymm8
  c2cdfa:	vpmaddwd ymm8,ymm15,ymm0
  c2cdfe:	vmovdqu YMMWORD PTR [rsp+0x120],ymm0
  c2ce07:	vpaddd ymm8,ymm8,ymm14
  c2ce0c:	vpaddusw ymm1,ymm5,ymm1
  c2ce10:	vpxor  ymm5,ymm11,ymm6
  c2ce14:	vpxor  ymm6,ymm12,ymm13
  c2ce19:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x8a0]
  c2ce22:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x8c0]
  c2ce2b:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rdx+0x8e0]
  c2ce34:	vpminuw ymm6,ymm6,YMMWORD PTR [rdx+0x900]
  c2ce3d:	vpaddusw ymm5,ymm5,ymm6
  c2ce41:	vpmaxuw ymm6,ymm1,ymm3
  c2ce46:	vpmaxuw ymm5,ymm5,ymm3
  c2ce4b:	vmovdqa ymm11,YMMWORD PTR [rdx+0xa80]
  c2ce53:	vpunpckhwd ymm1,ymm6,ymm5
  c2ce57:	vmovdqu YMMWORD PTR [rsp+0x40],ymm1
  c2ce5d:	vpmaddwd ymm1,ymm11,ymm1
  c2ce61:	vpaddd ymm1,ymm8,ymm1
  c2ce65:	vmovdqu ymm3,YMMWORD PTR [rsp-0x40]
  c2ce6b:	vpsubd ymm1,ymm3,ymm1
  c2ce6f:	vpunpcklwd ymm4,ymm4,YMMWORD PTR [rsp]
  c2ce74:	vmovdqu YMMWORD PTR [rsp],ymm4
  c2ce79:	vpunpcklwd ymm3,ymm2,YMMWORD PTR [rsp-0x60]
  c2ce7f:	vpmaddwd ymm3,ymm3,YMMWORD PTR [rsp-0x20]
  c2ce85:	vpmaddwd ymm2,ymm15,ymm4
  c2ce89:	vpaddd ymm2,ymm2,ymm3
  c2ce8d:	vpunpcklwd ymm3,ymm6,ymm5
  c2ce91:	vmovdqu YMMWORD PTR [rsp-0x40],ymm3
  c2ce97:	vpmaddwd ymm3,ymm11,ymm3
  c2ce9b:	vpaddd ymm2,ymm2,ymm3
  c2ce9f:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0xd90]
  c2cea7:	vpsubw ymm3,ymm9,YMMWORD PTR [rsi+0xd88]
  c2ceaf:	vpxor  ymm5,ymm4,ymm3
  c2ceb3:	vmovdqu ymm14,YMMWORD PTR [rsp-0x80]
  c2ceb9:	vpand  ymm5,ymm14,ymm5
  c2cebd:	vpxor  ymm3,ymm5,ymm3
  c2cec1:	vpxor  ymm5,ymm5,ymm4
  c2cec5:	vpsubw ymm4,ymm9,YMMWORD PTR [rsi+0xb4e]
  c2cecd:	vpsubw ymm6,ymm9,YMMWORD PTR [rsi+0xb4a]
  c2ced5:	vpxor  ymm8,ymm4,ymm6
  c2ced9:	vpand  ymm8,ymm14,ymm8
  c2cede:	vpxor  ymm6,ymm8,ymm6
  c2cee2:	vmovdqu YMMWORD PTR [rsp-0x20],ymm6
  c2cee8:	vpxor  ymm6,ymm3,ymm6
  c2ceec:	vpand  ymm6,ymm6,ymm7
  c2cef0:	vmovdqu YMMWORD PTR [rsp+0x300],ymm6
  c2cef9:	vpxor  ymm3,ymm6,ymm3
  c2cefd:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rdx+0x3a0]
  c2cf06:	vpminuw ymm3,ymm3,YMMWORD PTR [rdx+0x3c0]
  c2cf0f:	vpsubw ymm6,ymm10,YMMWORD PTR [rsi+0x1208]
  c2cf17:	vpxor  ymm15,ymm8,ymm4
  c2cf1b:	vmovdqu YMMWORD PTR [rsp+0x2a0],ymm15
  c2cf24:	vpsubw ymm4,ymm10,YMMWORD PTR [rsi+0x1210]
  c2cf2c:	vpxor  ymm8,ymm6,ymm4
  c2cf30:	vpand  ymm8,ymm14,ymm8
  c2cf35:	vpxor  ymm4,ymm8,ymm4
  c2cf39:	vpsubw ymm11,ymm10,YMMWORD PTR [rsi+0x144a]
  c2cf41:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0x144e]
  c2cf49:	vpxor  ymm13,ymm11,ymm12
  c2cf4e:	vpand  ymm13,ymm14,ymm13
  c2cf53:	vpxor  ymm12,ymm13,ymm12
  c2cf58:	vmovdqu YMMWORD PTR [rsp+0x2e0],ymm12
  c2cf61:	vpxor  ymm12,ymm12,ymm4
  c2cf65:	vpand  ymm12,ymm12,ymm7
  c2cf69:	vmovdqu YMMWORD PTR [rsp+0x2c0],ymm12
  c2cf72:	vpxor  ymm4,ymm12,ymm4
  c2cf76:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x3e0]
  c2cf7f:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0x400]
  c2cf88:	vpxor  ymm6,ymm8,ymm6
  c2cf8c:	vpxor  ymm8,ymm15,ymm5
  c2cf90:	vpand  ymm8,ymm8,ymm7
  c2cf94:	vmovdqu YMMWORD PTR [rsp+0x280],ymm8
  c2cf9d:	vpxor  ymm5,ymm8,ymm5
  c2cfa1:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x5a0]
  c2cfaa:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x5c0]
  c2cfb3:	vpxor  ymm8,ymm13,ymm11
  c2cfb8:	vmovdqu YMMWORD PTR [rsp+0x260],ymm8
  c2cfc1:	vpxor  ymm8,ymm8,ymm6
  c2cfc5:	vpand  ymm8,ymm8,ymm7
  c2cfc9:	vmovdqu YMMWORD PTR [rsp+0x240],ymm8
  c2cfd2:	vpxor  ymm6,ymm8,ymm6
  c2cfd6:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rdx+0x5e0]
  c2cfdf:	vpminuw ymm6,ymm6,YMMWORD PTR [rdx+0x600]
  c2cfe8:	vpsubw ymm8,ymm9,YMMWORD PTR [rsi+0xfc0]
  c2cff0:	vpsubw ymm12,ymm9,YMMWORD PTR [rsi+0x24c]
  c2cff8:	vmovdqu YMMWORD PTR [rsp+0x220],ymm12
  c2d001:	vmovdqu ymm11,YMMWORD PTR [rsp+0x20]
  c2d007:	vpsubd ymm2,ymm11,ymm2
  c2d00b:	vpxor  ymm11,ymm8,ymm12
  c2d010:	vpand  ymm11,ymm11,ymm7
  c2d014:	vmovdqu YMMWORD PTR [rsp+0x200],ymm11
  c2d01d:	vpxor  ymm8,ymm8,ymm11
  c2d022:	vpmaxuw ymm8,ymm8,YMMWORD PTR [rdx+0x620]
  c2d02b:	vpminuw ymm8,ymm8,YMMWORD PTR [rdx+0x640]
  c2d034:	vpsubw ymm11,ymm10,YMMWORD PTR [rsi+0xfd8]
  c2d03c:	vpsubw ymm12,ymm10,YMMWORD PTR [rsi+0x1d4c]
  c2d044:	vmovdqu YMMWORD PTR [rsp+0x1c0],ymm12
  c2d04d:	vpackssdw ymm1,ymm2,ymm1
  c2d051:	vmovdqu YMMWORD PTR [rsp+0x20],ymm1
  c2d057:	vpxor  ymm1,ymm11,ymm12
  c2d05c:	vpand  ymm1,ymm1,ymm7
  c2d060:	vmovdqu YMMWORD PTR [rsp+0x180],ymm1
  c2d069:	vpxor  ymm1,ymm11,ymm1
  c2d06d:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x660]
  c2d076:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x680]
  c2d07f:	vpsubw ymm2,ymm9,YMMWORD PTR [rsi+0xfc2]
  c2d087:	vpsubw ymm11,ymm9,YMMWORD PTR [rsi+0x48c]
  c2d08f:	vmovdqu YMMWORD PTR [rsp+0x1e0],ymm11
  c2d098:	vpaddusw ymm3,ymm3,ymm4
  c2d09c:	vmovdqu YMMWORD PTR [rsp+0x80],ymm3
  c2d0a5:	vpxor  ymm3,ymm11,ymm2
  c2d0a9:	vpand  ymm3,ymm3,ymm7
  c2d0ad:	vmovdqu YMMWORD PTR [rsp+0x1a0],ymm3
  c2d0b6:	vpxor  ymm2,ymm2,ymm3
  c2d0ba:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x6a0]
  c2d0c3:	vpminuw ymm2,ymm2,YMMWORD PTR [rdx+0x6c0]
  c2d0cc:	vpsubw ymm3,ymm10,YMMWORD PTR [rsi+0xfd6]
  c2d0d4:	vpsubw ymm4,ymm10,YMMWORD PTR [rsi+0x1b0c]
  c2d0dc:	vmovdqu YMMWORD PTR [rsp+0x160],ymm4
  c2d0e5:	vpaddusw ymm11,ymm5,ymm6
  c2d0e9:	vpxor  ymm4,ymm3,ymm4
  c2d0ed:	vpand  ymm4,ymm4,ymm7
  c2d0f1:	vmovdqu YMMWORD PTR [rsp+0x140],ymm4
  c2d0fa:	vpxor  ymm3,ymm3,ymm4
  c2d0fe:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rdx+0x6e0]
  c2d107:	vpminuw ymm3,ymm3,YMMWORD PTR [rdx+0x700]
  c2d110:	vpaddusw ymm1,ymm8,ymm1
  c2d114:	vpaddusw ymm2,ymm2,ymm3
  c2d118:	vpbroadcastw ymm12,WORD PTR [rip+0xffffffffff418949]        # 45a6a <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18fe>
  c2d121:	vpmaxuw ymm1,ymm1,ymm12
  c2d126:	vmovdqu YMMWORD PTR [rsp+0x60],ymm1
  c2d12c:	vpmaxuw ymm6,ymm2,ymm12
  c2d131:	vmovdqa ymm5,YMMWORD PTR [rdx+0x940]
  c2d139:	vpunpckhwd ymm1,ymm1,ymm6
  c2d13d:	vpsubw ymm2,ymm9,YMMWORD PTR [rsi+0xfc4]
  c2d145:	vpmaddwd ymm1,ymm1,ymm5
  c2d149:	vpsubw ymm3,ymm9,YMMWORD PTR [rsi+0x6cc]
  c2d151:	vmovdqu YMMWORD PTR [rsp+0x100],ymm3
  c2d15a:	vpxor  ymm3,ymm2,ymm3
  c2d15e:	vpand  ymm3,ymm3,ymm7
  c2d162:	vmovdqu YMMWORD PTR [rsp+0xe0],ymm3
  c2d16b:	vpxor  ymm2,ymm2,ymm3
  c2d16f:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x720]
  c2d178:	vmovdqa ymm4,YMMWORD PTR [rdx+0xac0]
  c2d180:	vpmaddwd ymm8,ymm0,ymm4
  c2d184:	vpsubw ymm14,ymm10,YMMWORD PTR [rsi+0xfd4]
  c2d18c:	vpaddd ymm8,ymm8,ymm1
  c2d190:	vpsubw ymm0,ymm10,YMMWORD PTR [rsi+0x18cc]
  c2d198:	vmovdqu YMMWORD PTR [rsp+0xc0],ymm0
  c2d1a1:	vpxor  ymm1,ymm14,ymm0
  c2d1a5:	vpand  ymm1,ymm1,ymm7
  c2d1a9:	vmovdqu YMMWORD PTR [rsp+0xa0],ymm1
  c2d1b2:	vpminuw ymm0,ymm2,YMMWORD PTR [rdx+0x740]
  c2d1bb:	vpxor  ymm1,ymm14,ymm1
  c2d1bf:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x760]
  c2d1c8:	vpminuw ymm1,ymm1,YMMWORD PTR [rdx+0x780]
  c2d1d1:	vpaddusw ymm0,ymm0,ymm1
  c2d1d5:	vpmaxuw ymm1,ymm0,ymm12
  c2d1da:	vmovdqa ymm3,YMMWORD PTR [rdx+0x980]
  c2d1e2:	vmovdqu ymm7,YMMWORD PTR [rsp-0x60]
  c2d1e8:	vpunpckhwd ymm2,ymm1,ymm7
  c2d1ec:	vpmaddwd ymm2,ymm2,ymm3
  c2d1f0:	vpaddd ymm2,ymm8,ymm2
  c2d1f4:	vpsubw ymm8,ymm9,YMMWORD PTR [rsi+0xd8e]
  c2d1fc:	vpsubw ymm9,ymm9,YMMWORD PTR [rsi+0xd8a]
  c2d204:	vpxor  ymm14,ymm8,ymm9
  c2d209:	vmovdqu ymm13,YMMWORD PTR [rsp-0x80]
  c2d20f:	vpand  ymm14,ymm14,ymm13
  c2d214:	vpsubw ymm0,ymm10,YMMWORD PTR [rsi+0x120a]
  c2d21c:	vpsubw ymm10,ymm10,YMMWORD PTR [rsi+0x120e]
  c2d224:	vpxor  ymm15,ymm10,ymm0
  c2d228:	vpand  ymm15,ymm15,ymm13
  c2d22d:	vpxor  ymm9,ymm9,ymm14
  c2d232:	vpxor  ymm8,ymm8,ymm14
  c2d237:	vpxor  ymm10,ymm10,ymm15
  c2d23c:	vpxor  ymm0,ymm15,ymm0
  c2d240:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rdx+0x420]
  c2d249:	vpminuw ymm9,ymm9,YMMWORD PTR [rdx+0x440]
  c2d252:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rdx+0x460]
  c2d25b:	vpminuw ymm10,ymm10,YMMWORD PTR [rdx+0x480]
  c2d264:	vpmaxuw ymm8,ymm8,YMMWORD PTR [rdx+0x520]
  c2d26d:	vpminuw ymm8,ymm8,YMMWORD PTR [rdx+0x540]
  c2d276:	vpmaxuw ymm0,ymm0,YMMWORD PTR [rdx+0x560]
  c2d27f:	vpaddusw ymm9,ymm9,ymm10
  c2d284:	vpminuw ymm0,ymm0,YMMWORD PTR [rdx+0x580]
  c2d28d:	vpaddusw ymm0,ymm8,ymm0
  c2d291:	vpmaxuw ymm8,ymm9,ymm12
  c2d296:	vpmaxuw ymm0,ymm0,ymm12
  c2d29b:	vmovdqa ymm14,YMMWORD PTR [rdx+0xa20]
  c2d2a3:	vpunpckhwd ymm9,ymm8,ymm0
  c2d2a7:	vmovdqu YMMWORD PTR [rsp-0x80],ymm9
  c2d2ad:	vpmaddwd ymm10,ymm9,ymm14
  c2d2b2:	vpaddd ymm2,ymm10,ymm2
  c2d2b6:	vpmaxuw ymm10,ymm12,YMMWORD PTR [rsp+0x80]
  c2d2c0:	vpmaxuw ymm11,ymm11,ymm12
  c2d2c5:	vmovdqa ymm9,ymm12
  c2d2ca:	vmovdqa ymm15,YMMWORD PTR [rdx+0x9e0]
  c2d2d2:	vpunpckhwd ymm13,ymm10,ymm11
  c2d2d7:	vpmaddwd ymm13,ymm13,ymm15
  c2d2dc:	vpaddd ymm2,ymm13,ymm2
  c2d2e0:	vmovdqa ymm13,YMMWORD PTR [rdx+0xa60]
  c2d2e8:	vpmaddwd ymm12,ymm13,YMMWORD PTR [rsp+0x40]
  c2d2ee:	vpaddd ymm2,ymm12,ymm2
  c2d2f2:	vpunpcklwd ymm10,ymm10,ymm11
  c2d2f7:	vpmaddwd ymm11,ymm10,ymm15
  c2d2fc:	vmovdqu ymm10,YMMWORD PTR [rsp+0x60]
  c2d302:	vpunpcklwd ymm6,ymm10,ymm6
  c2d306:	vpmaddwd ymm5,ymm6,ymm5
  c2d30a:	vmovdqu ymm10,YMMWORD PTR [rsp]
  c2d30f:	vpmaddwd ymm4,ymm10,ymm4
  c2d313:	vpaddd ymm4,ymm4,ymm5
  c2d317:	vpunpcklwd ymm1,ymm1,ymm7
  c2d31b:	vpmaddwd ymm1,ymm1,ymm3
  c2d31f:	vpaddd ymm1,ymm4,ymm1
  c2d323:	vpunpcklwd ymm0,ymm8,ymm0
  c2d327:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  c2d32d:	vpmaddwd ymm0,ymm14,ymm0
  c2d331:	vpaddd ymm0,ymm1,ymm0
  c2d335:	vpaddd ymm0,ymm11,ymm0
  c2d339:	vpmaddwd ymm1,ymm13,YMMWORD PTR [rsp-0x40]
  c2d33f:	vpaddd ymm0,ymm0,ymm1
  c2d343:	vpbroadcastd ymm1,DWORD PTR [rdx+0xb08]
  c2d34c:	vpsubd ymm2,ymm1,ymm2
  c2d350:	vpsubd ymm0,ymm1,ymm0
  c2d354:	vmovdqu ymm1,YMMWORD PTR [rsp+0x300]
  c2d35d:	vpxor  ymm1,ymm1,YMMWORD PTR [rsp-0x20]
  c2d363:	vmovdqu ymm3,YMMWORD PTR [rsp+0x2c0]
  c2d36c:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x2e0]
  c2d375:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rdx+0x220]
  c2d37e:	vpminuw ymm4,ymm1,YMMWORD PTR [rdx+0x240]
  c2d387:	vpmaxuw ymm1,ymm3,YMMWORD PTR [rdx+0x260]
  c2d390:	vpminuw ymm3,ymm1,YMMWORD PTR [rdx+0x280]
  c2d399:	vpackssdw ymm1,ymm0,ymm2
  c2d39d:	vpaddusw ymm0,ymm4,ymm3
  c2d3a1:	vmovdqu ymm2,YMMWORD PTR [rsp+0x280]
  c2d3aa:	vpxor  ymm2,ymm2,YMMWORD PTR [rsp+0x2a0]
  c2d3b3:	vmovdqu ymm3,YMMWORD PTR [rsp+0x240]
  c2d3bc:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x260]
  c2d3c5:	vmovdqu ymm4,YMMWORD PTR [rsp+0x200]
  c2d3ce:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp+0x220]
  c2d3d7:	vmovdqu ymm5,YMMWORD PTR [rsp+0x180]
  c2d3e0:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x1c0]
  c2d3e9:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rdx+0x320]
  c2d3f2:	vpminuw ymm2,ymm2,YMMWORD PTR [rdx+0x340]
  c2d3fb:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rdx+0x360]
  c2d404:	vpminuw ymm3,ymm3,YMMWORD PTR [rdx+0x380]
  c2d40d:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0x20]
  c2d413:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0x40]
  c2d419:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x60]
  c2d41f:	vpaddusw ymm2,ymm2,ymm3
  c2d423:	vpminuw ymm3,ymm5,YMMWORD PTR [rdx+0x80]
  c2d42c:	vpaddusw ymm3,ymm4,ymm3
  c2d430:	vmovdqu ymm4,YMMWORD PTR [rsp+0x1a0]
  c2d439:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp+0x1e0]
  c2d442:	vmovdqu ymm5,YMMWORD PTR [rsp+0x140]
  c2d44b:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x160]
  c2d454:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rdx+0xa0]
  c2d45d:	vpminuw ymm4,ymm4,YMMWORD PTR [rdx+0xc0]
  c2d466:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0xe0]
  c2d46f:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x100]
  c2d478:	vpaddusw ymm4,ymm4,ymm5
  c2d47c:	vmovdqu ymm5,YMMWORD PTR [rsp+0xe0]
  c2d485:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x100]
  c2d48e:	vmovdqu ymm6,YMMWORD PTR [rsp+0xa0]
  c2d497:	vpxor  ymm6,ymm6,YMMWORD PTR [rsp+0xc0]
  c2d4a0:	vmovdqa ymm7,YMMWORD PTR [rdx+0xaa0]
  c2d4a8:	vpmaddwd ymm8,ymm7,YMMWORD PTR [rsp+0x120]
  c2d4b1:	vpmaxuw ymm3,ymm3,ymm9
  c2d4b6:	vpmaxuw ymm4,ymm4,ymm9
  c2d4bb:	vmovdqa ymm11,YMMWORD PTR [rdx+0x920]
  c2d4c3:	vpunpckhwd ymm12,ymm3,ymm4
  c2d4c7:	vpmaddwd ymm12,ymm12,ymm11
  c2d4cc:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rdx+0x120]
  c2d4d5:	vpminuw ymm5,ymm5,YMMWORD PTR [rdx+0x140]
  c2d4de:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rdx+0x160]
  c2d4e7:	vpminuw ymm6,ymm6,YMMWORD PTR [rdx+0x180]
  c2d4f0:	vpaddd ymm8,ymm8,ymm12
  c2d4f5:	vpaddusw ymm5,ymm5,ymm6
  c2d4f9:	vpmaxuw ymm0,ymm0,ymm9
  c2d4fe:	vpmaxuw ymm2,ymm2,ymm9
  c2d503:	vpmaxuw ymm5,ymm5,ymm9
  c2d508:	vmovdqa ymm6,YMMWORD PTR [rdx+0x960]
  c2d510:	vmovdqu ymm15,YMMWORD PTR [rsp+0x320]
  c2d519:	vpunpckhwd ymm12,ymm5,ymm15
  c2d51e:	vpmaddwd ymm12,ymm12,ymm6
  c2d522:	vpaddd ymm8,ymm8,ymm12
  c2d527:	vmovdqa ymm12,YMMWORD PTR [rdx+0xa00]
  c2d52f:	vpmaddwd ymm9,ymm12,YMMWORD PTR [rsp-0x80]
  c2d535:	vpaddd ymm8,ymm8,ymm9
  c2d53a:	vmovdqa ymm9,YMMWORD PTR [rdx+0x9c0]
  c2d542:	vpunpckhwd ymm13,ymm0,ymm2
  c2d546:	vpmaddwd ymm13,ymm13,ymm9
  c2d54b:	vpaddd ymm8,ymm8,ymm13
  c2d550:	vmovdqa ymm13,YMMWORD PTR [rdx+0xa40]
  c2d558:	vpmaddwd ymm14,ymm13,YMMWORD PTR [rsp+0x40]
  c2d55e:	vpaddd ymm8,ymm8,ymm14
  c2d563:	vpmaddwd ymm7,ymm10,ymm7
  c2d567:	vpunpcklwd ymm0,ymm0,ymm2
  c2d56b:	vpmaddwd ymm0,ymm9,ymm0
  c2d56f:	vpunpcklwd ymm2,ymm3,ymm4
  c2d573:	vpmaddwd ymm2,ymm11,ymm2
  c2d577:	vpaddd ymm2,ymm7,ymm2
  c2d57b:	vpunpcklwd ymm3,ymm5,ymm15
  c2d580:	vpmaddwd ymm3,ymm3,ymm6
  c2d584:	vpaddd ymm2,ymm2,ymm3
  c2d588:	vpmaddwd ymm3,ymm12,YMMWORD PTR [rsp-0x60]
  c2d58e:	vpaddd ymm2,ymm2,ymm3
  c2d592:	vpaddd ymm0,ymm2,ymm0
  c2d596:	vpmaddwd ymm2,ymm13,YMMWORD PTR [rsp-0x40]
  c2d59c:	vpaddd ymm0,ymm0,ymm2
  c2d5a0:	vpbroadcastd ymm2,DWORD PTR [rdx+0xb04]
  c2d5a9:	vpsubd ymm3,ymm2,ymm8
  c2d5ae:	vpsubd ymm0,ymm2,ymm0
  c2d5b2:	vpackssdw ymm0,ymm0,ymm3
  c2d5b6:	mov    eax,DWORD PTR [rdx+0xd6c]
  c2d5bc:	vmovd  xmm2,eax
  c2d5c0:	vpbroadcastw ymm2,xmm2
  c2d5c5:	vpsignw ymm3,ymm2,ymm0
  c2d5ca:	vpmulhrsw ymm3,ymm3,ymm0
  c2d5cf:	vpsignw ymm0,ymm3,ymm0
  c2d5d4:	vpsignw ymm3,ymm2,ymm1
  c2d5d9:	vpmulhrsw ymm3,ymm3,ymm1
  c2d5de:	vpsignw ymm1,ymm3,ymm1
  c2d5e3:	dec    eax
  c2d5e5:	vmovdqu ymm3,YMMWORD PTR [rsp+0x20]
  c2d5eb:	vpsignw ymm2,ymm2,ymm3
  c2d5f0:	vpmulhrsw ymm2,ymm2,ymm3
  c2d5f5:	vpsignw ymm2,ymm2,ymm3
  c2d5fa:	vmovd  xmm3,eax
  c2d5fe:	vpbroadcastw ymm3,xmm3
  c2d603:	vpminsw ymm0,ymm0,ymm3
  c2d607:	vpminsw ymm1,ymm1,ymm3
  c2d60b:	vpminsw ymm2,ymm2,ymm3
  c2d60f:	vpbroadcastw ymm3,WORD PTR [rdx+0xb12]
  c2d618:	vpmullw ymm0,ymm3,ymm0
  c2d61c:	vpaddw ymm0,ymm0,ymm2
  c2d620:	vpbroadcastw ymm2,WORD PTR [rdx+0xb10]
  c2d629:	vpbroadcastw ymm3,WORD PTR [rdx+0xb14]
  c2d632:	vpmullw ymm1,ymm2,ymm1
  c2d636:	vpaddw ymm1,ymm1,ymm3
  c2d63a:	vpaddw ymm0,ymm0,ymm1
  c2d63e:	vmovdqu YMMWORD PTR [rdi],ymm0
  c2d642:	add    rsp,0x348
  c2d649:	vzeroupper
  c2d64c:	ret
