
<WORKTREES>/splot-1934-tip-overlap/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000946f80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtCsdbBTXDzdjsm_12splot_decode7filters3gdf4simd6inlane9row_indexNtB1Z_11TiledWindowKj1_Kb0_Kb1_E0Atj10_EB25_>:
  946f80:	sub    rsp,0x328
  946f87:	mov    rax,QWORD PTR [rsi+0x8]
  946f8b:	mov    rdx,QWORD PTR [rsi+0x10]
  946f8f:	mov    rcx,QWORD PTR [rax]
  946f92:	vmovdqu ymm0,YMMWORD PTR [rcx+0xfcc]
  946f9a:	vmovdqa ymm6,YMMWORD PTR [rdx]
  946f9e:	vpaddw ymm7,ymm0,YMMWORD PTR [rip+0xffffffffff6d541a]        # 1c3c0 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xa0>
  946fa6:	vpsubw ymm1,ymm7,YMMWORD PTR [rcx+0xfc8]
  946fae:	vpsubw ymm2,ymm7,YMMWORD PTR [rcx+0xb4c]
  946fb6:	mov    rax,QWORD PTR [rsi+0x18]
  946fba:	vpxor  ymm3,ymm1,ymm2
  946fbe:	vpand  ymm3,ymm3,ymm6
  946fc2:	vpxor  ymm2,ymm2,ymm3
  946fc6:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x2a0]
  946fcf:	vpminuw ymm2,ymm2,YMMWORD PTR [rax+0x2c0]
  946fd8:	vpaddw ymm8,ymm0,YMMWORD PTR [rip+0xffffffffff6d5880]        # 1c860 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0x540>
  946fe0:	vpsubw ymm4,ymm8,YMMWORD PTR [rcx+0xfd0]
  946fe8:	vmovdqa ymm14,YMMWORD PTR [rax+0x9a0]
  946ff0:	vmovdqu YMMWORD PTR [rsp-0x80],ymm14
  946ff6:	vpsubw ymm5,ymm8,YMMWORD PTR [rcx+0x144c]
  946ffe:	vpxor  ymm9,ymm4,ymm5
  947002:	vpand  ymm9,ymm9,ymm6
  947006:	vpxor  ymm5,ymm9,ymm5
  94700a:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x2e0]
  947013:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x300]
  94701c:	vpaddusw ymm2,ymm2,ymm5
  947020:	vpxor  ymm1,ymm1,ymm3
  947024:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x820]
  94702d:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x840]
  947036:	vpbroadcastw ymm0,WORD PTR [rip+0xffffffffff6fe9df]        # 45a1e <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18b2>
  94703f:	vpxor  ymm3,ymm9,ymm4
  947043:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x860]
  94704c:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x880]
  947055:	vpsubw ymm5,ymm7,YMMWORD PTR [rcx+0xfc6]
  94705d:	vpmaxuw ymm2,ymm2,ymm0
  947062:	vpsubw ymm4,ymm7,YMMWORD PTR [rcx+0x90c]
  94706a:	vpxor  ymm9,ymm5,ymm4
  94706e:	vpand  ymm9,ymm9,ymm6
  947072:	vpxor  ymm4,ymm9,ymm4
  947076:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x1a0]
  94707f:	vpminuw ymm10,ymm4,YMMWORD PTR [rax+0x1c0]
  947088:	vpsubw ymm12,ymm8,YMMWORD PTR [rcx+0xfd2]
  947090:	vpaddusw ymm1,ymm1,ymm3
  947094:	vpsubw ymm3,ymm8,YMMWORD PTR [rcx+0x168c]
  94709c:	vpxor  ymm4,ymm12,ymm3
  9470a0:	vpand  ymm13,ymm4,ymm6
  9470a4:	vpxor  ymm3,ymm13,ymm3
  9470a8:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x1e0]
  9470b1:	vpmaxuw ymm4,ymm1,ymm0
  9470b6:	vpminuw ymm1,ymm3,YMMWORD PTR [rax+0x200]
  9470bf:	vpxor  ymm3,ymm9,ymm5
  9470c3:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x7a0]
  9470cc:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x7c0]
  9470d5:	vpaddusw ymm1,ymm10,ymm1
  9470d9:	vpxor  ymm5,ymm12,ymm13
  9470de:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x7e0]
  9470e7:	vpmaxuw ymm11,ymm1,ymm0
  9470ec:	vpminuw ymm1,ymm5,YMMWORD PTR [rax+0x800]
  9470f5:	vpaddusw ymm1,ymm3,ymm1
  9470f9:	vpsubw ymm3,ymm7,YMMWORD PTR [rcx+0xfca]
  947101:	vpsubw ymm5,ymm7,YMMWORD PTR [rcx+0xd8c]
  947109:	vpmaxuw ymm0,ymm1,ymm0
  94710e:	vmovdqu YMMWORD PTR [rsp-0x20],ymm0
  947114:	vpxor  ymm1,ymm3,ymm5
  947118:	vpand  ymm1,ymm1,ymm6
  94711c:	vpxor  ymm5,ymm5,ymm1
  947120:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x4a0]
  947129:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x4c0]
  947132:	vpsubw ymm9,ymm8,YMMWORD PTR [rcx+0xfce]
  94713a:	vpsubw ymm10,ymm8,YMMWORD PTR [rcx+0x120c]
  947142:	vpunpckhwd ymm12,ymm11,ymm0
  947146:	vmovdqu YMMWORD PTR [rsp+0x300],ymm11
  94714f:	vpxor  ymm13,ymm9,ymm10
  947154:	vpand  ymm13,ymm13,ymm6
  947158:	vpxor  ymm10,ymm10,ymm13
  94715d:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rax+0x4e0]
  947166:	vpminuw ymm10,ymm10,YMMWORD PTR [rax+0x500]
  94716f:	vpmaddwd ymm12,ymm12,ymm14
  947174:	vmovdqa ymm14,YMMWORD PTR [rax+0xae0]
  94717c:	vpunpckhwd ymm0,ymm2,ymm4
  947180:	vmovdqu YMMWORD PTR [rsp],ymm0
  947185:	vpmaddwd ymm15,ymm14,ymm0
  947189:	vpaddd ymm12,ymm15,ymm12
  94718e:	vpaddusw ymm5,ymm10,ymm5
  947192:	vpxor  ymm1,ymm3,ymm1
  947196:	vpxor  ymm9,ymm9,ymm13
  94719b:	vmovdqa ymm3,YMMWORD PTR [rax+0xa80]
  9471a3:	vpbroadcastw ymm0,WORD PTR [rip+0xffffffffff6fe872]        # 45a1e <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18b2>
  9471ac:	vpmaxuw ymm5,ymm5,ymm0
  9471b1:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x8a0]
  9471ba:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x8c0]
  9471c3:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rax+0x8e0]
  9471cc:	vpminuw ymm9,ymm9,YMMWORD PTR [rax+0x900]
  9471d5:	vpaddusw ymm1,ymm9,ymm1
  9471d9:	vpmaxuw ymm9,ymm1,ymm0
  9471de:	vpunpckhwd ymm1,ymm5,ymm9
  9471e3:	vmovdqu YMMWORD PTR [rsp+0x40],ymm1
  9471e9:	vpmaddwd ymm1,ymm1,ymm3
  9471ed:	vpaddd ymm1,ymm12,ymm1
  9471f1:	mov    rsi,QWORD PTR [rsi+0x20]
  9471f5:	vmovdqa ymm10,YMMWORD PTR [rsi+0x20]
  9471fa:	vpsubd ymm0,ymm10,ymm1
  9471fe:	vmovdqu YMMWORD PTR [rsp-0x40],ymm0
  947204:	vpunpcklwd ymm2,ymm2,ymm4
  947208:	vmovdqu YMMWORD PTR [rsp+0x20],ymm2
  94720e:	vpmaddwd ymm2,ymm14,ymm2
  947212:	vmovdqu ymm15,YMMWORD PTR [rsp-0x20]
  947218:	vpunpcklwd ymm4,ymm11,ymm15
  94721d:	vpmaddwd ymm0,ymm4,YMMWORD PTR [rsp-0x80]
  947223:	vpaddd ymm0,ymm2,ymm0
  947227:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  94722d:	vpunpcklwd ymm2,ymm5,ymm9
  947232:	vmovdqu YMMWORD PTR [rsp-0x80],ymm2
  947238:	vpsubw ymm5,ymm7,YMMWORD PTR [rcx+0xd90]
  947240:	vpsubw ymm4,ymm7,YMMWORD PTR [rcx+0xd88]
  947248:	vmovdqa ymm11,YMMWORD PTR [rdx+0x20]
  94724d:	vpxor  ymm9,ymm5,ymm4
  947251:	vpand  ymm9,ymm11,ymm9
  947256:	vpxor  ymm4,ymm9,ymm4
  94725a:	vpsubw ymm10,ymm7,YMMWORD PTR [rcx+0xb4e]
  947262:	vpsubw ymm12,ymm7,YMMWORD PTR [rcx+0xb4a]
  94726a:	vpxor  ymm9,ymm9,ymm5
  94726e:	vpxor  ymm5,ymm10,ymm12
  947273:	vpand  ymm5,ymm11,ymm5
  947277:	vpxor  ymm14,ymm12,ymm5
  94727b:	vmovdqu YMMWORD PTR [rsp+0x2e0],ymm14
  947284:	vpsubw ymm12,ymm8,YMMWORD PTR [rcx+0x1208]
  94728c:	vpsubw ymm13,ymm8,YMMWORD PTR [rcx+0x1210]
  947294:	vpxor  ymm1,ymm10,ymm5
  947298:	vmovdqu YMMWORD PTR [rsp+0x2a0],ymm1
  9472a1:	vpxor  ymm5,ymm12,ymm13
  9472a6:	vpand  ymm5,ymm11,ymm5
  9472aa:	vpxor  ymm10,ymm13,ymm5
  9472ae:	vpxor  ymm12,ymm12,ymm5
  9472b2:	vpxor  ymm5,ymm14,ymm4
  9472b6:	vpand  ymm5,ymm5,ymm6
  9472ba:	vmovdqu YMMWORD PTR [rsp+0x2c0],ymm5
  9472c3:	vpxor  ymm4,ymm5,ymm4
  9472c7:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x3a0]
  9472d0:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0x3c0]
  9472d9:	vpsubw ymm5,ymm8,YMMWORD PTR [rcx+0x144a]
  9472e1:	vpsubw ymm13,ymm8,YMMWORD PTR [rcx+0x144e]
  9472e9:	vpxor  ymm14,ymm13,ymm5
  9472ed:	vpand  ymm14,ymm11,ymm14
  9472f2:	vpxor  ymm0,ymm14,ymm13
  9472f7:	vmovdqu YMMWORD PTR [rsp+0x280],ymm0
  947300:	vpxor  ymm13,ymm10,ymm0
  947304:	vpand  ymm0,ymm13,ymm6
  947308:	vmovdqu YMMWORD PTR [rsp+0x220],ymm0
  947311:	vpxor  ymm10,ymm10,ymm0
  947315:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rax+0x3e0]
  94731e:	vpxor  ymm13,ymm14,ymm5
  947322:	vmovdqu YMMWORD PTR [rsp+0x240],ymm13
  94732b:	vpminuw ymm5,ymm10,YMMWORD PTR [rax+0x400]
  947334:	vpxor  ymm10,ymm9,ymm1
  947338:	vpand  ymm0,ymm10,ymm6
  94733c:	vmovdqu YMMWORD PTR [rsp+0x260],ymm0
  947345:	vpxor  ymm9,ymm9,ymm0
  947349:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rax+0x5a0]
  947352:	vpmaddwd ymm10,ymm2,ymm3
  947356:	vpminuw ymm3,ymm9,YMMWORD PTR [rax+0x5c0]
  94735f:	vpxor  ymm9,ymm12,ymm13
  947364:	vpand  ymm0,ymm9,ymm6
  947368:	vmovdqu YMMWORD PTR [rsp+0x200],ymm0
  947371:	vpxor  ymm9,ymm12,ymm0
  947375:	vpmaxuw ymm9,ymm9,YMMWORD PTR [rax+0x5e0]
  94737e:	vpaddd ymm10,ymm10,YMMWORD PTR [rsp-0x60]
  947384:	vpminuw ymm2,ymm9,YMMWORD PTR [rax+0x600]
  94738d:	vmovdqa ymm9,YMMWORD PTR [rsi]
  947391:	vpsubw ymm12,ymm7,YMMWORD PTR [rcx+0xfc0]
  947399:	vpsubw ymm0,ymm7,YMMWORD PTR [rcx+0x24c]
  9473a1:	vmovdqu YMMWORD PTR [rsp-0x60],ymm0
  9473a7:	vpsubd ymm9,ymm9,ymm10
  9473ac:	vpxor  ymm10,ymm12,ymm0
  9473b0:	vpand  ymm0,ymm10,ymm6
  9473b4:	vmovdqu YMMWORD PTR [rsp+0x1e0],ymm0
  9473bd:	vpxor  ymm10,ymm12,ymm0
  9473c1:	vpmaxuw ymm10,ymm10,YMMWORD PTR [rax+0x620]
  9473ca:	vpminuw ymm10,ymm10,YMMWORD PTR [rax+0x640]
  9473d3:	vpsubw ymm12,ymm8,YMMWORD PTR [rcx+0xfd8]
  9473db:	vpsubw ymm1,ymm8,YMMWORD PTR [rcx+0x1d4c]
  9473e3:	vmovdqu YMMWORD PTR [rsp+0x1a0],ymm1
  9473ec:	vpackssdw ymm0,ymm9,YMMWORD PTR [rsp-0x40]
  9473f2:	vmovdqu YMMWORD PTR [rsp-0x40],ymm0
  9473f8:	vpxor  ymm1,ymm12,ymm1
  9473fc:	vpand  ymm0,ymm1,ymm6
  947400:	vmovdqu YMMWORD PTR [rsp+0x160],ymm0
  947409:	vpxor  ymm1,ymm12,ymm0
  94740d:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x660]
  947416:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x680]
  94741f:	vpsubw ymm9,ymm7,YMMWORD PTR [rcx+0xfc2]
  947427:	vpsubw ymm0,ymm7,YMMWORD PTR [rcx+0x48c]
  94742f:	vmovdqu YMMWORD PTR [rsp+0x1c0],ymm0
  947438:	vpaddusw ymm4,ymm4,ymm5
  94743c:	vmovdqu YMMWORD PTR [rsp+0x60],ymm4
  947442:	vpxor  ymm4,ymm9,ymm0
  947446:	vpand  ymm0,ymm4,ymm6
  94744a:	vmovdqu YMMWORD PTR [rsp+0x180],ymm0
  947453:	vpxor  ymm4,ymm9,ymm0
  947457:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x6a0]
  947460:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0x6c0]
  947469:	vpsubw ymm5,ymm8,YMMWORD PTR [rcx+0xfd6]
  947471:	vpsubw ymm0,ymm8,YMMWORD PTR [rcx+0x1b0c]
  947479:	vmovdqu YMMWORD PTR [rsp+0x140],ymm0
  947482:	vpaddusw ymm13,ymm3,ymm2
  947486:	vpxor  ymm2,ymm5,ymm0
  94748a:	vpand  ymm0,ymm2,ymm6
  94748e:	vmovdqu YMMWORD PTR [rsp+0x120],ymm0
  947497:	vpxor  ymm2,ymm5,ymm0
  94749b:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x6e0]
  9474a4:	vpminuw ymm2,ymm2,YMMWORD PTR [rax+0x700]
  9474ad:	vpaddusw ymm1,ymm10,ymm1
  9474b1:	vpaddusw ymm2,ymm4,ymm2
  9474b5:	vpbroadcastw ymm14,WORD PTR [rip+0xffffffffff6fe560]        # 45a1e <anon.cc12a96aad8e8161c70cdf7b3ff46615.1581.llvm.11881531444527471705+0x18b2>
  9474be:	vpmaxuw ymm12,ymm1,ymm14
  9474c3:	vpmaxuw ymm9,ymm2,ymm14
  9474c8:	vmovdqa ymm10,YMMWORD PTR [rax+0x940]
  9474d0:	vpunpckhwd ymm1,ymm12,ymm9
  9474d5:	vpsubw ymm2,ymm7,YMMWORD PTR [rcx+0xfc4]
  9474dd:	vpmaddwd ymm1,ymm10,ymm1
  9474e1:	vpsubw ymm0,ymm7,YMMWORD PTR [rcx+0x6cc]
  9474e9:	vmovdqu YMMWORD PTR [rsp+0x100],ymm0
  9474f2:	vpxor  ymm3,ymm2,ymm0
  9474f6:	vpand  ymm0,ymm3,ymm6
  9474fa:	vmovdqu YMMWORD PTR [rsp+0xe0],ymm0
  947503:	vpxor  ymm2,ymm2,ymm0
  947507:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x720]
  947510:	vmovdqa ymm5,YMMWORD PTR [rax+0xac0]
  947518:	vpmaddwd ymm3,ymm5,YMMWORD PTR [rsp]
  94751d:	vpsubw ymm0,ymm8,YMMWORD PTR [rcx+0xfd4]
  947525:	vpaddd ymm3,ymm3,ymm1
  947529:	vpsubw ymm1,ymm8,YMMWORD PTR [rcx+0x18cc]
  947531:	vmovdqu YMMWORD PTR [rsp+0xc0],ymm1
  94753a:	vpxor  ymm1,ymm0,ymm1
  94753e:	vpand  ymm4,ymm1,ymm6
  947542:	vmovdqu YMMWORD PTR [rsp+0xa0],ymm4
  94754b:	vpminuw ymm1,ymm2,YMMWORD PTR [rax+0x740]
  947554:	vpxor  ymm0,ymm0,ymm4
  947558:	vpmaxuw ymm0,ymm0,YMMWORD PTR [rax+0x760]
  947561:	vpminuw ymm0,ymm0,YMMWORD PTR [rax+0x780]
  94756a:	vpaddusw ymm0,ymm1,ymm0
  94756e:	vpmaxuw ymm2,ymm0,ymm14
  947573:	vmovdqa ymm6,ymm14
  947577:	vmovdqa ymm4,YMMWORD PTR [rax+0x980]
  94757f:	vpunpckhwd ymm0,ymm2,ymm15
  947584:	vpmaddwd ymm0,ymm0,ymm4
  947588:	vpaddd ymm3,ymm3,ymm0
  94758c:	vpsubw ymm1,ymm7,YMMWORD PTR [rcx+0xd8e]
  947594:	vpsubw ymm7,ymm7,YMMWORD PTR [rcx+0xd8a]
  94759c:	vpxor  ymm14,ymm1,ymm7
  9475a0:	vpand  ymm14,ymm14,ymm11
  9475a5:	vpsubw ymm0,ymm8,YMMWORD PTR [rcx+0x120a]
  9475ad:	vpsubw ymm8,ymm8,YMMWORD PTR [rcx+0x120e]
  9475b5:	vpxor  ymm15,ymm8,ymm0
  9475b9:	vpand  ymm11,ymm15,ymm11
  9475be:	vpxor  ymm7,ymm14,ymm7
  9475c2:	vpxor  ymm1,ymm14,ymm1
  9475c6:	vpxor  ymm8,ymm8,ymm11
  9475cb:	vpxor  ymm0,ymm11,ymm0
  9475cf:	vpmaxuw ymm7,ymm7,YMMWORD PTR [rax+0x420]
  9475d8:	vpminuw ymm7,ymm7,YMMWORD PTR [rax+0x440]
  9475e1:	vpmaxuw ymm8,ymm8,YMMWORD PTR [rax+0x460]
  9475ea:	vpminuw ymm8,ymm8,YMMWORD PTR [rax+0x480]
  9475f3:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x520]
  9475fc:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x540]
  947605:	vpmaxuw ymm0,ymm0,YMMWORD PTR [rax+0x560]
  94760e:	vpaddusw ymm7,ymm8,ymm7
  947612:	vpminuw ymm0,ymm0,YMMWORD PTR [rax+0x580]
  94761b:	vpaddusw ymm0,ymm1,ymm0
  94761f:	vpmaxuw ymm1,ymm7,ymm6
  947624:	vpmaxuw ymm0,ymm0,ymm6
  947629:	vmovdqa ymm11,YMMWORD PTR [rax+0xa20]
  947631:	vpunpckhwd ymm7,ymm1,ymm0
  947635:	vmovdqu YMMWORD PTR [rsp+0x80],ymm7
  94763e:	vpmaddwd ymm8,ymm11,ymm7
  947642:	vpaddd ymm3,ymm8,ymm3
  947646:	vpmaxuw ymm8,ymm6,YMMWORD PTR [rsp+0x60]
  94764d:	vpmaxuw ymm13,ymm13,ymm6
  947652:	vmovdqa ymm7,ymm6
  947656:	vmovdqa ymm14,YMMWORD PTR [rax+0x9e0]
  94765e:	vpunpckhwd ymm15,ymm8,ymm13
  947663:	vpmaddwd ymm15,ymm15,ymm14
  947668:	vpaddd ymm3,ymm15,ymm3
  94766c:	vmovdqa ymm15,YMMWORD PTR [rax+0xa60]
  947674:	vpmaddwd ymm6,ymm15,YMMWORD PTR [rsp+0x40]
  94767a:	vpaddd ymm3,ymm3,ymm6
  94767e:	vpunpcklwd ymm6,ymm8,ymm13
  947683:	vpmaddwd ymm6,ymm14,ymm6
  947687:	vpunpcklwd ymm8,ymm12,ymm9
  94768c:	vpmaddwd ymm8,ymm8,ymm10
  947691:	vpmaddwd ymm5,ymm5,YMMWORD PTR [rsp+0x20]
  947697:	vpaddd ymm5,ymm8,ymm5
  94769b:	vpunpcklwd ymm2,ymm2,YMMWORD PTR [rsp-0x20]
  9476a1:	vpmaddwd ymm2,ymm2,ymm4
  9476a5:	vpaddd ymm2,ymm5,ymm2
  9476a9:	vpunpcklwd ymm8,ymm1,ymm0
  9476ad:	vpmaddwd ymm0,ymm8,ymm11
  9476b2:	vpaddd ymm0,ymm2,ymm0
  9476b6:	vpaddd ymm0,ymm0,ymm6
  9476ba:	vpmaddwd ymm1,ymm15,YMMWORD PTR [rsp-0x80]
  9476c0:	vpaddd ymm0,ymm0,ymm1
  9476c4:	vpbroadcastd ymm1,DWORD PTR [rax+0xb08]
  9476cd:	vpsubd ymm2,ymm1,ymm3
  9476d1:	vpsubd ymm0,ymm1,ymm0
  9476d5:	vmovdqu ymm1,YMMWORD PTR [rsp+0x2c0]
  9476de:	vpxor  ymm1,ymm1,YMMWORD PTR [rsp+0x2e0]
  9476e7:	vmovdqu ymm3,YMMWORD PTR [rsp+0x220]
  9476f0:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x280]
  9476f9:	vpmaxuw ymm1,ymm1,YMMWORD PTR [rax+0x220]
  947702:	vpminuw ymm1,ymm1,YMMWORD PTR [rax+0x240]
  94770b:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x260]
  947714:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x280]
  94771d:	vpackssdw ymm0,ymm0,ymm2
  947721:	vpaddusw ymm1,ymm1,ymm3
  947725:	vmovdqu ymm2,YMMWORD PTR [rsp+0x260]
  94772e:	vpxor  ymm2,ymm2,YMMWORD PTR [rsp+0x2a0]
  947737:	vmovdqu ymm3,YMMWORD PTR [rsp+0x200]
  947740:	vpxor  ymm3,ymm3,YMMWORD PTR [rsp+0x240]
  947749:	vmovdqu ymm4,YMMWORD PTR [rsp+0x1e0]
  947752:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp-0x60]
  947758:	vmovdqu ymm5,YMMWORD PTR [rsp+0x160]
  947761:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x1a0]
  94776a:	vpmaxuw ymm2,ymm2,YMMWORD PTR [rax+0x320]
  947773:	vpminuw ymm2,ymm2,YMMWORD PTR [rax+0x340]
  94777c:	vpmaxuw ymm3,ymm3,YMMWORD PTR [rax+0x360]
  947785:	vpminuw ymm3,ymm3,YMMWORD PTR [rax+0x380]
  94778e:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0x20]
  947794:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0x40]
  94779a:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x60]
  9477a0:	vpaddusw ymm2,ymm2,ymm3
  9477a4:	vpminuw ymm3,ymm5,YMMWORD PTR [rax+0x80]
  9477ad:	vpaddusw ymm3,ymm4,ymm3
  9477b1:	vmovdqu ymm4,YMMWORD PTR [rsp+0x180]
  9477ba:	vpxor  ymm4,ymm4,YMMWORD PTR [rsp+0x1c0]
  9477c3:	vmovdqu ymm5,YMMWORD PTR [rsp+0x120]
  9477cc:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x140]
  9477d5:	vpmaxuw ymm4,ymm4,YMMWORD PTR [rax+0xa0]
  9477de:	vpminuw ymm4,ymm4,YMMWORD PTR [rax+0xc0]
  9477e7:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0xe0]
  9477f0:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x100]
  9477f9:	vpaddusw ymm4,ymm4,ymm5
  9477fd:	vmovdqu ymm5,YMMWORD PTR [rsp+0xe0]
  947806:	vpxor  ymm5,ymm5,YMMWORD PTR [rsp+0x100]
  94780f:	vmovdqu ymm6,YMMWORD PTR [rsp+0xa0]
  947818:	vpxor  ymm6,ymm6,YMMWORD PTR [rsp+0xc0]
  947821:	vmovdqa ymm9,YMMWORD PTR [rax+0xaa0]
  947829:	vpmaddwd ymm10,ymm9,YMMWORD PTR [rsp]
  94782e:	vpmaxuw ymm3,ymm3,ymm7
  947833:	vpmaxuw ymm4,ymm4,ymm7
  947838:	vmovdqa ymm11,YMMWORD PTR [rax+0x920]
  947840:	vpunpckhwd ymm12,ymm3,ymm4
  947844:	vpmaddwd ymm12,ymm12,ymm11
  947849:	vpmaxuw ymm5,ymm5,YMMWORD PTR [rax+0x120]
  947852:	vpminuw ymm5,ymm5,YMMWORD PTR [rax+0x140]
  94785b:	vpmaxuw ymm6,ymm6,YMMWORD PTR [rax+0x160]
  947864:	vpminuw ymm6,ymm6,YMMWORD PTR [rax+0x180]
  94786d:	vpaddd ymm10,ymm10,ymm12
  947872:	vpaddusw ymm5,ymm5,ymm6
  947876:	vpmaxuw ymm1,ymm1,ymm7
  94787b:	vpmaxuw ymm2,ymm2,ymm7
  947880:	vpmaxuw ymm5,ymm5,ymm7
  947885:	vmovdqa ymm6,YMMWORD PTR [rax+0x960]
  94788d:	vmovdqu ymm15,YMMWORD PTR [rsp+0x300]
  947896:	vpunpckhwd ymm12,ymm5,ymm15
  94789b:	vpmaddwd ymm12,ymm12,ymm6
  94789f:	vpaddd ymm10,ymm10,ymm12
  9478a4:	vmovdqa ymm12,YMMWORD PTR [rax+0xa00]
  9478ac:	vpmaddwd ymm7,ymm12,YMMWORD PTR [rsp+0x80]
  9478b5:	vpaddd ymm7,ymm10,ymm7
  9478b9:	vmovdqa ymm10,YMMWORD PTR [rax+0x9c0]
  9478c1:	vpunpckhwd ymm13,ymm1,ymm2
  9478c5:	vpmaddwd ymm13,ymm13,ymm10
  9478ca:	vpaddd ymm7,ymm13,ymm7
  9478ce:	vmovdqa ymm13,YMMWORD PTR [rax+0xa40]
  9478d6:	vpmaddwd ymm14,ymm13,YMMWORD PTR [rsp+0x40]
  9478dc:	vpaddd ymm7,ymm14,ymm7
  9478e0:	vpmaddwd ymm9,ymm9,YMMWORD PTR [rsp+0x20]
  9478e6:	vpunpcklwd ymm1,ymm1,ymm2
  9478ea:	vpmaddwd ymm1,ymm10,ymm1
  9478ee:	vpunpcklwd ymm2,ymm3,ymm4
  9478f2:	vpmaddwd ymm2,ymm11,ymm2
  9478f6:	vpaddd ymm2,ymm9,ymm2
  9478fa:	vpunpcklwd ymm3,ymm5,ymm15
  9478ff:	vpmaddwd ymm3,ymm3,ymm6
  947903:	vpaddd ymm2,ymm2,ymm3
  947907:	vpmaddwd ymm3,ymm8,ymm12
  94790c:	vpaddd ymm2,ymm2,ymm3
  947910:	vpaddd ymm1,ymm2,ymm1
  947914:	vpmaddwd ymm2,ymm13,YMMWORD PTR [rsp-0x80]
  94791a:	vpaddd ymm1,ymm1,ymm2
  94791e:	vpbroadcastd ymm2,DWORD PTR [rax+0xb04]
  947927:	vpsubd ymm3,ymm2,ymm7
  94792b:	vpsubd ymm1,ymm2,ymm1
  94792f:	vpackssdw ymm1,ymm1,ymm3
  947933:	mov    ecx,DWORD PTR [rax+0xd6c]
  947939:	vmovd  xmm2,ecx
  94793d:	vpbroadcastw ymm2,xmm2
  947942:	vpsignw ymm3,ymm2,ymm1
  947947:	vpmulhrsw ymm3,ymm3,ymm1
  94794c:	vpsignw ymm1,ymm3,ymm1
  947951:	vpsignw ymm3,ymm2,ymm0
  947956:	vpmulhrsw ymm3,ymm3,ymm0
  94795b:	vpsignw ymm0,ymm3,ymm0
  947960:	dec    ecx
  947962:	vmovdqu ymm3,YMMWORD PTR [rsp-0x40]
  947968:	vpsignw ymm2,ymm2,ymm3
  94796d:	vpmulhrsw ymm2,ymm2,ymm3
  947972:	vpsignw ymm2,ymm2,ymm3
  947977:	vmovd  xmm3,ecx
  94797b:	vpbroadcastw ymm3,xmm3
  947980:	vpminsw ymm1,ymm1,ymm3
  947984:	vpminsw ymm0,ymm0,ymm3
  947988:	vpminsw ymm2,ymm2,ymm3
  94798c:	vpbroadcastw ymm3,WORD PTR [rax+0xb12]
  947995:	vpmullw ymm1,ymm3,ymm1
  947999:	vpaddw ymm1,ymm1,ymm2
  94799d:	vpbroadcastw ymm2,WORD PTR [rax+0xb10]
  9479a6:	vpbroadcastw ymm3,WORD PTR [rax+0xb14]
  9479af:	vpmullw ymm0,ymm2,ymm0
  9479b3:	vpaddw ymm0,ymm0,ymm3
  9479b7:	vpaddw ymm0,ymm1,ymm0
  9479bb:	vmovdqu YMMWORD PTR [rdi],ymm0
  9479bf:	add    rsp,0x328
  9479c6:	vzeroupper
  9479c9:	ret
