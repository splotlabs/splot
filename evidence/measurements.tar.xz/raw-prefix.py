from pathlib import Path
import hashlib
import subprocess
import sys
root=Path(__file__).resolve().parent
ref=root/'shipped/target/release/splot'
candidate=Path(sys.argv[1]).resolve()
def raw(exe, stream, threads):
    with subprocess.Popen([exe,'decode',stream,'--threads',str(threads),'--limit','40','--output-format','raw','-o','-'], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL) as decode:
        digest=hashlib.file_digest(decode.stdout,'sha256').hexdigest()
        if decode.wait()!=0:
            raise RuntimeError(f'decode failed for {stream} with {threads} threads')
        return digest
for stream in sorted((root/'data').glob('*.ivf')):
    expected=raw(ref,stream,1)
    for threads in (1,7,12):
        actual=raw(candidate,stream,threads)
        if actual!=expected:
            raise RuntimeError(f'{candidate}: {actual} != {expected}')
        print(stream.name,threads,actual,flush=True)
