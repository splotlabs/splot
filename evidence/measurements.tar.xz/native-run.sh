set -euo pipefail
root=$(pwd)
repo="$root/../splot-1934-native-kernels"
out="$root/native"
mkdir -p "$out"
git -C "$repo" rev-parse HEAD > "$out/revision"
(cd "$repo" && systemd-run --user --scope --quiet -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p CPUQuota=180% flock "$root/build.lock" taskset -c 6-11,14-19 env CARGO_TARGET_DIR="$out/target" CARGO_PROFILE_RELEASE_STRIP=none cargo build --release -j1 --offline --locked -p splot-cli -p splot-capi) > "$out/build.log" 2>&1
cli="$out/target/release/splot"
sha256sum "$cli" "$out/target/release/libsplot_capi.so" > "$out/artifacts.sha256"
bash native-raw.sh > "$out/sse2.txt" 2>&1
python3 matrix-callgrind.py native "$cli"
for name in WITCHER3 TunnelFlag Noise_Ocean; do
    if [[ $name == Noise_Ocean ]]; then input="$root/ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf"; frames=16; else match=("$root"/data/"$name"*.ivf); input=${match[0]}; frames=3; fi
    taskset -c 2 valgrind --tool=callgrind --callgrind-out-file="$out/$name.cg" --log-file="$out/$name.cglog" "$cli" decode "$input" --threads 1 --frame-delay 1 --limit "$frames" --output-format null
done
flock "$root/build.lock" python3 -u bench.py native-four-way.csv native kernels module shipped > native-four-way.txt
