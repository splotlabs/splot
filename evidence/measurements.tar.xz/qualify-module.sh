set -euo pipefail
qual=$(pwd)
repo="$qual/../splot-1934-cdef-module"
for phase in micro decoder; do
 for version in function module; do
  out="$qual/cdef-$version"
  mkdir -p "$out"
  opts=(CARGO_PROFILE_RELEASE_STRIP=none)
  if [[ $version == module ]]; then opts+=(RUSTC_WRAPPER="$repo/scripts/rustc-cdef-prototype.py" SPLOT_CDEF_COMPILE_LOG="$out/$phase-flags.tsv"); fi
  if [[ $phase == micro ]]; then
    (cd "$qual/cdef-micro" && env "${opts[@]}" CARGO_TARGET_DIR="$out/micro-target" cargo +1.100.0 build --release -j1 --locked --offline) > "$out/micro-build.log" 2>&1
    micro="$out/micro-target/release/cdef-micro"
    "$micro" --iterations 0 > "$out/native-parity.txt"
    "$qual/qemu/usr/bin/qemu-x86_64" -cpu qemu64,-pni,-sse4a,-ssse3,-sse4.1,-sse4.2 "$micro" --sse2-only --iterations 0 > "$out/sse2-parity.txt"
  else
    (cd "$repo" && env "${opts[@]}" CARGO_TARGET_DIR="$out/target" cargo build --release -j1 --locked --offline -p splot-cli -p splot-capi) > "$out/build.log" 2>&1
    sha256sum "$out"/target/release/{splot,libsplot_capi.so} > "$out/artifacts.sha256"
    nm -S --demangle=rust --size-sort "$out/target/release/splot" | rg 'splot_cdef_(avx2|base)::gather_packed' > "$out/linked-functions.txt"
  fi
 done
 if [[ $phase == micro ]]; then python3 -u micro-times.py > micro-times.txt; fi
done
python3 -u bench.py module-four-way.csv module function kernels shipped > module-four-way.txt
