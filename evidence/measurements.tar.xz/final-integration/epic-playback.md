### Portable AVX2 playback after the TIP and smooth prediction fixes

The ordinary Cargo build selects AVX2 on the i7-12700H. The current draft includes the two measured fixes in `7c50c1b4`. The latest commit `29e00167` removes a redundant comment for CI. #1987 remains a draft while playback is slower than the shipped v3 build `10279846`.

| Stream | Frames | Portable elapsed time vs shipped | Paired 95% interval |
| --- | ---: | ---: | ---: |
| WITCHER3 | 40 | +9.46% | +5.60% to +12.21% |
| TunnelFlag | 40 | +10.30% | +8.35% to +11.30% |
| Noise_Ocean | 16 | +13.53% | +4.68% to +16.26% |
| RitualDance | 16 | +11.98% | +7.56% to +19.04% |

These are 12 counterbalanced rounds with one decoder thread, frame delay one and null output. Full output matched AVM in all 21 checks across seven streams and three thread counts. The strict SSE2 CLI and external C consumer passed all 40 comparisons. The last completed CI instruction comparison was +13.378% over its base across five streams. Both linked artifacts passed their size check. [Gate and exact byte counts](https://github.com/splotlabs/splot/actions/runs/45654396017/job/139347080197).

The remaining cost depends on the input. On 8-bit Noise_Ocean, CDEF accounted for 71 ms of the 166 ms mean sampled CPU difference over 130 frames. On 10-bit RitualDance the first 16 frames refined exactly 2,915 TIP blocks in both builds, with 319.05M instructions in the shipped refinement path and 461.08M in the draft. The scope of ordinary Rust helpers around SIMD work matters here. A whole temporal-scan experiment increased instruction counts on both streams and stays out of the draft. The tests of CDEF calling conventions and the two measured prediction/filter paths are still in progress.

#1972 and #1978 are merged. Native Xeon coverage matched 63/63 outputs across Auto, AVX2 and forced AVX-512. The M2 Max completed 21/21 NEON output checks. Its two native first-picture latency reruns are tracked separately. [Xeon qualification](https://github.com/splotlabs/splot/actions/runs/45634575719/attempts/2) · [M2 Max follow-up](https://github.com/splotlabs/splot/issues/1993).
