Tracks #1934 under #1882. This draft includes the typed-driver work in #1977 and the portable x86 backend. Keep it in draft while the AVX2 throughput gate is open.

### Changes

Replace the checkout-wide x86-64-v3 and AVX-512-disabling flags with startup backend selection. A baseline x86-64 decoder can select SSE2; a qualified AVX2 host selects AVX2. The forced AVX-512 path remains available on supported machines. The current automatic wide-kernel policy remains conservative. The external consumer workflow exercises a Cargo project built outside this checkout.

Keep the existing decoder and kernel algorithms. Compile measured CDEF, GDF, transform, restoration, motion and prediction loops inside the selected SIMD scope so portable builds can inline their vector operations.

### Combined AVX2 measurements

The runtime code at `7c50c1b4` includes the TIP field and smooth intra changes, together with main `d49defcf`. `6387bf3f` changes only the CLI byte ceiling. The four workloads below ran on the i7-12700H with Auto, one decode worker, frame delay one and null output. Twelve paired rounds covered all six executable orders twice. Entries are median changes in elapsed time with paired 95% bootstrap intervals. Positive values are slower.

| Stream | Frames | Combined vs previous draft `f03b06e2` | Combined vs shipped v3 `10279846` |
|---|---:|---:|---:|
| WITCHER3 | 40 | -0.61% [-3.47%, +2.64%] | +9.46% [+5.60%, +12.21%] |
| TunnelFlag | 40 | -1.27% [-6.15%, +1.88%] | +10.30% [+8.35%, +11.30%] |
| Noise_Ocean | 16 | -3.95% [-7.98%, +1.57%] | +13.53% [+4.68%, +16.26%] |
| RitualDance | 16 | -2.97% [-8.16%, +2.33%] | +11.98% [+7.56%, +19.04%] |

In isolated 16-frame tests the TIP fix alone reduced Noise_Ocean by 64.15M guest instructions, and the smooth fix alone reduced RitualDance by 38.34M. In the combined benchmark the comparison with the earlier draft also includes changes from main. It cannot isolate either fix. On the earlier draft 83% of excess Noise_Ocean instructions in the symbolized proxy were in motion/prediction and filters. [Stage breakdown and restoration results](https://github.com/splotlabs/splot/issues/1934#issuecomment-7167468003).

The exact-head CI instruction check counted 14,747,667,627 on the portable draft and 13,007,495,146 on its base (**+13.378%**). Per-stream excess was +9.600% DOTA2, +17.749% RitualDance, +12.206% Slides1, +15.140% Noise_Ocean, and +11.246% old_town_cross. The previous draft was +16.178% against its then-current base. [Current instruction and size gate](https://github.com/splotlabs/splot/actions/runs/45654396017/job/139347080197).

### Output and hardware coverage

All seven complete streams matched AVM at 1, 7 and 12 workers (21/21) on `7c50c1b4`. A strict SSE2 CPU model matched all 40 reference outputs across the release CLI and external C consumer. Earlier native Xeon qualification matched all 63 outputs across Auto/AVX2/AVX-512. The M2 Max verified corrected NEON dispatch and 21 full-stream outputs. Native idle first-picture latency checks on two inputs remain open. [Xeon run](https://github.com/splotlabs/splot/actions/runs/45634575719/attempts/2) · [Apple results](https://github.com/splotlabs/splot/issues/1980) · [Apple follow-up](https://github.com/splotlabs/splot/issues/1993).

### Linux linked size

CI measured 16,759,752 bytes after merging main, then 16,759,640 on the budget-only follow-up. Local GNU strip measured 16,759,728 bytes. Main raised its own single-backend CLI ceiling by 85,000 bytes (12,390,000 → 12,475,000). `6387bf3f` carries the same delta into the portable CLI ceiling (16,680,000 → 16,765,000) and retains the 4,290,000-byte dual-backend allowance relative to main. CI measured the C library at 12,943,616 bytes, 26,384 below its unchanged ceiling of 12,970,000. Both linked artifacts passed their size gate. CPU-instruction and throughput limits still apply. The draft remains blocked on AVX2 speed.
