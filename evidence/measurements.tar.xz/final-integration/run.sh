#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 2 || ! $2 =~ ^[0-9a-f]{40}$ ]]; then
    echo "Usage: $0 WORKTREE FULL_COMMIT_SHA" >&2
    exit 2
fi
out=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
worktree=$(realpath -- "$1")
qualification=$(dirname -- "$out")
exec systemd-run --user --scope --quiet \
    -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p CPUQuota=180% \
    flock "$qualification/build.lock" bash "$out/qualify.sh" "$worktree" "$2"
