#!/usr/bin/env bash
set -euo pipefail
worktree=$1
sha=$2
out=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
qualification=$(dirname -- "$out")
release="$out/target/release"
f03="$qualification/draft-f03"
shipped="$qualification/shipped"
build_cpus=6-11,14-19

check_checkout() {
    local actual status
    actual=$(git -C "$worktree" rev-parse HEAD)
    status=$(git -C "$worktree" status --porcelain)
    if [[ $actual != "$sha" || -n $status ]]; then
        printf 'Expected clean %s, got %s\n%s\n' "$sha" "$actual" "$status" >&2
        return 1
    fi
}

check_checkout
if [[ -e $release/splot || -e $out/paired.csv ]]; then
    echo "Refusing to overwrite an existing qualification." >&2
    exit 2
fi
git -C "$worktree" verify-commit "$sha" > "$out/git-signature.txt" 2>&1
test "$(git -C "$shipped" rev-parse HEAD)" = 102798461d19a98b6e04b935538fb24f7b339701
(
    cd "$shipped"
    printf '%s  %s\n' bae0f1d42e854c584948bcad82f9618fbb49bfdef93a852dc9e95d8a2aab9cd2 \
        target/release/splot | sha256sum -c
) > "$out/shipped-reference.txt"
(
    cd "$f03"
    sha256sum -c artifacts.sha256
) > "$out/f03-reference.txt"
(
    cd "$worktree"
    printf 'Combined %s\nf03 %s\nShipped %s\n' "$sha" \
        f03b06e2419b27cf8ab4b55c62471695513cdbe1 102798461d19a98b6e04b935538fb24f7b339701
    date --iso-8601=seconds
    uname -srmo
    lscpu | sed -n '/^Model name:/p'
    cargo -V
    rustc -Vv
    sha256sum "$shipped/target/release/splot"
) > "$out/environment.txt"

# Keep registry artifacts only. rsync creates private files and leaves f03 untouched.
rsync -a --exclude='*splot*' --exclude='*xtask*' --exclude='.cargo-*lock' \
    "$f03/target/" "$out/target/" > "$out/cache.log" 2>&1
printf 'Building %s\n' "$sha"
(
    cd "$worktree"
    taskset -c "$build_cpus" env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u RUSTC_WRAPPER \
        CARGO_PROFILE_RELEASE_STRIP=none CARGO_TARGET_DIR="$out/target" \
        cargo build --release --offline --locked -j1 -p splot-cli -p splot-capi
) > "$out/build.log" 2>&1
check_checkout
echo "Preserving symbolized control and stripping qualification artifacts"
mv "$release/splot" "$out/splot.full"
mv "$release/libsplot_capi.so" "$out/libsplot_capi.so.full"
strip --strip-all -o "$release/splot" "$out/splot.full"
strip --strip-all -o "$release/libsplot_capi.so" "$out/libsplot_capi.so.full"
(
    cd "$out"
    file target/release/{splot,libsplot_capi.so} splot.full libsplot_capi.so.full > artifact-file.txt
    sha256sum target/release/{splot,libsplot_capi.so} splot.full libsplot_capi.so.full > artifacts.sha256
)

failed=0
echo "Checking release package sizes"
python3 "$out/size.py" "$worktree" > "$out/sizes.txt" || failed=1
echo "Running paired playback on CPU 4"
taskset -c 4 python3 -u "$out/bench.py" > "$out/paired.txt" 2>&1 || failed=1
echo "Checking full AVM hashes"
taskset -c "$build_cpus" python3 -u "$out/hash_avm.py" > "$out/avm.txt" 2> "$out/avm.stderr" || failed=1
echo "Checking strict-SSE2 CLI and external C consumer"
taskset -c "$build_cpus" bash "$out/sse2.sh" "$worktree" > "$out/sse2.txt" 2> "$out/sse2.stderr" || failed=1
(
    cd "$out"
    sha256sum -c artifacts.sha256
) || failed=1
check_checkout || failed=1
exit "$failed"
