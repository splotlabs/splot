#!/usr/bin/env bash
set -euo pipefail
worktree=$1
out=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
qualification=$(dirname -- "$out")
release="$out/target/release"
shipped="$qualification/shipped/target/release/splot"
qemu="$qualification/qemu/usr/bin/qemu-x86_64"
cpu=qemu64,-pni,-sse4a,-ssse3,-sse4.1,-sse4.2,-avx,-avx2
raw=$(mktemp -d "$out/sse2-raw.XXXXXX")
example="$out/c-example"
capi="$worktree/crates/splot-capi"

cc -O2 -march=x86-64 -I "$capi/include" "$capi/examples/decode.c" \
    -L "$release" -lsplot_capi -Wl,-rpath,"$release" -o "$example"
fixtures=(
    syn-3frame-multiref-64x64
    syn-8frame-opfl-refine-all-64x64-q120
    syn-3frame-deblock-subpu-chroma-64x32-10bit-q90
    syn-filmgrain-intra-64x64
    syn-bru-lr-stripe-wienerns-8bit
    syn-bru-lr-stripe-wienerns-10bit
    syn-bru-lr-stripe-pcwiener-8bit
    syn-bru-lr-stripe-pcwiener-10bit
    syn-bru-lr-multitile-cross-8bit
    syn-bru-gdf-block-10bit
)
failures=0
printf 'QEMU CPU %s\n' "$cpu"
for name in "${fixtures[@]}"; do
    ivf="$worktree/tests/conformance/vectors/valid/$name.ivf"
    reference="$raw/$name.reference.yuv"
    if ! "$shipped" decode "$ivf" --threads 1 --output-format raw -o "$reference"; then
        printf 'FAIL %s shipped reference\n' "$name"
        failures=$((failures + 1))
        continue
    fi
    for threads in 1 3 8; do
        actual="$raw/$name.cli-$threads.yuv"
        if "$qemu" -cpu "$cpu" "$release/splot" decode "$ivf" --threads "$threads" \
                --output-format raw -o "$actual" && cmp "$reference" "$actual"; then
            printf 'PASS %s CLI %s\n' "$name" "$threads"
        else
            printf 'FAIL %s CLI %s\n' "$name" "$threads"
            failures=$((failures + 1))
        fi
    done
    actual="$raw/$name.c-api.yuv"
    if env -u LD_LIBRARY_PATH -u LD_PRELOAD "$qemu" -cpu "$cpu" "$example" "$ivf" "$actual" \
            && cmp "$reference" "$actual"; then
        printf 'PASS %s C API\n' "$name"
    else
        printf 'FAIL %s C API\n' "$name"
        failures=$((failures + 1))
    fi
done
test "$failures" -eq 0
