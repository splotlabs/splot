from pathlib import Path
import sys
import tomllib

output = Path(__file__).resolve().parent
release = output / "target/release"
f03_release = output.parent / "draft-f03/target/release"
budget_file = Path(sys.argv[1]) / "tests/perf/binary-size.toml"
budgets = tomllib.loads(budget_file.read_text())

failed = False
for artifact, key in [("splot", "budget"), ("libsplot_capi.so", "capi_budget")]:
    size = (release / artifact).stat().st_size
    limit = budgets[key]["x86_64-linux"]
    delta = size - limit
    previous = (f03_release / artifact).stat().st_size
    print(f"{artifact}: f03 Cargo-stripped {previous:,} bytes, merged GNU-stripped {size:,} bytes, "
          f"change {size-previous:+,} bytes, budget {limit:,}, budget delta {delta:+,} bytes")
    failed |= delta > 0
sys.exit(failed)
