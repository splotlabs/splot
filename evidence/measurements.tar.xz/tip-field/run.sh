set -euo pipefail
q=$(cd .. && pwd)
out=$q/tip-field
repo=$q/../splot-1934-tip-field
base=$q/draft-f03
cd "$repo"
(
 flock -x 9
 if [[ ! -d $out/target ]]; then cp -a --reflink=auto "$base/target" "$out/target"; fi
 taskset -c 6-11,14-19 env CARGO_PROFILE_RELEASE_STRIP=none CARGO_TARGET_DIR="$out/target" cargo build --release --locked --offline -j1 -p splot-cli -p splot-capi
) 9>"$q/build.lock" > "$out/build.log" 2>&1
for id in Noise_Ocean_1920x1080_60fps_qp135 RitualDance; do
 input=("$q/ci-data/$id"*.ivf)
 for variant in "$base" "$out"; do
  if [[ $id == RitualDance && $variant == "$base" ]]; then continue; fi
  name=noise16; if [[ $id == RitualDance ]]; then name=ritual16; fi
  taskset -c 2 valgrind --tool=callgrind --callgrind-out-file="$variant/$name.cg" --log-file="$variant/$name.log" "$variant/target/release/splot" decode "${input[0]}" --threads 1 --frame-delay 1 --limit 16 --output-format null
 done
done
cd "$q"
cp module-raw-check.sh "$out/check-template.sh"
sed 's|splot-1934-cdef-module|splot-1934-tip-field|g;s|out="$root/cdef-module"|out="$root/tip-field"|g' "$out/check-template.sh" > "$out/checks.sh"
taskset -c 3 bash "$out/checks.sh" > "$out/sse2.txt" 2>&1
