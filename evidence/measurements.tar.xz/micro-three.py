import csv, itertools, os, random, re, statistics, subprocess
from pathlib import Path
from statistics import median
root=Path(__file__).resolve().parent
bins={k:root/f'cdef-{k}/micro-target/release/cdef-micro' for k in ('function','module')}
bins['direct']=root/'cdef-micro-direct/target/release/cdef-micro'
os.sched_setaffinity(0,{4})
orders=list(itertools.permutations(bins))
for exe in bins.values():
    subprocess.run([exe,'--iterations','50000'],check=True,stdout=subprocess.DEVNULL)
data={}
with (root/'micro-direct-three.csv').open('x') as f:
    w=csv.writer(f)
    w.writerow(['round','order','build','policy','ns_per_call'])
    for i,order in enumerate(orders*2):
        for j,key in enumerate(order):
            out=subprocess.check_output([bins[key],'--iterations','1000000'],text=True)
            for mode,t in re.findall(r'^(sse2|avx2|auto) iterations=.*?ns_per_call=([0-9.]+)',out,re.M):
                w.writerow([i+1,j+1,key,mode,t])
                data[i,key,mode]=float(t)
        f.flush()
for mode in ('sse2','avx2','auto'):
    print(mode, {k:round(median(data[i,k,mode] for i in range(12)),3) for k in bins})
    for k in ('function','module'):
        d=[100*(data[i,'direct',mode]/data[i,k,mode]-1) for i in range(12)]
        r=random.Random(1882)
        boot=sorted(median(r.choices(d,k=12)) for _ in range(10000))
        print('direct vs',k,*(round(x,2) for x in (median(d),boot[250],boot[9749])))
