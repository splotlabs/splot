# CDEF block call with a shared context

This adjacent experiment is based on signed `536185a0` and leaves its executable in place. It uses the same process-startup mode, typed backend gate, four-block gather, active-block condition, and bit-depth-specific filter algorithms. See the first experiment's startup details in `../cdef-table/experiment.md`.

Set `SPLOT_CDEF_BLOCK_CALL=direct` or `SPLOT_CDEF_BLOCK_CALL=pointer` before starting the decoder. Both modes call the same complete AVX2 block worker using a mutable reference to context initialized once per segment and a block index. Each worker borrows the output slices and looks up block flags within that context. Both modes share one entry into the concrete segment loop per four-block group, with mode selection ahead of the loop. The worker enters its AVX2 scope before direction, filtering, and output writes.

The independent baseline remains the ordinary Cargo `7c50c1b4` CLI in default Auto mode. `verify.py` runs full one-thread AVM output validation for both call modes using the official 8-bit Noise_Ocean and 10-bit RitualDance oracles.

The unstripped release CLI has SHA-256 `e10f02433044ede029372f986af912151cc8841b05ce417d0905432991b5e644`. In `block-calls.dis`, both byte and word wrappers shrink from 109 bytes to a single 5-byte `jmp rel32` into their corresponding AVX2 feature body. The wrappers have no stack traffic. At the call sites in both modes the context address is in `rdi` and the block index is in `esi`. The pointer route binds the callable in `rbx` before the unrolled visits and uses `call *%rbx` at each active block. The direct route uses `call rel32` to the corresponding wrapper. Both routes prepare the context once before the four potential calls.
