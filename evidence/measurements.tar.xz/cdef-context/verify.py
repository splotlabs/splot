"""Check both CDEF call modes against the full AVM output oracles."""
import hashlib
import os
from pathlib import Path
import subprocess

run_dir = Path(__file__).resolve().parent
fixtures = run_dir.parent / "ci-data"
decoder = run_dir / "target/release/splot"
cases = {
    name: (digest, int(frames), int(size))
    for name, digest, frames, size in (
        line.split("\t")
        for line in (fixtures / "simd-cases.tsv").read_text().splitlines()
    )
    if name.startswith(("Noise_Ocean_1920x1080_60fps_qp135_", "RitualDance_"))
}
assert len(cases) == 2, cases
for mode in ("direct", "pointer"):
    env = dict(os.environ, SPLOT_CDEF_BLOCK_CALL=mode)
    for name, (expected_digest, frames, expected_size) in cases.items():
        command = [
            decoder, "decode", fixtures / name, "--threads", "1",
            "--output-format", "raw", "-o", "-",
        ]
        digest = hashlib.sha256()
        size = 0
        with subprocess.Popen(command, stdout=subprocess.PIPE, env=env) as decode:
            while chunk := decode.stdout.read(1 << 20):
                digest.update(chunk)
                size += len(chunk)
            code = decode.wait()
        actual = digest.hexdigest()
        if (code, size, actual) != (0, expected_size, expected_digest):
            raise RuntimeError((mode, name, code, size, actual))
        print(f"PASS {mode} {name} {frames} {size} {actual}", flush=True)
