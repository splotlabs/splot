
<WORKTREES>/qualification-1882/lr-external-unit/target/release/lr-consumer:     file format elf64-x86-64


Disassembly of section .text:

0000000000d27f40 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run>:
  d27f40:	push   %rbp
  d27f41:	push   %r15
  d27f43:	push   %r14
  d27f45:	push   %r13
  d27f47:	push   %r12
  d27f49:	push   %rbx
  d27f4a:	sub    $0x798,%rsp
  d27f51:	xor    %r12d,%r12d
  d27f54:	sub    %rcx,%r8
  d27f57:	cmovae %r8,%r12
  d27f5b:	mov    %r12,%r8
  d27f5e:	and    $0xfffffffffffffff0,%r8
  d27f62:	sete   %r10b
  d27f66:	test   %rdx,%rdx
  d27f69:	sete   %al
  d27f6c:	or     %r10b,%al
  d27f6f:	cmp    $0x9,%rdx
  d27f73:	setae  %r10b
  d27f77:	or     %al,%r10b
  d27f7a:	jne    d27fb0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
  d27f7c:	mov    %r8,%r11
  d27f7f:	add    %rcx,%r11
  d27f82:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d27f84:	sub    $0xfffffffffffffff8,%r11
  d27f88:	setae  %al
  d27f8b:	test   %rsi,%rsi
  d27f8e:	sete   %r10b
  d27f92:	or     %al,%r10b
  d27f95:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d27f97:	mov    %r11,%r13
  d27f9a:	sub    %rcx,%r13
  d27f9d:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d27f9f:	cmp    0x8(%rdi),%r11
  d27fa3:	ja     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d27fa5:	lea    0x8(%rdx),%r15
  d27fa9:	cmp    %r15,%rsi
  d27fac:	jae    d27fc5 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x85>
  d27fae:	xor    %eax,%eax
  d27fb0:	add    $0x798,%rsp
  d27fb7:	pop    %rbx
  d27fb8:	pop    %r12
  d27fba:	pop    %r13
  d27fbc:	pop    %r14
  d27fbe:	pop    %r15
  d27fc0:	pop    %rbp
  d27fc1:	vzeroupper
  d27fc4:	ret
  d27fc5:	mov    0x7d0(%rsp),%r10
  d27fcd:	mov    (%r10),%rax
  d27fd0:	mov    0x8(%r10),%r14
  d27fd4:	mov    0x10(%r10),%r10
  d27fd8:	mov    %r10,0x1b0(%rsp)
  d27fe0:	mov    (%rdi),%r10
  d27fe3:	lea    (%r10,%rcx,2),%r10
  d27fe7:	mov    %r10,0x18(%rsp)
  d27fec:	mov    %r13,0x20(%rsp)
  d27ff1:	mov    %r10,0x28(%rsp)
  d27ff6:	mov    %r13,0x30(%rsp)
  d27ffb:	mov    %r10,0x38(%rsp)
  d28000:	mov    %r13,0x40(%rsp)
  d28005:	mov    %r10,0x48(%rsp)
  d2800a:	mov    %r13,0x50(%rsp)
  d2800f:	mov    %r10,0x58(%rsp)
  d28014:	mov    %r13,0x60(%rsp)
  d28019:	mov    %r10,0x68(%rsp)
  d2801e:	mov    %r13,0x70(%rsp)
  d28023:	mov    %r10,0x78(%rsp)
  d28028:	mov    %r13,0x80(%rsp)
  d28030:	mov    %r10,0x88(%rsp)
  d28038:	mov    %r13,0x90(%rsp)
  d28040:	mov    %r10,0x98(%rsp)
  d28048:	mov    %r13,0xa0(%rsp)
  d28050:	mov    %r10,0xa8(%rsp)
  d28058:	mov    %r13,0xb0(%rsp)
  d28060:	mov    %r10,0xb8(%rsp)
  d28068:	mov    %r13,0xc0(%rsp)
  d28070:	mov    %r10,0xc8(%rsp)
  d28078:	mov    %r13,0xd0(%rsp)
  d28080:	mov    %r10,0xd8(%rsp)
  d28088:	mov    %r13,0xe0(%rsp)
  d28090:	mov    %r10,0xe8(%rsp)
  d28098:	mov    %r13,0xf0(%rsp)
  d280a0:	mov    %r10,0xf8(%rsp)
  d280a8:	mov    %r13,0x100(%rsp)
  d280b0:	mov    %r10,0x128(%rsp)
  d280b8:	mov    %r10,0x108(%rsp)
  d280c0:	cmp    $0x10,%rsi
  d280c4:	mov    $0x10,%ebx
  d280c9:	cmovb  %rsi,%rbx
  d280cd:	mov    %r13,0x110(%rsp)
  d280d5:	shl    $0x4,%ebx
  d280d8:	xor    %esi,%esi
  d280da:	lea    (%rcx,%rcx,1),%r10
  d280de:	xchg   %ax,%ax
  d280e0:	cmp    %rsi,%rbx
  d280e3:	je     d2810d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x1cd>
  d280e5:	cmp    0x8(%rdi,%rsi,1),%r11
  d280ea:	ja     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d280f0:	dec    %r15
  d280f3:	mov    (%rdi,%rsi,1),%rbp
  d280f7:	add    %r10,%rbp
  d280fa:	mov    %rbp,0x18(%rsp,%rsi,1)
  d280ff:	mov    %r13,0x20(%rsp,%rsi,1)
  d28104:	add    $0x10,%rsi
  d28108:	test   %r15,%r15
  d2810b:	jne    d280e0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x1a0>
  d2810d:	vbroadcasti128 -0xce4fe6(%rip),%ymm0        # 43130 <anon.936c60de95d7a09f3acdd5b08a91176d.199.llvm.6645579717452751935+0xeb0>
  d28116:	vmovdqu %ymm0,0x1d0(%rsp)
  d2811f:	vmovdqu %ymm0,0x1f0(%rsp)
  d28128:	vmovdqu %ymm0,0x210(%rsp)
  d28131:	vmovdqu %ymm0,0x230(%rsp)
  d2813a:	vmovdqu %ymm0,0x250(%rsp)
  d28143:	vmovdqu %ymm0,0x270(%rsp)
  d2814c:	vmovdqu %ymm0,0x290(%rsp)
  d28155:	vmovdqu %ymm0,0x2b0(%rsp)
  d2815e:	mov    %r14,%rsi
  d28161:	sub    %rcx,%rsi
  d28164:	mov    0x1b0(%rsp),%r11
  d2816c:	cmp    %r8,%r11
  d2816f:	jae    d281a8 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x268>
  d28171:	cmp    %rcx,%r14
  d28174:	setb   %dil
  d28178:	cmp    %r8,%rsi
  d2817b:	setb   %sil
  d2817f:	or     %dil,%sil
  d28182:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28188:	lea    (%rax,%rcx,2),%rax
  d2818c:	mov    %rax,0x1d0(%rsp)
  d28194:	mov    %r8,0x1d8(%rsp)
  d2819c:	cmp    $0x1,%rdx
  d281a0:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d281a6:	jmp    d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
  d281a8:	cmp    %rcx,%r14
  d281ab:	setb   %dil
  d281af:	cmp    %r8,%rsi
  d281b2:	setb   %r10b
  d281b6:	or     %dil,%r10b
  d281b9:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d281bf:	lea    (%rax,%rcx,2),%rax
  d281c3:	mov    %rax,0x1d0(%rsp)
  d281cb:	mov    %r8,0x1d8(%rsp)
  d281d3:	cmp    $0x1,%rdx
  d281d7:	jne    d288e6 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x9a6>
  d281dd:	mov    (%r9),%r14
  d281e0:	test   %r14,%r14
  d281e3:	jne    d28218 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x2d8>
  d281e5:	vpbroadcastq 0x8(%r9),%ymm0
  d281eb:	vmovdqu %ymm0,0x310(%rsp)
  d281f4:	lea    0x558(%rsp),%rdi
  d281fc:	lea    0x310(%rsp),%rsi
  d28204:	mov    %r9,%rbx
  d28207:	mov    %rdx,%r15
  d2820a:	vzeroupper
  d2820d:	call   d28bc0 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  d28212:	mov    %r15,%rdx
  d28215:	mov    %rbx,%r9
  d28218:	shr    $0x4,%r12
  d2821c:	mov    $0x1,%al
  d2821e:	je     d27fb0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
  d28224:	mov    %rdx,(%rsp)
  d28228:	lea    0x558(%rsp),%rax
  d28230:	movzwl 0x7d8(%rsp),%ecx
  d28238:	vmovd  %ecx,%xmm0
  d2823c:	vpbroadcastw %xmm0,%ymm0
  d28241:	vmovdqu %ymm0,0x2f0(%rsp)
  d2824a:	xor    %ebx,%ebx
  d2824c:	movq   $0x0,0x8(%rsp)
  d28255:	mov    %r14,0x120(%rsp)
  d2825d:	mov    %rax,0x10(%rsp)
  d28262:	test   %r14,%r14
  d28265:	je     d282b1 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x371>
  d28267:	lea    0x2d0(%rsp),%rdi
  d2826f:	mov    %r9,%rsi
  d28272:	mov    0x8(%rsp),%rdx
  d28277:	mov    %r9,%r15
  d2827a:	vzeroupper
  d2827d:	call   d28ac0 <_RNvMCs3HZP85FyIZE_15splot_lr_kernelNtB2_7Classes5group>
  d28282:	cmpq   $0x0,0x2d0(%rsp)
  d2828b:	je     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28291:	lea    0x310(%rsp),%rbp
  d28299:	mov    %rbp,%rdi
  d2829c:	lea    0x2d0(%rsp),%rsi
  d282a4:	call   d28bc0 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  d282a9:	mov    %r15,%r9
  d282ac:	mov    %rbp,0x10(%rsp)
  d282b1:	mov    %r13,%rcx
  d282b4:	sub    %rbx,%rcx
  d282b7:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d282bd:	cmp    $0x18,%rcx
  d282c1:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d282c7:	mov    0x128(%rsp),%rcx
  d282cf:	lea    (%rcx,%rbx,2),%rcx
  d282d3:	vmovq  %rcx,%xmm0
  d282d8:	vpbroadcastq %xmm0,%ymm0
  d282dd:	vmovdqu %ymm0,0x178(%rsp)
  d282e6:	mov    %rcx,0x198(%rsp)
  d282ee:	mov    %rcx,0x1a0(%rsp)
  d282f6:	mov    %rcx,0x1a8(%rsp)
  d282fe:	mov    0x20(%rsp),%rdx
  d28303:	sub    %rbx,%rdx
  d28306:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2830c:	cmp    $0x18,%rdx
  d28310:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28316:	lea    (%rbx,%rbx,1),%rdx
  d2831a:	mov    0x18(%rsp),%rcx
  d2831f:	add    %rdx,%rcx
  d28322:	mov    %rcx,0x130(%rsp)
  d2832a:	mov    0x30(%rsp),%rsi
  d2832f:	sub    %rbx,%rsi
  d28332:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28338:	cmp    $0x18,%rsi
  d2833c:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28342:	mov    0x28(%rsp),%rcx
  d28347:	add    %rdx,%rcx
  d2834a:	mov    %rcx,0x138(%rsp)
  d28352:	mov    0x40(%rsp),%rsi
  d28357:	sub    %rbx,%rsi
  d2835a:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28360:	cmp    $0x18,%rsi
  d28364:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2836a:	mov    0x38(%rsp),%rcx
  d2836f:	add    %rdx,%rcx
  d28372:	mov    %rcx,0x140(%rsp)
  d2837a:	mov    0x50(%rsp),%rsi
  d2837f:	sub    %rbx,%rsi
  d28382:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28388:	cmp    $0x18,%rsi
  d2838c:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28392:	mov    0x48(%rsp),%rcx
  d28397:	add    %rdx,%rcx
  d2839a:	mov    %rcx,0x148(%rsp)
  d283a2:	mov    0x60(%rsp),%rsi
  d283a7:	sub    %rbx,%rsi
  d283aa:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d283b0:	cmp    $0x18,%rsi
  d283b4:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d283ba:	mov    0x58(%rsp),%rcx
  d283bf:	add    %rdx,%rcx
  d283c2:	mov    %rcx,0x150(%rsp)
  d283ca:	mov    0x70(%rsp),%rsi
  d283cf:	sub    %rbx,%rsi
  d283d2:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d283d8:	cmp    $0x18,%rsi
  d283dc:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d283e2:	mov    0x68(%rsp),%rcx
  d283e7:	add    %rdx,%rcx
  d283ea:	mov    %rcx,0x158(%rsp)
  d283f2:	mov    0x80(%rsp),%rsi
  d283fa:	sub    %rbx,%rsi
  d283fd:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28403:	cmp    $0x18,%rsi
  d28407:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2840d:	mov    0x78(%rsp),%rcx
  d28412:	add    %rdx,%rcx
  d28415:	mov    %rcx,0x160(%rsp)
  d2841d:	mov    0x90(%rsp),%rsi
  d28425:	sub    %rbx,%rsi
  d28428:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2842e:	cmp    $0x18,%rsi
  d28432:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28438:	mov    0x88(%rsp),%rcx
  d28440:	add    %rdx,%rcx
  d28443:	mov    %rcx,0x168(%rsp)
  d2844b:	mov    0xa0(%rsp),%rsi
  d28453:	sub    %rbx,%rsi
  d28456:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2845c:	cmp    $0x18,%rsi
  d28460:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28466:	mov    0x98(%rsp),%rcx
  d2846e:	add    %rdx,%rcx
  d28471:	mov    %rcx,0x170(%rsp)
  d28479:	cmpq   $0x1,(%rsp)
  d2847e:	je     d285fd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
  d28484:	mov    0xb0(%rsp),%rsi
  d2848c:	sub    %rbx,%rsi
  d2848f:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28495:	cmp    $0x18,%rsi
  d28499:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2849f:	mov    0xa8(%rsp),%rcx
  d284a7:	add    %rdx,%rcx
  d284aa:	mov    %rcx,0x178(%rsp)
  d284b2:	cmpq   $0x2,(%rsp)
  d284b7:	je     d285fd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
  d284bd:	mov    0xc0(%rsp),%rsi
  d284c5:	sub    %rbx,%rsi
  d284c8:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d284ce:	cmp    $0x18,%rsi
  d284d2:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d284d8:	mov    0xb8(%rsp),%rcx
  d284e0:	add    %rdx,%rcx
  d284e3:	mov    %rcx,0x180(%rsp)
  d284eb:	cmpq   $0x3,(%rsp)
  d284f0:	je     d285fd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
  d284f6:	mov    0xd0(%rsp),%rsi
  d284fe:	sub    %rbx,%rsi
  d28501:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28507:	cmp    $0x18,%rsi
  d2850b:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28511:	mov    0xc8(%rsp),%rcx
  d28519:	add    %rdx,%rcx
  d2851c:	mov    %rcx,0x188(%rsp)
  d28524:	cmpq   $0x4,(%rsp)
  d28529:	je     d285fd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
  d2852f:	mov    0xe0(%rsp),%rsi
  d28537:	sub    %rbx,%rsi
  d2853a:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28540:	cmp    $0x18,%rsi
  d28544:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2854a:	mov    0xd8(%rsp),%rcx
  d28552:	add    %rdx,%rcx
  d28555:	mov    %rcx,0x190(%rsp)
  d2855d:	cmpq   $0x5,(%rsp)
  d28562:	je     d285fd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
  d28568:	mov    0xf0(%rsp),%rsi
  d28570:	sub    %rbx,%rsi
  d28573:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28579:	cmp    $0x18,%rsi
  d2857d:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28583:	mov    0xe8(%rsp),%rcx
  d2858b:	add    %rdx,%rcx
  d2858e:	mov    %rcx,0x198(%rsp)
  d28596:	cmpq   $0x6,(%rsp)
  d2859b:	je     d285fd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
  d2859d:	mov    0x100(%rsp),%rsi
  d285a5:	sub    %rbx,%rsi
  d285a8:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d285ae:	cmp    $0x18,%rsi
  d285b2:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d285b8:	mov    0xf8(%rsp),%rcx
  d285c0:	add    %rdx,%rcx
  d285c3:	mov    %rcx,0x1a0(%rsp)
  d285cb:	cmpq   $0x7,(%rsp)
  d285d0:	je     d285fd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
  d285d2:	mov    0x110(%rsp),%rsi
  d285da:	sub    %rbx,%rsi
  d285dd:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d285e3:	cmp    $0x18,%rsi
  d285e7:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d285ed:	add    0x108(%rsp),%rdx
  d285f5:	mov    %rdx,0x1a8(%rsp)
  d285fd:	lea    0x10(%rbx),%rax
  d28601:	mov    %rax,0x118(%rsp)
  d28609:	dec    %r12
  d2860c:	incq   0x8(%rsp)
  d28611:	lea    0x1d8(%rsp),%rsi
  d28619:	xor    %edi,%edi
  d2861b:	mov    (%rsi),%rdx
  d2861e:	sub    %rbx,%rdx
  d28621:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28627:	cmp    $0x10,%rdx
  d2862b:	jb     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28631:	cmp    $0x7,%rdi
  d28635:	ja     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2863b:	mov    0x158(%rsp,%rdi,8),%r10
  d28643:	mov    0x148(%rsp,%rdi,8),%r11
  d2864b:	mov    0x150(%rsp,%rdi,8),%r8
  d28653:	vmovdqu (%r8),%ymm4
  d28658:	vmovdqu 0x2(%r8),%ymm6
  d2865e:	mov    0x160(%rsp,%rdi,8),%rdx
  d28666:	mov    0x140(%rsp,%rdi,8),%r15
  d2866e:	vmovdqu 0x6(%r15),%ymm11
  d28674:	vmovdqu 0xa(%r15),%ymm10
  d2867a:	mov    0x168(%rsp,%rdi,8),%r14
  d28682:	mov    0x130(%rsp,%rdi,8),%rcx
  d2868a:	mov    %rbx,%rax
  d2868d:	mov    0x138(%rsp,%rdi,8),%rbx
  d28695:	mov    0x170(%rsp,%rdi,8),%rbp
  d2869d:	vmovdqu 0x8(%rcx),%ymm2
  d286a2:	vmovdqu 0x2(%rbx),%ymm0
  d286a7:	vpaddw 0xe(%r14),%ymm0,%ymm0
  d286ad:	vmovdqu %ymm0,0x1b0(%rsp)
  d286b6:	vmovdqu 0xe(%rbx),%ymm1
  d286bb:	vpaddw 0x2(%r14),%ymm1,%ymm1
  d286c1:	vpunpckhwd %ymm1,%ymm0,%ymm5
  d286c5:	mov    0x10(%rsp),%rcx
  d286ca:	vpmaddwd 0x1e0(%rcx),%ymm5,%ymm13
  d286d2:	vpaddw 0x8(%rbp),%ymm2,%ymm2
  d286d7:	vmovdqu 0x8(%rbx),%ymm5
  d286dc:	mov    %rax,%rbx
  d286df:	vpaddw 0x10(%r8),%ymm4,%ymm4
  d286e5:	vpunpckhwd %ymm4,%ymm2,%ymm7
  d286e9:	vpmaddwd 0x1a0(%rcx),%ymm7,%ymm14
  d286f1:	vpaddw 0x8(%r14),%ymm5,%ymm5
  d286f7:	vmovdqu 0x4(%r11),%ymm7
  d286fd:	vpaddw 0xe(%r8),%ymm6,%ymm6
  d28703:	vpunpckhwd %ymm6,%ymm5,%ymm8
  d28707:	vpmaddwd 0x160(%rcx),%ymm8,%ymm15
  d2870f:	vpaddw 0xc(%r10),%ymm7,%ymm7
  d28715:	vmovdqu 0xc(%r11),%ymm8
  d2871b:	vpaddw 0x4(%r10),%ymm8,%ymm8
  d28721:	vpunpckhwd %ymm8,%ymm7,%ymm9
  d28726:	vpmaddwd 0x120(%rcx),%ymm9,%ymm3
  d2872e:	vpaddw 0xa(%rdx),%ymm11,%ymm9
  d28733:	vmovdqu 0x6(%r11),%ymm11
  d28739:	vpaddw 0x6(%rdx),%ymm10,%ymm10
  d2873e:	vpunpckhwd %ymm10,%ymm9,%ymm12
  d28743:	vpmaddwd 0xe0(%rcx),%ymm12,%ymm0
  d2874b:	vpaddw 0xa(%r10),%ymm11,%ymm11
  d28751:	vmovdqu 0x6(%r10),%ymm12
  d28757:	vpaddw 0xa(%r11),%ymm12,%ymm12
  d2875d:	vpaddd %ymm13,%ymm14,%ymm14
  d28762:	vpunpckhwd %ymm12,%ymm11,%ymm13
  d28767:	vpmaddwd 0xa0(%rcx),%ymm13,%ymm13
  d2876f:	vpaddd %ymm3,%ymm15,%ymm3
  d28773:	vmovdqu 0x8(%r15),%ymm15
  d28779:	vpaddw 0x8(%rdx),%ymm15,%ymm15
  d2877e:	vpaddd %ymm3,%ymm14,%ymm3
  d28782:	vmovdqu 0x4(%r8),%ymm14
  d28788:	vpaddw 0xc(%r8),%ymm14,%ymm14
  d2878e:	vpaddd %ymm0,%ymm13,%ymm0
  d28792:	vpunpckhwd %ymm14,%ymm15,%ymm13
  d28797:	vpmaddwd 0x60(%rcx),%ymm13,%ymm13
  d2879c:	vpaddd %ymm0,%ymm13,%ymm0
  d287a0:	vpaddd %ymm0,%ymm3,%ymm3
  d287a4:	vmovdqu 0x1b0(%rsp),%ymm0
  d287ad:	vpunpcklwd %ymm1,%ymm0,%ymm0
  d287b1:	vpunpcklwd %ymm4,%ymm2,%ymm1
  d287b5:	vpmaddwd 0x1c0(%rcx),%ymm0,%ymm0
  d287bd:	vpmaddwd 0x180(%rcx),%ymm1,%ymm1
  d287c5:	vpaddd %ymm0,%ymm1,%ymm0
  d287c9:	vpunpcklwd %ymm6,%ymm5,%ymm1
  d287cd:	vpmaddwd 0x140(%rcx),%ymm1,%ymm1
  d287d5:	vpunpcklwd %ymm8,%ymm7,%ymm2
  d287da:	vpmaddwd 0x100(%rcx),%ymm2,%ymm2
  d287e2:	vpaddd %ymm2,%ymm1,%ymm1
  d287e6:	vpaddd %ymm1,%ymm0,%ymm0
  d287ea:	vpunpcklwd %ymm10,%ymm9,%ymm1
  d287ef:	vpunpcklwd %ymm12,%ymm11,%ymm2
  d287f4:	vmovdqu 0x6(%r8),%ymm4
  d287fa:	vpunpcklwd %ymm14,%ymm15,%ymm5
  d287ff:	vmovdqu 0x8(%r11),%ymm6
  d28805:	vpaddw 0x8(%r10),%ymm6,%ymm6
  d2880b:	vpaddw 0xa(%r8),%ymm4,%ymm4
  d28811:	vpmaddwd 0xc0(%rcx),%ymm1,%ymm1
  d28819:	vpmaddwd 0x80(%rcx),%ymm2,%ymm2
  d28821:	vpmaddwd 0x40(%rcx),%ymm5,%ymm5
  d28826:	vpaddd %ymm2,%ymm1,%ymm1
  d2882a:	vpaddd %ymm5,%ymm1,%ymm1
  d2882e:	vpunpckhwd %ymm4,%ymm6,%ymm2
  d28832:	vpaddd %ymm1,%ymm0,%ymm0
  d28836:	vpunpcklwd %ymm4,%ymm6,%ymm1
  d2883a:	vpmaddwd (%rcx),%ymm1,%ymm1
  d2883e:	vmovdqu 0x8(%r8),%ymm4
  d28844:	vpunpcklwd -0xce368c(%rip),%ymm4,%ymm5        # 451c0 <anon.641001004215a5507dd026cf93eadf7f.0.llvm.16322531315505051856+0x2e0>
  d2884c:	vpshufb -0xce29b5(%rip),%ymm5,%ymm5        # 45ea0 <anon.641001004215a5507dd026cf93eadf7f.0.llvm.16322531315505051856+0xfc0>
  d28855:	vpmaddwd 0x200(%rcx),%ymm5,%ymm5
  d2885d:	vpaddd %ymm5,%ymm1,%ymm1
  d28861:	vpaddd %ymm1,%ymm0,%ymm0
  d28865:	vpmaddwd 0x20(%rcx),%ymm2,%ymm1
  d2886a:	vpunpckhwd -0xce2572(%rip),%ymm4,%ymm2        # 46300 <anon.641001004215a5507dd026cf93eadf7f.0.llvm.16322531315505051856+0x1420>
  d28872:	vpshufb -0xce3afb(%rip),%ymm2,%ymm2        # 44d80 <anon.b06d5af9046adfc4f8b836ea1c075b06.152.llvm.16901765343427469375+0x20>
  d2887b:	vpmaddwd 0x220(%rcx),%ymm2,%ymm2
  d28883:	vpaddd %ymm2,%ymm1,%ymm1
  d28887:	vpaddd %ymm1,%ymm3,%ymm1
  d2888b:	vpsrad $0x7,%ymm0,%ymm0
  d28890:	vpsrad $0x7,%ymm1,%ymm1
  d28895:	vpackusdw %ymm1,%ymm0,%ymm0
  d2889a:	mov    -0x8(%rsi),%rcx
  d2889e:	vpminuw 0x2f0(%rsp),%ymm0,%ymm0
  d288a8:	vmovdqu %ymm0,(%rcx,%rax,2)
  d288ad:	inc    %rdi
  d288b0:	add    $0x10,%rsi
  d288b4:	cmp    %rdi,(%rsp)
  d288b8:	jne    d2861b <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6db>
  d288be:	mov    0x118(%rsp),%rbx
  d288c6:	test   %r12,%r12
  d288c9:	mov    0x120(%rsp),%r14
  d288d1:	lea    0x558(%rsp),%rax
  d288d9:	jne    d2825d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x31d>
  d288df:	mov    $0x1,%al
  d288e1:	jmp    d27fb0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
  d288e6:	sub    %r11,%rsi
  d288e9:	setb   %cl
  d288ec:	cmp    %r8,%rsi
  d288ef:	setb   %dil
  d288f3:	or     %cl,%dil
  d288f6:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d288fc:	lea    (%rax,%r11,2),%rax
  d28900:	mov    %rax,0x1e0(%rsp)
  d28908:	mov    %r8,0x1e8(%rsp)
  d28910:	cmp    $0x2,%rdx
  d28914:	je     d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
  d2891a:	sub    %r11,%rsi
  d2891d:	setb   %cl
  d28920:	cmp    %r8,%rsi
  d28923:	setb   %dil
  d28927:	or     %cl,%dil
  d2892a:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28930:	lea    (%rax,%r11,2),%rax
  d28934:	mov    %rax,0x1f0(%rsp)
  d2893c:	mov    %r8,0x1f8(%rsp)
  d28944:	cmp    $0x3,%rdx
  d28948:	je     d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
  d2894e:	sub    %r11,%rsi
  d28951:	setb   %cl
  d28954:	cmp    %r8,%rsi
  d28957:	setb   %dil
  d2895b:	or     %cl,%dil
  d2895e:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28964:	lea    (%rax,%r11,2),%rax
  d28968:	mov    %rax,0x200(%rsp)
  d28970:	mov    %r8,0x208(%rsp)
  d28978:	cmp    $0x4,%rdx
  d2897c:	je     d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
  d28982:	mov    %rdx,%rcx
  d28985:	mov    %r9,%rdi
  d28988:	sub    %r11,%rsi
  d2898b:	setb   %dl
  d2898e:	cmp    %r8,%rsi
  d28991:	setb   %r9b
  d28995:	or     %dl,%r9b
  d28998:	jne    d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d2899e:	mov    0x1b0(%rsp),%r11
  d289a6:	lea    (%rax,%r11,2),%r10
  d289aa:	mov    %r10,0x210(%rsp)
  d289b2:	mov    %r8,0x218(%rsp)
  d289ba:	mov    %rcx,%rdx
  d289bd:	cmp    $0x5,%rcx
  d289c1:	mov    %rdi,%r9
  d289c4:	je     d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
  d289ca:	xor    %eax,%eax
  d289cc:	sub    %r11,%rsi
  d289cf:	lea    (%r10,%r11,2),%r10
  d289d3:	mov    $0x0,%edx
  d289d8:	cmovae %r10,%rdx
  d289dc:	test   %rdx,%rdx
  d289df:	sete   %r9b
  d289e3:	cmp    %r8,%rsi
  d289e6:	setb   %r11b
  d289ea:	or     %r9b,%r11b
  d289ed:	jne    d27fb0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
  d289f3:	mov    %rdx,0x220(%rsp)
  d289fb:	mov    %r8,0x228(%rsp)
  d28a03:	mov    %rcx,%rdx
  d28a06:	cmp    $0x6,%rcx
  d28a0a:	mov    %rdi,%r9
  d28a0d:	mov    0x1b0(%rsp),%r11
  d28a15:	je     d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
  d28a1b:	xor    %eax,%eax
  d28a1d:	sub    %r11,%rsi
  d28a20:	lea    (%r10,%r11,2),%r10
  d28a24:	mov    $0x0,%edx
  d28a29:	cmovae %r10,%rdx
  d28a2d:	test   %rdx,%rdx
  d28a30:	sete   %r9b
  d28a34:	cmp    %r8,%rsi
  d28a37:	setb   %r11b
  d28a3b:	or     %r9b,%r11b
  d28a3e:	jne    d27fb0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
  d28a44:	mov    %rdx,0x230(%rsp)
  d28a4c:	mov    %r8,0x238(%rsp)
  d28a54:	mov    %rcx,%rdx
  d28a57:	cmp    $0x7,%rcx
  d28a5b:	mov    %rdi,%r9
  d28a5e:	mov    0x1b0(%rsp),%r11
  d28a66:	je     d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
  d28a6c:	xor    %eax,%eax
  d28a6e:	sub    %r11,%rsi
  d28a71:	lea    (%r10,%r11,2),%rdx
  d28a75:	cmovb  %rax,%rdx
  d28a79:	setae  %al
  d28a7c:	cmp    %r8,%rsi
  d28a7f:	setb   %sil
  d28a83:	test   %rdx,%rdx
  d28a86:	je     d27fae <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
  d28a8c:	and    %sil,%al
  d28a8f:	mov    $0x0,%eax
  d28a94:	jne    d27fb0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
  d28a9a:	mov    %rdx,0x240(%rsp)
  d28aa2:	mov    %r8,0x248(%rsp)
  d28aaa:	mov    %rdi,%r9
  d28aad:	mov    %rcx,%rdx
  d28ab0:	jmp    d281dd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
