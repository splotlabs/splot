import pathlib
import subprocess
import sys
root = pathlib.Path(__file__).resolve().parent
name, binary = sys.argv[1:]
folder = root / name
folder.mkdir(exist_ok=True)
for case, limit in [('DOTA2', 20), ('RitualDance', 16), ('Slides1', 16), ('old_town_cross', 10)]:
    [stream] = (root/'ci-data').glob(case + '*.ivf')
    profile = folder/(case + '.cg')
    if profile.exists() and '\nsummary:' in profile.read_text():
        continue
    subprocess.run(['taskset', '-c', '2', 'valgrind', '--tool=callgrind', '--callgrind-out-file=' + str(profile), '--log-file=' + str(folder/(case+'.cglog')), binary, 'decode', str(stream), '--threads', '1', '--frame-delay', '1', '--limit', str(limit), '--output-format', 'null'], check=True)
