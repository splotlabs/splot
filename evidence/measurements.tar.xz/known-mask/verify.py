"""Check the focused 8- and 10-bit official AVM output oracles."""
from hashlib import sha256
from pathlib import Path
import subprocess

scratch = Path(__file__).resolve().parent
fixtures = scratch.parent / "ci-data"
decoder = scratch / "target/release/splot"
prefixes = ("Noise_Ocean_1920x1080_60fps_qp135_", "RitualDance_")
cases = [
    line.split("\t")
    for line in (fixtures / "simd-cases.tsv").read_text().splitlines()
    if line.startswith(prefixes)
]
assert len(cases) == 2, cases
for name, expected_digest, frames, expected_size in cases:
    command = [
        decoder, "decode", fixtures / name, "--threads", "1",
        "--output-format", "raw", "-o", "-",
    ]
    digest = sha256()
    size = 0
    with subprocess.Popen(command, stdout=subprocess.PIPE) as decode:
        while chunk := decode.stdout.read(1 << 20):
            digest.update(chunk)
            size += len(chunk)
        code = decode.wait()
    actual = digest.hexdigest()
    if (code, size, actual) != (0, int(expected_size), expected_digest):
        raise RuntimeError((name, code, size, actual))
    print(f"PASS {name} {frames} {size} {actual}", flush=True)
