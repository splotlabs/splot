# Supplied compound mask on the existing SIMD route

Base commit `29e001679265816c1e0fed9e09a5e32efe1a2d47`. The patch keeps the supplied-mask callback and row loops in the caller's SIMD scope. It leaves difference-weight mask generation, arithmetic, dispatch, validation, and tails alone. The shared row iterators are also used by the narrow byte mask path. Noise_Ocean checks the effect on that path.

The exact 16-frame RitualDance baseline reports 47,880,506 inclusive Ir in the AVX2 supplied-mask vector scope across 1,858 calls. The callback it invokes reached 219,112 calls and 44,260,624 inclusive Ir in the same trace. The analogous difference-weighted scope reaches 9,003,830 Ir separately and is outside the change.

Run the selected baseline/candidate traces with `python3 qualification-1882/cdef-boundary-ab/compare.py trace known-mask qualification-1882/final-integration/splot.full qualification-1882/known-mask/target/release/splot`. The known-mask directory contains symlinks to existing exact draft traces, so it collects only the two candidate traces. Run full oracle checks with `taskset -c 5 python3 qualification-1882/known-mask/verify.py`. Run the paired wall comparison only after trace and oracle checks succeed.
