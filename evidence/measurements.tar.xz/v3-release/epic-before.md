## Outcome

Ship a portable x86-64 baseline, AVX2, and selectively optimized AVX-512 in one Splot binary/library. Resolve usable capabilities and implementation policy at decoder/session startup, retain concrete backend types through repeated computation, and use direct/inlined SIMD calls. **Performance is the product: no reproducible regression in existing workloads, and no uncontrolled library/code-size expansion.** A large refactor is permitted, not required for its own sake.

This epic operationalizes the startup-only SIMD design discussed with the owner. It is a proposed implementation with mandatory measurement gates, not a claim of proven speedups. The linked tasks are the self-contained coding-agent specification; no chat attachment is required.

## Task checklist and execution order

### A — Prove feasibility before broad refactoring

- [ ] #1883 — Freeze performance baselines, consumer builds, corpus and linked-library size budgets.
- [ ] #1884 — Prove startup-only machine code and the smallest viable specialization surface; record GO/NO-GO.

### B — Static execution without algorithm changes

- [x] #1885 — Sealed backend policies, genuine capability tokens and validated startup selection.
- [x] #1886 — Typed persistent decoder lifetime, strict synchronous entry and Rust/C API compatibility.
- [x] #1887 — Concrete-backend worker execution with preserved scheduling semantics and bounded code size.
- [x] #1888 — Prediction, transform and reconstruction call-graph migration.
- [x] #1889 — Filters, prepared layouts, scratch reuse and output/film-grain migration.

### C — Useful AVX-512 within the byte budget

- [ ] #1890 — Forced AVX-512 end-to-end parity and CPU safety; Auto remains conservative.
- [ ] #1891 — Profile-led AVX-512 improvements with per-kernel and end-to-end speed-versus-bytes evidence.
- [ ] #1892 — Specialization consolidation, shared compact tables and linked-library size qualification.

### D — Regression protection and measured rollout

- [ ] #1893 — Cross-backend correctness, CPU-safety, codegen and performance/size checks.
- [ ] #1894 — Final end-to-end qualification, documentation and evidence-gated Auto rollout.
- [ ] #1934 — Implement portable x86-64 baseline backend and downstream consumer qualification (fulfills #1779).

**Dependency spine:** #1883 → #1884 → #1885 → #1886 → #1887 → (#1888 and #1889) → #1890 → #1891 → #1894. #1892 starts during the proof and remains active throughout; final size acceptance follows the optimized multi-backend implementation. #1893 starts after backend initialization exists and grows with every migration; it must pass before #1894. #1934 depends on #1885, #1887, and #1893, and must pass before #1894. The two primitive-migration tasks can run in parallel once their shared interface is stable.

These are separate linked task issues with parent backlinks and explicit prerequisites. Each task may use multiple small compiling PRs; it is not a requirement for one enormous PR per issue.

## Current source and related work

Planning baseline: [`702bff7fdcda8000e8d2191cab6975b23faa1d05`](https://github.com/splotlabs/splot/commit/702bff7fdcda8000e8d2191cab6975b23faa1d05), checked 2026-11-22. Reconcile actual HEAD before implementing; do not revert to the earlier design snapshot `7d7479e`.

- [AGENTS.md](https://github.com/splotlabs/splot/blob/702bff7fdcda8000e8d2191cab6975b23faa1d05/AGENTS.md) makes both bit depths, every stream/thread count, bit-exactness, minimal dependencies and measured SIMD changes explicit requirements.
- [Build configuration](https://github.com/splotlabs/splot/blob/702bff7fdcda8000e8d2191cab6975b23faa1d05/.cargo/config.toml) uses `x86-64-v3` and `disable_dispatch_avx512`. [Release configuration](https://github.com/splotlabs/splot/blob/702bff7fdcda8000e8d2191cab6975b23faa1d05/Cargo.toml) uses ThinLTO and one codegen unit. Re-read the actual lockfile/toolchain; do not assume upstream-main SIMD APIs.
- [Streaming driver](https://github.com/splotlabs/splot/blob/702bff7fdcda8000e8d2191cab6975b23faa1d05/crates/splot-decode/src/decoder.rs) is already persistent; [row scheduling](https://github.com/splotlabs/splot/blob/702bff7fdcda8000e8d2191cab6975b23faa1d05/crates/splot-parallel/src/rows.rs) currently stores `Arc<dyn FrameWork>`.
- Related: #1779 (downstream consumers do not inherit checkout CPU flags; portable distributable binary) is directly addressed and closed by #1934 within this epic.
- Preserve the compact table representation landed in #1881. Do not duplicate or widen immutable tables for each ISA.

## Non-negotiable acceptance contract

### Correctness and safety

Output remains byte-exact against the frozen baseline and AVM oracle. Preserve all supported routes and sample depths, scheduling/lifetime behavior, resource limits, Rust/C API semantics, and ARM/NEON performance. No fabricated CPU tokens, weaker feature checks, global AVX-512/native distribution flags, new production scalar sample-processing/tail paths, or new unsafe blocks without the existing sign-off process.

### Startup-only ISA selection

The strict path performs no repeated CPU detection, capability-cache reads, runtime ISA discriminator, backend vtable, or ISA-dependent function-pointer call per frame, pass, row, block or kernel. Cached discovery is not zero dispatch. Ordinary semantic stage/mode/bit-depth decisions, bounds checks, direct calls, I/O and synchronization are not claimed to disappear.

Choose concrete `B: Backend` outside the repeated processing lifetime. Hide it behind the existing streaming control handle, not inside repeated computation. Synchronous callers need a typed or scoped/continuation path enclosing the whole processing loop; do not add a thread, queue or input copy merely to avoid a branch. A compatibility facade must describe any remaining outer dispatch honestly. Each worker and non-inlined SIMD boundary needs its own correct target-feature context. Generated machine code, not merely Rust generics or inline annotations, establishes the performance claim.

### No performance regression

Compare each implementation PR against both the frozen pre-epic baseline and its merge base with identical compiler/profile/features/corpus/hardware conditions. Do not accumulate many individually small losses.

**Any statistically credible repeatable slowdown blocks merge/default enablement of the affected change until fixed.** Roughly 0.5% is an investigation trigger consistent with AGENTS.md, not a permitted regression allowance; smaller credible losses also require resolution. Noise/insufficient samples is inconclusive, not pass. Report per-stream/per-depth/per-thread results and uncertainty. A geometric-mean gain cannot hide a losing supported case, and AVX-512 wins cannot compensate for AVX2 or NEON regressions. Agents cannot invent exemptions.

Protect AVX2-only hardware, forced AVX2 on AVX-512 machines, 8-bit, 10-bit, NEON, single-/multithread execution, first-picture/tail latency and shared encoder consumers. Use retired instructions where supported for kernel/single-thread work and alternating wall-time measurements for scheduling changes. Compare a dual-backend branch to an equivalent **same-ISA single-backend control**, separately from AVX2-versus-AVX-512 gains. Automatic AVX-512 requires repeatable useful end-to-end benefit for the validated policy, not merely a fast microkernel or capability bit.

### Explicit library-size and specialization budget

Initial engineering guardrails, **not measured feasibility claims**:

| Artifact/change | Target / review-stop ceiling versus frozen equivalent baseline |
| --- | --- |
| AVX2-only structural refactor | Size-neutral target; stop/investigate above +2% executable code or stripped linked artifact size |
| Dual-backend shipped artifact | Minimize growth; provisional ceiling +15% executable code and +10% stripped artifact size, independently |
| Immutable codec tables | No per-backend duplication or expansion of the compact representation |

#1883 records actual bytes and relevant artifacts, then freezes the budget before broad implementation. Exceeding a ceiling requires a smaller specialization surface or explicit owner approval with speed-versus-bytes evidence. Agents must not relax thresholds, reset the baseline, change the feature set or measure unlike artifacts to make a check pass. These are ceilings, not a spending target.

Measure the C shared library where produced, stripped CLI and minimal linked Rust/C consumers, with section/symbol attribution. Record raw `rlib`/`staticlib` sizes separately: metadata/unlinked archive size is not shipped-code size. Report build time, peak compiler memory, stack/scratch and RSS too. Size reduction is not allowed to introduce a performance regression.

## Architecture and scope

- Start with only two x86 implementation policies. AVX-512 may directly reuse narrower/AVX2 kernels where better; 512-bit vectors everywhere are not the goal.
- Specialize the smallest necessary call graph. Keep syntax parsing, metadata, errors, plane ownership, immutable tables and unrelated orchestration shared. No blanket whole-workspace monomorphization, combinatorial const-generic policies or indiscriminate `inline(always)`.
- Use small inline helpers and measured feature-aware out-of-line kernels for large/recursive computation. A concrete token does not transitively enable target features on every callee.
- Existing task-vtable calls are not CPU-feature checks. Preserve scheduling algorithms and share neutral scheduler mechanics; prove the required typed worker-to-compute boundary without hiding it behind new erased callbacks. Do not land slower or bloated scheduling merely for architectural purity.
- Migrate preparation and consumption together, including restoration lane layouts and scratch. A mechanical `baseline_simd!` replacement is insufficient.
- Decoder execution and shared reconstruction are the implementation focus. Preserve existing encoder/downstream performance and bit-exactness; do not advertise a fully migrated encoder unless its paths were actually audited.
- Retain NEON and explicitly test external consumer selection. #1934 introduces the portable generic x86-64 baseline backend alongside AVX2 and AVX-512 so pre-AVX2 CPUs run safely without SIGILL, without slowing existing supported targets.

## Required PR evidence and stopping rules

No broad refactor before #1883 and #1884 pass. Separate mechanical migration, scheduler representation changes and algorithmic widening. Each PR links its task and this epic and includes exact SHAs/commands; corpus hashes; CPU/OS/toolchain/build flags; correctness results; per-case throughput/latency/instruction evidence with repeat methodology; artifact/section byte deltas; relevant assembly; and unavailable hardware marked untested.

Use existing tests, benchmarks and `cargo xtask ci`; extend minimally instead of adding a new reporting framework. Follow current AGENTS.md feature/dependency/concurrency/documentation rules. Failed experiments may be reported and discarded. Do not land regressions with a promise to optimize later, weaken safety checks, or call compile-only hardware coverage a performance pass.

## Epic completion

- [ ] All linked-task acceptance criteria and measured GO/NO-GO gates pass.
- [ ] Claimed strict paths show startup-only ISA selection in optimized final artifacts.
- [ ] No confirmed performance regression on the qualification matrix, including downstream/encoder consumers.
- [ ] Useful AVX-512 end-to-end improvement is demonstrated before automatic selection for its validated policy.
- [ ] Linked-artifact size budgets and compact-table sharing pass.
- [ ] Rust/C compatibility, CPU safety, both bit depths, NEON and lifecycle/concurrency checks pass.
- [ ] Documentation states exact CPU/backend guarantees, compatibility-path costs, measurements and remaining hardware gaps; #1779 is fully resolved, verified on pre-AVX2 targets, and closed.

## Coding-agent starting instruction

Start with #1883, then #1884. Read this epic, the task and current AGENTS.md; inspect actual HEAD/lockfile/toolchain and preserve existing work. Prove code generation and freeze measurements before propagating backend types. Optimize for real throughput/latency and bounded linked bytes, not abstract dispatch purity. Proceed through dependencies in small reviewable changes; attach actual evidence and leave unverified acceptance criteria unchecked.

## Implementation references

Use the exact source resolved by Cargo.lock. The earlier design reviewed [Fearless SIMD 1.2.0 target-feature bridge](https://github.com/linebender/fearless_simd/blob/fearless_simd-v1.2.0/fearless_simd/src/kernel_macros.rs) and [manual inlining guidance](https://github.com/linebender/fearless_simd/blob/fearless_simd-v1.2.0/fearless_simd/MANUAL_INLINING.md). Verify actual APIs/expansions rather than newer examples. Generic specialization and compiler inlining are mechanisms to inspect, not guarantees of a speedup.

