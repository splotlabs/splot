# AVX-512 scaled film-grain noise

Feature AV2-5.14-FILM-GRAIN. Experiment `bf2d4a4e` is based on `d171d824`. Its only production boundary is the existing `apply_film_grain_into_with`: the output layer must pass the actual startup-selected backend, including in retained-picture film grain. The release pipeline integration is tracked separately.

Main's film-grain entry took the narrow token. The operation with wide arithmetic here is adding a complete 32-sample scaled-noise chunk. It uses one `i16x32` operation group or widens it to `i32x16` halves for exact 10-bit products. AVX2 still computes two 16-word vectors. The LUT, template, stripe, and overlap computation keep their earlier narrow token. The SIMD scope changes once for an eligible row. A row shorter than 32 samples or a frame above 10 bits stays on the existing path.

The prior #1891 experiment `02c20b54` used 256-bit VNNI for Wiener luma. Its Xeon 6975P-C timings were +0.023% aggregate, with a CLI size increase of 168,064 bytes, and it was dropped. [Experiment record](https://github.com/splotlabs/splot/issues/1891#issuecomment-7159816019).

The rendered 16-frame grained Noise_Ocean profile contained 236,390,400 self instructions in the AVX2 noise callback. This ranks the candidate and does not estimate speedup.

With the release's AVX-512 dispatch enabled, a native AVX-512 runner should collect:

- `cargo test --release --locked -p splot-recon --lib film_grain::tests::wide_noise_matches_scalar_at_both_depths`.
- `taskset -c <isolated-core> cargo test --release --locked -p splot-recon --lib film_grain::tests::measure_wide_grain_noise_rows -- --ignored --nocapture`.
- Raw output for the frozen 8-bit `Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f.ivf` (expected SHA-256 `06b6a20fda225a8796fa28cfebcc9527845eaedc5908b3829284d3dfe9f872fd`) and the repository three-frame 10-bit `syn-3frame-filmgrain-inter-64x64-10bit.ivf` (expected `e03fa2fe0bd341f21282ede12d527aea2066d00ab9603728a3acb31836f54b5b`), under Auto and both forced policies.
- One-binary native AVX2 vs AVX-512 rendered-grain decode timing. Also compare candidate forced AVX2 against the v3 control and measure linked sections, largest symbols, and stack use. Verify execution of a row worker with real ZMM instructions before attributing an end-to-end difference to width.
