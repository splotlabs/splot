
<WORKTREES>/qualification-1882/final-integration/splot.full:     file format elf64-x86-64


Disassembly of section .text:

000000000042fb10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_>:
  42fb10:	push   rbp
  42fb11:	push   r15
  42fb13:	push   r14
  42fb15:	push   r13
  42fb17:	push   r12
  42fb19:	push   rbx
  42fb1a:	sub    rsp,0x18
  42fb1e:	movabs rax,0x7fffffffffffffff
  42fb28:	mov    QWORD PTR [rsp-0x30],rax
  42fb2d:	mov    QWORD PTR [rsp-0x78],rsi
  42fb32:	mov    rax,QWORD PTR [rsi+0x130]
  42fb39:	mov    QWORD PTR [rsp-0x28],rax
  42fb3e:	mov    rax,QWORD PTR [rdi+0x10]
  42fb42:	sub    rax,QWORD PTR [rdx+0x30]
  42fb46:	jb     42fb68 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x58>
  42fb48:	imul   rax,QWORD PTR [rdx+0x58]
  42fb4d:	mov    r8,QWORD PTR [rdx+0x28]
  42fb51:	cmp    rax,r8
  42fb54:	jae    42fb68 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x58>
  42fb56:	add    rax,QWORD PTR [rdi+0x18]
  42fb5a:	imul   r8,QWORD PTR [rsp-0x28]
  42fb60:	add    r8,rax
  42fb63:	mov    QWORD PTR [rsp-0x30],r8
  42fb68:	mov    r11,QWORD PTR [rdi+0x8]
  42fb6c:	test   r11,r11
  42fb6f:	mov    r8,QWORD PTR [rsp-0x78]
  42fb74:	je     42ff39 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x429>
  42fb7a:	mov    rbx,QWORD PTR [rdi]
  42fb7d:	mov    rax,QWORD PTR [rdi+0x20]
  42fb81:	mov    QWORD PTR [rsp-0x8],rax
  42fb86:	mov    r12,QWORD PTR [rdx+0x28]
  42fb8a:	mov    rax,QWORD PTR [rcx]
  42fb8d:	mov    QWORD PTR [rsp-0x70],rax
  42fb92:	mov    rax,QWORD PTR [rcx+0x8]
  42fb96:	mov    QWORD PTR [rsp+0x10],rax
  42fb9b:	mov    eax,DWORD PTR [rdx+0x68]
  42fb9e:	and    eax,0x3f
  42fba1:	mov    QWORD PTR [rsp+0x8],rax
  42fba6:	movzx  eax,BYTE PTR [rdx+0x6c]
  42fbaa:	mov    BYTE PTR [rsp-0x79],al
  42fbae:	mov    rax,QWORD PTR [rdx+0x18]
  42fbb2:	mov    QWORD PTR [rsp-0x40],rax
  42fbb7:	mov    rax,QWORD PTR [rdx+0x10]
  42fbbb:	mov    QWORD PTR [rsp-0x48],rax
  42fbc0:	mov    rax,QWORD PTR [rdx]
  42fbc3:	mov    QWORD PTR [rsp-0x50],rax
  42fbc8:	mov    rax,QWORD PTR [rdx+0x8]
  42fbcc:	mov    QWORD PTR [rsp-0x38],rax
  42fbd1:	mov    rax,QWORD PTR [rdx+0x20]
  42fbd5:	mov    QWORD PTR [rsp],rax
  42fbd9:	mov    QWORD PTR [rsp-0x20],r12
  42fbde:	jmp    42fc1d <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x10d>
  42fbe0:	mov    BYTE PTR [rax+0xd],cl
  42fbe3:	xor    edx,edx
  42fbe5:	mov    dil,0x1
  42fbe8:	mov    rcx,QWORD PTR [rsp-0x60]
  42fbed:	shl    dil,cl
  42fbf0:	mov    rsi,QWORD PTR [rsp-0x58]
  42fbf5:	shr    rsi,0x10
  42fbf9:	mov    DWORD PTR [rax+rcx*4],esi
  42fbfc:	or     dil,dl
  42fbff:	mov    BYTE PTR [rax+0xc],dil
  42fc03:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  42fc10:	lea    rax,[r11-0x1]
  42fc14:	and    r11,rax
  42fc17:	je     42ff39 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x429>
  42fc1d:	tzcnt  r15,r11
  42fc22:	movzx  r10d,BYTE PTR [rbx+r15*1+0xc00]
  42fc2b:	cmp    r10d,0x8
  42fc2f:	ja     42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fc31:	shl    r10d,0x5
  42fc35:	add    r10,r8
  42fc38:	movzx  eax,BYTE PTR [rbx+r15*1+0xc40]
  42fc41:	movzx  r9d,BYTE PTR [r10]
  42fc45:	mov    ebp,eax
  42fc47:	and    bpl,0xa
  42fc4b:	cmp    bpl,0xa
  42fc4f:	jne    42fc69 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x159>
  42fc51:	test   r9b,r9b
  42fc54:	je     42fc69 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x159>
  42fc56:	mov    rcx,QWORD PTR [r10+0x8]
  42fc5a:	imul   rcx,r12
  42fc5e:	mov    r14d,DWORD PTR [rbx+r15*4+0xb00]
  42fc66:	add    r14,rcx
  42fc69:	test   al,0x4
  42fc6b:	je     42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fc6d:	mov    ecx,DWORD PTR [rbx+r15*4+0x900]
  42fc75:	cmp    QWORD PTR [rsp+0x10],rcx
  42fc7a:	jbe    42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fc7c:	mov    edx,DWORD PTR [rbx+r15*4+0x300]
  42fc84:	mov    QWORD PTR [rsp-0x18],rdx
  42fc89:	mov    esi,DWORD PTR [rbx+r15*4+0x400]
  42fc91:	mov    rdx,QWORD PTR [rsp-0x70]
  42fc96:	cmp    BYTE PTR [rdx+rcx*8+0x6],0x0
  42fc9b:	je     42fcc1 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x1b1>
  42fc9d:	cmp    BYTE PTR [r10+0x1b],0x1
  42fca2:	jne    42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fca8:	mov    rdx,QWORD PTR [rsp-0x70]
  42fcad:	movsx  r13d,WORD PTR [rdx+rcx*8]
  42fcb2:	mov    edx,DWORD PTR [r10+0x10]
  42fcb6:	cmp    edx,r13d
  42fcb9:	je     42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fcbf:	jmp    42fcc5 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x1b5>
  42fcc1:	mov    edx,DWORD PTR [r10+0x10]
  42fcc5:	mov    rdi,QWORD PTR [rsp-0x18]
  42fcca:	mov    r13d,edi
  42fccd:	neg    r13d
  42fcd0:	mov    r12d,esi
  42fcd3:	neg    r12d
  42fcd6:	cmp    BYTE PTR [r10+0x1a],0x0
  42fcdb:	cmove  r13d,edi
  42fcdf:	cmove  r12d,esi
  42fce3:	shl    r12d,0x10
  42fce7:	movzx  r13d,r13w
  42fceb:	or     r13d,r12d
  42fcee:	mov    r12,QWORD PTR [rsp-0x20]
  42fcf3:	mov    r8,QWORD PTR [rsp-0x78]
  42fcf8:	mov    rdi,QWORD PTR [rsp-0x70]
  42fcfd:	mov    WORD PTR [rdi+rcx*8],dx
  42fd01:	mov    DWORD PTR [rdi+rcx*8+0x2],r13d
  42fd06:	mov    BYTE PTR [rdi+rcx*8+0x6],0x1
  42fd0b:	test   al,0x10
  42fd0d:	je     42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fd13:	mov    eax,DWORD PTR [rbx+r15*4+0xa00]
  42fd1b:	cmp    r12,rax
  42fd1e:	jbe    42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fd24:	mov    ecx,DWORD PTR [rbx+r15*4+0x500]
  42fd2c:	mov    DWORD PTR [rsp-0x68],ecx
  42fd30:	mov    ecx,DWORD PTR [rbx+r15*4+0x600]
  42fd38:	mov    DWORD PTR [rsp-0x64],ecx
  42fd3c:	mov    QWORD PTR [rsp-0x10],rax
  42fd41:	movsxd rdi,DWORD PTR [rbx+r15*4+0x800]
  42fd49:	mov    r13d,DWORD PTR [rbx+r15*4+0x700]
  42fd51:	mov    r12,rdi
  42fd54:	mov    rcx,QWORD PTR [rsp+0x8]
  42fd59:	shr    r12,cl
  42fd5c:	mov    rax,r12
  42fd5f:	movabs rcx,0xaaaaaaaaaaaaaaab
  42fd69:	mul    rcx
  42fd6c:	shr    rdx,1
  42fd6f:	lea    rax,[rdx+rdx*2]
  42fd73:	sub    r12,rax
  42fd76:	mov    QWORD PTR [rsp-0x60],r12
  42fd7b:	mov    eax,r13d
  42fd7e:	or     eax,edi
  42fd80:	shl    rdi,0x20
  42fd84:	shl    r13,0x10
  42fd88:	add    r13,rdi
  42fd8b:	mov    rdi,QWORD PTR [rsp-0x10]
  42fd90:	mov    QWORD PTR [rsp-0x58],r13
  42fd95:	cmp    eax,0xffff
  42fd9a:	ja     42fdf3 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x2e3>
  42fd9c:	imul   r15,QWORD PTR [rsp-0x8]
  42fda2:	add    r15,QWORD PTR [rsp-0x30]
  42fda7:	cmp    r15,QWORD PTR [rsp-0x40]
  42fdac:	jae    42fdf3 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x2e3>
  42fdae:	shl    r15,0x4
  42fdb2:	mov    r12,QWORD PTR [rsp-0x48]
  42fdb7:	lea    rdx,[r12+r15*1]
  42fdbb:	movzx  ecx,BYTE PTR [rsp-0x79]
  42fdc0:	cmp    BYTE PTR [r12+r15*1+0xd],cl
  42fdc5:	jne    42fdce <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x2be>
  42fdc7:	movzx  r13d,BYTE PTR [rdx+0xc]
  42fdcc:	jmp    42fdd4 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x2c4>
  42fdce:	mov    BYTE PTR [rdx+0xd],cl
  42fdd1:	xor    r13d,r13d
  42fdd4:	mov    r12,QWORD PTR [rsp-0x58]
  42fdd9:	mov    r15b,0x1
  42fddc:	mov    rcx,QWORD PTR [rsp-0x60]
  42fde1:	shl    r15b,cl
  42fde4:	shr    r12,0x10
  42fde8:	mov    DWORD PTR [rdx+rcx*4],r12d
  42fdec:	or     r15b,r13b
  42fdef:	mov    BYTE PTR [rdx+0xc],r15b
  42fdf3:	imul   rdi,QWORD PTR [rsp]
  42fdf8:	mov    rcx,QWORD PTR [rsp-0x28]
  42fdfd:	add    rcx,rdi
  42fe00:	cmp    rcx,QWORD PTR [rsp-0x38]
  42fe05:	jae    42fe5e <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x34e>
  42fe07:	mov    r12d,DWORD PTR [rsp-0x64]
  42fe0c:	neg    r12d
  42fe0f:	cmp    r12d,0xfffff802
  42fe16:	mov    edx,0xfffff801
  42fe1b:	cmovl  r12d,edx
  42fe1f:	cmp    r12d,0x7ff
  42fe26:	mov    r15d,0x7ff
  42fe2c:	cmovge r12d,r15d
  42fe30:	mov    r13d,DWORD PTR [rsp-0x68]
  42fe35:	neg    r13d
  42fe38:	cmp    r13d,0xfffff802
  42fe3f:	cmovl  r13d,edx
  42fe43:	cmp    r13d,0x7ff
  42fe4a:	cmovge r13d,r15d
  42fe4e:	mov    rdx,QWORD PTR [rsp-0x50]
  42fe53:	mov    WORD PTR [rdx+rcx*4],r13w
  42fe58:	mov    WORD PTR [rdx+rcx*4+0x2],r12w
  42fe5e:	test   r9b,r9b
  42fe61:	mov    r12,QWORD PTR [rsp-0x20]
  42fe66:	je     42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fe6c:	add    rdi,QWORD PTR [r10+0x8]
  42fe70:	cmp    rdi,QWORD PTR [rsp-0x38]
  42fe75:	jae    42fef3 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x3e3>
  42fe77:	mov    ecx,DWORD PTR [r10+0x14]
  42fe7b:	imul   esi,ecx
  42fe7e:	mov    edx,esi
  42fe80:	sar    esi,0x1f
  42fe83:	add    edx,esi
  42fe85:	add    edx,0x2000
  42fe8b:	sar    edx,0xe
  42fe8e:	cmp    edx,0xfffff802
  42fe94:	mov    r8d,0xfffff801
  42fe9a:	cmovl  edx,r8d
  42fe9e:	cmp    edx,0x7ff
  42fea4:	mov    r9d,0x7ff
  42feaa:	cmovge edx,r9d
  42feae:	mov    r10,QWORD PTR [rsp-0x18]
  42feb3:	imul   r10d,ecx
  42feb7:	mov    ecx,r10d
  42feba:	sar    r10d,0x1f
  42febe:	add    ecx,r10d
  42fec1:	add    ecx,0x2000
  42fec7:	sar    ecx,0xe
  42feca:	cmp    ecx,0xfffff802
  42fed0:	cmovl  ecx,r8d
  42fed4:	cmp    ecx,0x7ff
  42feda:	cmovge ecx,r9d
  42fede:	mov    r8,QWORD PTR [rsp-0x50]
  42fee3:	mov    WORD PTR [r8+rdi*4],cx
  42fee8:	mov    WORD PTR [r8+rdi*4+0x2],dx
  42feee:	mov    r8,QWORD PTR [rsp-0x78]
  42fef3:	cmp    bpl,0xa
  42fef7:	jne    42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42fefd:	cmp    eax,0xffff
  42ff02:	ja     42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42ff08:	cmp    r14,QWORD PTR [rsp-0x40]
  42ff0d:	jae    42fc10 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x100>
  42ff13:	shl    r14,0x4
  42ff17:	mov    rdx,QWORD PTR [rsp-0x48]
  42ff1c:	lea    rax,[rdx+r14*1]
  42ff20:	movzx  ecx,BYTE PTR [rsp-0x79]
  42ff25:	cmp    BYTE PTR [rdx+r14*1+0xd],cl
  42ff2a:	jne    42fbe0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0xd0>
  42ff30:	movzx  edx,BYTE PTR [rax+0xc]
  42ff34:	jmp    42fbe5 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0xd5>
  42ff39:	add    rsp,0x18
  42ff3d:	pop    rbx
  42ff3e:	pop    r12
  42ff40:	pop    r13
  42ff42:	pop    r14
  42ff44:	pop    r15
  42ff46:	pop    rbp
  42ff47:	ret
