
<WORKTREES>/qualification-1882/temporal-scan/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

00000000008fa330 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_>:
  8fa330:	push   rbp
  8fa331:	mov    rbp,rsp
  8fa334:	push   r15
  8fa336:	push   r14
  8fa338:	push   r13
  8fa33a:	push   r12
  8fa33c:	push   rbx
  8fa33d:	and    rsp,0xffffffffffffffc0
  8fa341:	sub    rsp,0x900
  8fa348:	mov    r15,rdi
  8fa34b:	mov    r12,QWORD PTR [rdi+0x8]
  8fa34f:	mov    rax,QWORD PTR [rdi+0x10]
  8fa353:	mov    rdx,QWORD PTR [rax]
  8fa356:	lea    rdi,[rsp+0x360]
  8fa35e:	mov    rsi,r12
  8fa361:	call   b8ac50 <_RNvMs_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanINtB4_12TargetTablesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2E3newBe_>
  8fa366:	mov    rdx,QWORD PTR [r15+0x28]
  8fa36a:	mov    r13,QWORD PTR [rdx]
  8fa36d:	test   r13,r13
  8fa370:	je     8fd8fa <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35ca>
  8fa376:	mov    r10,QWORD PTR [r15+0x38]
  8fa37a:	mov    r9,QWORD PTR [r15+0x40]
  8fa37e:	mov    eax,DWORD PTR [rdx+0x8]
  8fa381:	mov    DWORD PTR [rsp+0x8c],eax
  8fa388:	mov    eax,DWORD PTR [rdx+0xc]
  8fa38b:	mov    DWORD PTR [rsp+0x88],eax
  8fa392:	movsxd rax,DWORD PTR [rdx+0x10]
  8fa396:	mov    QWORD PTR [rsp+0x1b8],rax
  8fa39e:	mov    r8d,DWORD PTR [rdx+0x14]
  8fa3a2:	mov    edi,DWORD PTR [rdx+0x18]
  8fa3a5:	mov    esi,DWORD PTR [rdx+0x1c]
  8fa3a8:	mov    ecx,DWORD PTR [rdx+0x20]
  8fa3ab:	mov    eax,DWORD PTR [rdx+0x24]
  8fa3ae:	mov    DWORD PTR [rsp+0x90],eax
  8fa3b5:	xor    eax,eax
  8fa3b7:	mov    QWORD PTR [rsp+0x28],r10
  8fa3bc:	sub    r9,r10
  8fa3bf:	cmovae rax,r9
  8fa3c3:	mov    r9,rax
  8fa3c6:	or     r9,r13
  8fa3c9:	shr    r9,0x20
  8fa3cd:	mov    r9d,DWORD PTR [rdx+0x28]
  8fa3d1:	mov    DWORD PTR [rsp+0x84],r9d
  8fa3d9:	vmovq  xmm1,QWORD PTR [rdx+0x2c]
  8fa3de:	vmovq  xmm0,QWORD PTR [rdx+0x40]
  8fa3e3:	vpinsrd xmm0,xmm0,DWORD PTR [rdx+0x48],0x2
  8fa3ea:	vmovq  xmm2,QWORD PTR [rdx+0x34]
  8fa3ef:	mov    r9d,DWORD PTR [rdx+0x3c]
  8fa3f3:	mov    DWORD PTR [rsp+0x94],r9d
  8fa3fb:	movzx  edx,BYTE PTR [rdx+0x4c]
  8fa3ff:	mov    QWORD PTR [rsp+0x1a0],rdx
  8fa407:	mov    rdx,QWORD PTR [r15+0x18]
  8fa40b:	mov    QWORD PTR [rsp+0x10],rdx
  8fa410:	mov    rdx,QWORD PTR [r15+0x20]
  8fa414:	mov    QWORD PTR [rsp+0x18],rdx
  8fa419:	mov    r14,QWORD PTR [r15+0x48]
  8fa41d:	mov    rdx,QWORD PTR [r15+0x30]
  8fa421:	mov    QWORD PTR [rsp+0x68],rdx
  8fa426:	mov    r9,QWORD PTR [r12+0x138]
  8fa42e:	je     8fa437 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x107>
  8fa430:	xor    edx,edx
  8fa432:	div    r13
  8fa435:	jmp    8fa43c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x10c>
  8fa437:	xor    edx,edx
  8fa439:	div    r13d
  8fa43c:	xor    r10d,r10d
  8fa43f:	test   rdx,rdx
  8fa442:	setne  r10b
  8fa446:	add    r10,rax
  8fa449:	mov    QWORD PTR [rsp+0x1b0],r10
  8fa451:	je     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fa457:	mov    rax,r13
  8fa45a:	shl    rax,0x6
  8fa45e:	mov    QWORD PTR [rsp+0x98],rax
  8fa466:	je     8fd913 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35e3>
  8fa46c:	and    r9d,0x1
  8fa470:	lea    rdx,[r13*2+0x0]
  8fa478:	mov    rax,QWORD PTR [rsp+0x1a0]
  8fa480:	lea    eax,[rax*8+0x0]
  8fa487:	or     al,0x4
  8fa489:	mov    r10,QWORD PTR [rsp+0x10]
  8fa48e:	lea    r15,[r10+0xc00]
  8fa495:	lea    r11,[r10+0x300]
  8fa49c:	mov    QWORD PTR [rsp+0x20],r11
  8fa4a1:	add    r10,0x900
  8fa4a8:	mov    QWORD PTR [rsp+0x2a0],r10
  8fa4b0:	lea    r9,[r9+r9*2]
  8fa4b4:	mov    QWORD PTR [rsp+0xc8],r9
  8fa4bc:	lea    rdx,[rdx+rdx*2]
  8fa4c0:	mov    QWORD PTR [rsp+0xd0],rdx
  8fa4c8:	vmovd  xmm3,r13d
  8fa4cd:	vpbroadcastd ymm3,xmm3
  8fa4d2:	vpmulld xmm4,xmm3,XMMWORD PTR [rip+0xffffffffff71c8d5]        # 16db0 <anon.245362c1692d2350ec60721dad848e3d.1615.llvm.5944606840923237273+0x3c0>
  8fa4db:	vpmulld xmm5,xmm3,XMMWORD PTR [rip+0xffffffffff719afc]        # 13fe0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x72e>
  8fa4e4:	vpmulld ymm6,ymm3,YMMWORD PTR [rip+0xffffffffff71ff13]        # 1a400 <anon.db13f839740d960fd97bc530122b4c99.104.llvm.5594421697515501092+0x4b8>
  8fa4ed:	not    r8d
  8fa4f0:	vmovd  xmm7,r8d
  8fa4f5:	vpxor  xmm8,xmm8,xmm8
  8fa4fa:	vpblendd xmm3,xmm8,xmm3,0x2
  8fa500:	vpermq ymm4,ymm4,0xd0
  8fa506:	vpblendd ymm3,ymm4,ymm3,0x3
  8fa50c:	vpbroadcastq ymm4,xmm5
  8fa511:	vpblendd ymm4,ymm3,ymm4,0xc0
  8fa517:	vmovd  xmm3,eax
  8fa51b:	vpbroadcastb xmm3,xmm3
  8fa520:	vmovdqa XMMWORD PTR [rsp+0x270],xmm3
  8fa529:	mov    rax,QWORD PTR [rsp+0x1b8]
  8fa531:	not    eax
  8fa533:	vmovd  xmm3,eax
  8fa537:	vmovdqa XMMWORD PTR [rsp+0x3f0],xmm7
  8fa540:	vmovdqa XMMWORD PTR [rsp+0x350],xmm3
  8fa549:	vpand  xmm3,xmm7,xmm3
  8fa54d:	vpbroadcastd ymm3,xmm3
  8fa552:	vmovdqa YMMWORD PTR [rsp+0x520],ymm3
  8fa55b:	vmovss xmm3,DWORD PTR [rsp+0x8c]
  8fa564:	vbroadcastss ymm3,xmm3
  8fa569:	vmovaps YMMWORD PTR [rsp+0x500],ymm3
  8fa572:	vmovss xmm3,DWORD PTR [rsp+0x88]
  8fa57b:	vbroadcastss ymm3,xmm3
  8fa580:	vmovaps YMMWORD PTR [rsp+0x4e0],ymm3
  8fa589:	vmovd  xmm3,edi
  8fa58d:	vpbroadcastd ymm5,xmm3
  8fa592:	vmovd  xmm3,esi
  8fa596:	vpbroadcastd ymm3,xmm3
  8fa59b:	vmovdqa YMMWORD PTR [rsp+0x4c0],ymm3
  8fa5a4:	vpshufd xmm3,xmm2,0x55
  8fa5a9:	vpbroadcastd ymm3,xmm3
  8fa5ae:	vmovdqa YMMWORD PTR [rsp+0x460],ymm3
  8fa5b7:	vmovd  xmm3,ecx
  8fa5bb:	vpbroadcastd ymm3,xmm3
  8fa5c0:	vmovdqa YMMWORD PTR [rsp+0x3c0],ymm3
  8fa5c9:	vmovd  DWORD PTR [rsp+0xf4],xmm2
  8fa5d2:	vmovss xmm2,DWORD PTR [rsp+0x90]
  8fa5db:	vbroadcastss ymm2,xmm2
  8fa5e0:	vmovaps YMMWORD PTR [rsp+0x4a0],ymm2
  8fa5e9:	vmovd  DWORD PTR [rsp+0xf0],xmm1
  8fa5f2:	vpshufd xmm2,xmm1,0x55
  8fa5f7:	vpbroadcastd ymm2,xmm2
  8fa5fc:	vmovdqa YMMWORD PTR [rsp+0x7e0],ymm2
  8fa605:	vmovd  xmm2,DWORD PTR [rsp+0x84]
  8fa60e:	vpbroadcastd ymm2,xmm2
  8fa613:	vmovdqa YMMWORD PTR [rsp+0x7c0],ymm2
  8fa61c:	vmovq  rax,xmm1
  8fa621:	vpbroadcastd ymm1,xmm1
  8fa626:	vmovdqa YMMWORD PTR [rsp+0x7a0],ymm1
  8fa62f:	vpshufd xmm1,xmm0,0x55
  8fa634:	vpbroadcastd ymm1,xmm1
  8fa639:	vmovdqa YMMWORD PTR [rsp+0x780],ymm1
  8fa642:	vpbroadcastd ymm1,xmm0
  8fa647:	vmovdqa YMMWORD PTR [rsp+0x760],ymm1
  8fa650:	vpshufd xmm0,xmm0,0xee
  8fa655:	vpbroadcastd ymm0,xmm0
  8fa65a:	vmovdqa YMMWORD PTR [rsp+0x740],ymm0
  8fa663:	shr    rax,0x20
  8fa667:	vmovd  xmm0,eax
  8fa66b:	vpbroadcastd ymm0,xmm0
  8fa670:	vmovdqa YMMWORD PTR [rsp+0x6c0],ymm0
  8fa679:	mov    eax,r13d
  8fa67c:	shl    eax,0x6
  8fa67f:	mov    DWORD PTR [rsp+0xf8],eax
  8fa686:	mov    eax,r13d
  8fa689:	shl    eax,0x4
  8fa68c:	mov    DWORD PTR [rsp+0xfc],eax
  8fa693:	mov    rax,r13
  8fa696:	shl    rax,0x4
  8fa69a:	mov    QWORD PTR [rsp+0x2b8],rax
  8fa6a2:	neg    rax
  8fa6a5:	mov    QWORD PTR [rsp+0x288],rax
  8fa6ad:	vmovdqa YMMWORD PTR [rsp+0x540],ymm4
  8fa6b6:	vpaddd ymm0,ymm4,ymm5
  8fa6ba:	vmovdqa YMMWORD PTR [rsp+0x700],ymm0
  8fa6c3:	vmovdqa YMMWORD PTR [rsp+0x560],ymm6
  8fa6cc:	vmovdqa YMMWORD PTR [rsp+0x800],ymm5
  8fa6d5:	vpaddd ymm0,ymm6,ymm5
  8fa6d9:	vmovdqa YMMWORD PTR [rsp+0x6e0],ymm0
  8fa6e2:	mov    QWORD PTR [rsp+0x30],r13
  8fa6e7:	mov    QWORD PTR [rsp+0x38],r12
  8fa6ec:	mov    QWORD PTR [rsp+0x8],r14
  8fa6f1:	jmp    8fa713 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3e3>
  8fa6f3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8fa700:	add    QWORD PTR [rsp+0x28],r13
  8fa705:	dec    QWORD PTR [rsp+0x1b0]
  8fa70d:	je     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fa713:	mov    rax,QWORD PTR [rsp+0x28]
  8fa718:	mov    rcx,QWORD PTR [rsp+0x18]
  8fa71d:	sub    rax,QWORD PTR [rcx+0xe0]
  8fa724:	jb     8fa700 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3d0>
  8fa726:	mov    rcx,QWORD PTR [rsp+0x18]
  8fa72b:	mov    r8,QWORD PTR [rcx+0xc8]
  8fa732:	mul    r8
  8fa735:	jo     8fa700 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3d0>
  8fa737:	mov    rcx,rax
  8fa73a:	add    rcx,r8
  8fa73d:	jb     8fa700 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3d0>
  8fa73f:	mov    rdx,QWORD PTR [rsp+0x18]
  8fa744:	mov    rdx,QWORD PTR [rdx+0xa8]
  8fa74b:	cmp    rdx,0x2
  8fa74f:	je     8fa76f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x43f>
  8fa751:	cmp    edx,0x1
  8fa754:	jne    8fa78d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x45d>
  8fa756:	mov    rdx,QWORD PTR [rsp+0x18]
  8fa75b:	mov    rsi,QWORD PTR [rdx+0xb0]
  8fa762:	mov    rdx,QWORD PTR [rsi+0x18]
  8fa766:	mov    rsi,QWORD PTR [rsi+0x20]
  8fa76a:	jmp    8fa7f1 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x4c1>
  8fa76f:	mov    rdx,QWORD PTR [rsp+0x18]
  8fa774:	mov    rsi,QWORD PTR [rdx+0xc0]
  8fa77b:	cmp    BYTE PTR [rsi+0x10],0x0
  8fa77f:	je     8fa7a2 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x472>
  8fa781:	mov    r11,r8
  8fa784:	mov    edx,0x1
  8fa789:	xor    esi,esi
  8fa78b:	jmp    8fa7ad <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x47d>
  8fa78d:	mov    rsi,QWORD PTR [rsp+0x18]
  8fa792:	mov    rdx,QWORD PTR [rsi+0xb8]
  8fa799:	mov    rsi,QWORD PTR [rsi+0xc0]
  8fa7a0:	jmp    8fa7f1 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x4c1>
  8fa7a2:	mov    r11,r8
  8fa7a5:	mov    rdx,QWORD PTR [rsi+0x20]
  8fa7a9:	mov    rsi,QWORD PTR [rsi+0x28]
  8fa7ad:	mov    r8,QWORD PTR [rsp+0x18]
  8fa7b2:	mov    rdi,QWORD PTR [r8+0xb0]
  8fa7b9:	mov    r8,QWORD PTR [r8+0xb8]
  8fa7c0:	mov    r9,r8
  8fa7c3:	sub    r9,rdi
  8fa7c6:	setb   r10b
  8fa7ca:	cmp    r8,rsi
  8fa7cd:	seta   sil
  8fa7d1:	or     sil,r10b
  8fa7d4:	lea    rsi,[rdi+rdi*2]
  8fa7d8:	lea    rdx,[rdx+rsi*2]
  8fa7dc:	mov    esi,0x0
  8fa7e1:	cmove  rsi,r9
  8fa7e5:	mov    edi,0x1
  8fa7ea:	cmovne rdx,rdi
  8fa7ee:	mov    r8,r11
  8fa7f1:	cmp    rcx,rsi
  8fa7f4:	setbe  cl
  8fa7f7:	test   r8,r8
  8fa7fa:	setne  sil
  8fa7fe:	test   cl,sil
  8fa801:	je     8fa700 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3d0>
  8fa807:	lea    rax,[rax+rax*2]
  8fa80b:	lea    rsi,[rdx+rax*2]
  8fa80f:	mov    rdi,QWORD PTR [rsp+0x28]
  8fa814:	cmp    edi,DWORD PTR [rsp+0x90]
  8fa81b:	mov    ecx,0x0
  8fa820:	sbb    ecx,ecx
  8fa822:	cmp    edi,DWORD PTR [rsp+0xf4]
  8fa829:	mov    eax,0x0
  8fa82e:	sbb    eax,eax
  8fa830:	vmovd  xmm0,edi
  8fa834:	vpbroadcastd ymm1,xmm0
  8fa839:	vpand  xmm0,xmm1,XMMWORD PTR [rsp+0x3f0]
  8fa842:	vpbroadcastd ymm0,xmm0
  8fa847:	vmovdqa YMMWORD PTR [rsp+0x480],ymm0
  8fa850:	test   r14,r14
  8fa853:	vmovdqa YMMWORD PTR [rsp+0x320],ymm1
  8fa85c:	je     8fc879 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2549>
  8fa862:	mov    edx,edi
  8fa864:	sub    edx,DWORD PTR [rsp+0x8c]
  8fa86b:	mov    r9d,edx
  8fa86e:	imul   r9d,DWORD PTR [rsp+0x88]
  8fa877:	sar    edx,0x1f
  8fa87a:	vmovd  xmm0,ecx
  8fa87e:	vpbroadcastd ymm0,xmm0
  8fa883:	vmovdqa YMMWORD PTR [rsp+0x6a0],ymm0
  8fa88c:	mov    ecx,DWORD PTR [rsp+0x94]
  8fa893:	not    ecx
  8fa895:	vmovd  xmm0,ecx
  8fa899:	vmovdqa XMMWORD PTR [rsp+0x400],xmm0
  8fa8a2:	vpand  xmm0,xmm1,xmm0
  8fa8a6:	vpbroadcastd ymm0,xmm0
  8fa8ab:	vmovdqa YMMWORD PTR [rsp+0x720],ymm0
  8fa8b4:	vmovd  xmm0,eax
  8fa8b8:	vpbroadcastd ymm0,xmm0
  8fa8bd:	vmovdqa YMMWORD PTR [rsp+0x440],ymm0
  8fa8c6:	vmovd  xmm0,r9d
  8fa8cb:	vpbroadcastd ymm0,xmm0
  8fa8d0:	vmovdqa YMMWORD PTR [rsp+0x680],ymm0
  8fa8d9:	vmovd  xmm0,edx
  8fa8dd:	vpbroadcastd ymm0,xmm0
  8fa8e2:	vmovdqa YMMWORD PTR [rsp+0x660],ymm0
  8fa8eb:	mov    eax,edi
  8fa8ed:	sub    eax,DWORD PTR [rsp+0x84]
  8fa8f4:	mov    ecx,eax
  8fa8f6:	sar    ecx,0x1f
  8fa8f9:	imul   eax,DWORD PTR [rsp+0xf0]
  8fa901:	vmovd  xmm0,eax
  8fa905:	vpbroadcastd ymm0,xmm0
  8fa90a:	vmovdqa YMMWORD PTR [rsp+0x640],ymm0
  8fa913:	vmovd  xmm0,ecx
  8fa917:	vpbroadcastd ymm0,xmm0
  8fa91c:	vmovdqa YMMWORD PTR [rsp+0x620],ymm0
  8fa925:	mov    QWORD PTR [rsp+0xe8],0x0
  8fa931:	mov    rax,QWORD PTR [rsp+0x288]
  8fa939:	mov    QWORD PTR [rsp+0xe0],rax
  8fa941:	mov    QWORD PTR [rsp+0x198],0x0
  8fa94d:	mov    QWORD PTR [rsp+0x60],r15
  8fa952:	jmp    8fa9c3 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x693>
  8fa954:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8fa960:	mov    rcx,QWORD PTR [rsp+0x290]
  8fa968:	lea    rax,[rcx+rcx*2]
  8fa96c:	mov    rsi,QWORD PTR [rsp+0x298]
  8fa974:	lea    rsi,[rsi+rax*2]
  8fa978:	mov    r8,QWORD PTR [rsp+0xd8]
  8fa980:	sub    r8,rcx
  8fa983:	inc    QWORD PTR [rsp+0x198]
  8fa98b:	mov    rax,QWORD PTR [rsp+0xe8]
  8fa993:	add    eax,DWORD PTR [rsp+0xf8]
  8fa99a:	mov    QWORD PTR [rsp+0xe8],rax
  8fa9a2:	mov    rax,QWORD PTR [rsp+0xe0]
  8fa9aa:	add    rax,QWORD PTR [rsp+0x98]
  8fa9b2:	mov    QWORD PTR [rsp+0xe0],rax
  8fa9ba:	test   r8,r8
  8fa9bd:	je     8fa700 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3d0>
  8fa9c3:	mov    rcx,QWORD PTR [rsp+0x98]
  8fa9cb:	cmp    r8,rcx
  8fa9ce:	cmovb  rcx,r8
  8fa9d2:	mov    rax,rcx
  8fa9d5:	or     rax,r13
  8fa9d8:	shr    rax,0x20
  8fa9dc:	mov    QWORD PTR [rsp+0xd8],r8
  8fa9e4:	je     8faa00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x6d0>
  8fa9e6:	mov    rax,rcx
  8fa9e9:	xor    edx,edx
  8fa9eb:	div    r13
  8fa9ee:	mov    r9,rax
  8fa9f1:	jmp    8faa0a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x6da>
  8fa9f3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8faa00:	mov    eax,ecx
  8faa02:	xor    edx,edx
  8faa04:	div    r13d
  8faa07:	mov    r9d,eax
  8faa0a:	mov    rbx,QWORD PTR [rsp+0x28]
  8faa0f:	mov    rdi,QWORD PTR [rsp+0x10]
  8faa14:	cmp    rdx,0x1
  8faa18:	sbb    r9,0xffffffffffffffff
  8faa1c:	cmp    r9,0x40
  8faa20:	mov    eax,0x40
  8faa25:	cmovae r9,rax
  8faa29:	mov    QWORD PTR [rsp+0x290],rcx
  8faa31:	lea    rax,[rcx+rcx*1]
  8faa35:	lea    rax,[rax+rax*2]
  8faa39:	mov    r8,QWORD PTR [rsp+0xc8]
  8faa41:	sub    rax,r8
  8faa44:	mov    ecx,0x0
  8faa49:	cmovae rcx,rax
  8faa4d:	mov    QWORD PTR [rsp+0x1a8],r9
  8faa55:	imul   r9,QWORD PTR [rsp+0xd0]
  8faa5e:	cmp    rcx,r9
  8faa61:	cmovb  r9,rcx
  8faa65:	mov    QWORD PTR [rsp+0x298],rsi
  8faa6d:	add    rsi,r8
  8faa70:	cmp    r9,0x300
  8faa77:	mov    eax,0x300
  8faa7c:	cmovae r9,rax
  8faa80:	mov    rdx,r9
  8faa83:	vzeroupper
  8faa86:	call   QWORD PTR [rip+0x6ea014]        # fe4aa0 <memcpy@GLIBC_2.14>
  8faa8c:	mov    rdx,QWORD PTR [rsp+0x10]
  8faa91:	cmp    rbx,0x7fffffff
  8faa98:	vmovdqa xmm13,XMMWORD PTR [rsp+0x270]
  8faaa1:	vmovdqa xmm14,XMMWORD PTR [rip+0xffffffffff719547]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8faaa9:	vmovdqa ymm15,YMMWORD PTR [rsp+0x320]
  8faab2:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8faab8:	mov    rax,QWORD PTR [rsp+0x198]
  8faac0:	imul   rax,QWORD PTR [rsp+0x30]
  8faac6:	shl    rax,0x6
  8faaca:	mov    rcx,QWORD PTR [rsp+0x1a8]
  8faad2:	lea    rsi,[rcx+0xf]
  8faad6:	shr    rsi,0x4
  8faada:	mov    QWORD PTR [rsp+0xc0],rax
  8faae2:	je     8fb7e0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x14b0>
  8faae8:	or     rax,QWORD PTR [rsp+0x28]
  8faaed:	mov    QWORD PTR [rsp+0x2b0],rax
  8faaf5:	vmovaps xmm0,XMMWORD PTR [rsp+0x360]
  8faafe:	vmovaps XMMWORD PTR [rsp+0x420],xmm0
  8fab07:	vmovaps xmm0,XMMWORD PTR [rsp+0x370]
  8fab10:	vmovaps XMMWORD PTR [rsp+0x410],xmm0
  8fab19:	vmovaps xmm0,XMMWORD PTR [rsp+0x380]
  8fab22:	vmovaps XMMWORD PTR [rsp+0x430],xmm0
  8fab2b:	mov    r11d,0xc40
  8fab31:	mov    r14d,0x2b
  8fab37:	vbroadcastss ymm0,DWORD PTR [rsp+0x390]
  8fab41:	vmovaps YMMWORD PTR [rsp+0x820],ymm0
  8fab4a:	mov    r13,QWORD PTR [rsp+0xe0]
  8fab52:	mov    rax,QWORD PTR [rsp+0xe8]
  8fab5a:	mov    r12d,eax
  8fab5d:	xor    r15d,r15d
  8fab60:	xor    edi,edi
  8fab62:	mov    QWORD PTR [rsp+0x2a8],rsi
  8fab6a:	jmp    8fb200 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xed0>
  8fab6f:	nop
  8fab70:	vpsrld ymm5,ymm2,0x1a
  8fab75:	vpaddd ymm2,ymm5,ymm2
  8fab79:	vpsrad ymm2,ymm2,0x6
  8fab7e:	vpaddd ymm5,ymm15,ymm2
  8fab82:	vpbroadcastd ymm11,DWORD PTR [rsp+0x350]
  8fab8c:	vpand  ymm2,ymm11,ymm5
  8fab90:	vpsrld ymm9,ymm3,0x1a
  8fab95:	vpaddd ymm3,ymm9,ymm3
  8fab99:	vpsrad ymm3,ymm3,0x6
  8fab9e:	vpaddd ymm9,ymm15,ymm3
  8faba2:	vpand  ymm3,ymm9,ymm11
  8faba7:	vmovdqa YMMWORD PTR [rsp+0x840],ymm3
  8fabb0:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm2
  8fabb9:	vmovdqa YMMWORD PTR [rsp+0x860],ymm2
  8fabc2:	vmovdqu YMMWORD PTR [rdx+r11*4-0x29e0],ymm2
  8fabcc:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2a00],ymm3
  8fabd6:	vpsrad ymm13,ymm8,0x1f
  8fabdc:	vpsrld ymm13,ymm13,0x1a
  8fabe2:	vpaddd ymm13,ymm13,ymm8
  8fabe7:	vpsrad ymm8,ymm7,0x1f
  8fabec:	vpsrld ymm8,ymm8,0x1a
  8fabf2:	vpaddd ymm14,ymm8,ymm7
  8fabf6:	vpsrld ymm7,ymm12,0x1a
  8fabfc:	vpaddd ymm7,ymm12,ymm7
  8fac00:	vpsrad ymm7,ymm7,0x6
  8fac05:	vpaddd ymm12,ymm7,ymm0
  8fac09:	vpand  ymm2,ymm12,ymm11
  8fac0e:	vmovdqa YMMWORD PTR [rsp+0x220],ymm2
  8fac17:	vpsrld ymm8,ymm10,0x1a
  8fac1d:	vpaddd ymm8,ymm8,ymm10
  8fac22:	vpsrad ymm8,ymm8,0x6
  8fac28:	vpaddd ymm10,ymm8,ymm1
  8fac2c:	vpand  ymm7,ymm10,ymm11
  8fac31:	vmovdqa YMMWORD PTR [rsp+0x880],ymm7
  8fac3a:	vmovdqa YMMWORD PTR [rsp+0x8a0],ymm2
  8fac43:	lea    rax,[rsp+0x880]
  8fac4b:	vmovaps ymm15,YMMWORD PTR [rax]
  8fac4f:	vmovdqa ymm8,ymm0
  8fac53:	vmovdqa YMMWORD PTR [rsp+0x140],ymm0
  8fac5c:	vmovaps ymm0,YMMWORD PTR [rax+0x20]
  8fac61:	vmovups YMMWORD PTR [rdx+r11*4-0x28e0],ymm0
  8fac6b:	vpsrad ymm0,ymm14,0x6
  8fac71:	vpaddd ymm0,ymm0,YMMWORD PTR [rsp+0x320]
  8fac7a:	vmovups YMMWORD PTR [rdx+r11*4-0x2900],ymm15
  8fac84:	vpsrad ymm14,ymm6,0x1f
  8fac89:	vpsrld ymm14,ymm14,0x1a
  8fac8f:	vpaddd ymm6,ymm14,ymm6
  8fac93:	vpsrad ymm14,ymm4,0x1f
  8fac98:	vpsrld ymm14,ymm14,0x1a
  8fac9e:	vpaddd ymm14,ymm14,ymm4
  8faca2:	vmovdqa ymm2,YMMWORD PTR [rsp+0x4a0]
  8facab:	vpminud ymm4,ymm2,ymm0
  8facb0:	vpcmpeqd ymm4,ymm2,ymm4
  8facb4:	vpsrad ymm6,ymm6,0x6
  8facb9:	vpaddd ymm6,ymm8,ymm6
  8facbd:	vmovdqa ymm8,ymm1
  8facc1:	vmovdqa ymm1,YMMWORD PTR [rsp+0x3c0]
  8facca:	vpminud ymm15,ymm1,ymm6
  8faccf:	vpcmpeqd ymm15,ymm15,ymm1
  8facd3:	vpor   ymm4,ymm15,ymm4
  8facd7:	vmovdqa YMMWORD PTR [rsp+0x120],ymm4
  8face0:	vpsrad ymm13,ymm13,0x6
  8face6:	vpaddd ymm13,ymm13,YMMWORD PTR [rsp+0x320]
  8facef:	vpminud ymm15,ymm2,ymm13
  8facf4:	vpcmpeqd ymm15,ymm15,ymm2
  8facf8:	vpand  ymm4,ymm13,ymm11
  8facfd:	vmovdqa YMMWORD PTR [rsp+0xa0],ymm4
  8fad06:	vpand  ymm0,ymm11,ymm0
  8fad0a:	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm0
  8fad13:	vpand  ymm0,ymm11,ymm6
  8fad17:	vmovdqa YMMWORD PTR [rsp+0x40],ymm0
  8fad1d:	vpsrad ymm0,ymm14,0x6
  8fad23:	vpaddd ymm0,ymm8,ymm0
  8fad27:	vpand  ymm4,ymm11,ymm0
  8fad2b:	vmovdqa YMMWORD PTR [rsp+0x160],ymm4
  8fad34:	vpminud ymm0,ymm1,ymm0
  8fad39:	vpcmpeqd ymm0,ymm1,ymm0
  8fad3d:	vpor   ymm0,ymm15,ymm0
  8fad41:	vmovdqa YMMWORD PTR [rsp+0x100],ymm0
  8fad4a:	vpminud ymm0,ymm2,ymm9
  8fad4f:	vpcmpeqd ymm0,ymm2,ymm0
  8fad53:	vpminud ymm11,ymm1,ymm10
  8fad58:	vpcmpeqd ymm11,ymm11,ymm1
  8fad5c:	vpor   ymm13,ymm11,ymm0
  8fad60:	vpminud ymm0,ymm2,ymm5
  8fad65:	vpcmpeqd ymm0,ymm2,ymm0
  8fad69:	vpminud ymm11,ymm1,ymm12
  8fad6e:	vpcmpeqd ymm11,ymm11,ymm1
  8fad72:	vpor   ymm11,ymm11,ymm0
  8fad76:	vmovdqa ymm15,YMMWORD PTR [rsp+0x500]
  8fad7f:	vpsubd ymm0,ymm3,ymm15
  8fad84:	vmovdqa ymm6,ymm3
  8fad88:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4e0]
  8fad91:	vpmulld ymm14,ymm0,ymm1
  8fad96:	vpaddd ymm14,ymm14,ymm7
  8fad9a:	vpsrad ymm0,ymm0,0x1f
  8fad9f:	vpor   ymm0,ymm14,ymm0
  8fada3:	vmovdqa ymm3,YMMWORD PTR [rsp+0x1c0]
  8fadac:	vpsubd ymm14,ymm3,ymm15
  8fadb1:	vpmulld ymm15,ymm14,ymm1
  8fadb6:	vmovdqa ymm4,YMMWORD PTR [rsp+0x220]
  8fadbf:	vpaddd ymm15,ymm15,ymm4
  8fadc3:	vpsrad ymm14,ymm14,0x1f
  8fadc9:	vpor   ymm14,ymm15,ymm14
  8fadce:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2800],ymm0
  8fadd8:	vmovdqu YMMWORD PTR [rdx+r11*4-0x27e0],ymm14
  8fade2:	vmovdqa ymm14,YMMWORD PTR [rsp+0x520]
  8fadeb:	vpand  ymm0,ymm10,ymm14
  8fadf0:	vmovdqa ymm1,YMMWORD PTR [rsp+0x800]
  8fadf9:	vpaddd ymm10,ymm8,ymm1
  8fadfd:	vpsubd ymm0,ymm10,ymm0
  8fae01:	vpand  ymm10,ymm12,ymm14
  8fae06:	vmovdqa ymm15,YMMWORD PTR [rsp+0x140]
  8fae0f:	vpaddd ymm12,ymm15,ymm1
  8fae13:	vpsubd ymm10,ymm12,ymm10
  8fae18:	vpand  ymm9,ymm9,ymm14
  8fae1d:	vmovdqa ymm2,YMMWORD PTR [rsp+0x480]
  8fae26:	vpcmpeqd ymm9,ymm9,ymm2
  8fae2a:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4c0]
  8fae33:	vpminud ymm0,ymm1,ymm0
  8fae38:	vpcmpeqd ymm0,ymm1,ymm0
  8fae3c:	vpandn ymm0,ymm0,ymm9
  8fae41:	vpandn ymm12,ymm13,ymm0
  8fae45:	vmovdqa YMMWORD PTR [rsp+0x300],ymm12
  8fae4e:	vpand  ymm0,ymm14,ymm5
  8fae52:	vpcmpeqd ymm0,ymm0,ymm2
  8fae56:	vpminud ymm5,ymm1,ymm10
  8fae5b:	vpcmpeqd ymm5,ymm1,ymm5
  8fae5f:	vpandn ymm0,ymm5,ymm0
  8fae63:	vpandn ymm11,ymm11,ymm0
  8fae67:	vmovdqa YMMWORD PTR [rsp+0x240],ymm11
  8fae70:	vmovdqa ymm1,YMMWORD PTR [rsp+0x7c0]
  8fae79:	vpsubd ymm0,ymm6,ymm1
  8fae7d:	vpsubd ymm2,ymm3,ymm1
  8fae81:	vmovdqa ymm9,YMMWORD PTR [rsp+0x7a0]
  8fae8a:	vpmulld ymm3,ymm9,ymm0
  8fae8f:	vpaddd ymm3,ymm3,ymm7
  8fae93:	vpmulld ymm5,ymm9,ymm2
  8fae98:	vpaddd ymm5,ymm5,ymm4
  8fae9c:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff71dddb]        # 18c80 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  8faea5:	vpsrad ymm0,ymm0,0x1f
  8faeaa:	vpor   ymm0,ymm3,ymm0
  8faeae:	vpsrad ymm2,ymm2,0x1f
  8faeb3:	vpor   ymm2,ymm5,ymm2
  8faeb7:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2700],ymm0
  8faec1:	vmovdqu YMMWORD PTR [rdx+r11*4-0x26e0],ymm2
  8faecb:	vmovdqa ymm6,YMMWORD PTR [rsp+0xa0]
  8faed4:	vpsubd ymm0,ymm6,ymm1
  8faed8:	vmovdqa ymm4,YMMWORD PTR [rsp+0x1e0]
  8faee1:	vpsubd ymm2,ymm4,ymm1
  8faee5:	vpmulld ymm3,ymm0,ymm9
  8faeea:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x160]
  8faef3:	vpsrad ymm0,ymm0,0x1f
  8faef8:	vpor   ymm0,ymm3,ymm0
  8faefc:	vpmulld ymm3,ymm2,ymm9
  8faf01:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x40]
  8faf07:	vpsrad ymm2,ymm2,0x1f
  8faf0c:	vpor   ymm2,ymm3,ymm2
  8faf10:	vpand  ymm1,ymm12,ymm7
  8faf14:	vmovdqa YMMWORD PTR [rsp+0x220],ymm1
  8faf1d:	vpand  ymm1,ymm11,ymm7
  8faf21:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm1
  8faf2a:	vmovdqa ymm5,YMMWORD PTR [rsp+0x7e0]
  8faf33:	vpminud ymm1,ymm5,ymm8
  8faf38:	vpcmpeqd ymm1,ymm5,ymm1
  8faf3c:	vpminud ymm3,ymm5,ymm15
  8faf41:	vpcmpeqd ymm3,ymm5,ymm3
  8faf45:	vmovdqa ymm5,YMMWORD PTR [rsp+0x440]
  8faf4e:	vpandn ymm1,ymm1,ymm5
  8faf52:	vmovdqa YMMWORD PTR [rsp+0x2e0],ymm1
  8faf5b:	vpandn ymm1,ymm3,ymm5
  8faf5f:	vmovdqa YMMWORD PTR [rsp+0x140],ymm1
  8faf68:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2600],ymm0
  8faf72:	vmovdqu YMMWORD PTR [rdx+r11*4-0x25e0],ymm2
  8faf7c:	vmovdqa ymm1,YMMWORD PTR [rsp+0x460]
  8faf85:	vpminud ymm0,ymm1,ymm0
  8faf8a:	vpcmpeqd ymm0,ymm1,ymm0
  8faf8e:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0x100]
  8faf97:	vmovdqa YMMWORD PTR [rsp+0x100],ymm0
  8fafa0:	vpminud ymm0,ymm1,ymm2
  8fafa5:	vpcmpeqd ymm0,ymm1,ymm0
  8fafa9:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0x120]
  8fafb2:	vmovdqa YMMWORD PTR [rsp+0x200],ymm0
  8fafbb:	vpbroadcastd ymm0,DWORD PTR [rsp+0x400]
  8fafc5:	vpand  ymm1,ymm6,ymm0
  8fafc9:	vpand  ymm0,ymm4,ymm0
  8fafcd:	vmovdqa ymm2,YMMWORD PTR [rsp+0x720]
  8fafd6:	vpcmpeqd ymm1,ymm2,ymm1
  8fafda:	vmovdqa YMMWORD PTR [rsp+0x2c0],ymm1
  8fafe3:	vpcmpeqd ymm0,ymm2,ymm0
  8fafe7:	vmovdqa YMMWORD PTR [rsp+0x3a0],ymm0
  8faff0:	mov    QWORD PTR [rsp+0x120],rdi
  8faff8:	lea    rdi,[rsp+0x580]
  8fb000:	lea    rsi,[rsp+0x840]
  8fb008:	mov    edx,DWORD PTR [rsp+0x94]
  8fb00f:	mov    rbx,r11
  8fb012:	vzeroupper
  8fb015:	call   4b8bd0 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAINtNtNtCs9DW4HO7zhlu_13fearless_simd9generated10simd_types6i32x16NtNtBD_4avx24Avx2Ej2_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitBy_ENCINvMB27_B24_10wrap_mut_1By_NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesB1B_Kb1_Es4_0E0EB3x_>
  8fb01a:	mov    r11,rbx
  8fb01d:	mov    rdi,QWORD PTR [rsp+0x120]
  8fb025:	mov    rsi,QWORD PTR [rsp+0x2a8]
  8fb02d:	vmovdqa ymm15,YMMWORD PTR [rsp+0x320]
  8fb036:	vmovdqa xmm14,XMMWORD PTR [rip+0xffffffffff718fb2]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8fb03e:	vmovdqa xmm13,XMMWORD PTR [rsp+0x270]
  8fb047:	mov    rdx,QWORD PTR [rsp+0x10]
  8fb04c:	vmovdqa ymm0,YMMWORD PTR [rsp+0xa0]
  8fb055:	vpsubd ymm0,ymm0,YMMWORD PTR [rsp+0x580]
  8fb05e:	vmovdqa ymm2,YMMWORD PTR [rsp+0x780]
  8fb067:	vpaddd ymm1,ymm2,YMMWORD PTR [rsp+0x160]
  8fb070:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x5c0]
  8fb079:	vmovdqa ymm3,YMMWORD PTR [rsp+0x760]
  8fb082:	vpminud ymm0,ymm3,ymm0
  8fb087:	vpcmpeqd ymm0,ymm3,ymm0
  8fb08b:	vmovdqa ymm4,YMMWORD PTR [rsp+0x740]
  8fb094:	vpminud ymm1,ymm4,ymm1
  8fb099:	vpcmpeqd ymm1,ymm4,ymm1
  8fb09d:	vpor   ymm0,ymm0,ymm1
  8fb0a1:	vmovdqa ymm1,YMMWORD PTR [rsp+0x1e0]
  8fb0aa:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x5a0]
  8fb0b3:	vpaddd ymm2,ymm2,YMMWORD PTR [rsp+0x40]
  8fb0b9:	vpsubd ymm2,ymm2,YMMWORD PTR [rsp+0x5e0]
  8fb0c2:	vpminud ymm1,ymm3,ymm1
  8fb0c7:	vpcmpeqd ymm1,ymm3,ymm1
  8fb0cb:	vpminud ymm2,ymm4,ymm2
  8fb0d0:	vpcmpeqd ymm2,ymm4,ymm2
  8fb0d4:	vpor   ymm1,ymm1,ymm2
  8fb0d8:	vmovdqa ymm4,YMMWORD PTR [rsp+0x100]
  8fb0e1:	vpandn ymm2,ymm4,YMMWORD PTR [rsp+0x2c0]
  8fb0ea:	vmovdqa ymm5,YMMWORD PTR [rsp+0x200]
  8fb0f3:	vpandn ymm3,ymm5,YMMWORD PTR [rsp+0x3a0]
  8fb0fc:	vpor   ymm0,ymm0,ymm4
  8fb100:	vpor   ymm1,ymm1,ymm5
  8fb104:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff71dd8b]        # 18e98 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1449>
  8fb10d:	vpandn ymm0,ymm0,ymm4
  8fb111:	vpandn ymm1,ymm1,ymm4
  8fb115:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff71df52]        # 19070 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  8fb11e:	vmovdqa ymm7,YMMWORD PTR [rsp+0x2e0]
  8fb127:	vpand  ymm5,ymm7,ymm4
  8fb12b:	vpor   ymm5,ymm5,YMMWORD PTR [rsp+0x220]
  8fb134:	vmovdqa ymm8,YMMWORD PTR [rsp+0x140]
  8fb13d:	vpand  ymm4,ymm8,ymm4
  8fb141:	vpor   ymm4,ymm4,YMMWORD PTR [rsp+0x1c0]
  8fb14a:	vpbroadcastd ymm6,DWORD PTR [rip+0xffffffffff71dd6d]        # 18ec0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  8fb153:	vpand  ymm7,ymm7,ymm6
  8fb157:	vpand  ymm7,ymm7,YMMWORD PTR [rsp+0x300]
  8fb160:	vpsrld ymm2,ymm2,0x1f
  8fb165:	vpor   ymm2,ymm7,ymm2
  8fb169:	vpor   ymm2,ymm5,ymm2
  8fb16d:	vpor   ymm0,ymm2,ymm0
  8fb171:	vpand  ymm2,ymm8,ymm6
  8fb175:	vpand  ymm2,ymm2,YMMWORD PTR [rsp+0x240]
  8fb17e:	vpsrld ymm3,ymm3,0x1f
  8fb183:	vpor   ymm2,ymm2,ymm3
  8fb187:	vpor   ymm2,ymm4,ymm2
  8fb18b:	vpor   ymm1,ymm2,ymm1
  8fb18f:	lea    rax,[r11-0xc40]
  8fb196:	vmovdqa xmm2,XMMWORD PTR [rsp+0x70]
  8fb19c:	vpor   xmm2,xmm2,XMMWORD PTR [rip+0xffffffffff71a0ec]        # 15290 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0xed0>
  8fb1a4:	vextracti128 xmm3,ymm1,0x1
  8fb1aa:	vpackssdw xmm1,xmm1,xmm3
  8fb1ae:	vextracti128 xmm3,ymm0,0x1
  8fb1b4:	vpackssdw xmm0,xmm0,xmm3
  8fb1b8:	vpacksswb xmm0,xmm0,xmm1
  8fb1bc:	vpand  xmm0,xmm2,xmm0
  8fb1c0:	vmovdqu XMMWORD PTR [rdx+r11*1],xmm0
  8fb1c6:	vpand  xmm0,xmm13,xmm0
  8fb1ca:	vpxor  xmm1,xmm1,xmm1
  8fb1ce:	vpcmpeqb xmm0,xmm0,xmm1
  8fb1d2:	vpmovmskb ecx,xmm0
  8fb1d6:	xor    ecx,0xffff
  8fb1dc:	shlx   rax,rcx,rax
  8fb1e1:	or     rdi,rax
  8fb1e4:	inc    r15
  8fb1e7:	add    r11,0x10
  8fb1eb:	add    r14,0x30
  8fb1ef:	add    r12d,DWORD PTR [rsp+0xfc]
  8fb1f7:	cmp    r15,rsi
  8fb1fa:	jae    8fb7e2 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x14b2>
  8fb200:	add    r13,QWORD PTR [rsp+0x2b8]
  8fb208:	cmp    r13,0x7fffffff
  8fb20f:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fb215:	cmp    QWORD PTR [rsp+0x30],0x1
  8fb21b:	jne    8fb2d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xfa0>
  8fb221:	vmovdqu xmm0,XMMWORD PTR [rdx+r14*2-0x56]
  8fb228:	vmovdqu xmm1,XMMWORD PTR [rdx+r14*2-0x50]
  8fb22f:	vmovdqu xmm2,XMMWORD PTR [rdx+r14*2-0x26]
  8fb236:	vmovdqu xmm3,XMMWORD PTR [rdx+r14*2-0x20]
  8fb23d:	vpblendd xmm0,xmm0,XMMWORD PTR [rdx+r14*2-0x46],0x4
  8fb245:	vpblendd xmm0,xmm0,XMMWORD PTR [rdx+r14*2-0x36],0x2
  8fb24d:	vpblendd xmm2,xmm2,XMMWORD PTR [rdx+r14*2-0x16],0x4
  8fb255:	vpblendd xmm2,xmm2,XMMWORD PTR [rdx+r14*2-0x6],0x2
  8fb25d:	vpblendd xmm1,xmm1,XMMWORD PTR [rdx+r14*2-0x40],0x4
  8fb265:	vpblendd xmm1,xmm1,XMMWORD PTR [rdx+r14*2-0x30],0x2
  8fb26d:	vpblendd xmm3,xmm3,XMMWORD PTR [rdx+r14*2-0x10],0x4
  8fb275:	vpblendd xmm3,xmm3,XMMWORD PTR [rdx+r14*2],0x2
  8fb27c:	vmovq  xmm6,QWORD PTR [rip+0xffffffffff71b4fc]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8fb284:	vpshufb xmm4,xmm1,xmm6
  8fb289:	vpshufb xmm5,xmm0,xmm6
  8fb28e:	vpunpcklbw xmm4,xmm5,xmm4
  8fb292:	vpshufb xmm5,xmm3,xmm6
  8fb297:	vpshufb xmm6,xmm2,xmm6
  8fb29c:	vpunpcklbw xmm5,xmm6,xmm5
  8fb2a0:	vmovd  xmm6,DWORD PTR [rip+0xffffffffff719628]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x510>
  8fb2a8:	vpshufb xmm1,xmm1,xmm6
  8fb2ad:	vpshufb xmm0,xmm0,xmm6
  8fb2b2:	vpunpcklbw xmm0,xmm0,xmm1
  8fb2b6:	vpshufb xmm1,xmm3,xmm6
  8fb2bb:	vpshufb xmm2,xmm2,xmm6
  8fb2c0:	vpunpcklbw xmm1,xmm2,xmm1
  8fb2c4:	jmp    8fb389 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1059>
  8fb2c9:	nop    DWORD PTR [rax+0x0]
  8fb2d0:	vmovdqu xmm0,XMMWORD PTR [rdx+r14*4-0xac]
  8fb2da:	vmovdqu xmm1,XMMWORD PTR [rdx+r14*4-0x8c]
  8fb2e4:	vmovdqu xmm2,XMMWORD PTR [rdx+r14*4-0x7c]
  8fb2eb:	vmovdqu xmm3,XMMWORD PTR [rdx+r14*4-0x5c]
  8fb2f2:	vpblendd xmm0,xmm0,XMMWORD PTR [rdx+r14*4-0x9c],0x4
  8fb2fd:	vmovdqa xmm5,XMMWORD PTR [rip+0xffffffffff71ae5b]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8fb305:	vpshufb xmm1,xmm1,xmm5
  8fb30a:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71bfbe]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8fb312:	vpshufb xmm0,xmm0,xmm6
  8fb317:	vpor   xmm0,xmm0,xmm1
  8fb31b:	vpblendd xmm1,xmm2,XMMWORD PTR [rdx+r14*4-0x6c],0x4
  8fb323:	vpshufb xmm2,xmm3,xmm5
  8fb328:	vpshufb xmm1,xmm1,xmm6
  8fb32d:	vpor   xmm1,xmm1,xmm2
  8fb331:	vmovdqu xmm2,XMMWORD PTR [rdx+r14*4-0x2c]
  8fb338:	vmovdqu xmm3,XMMWORD PTR [rdx+r14*4-0x4c]
  8fb33f:	vpblendd xmm3,xmm3,XMMWORD PTR [rdx+r14*4-0x3c],0x4
  8fb347:	vpshufb xmm2,xmm2,xmm5
  8fb34c:	vpshufb xmm3,xmm3,xmm6
  8fb351:	vpor   xmm2,xmm3,xmm2
  8fb355:	vmovdqu xmm3,XMMWORD PTR [rdx+r14*4+0x4]
  8fb35c:	vmovdqu xmm4,XMMWORD PTR [rdx+r14*4-0x1c]
  8fb363:	vpblendd xmm4,xmm4,XMMWORD PTR [rdx+r14*4-0xc],0x4
  8fb36b:	vpshufb xmm3,xmm3,xmm5
  8fb370:	vpshufb xmm4,xmm4,xmm6
  8fb375:	vpor   xmm3,xmm4,xmm3
  8fb379:	vpunpckldq xmm4,xmm0,xmm1
  8fb37d:	vpunpckldq xmm5,xmm2,xmm3
  8fb381:	vpunpckhdq xmm0,xmm0,xmm1
  8fb385:	vpunpckhdq xmm1,xmm2,xmm3
  8fb389:	vpunpcklqdq xmm0,xmm0,xmm1
  8fb38d:	vpunpcklqdq xmm1,xmm4,xmm5
  8fb391:	vpunpckhqdq xmm3,xmm4,xmm5
  8fb395:	vpaddusb xmm2,xmm14,xmm1
  8fb399:	vmovdqa xmm4,XMMWORD PTR [rsp+0x430]
  8fb3a2:	vpshufb xmm4,xmm4,xmm2
  8fb3a7:	vptest xmm4,xmm13
  8fb3ac:	je     8fb1e4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xeb4>
  8fb3b2:	vmovdqa XMMWORD PTR [rsp+0x70],xmm4
  8fb3b8:	vmovdqu XMMWORD PTR [rdx+r11*1-0x40],xmm1
  8fb3bf:	vmovdqa xmm1,XMMWORD PTR [rsp+0x420]
  8fb3c8:	vpshufb xmm4,xmm1,xmm2
  8fb3cd:	vmovdqa xmm1,XMMWORD PTR [rsp+0x410]
  8fb3d6:	vpshufb xmm2,xmm1,xmm2
  8fb3db:	vpunpcklbw xmm1,xmm4,xmm2
  8fb3df:	vpunpckhbw xmm2,xmm4,xmm2
  8fb3e3:	vpmovsxbw ymm3,xmm3
  8fb3e8:	vpmovsxwd ymm4,xmm3
  8fb3ed:	vextracti128 xmm3,ymm3,0x1
  8fb3f3:	vpmovsxwd ymm3,xmm3
  8fb3f8:	vpabsd ymm5,ymm4
  8fb3fd:	vpabsd ymm6,ymm3
  8fb402:	vpsrld ymm7,ymm5,0x4
  8fb407:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff71db90]        # 18fa0 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  8fb410:	vpsrld ymm8,ymm6,0x4
  8fb415:	vpmaxud ymm7,ymm7,ymm9
  8fb41a:	vpcmpeqd ymm11,ymm11,ymm11
  8fb41f:	vpaddd ymm7,ymm11,ymm7
  8fb423:	vpmaxud ymm8,ymm8,ymm9
  8fb428:	vpaddd ymm8,ymm8,ymm11
  8fb42d:	vpslld ymm10,ymm7,0x4
  8fb432:	vpsubd ymm5,ymm5,ymm10
  8fb437:	vpslld ymm10,ymm8,0x4
  8fb43d:	vpsubd ymm6,ymm6,ymm10
  8fb442:	vpsllvd ymm5,ymm5,ymm7
  8fb447:	vpsllvd ymm6,ymm6,ymm8
  8fb44c:	vpsrad ymm4,ymm4,0x1f
  8fb451:	vpsrad ymm3,ymm3,0x1f
  8fb456:	vpxor  ymm5,ymm5,ymm4
  8fb45a:	vpxor  ymm6,ymm6,ymm3
  8fb45e:	vpsubd ymm8,ymm5,ymm4
  8fb462:	vpsubd ymm7,ymm6,ymm3
  8fb466:	vpmovsxbw ymm0,xmm0
  8fb46b:	vpmovsxwd ymm3,xmm0
  8fb470:	vextracti128 xmm0,ymm0,0x1
  8fb476:	vpmovsxwd ymm0,xmm0
  8fb47b:	vpabsd ymm4,ymm3
  8fb480:	vpabsd ymm5,ymm0
  8fb485:	vpsrld ymm6,ymm4,0x4
  8fb48a:	vpsrld ymm10,ymm5,0x4
  8fb48f:	vpmaxud ymm6,ymm6,ymm9
  8fb494:	vpaddd ymm6,ymm11,ymm6
  8fb498:	vpmaxud ymm9,ymm10,ymm9
  8fb49d:	vpaddd ymm9,ymm9,ymm11
  8fb4a2:	vpslld ymm10,ymm6,0x4
  8fb4a7:	vpsubd ymm4,ymm4,ymm10
  8fb4ac:	vpslld ymm10,ymm9,0x4
  8fb4b2:	vpsubd ymm5,ymm5,ymm10
  8fb4b7:	vpmovsxwd ymm1,xmm1
  8fb4bc:	vpmovsxwd ymm2,xmm2
  8fb4c1:	vmovdqa ymm10,YMMWORD PTR [rsp+0x820]
  8fb4ca:	vpmulld ymm1,ymm10,ymm1
  8fb4cf:	vpmulld ymm2,ymm10,ymm2
  8fb4d4:	vpsllvd ymm4,ymm4,ymm6
  8fb4d9:	vpsllvd ymm5,ymm5,ymm9
  8fb4de:	vpsrad ymm3,ymm3,0x1f
  8fb4e3:	vpsrad ymm0,ymm0,0x1f
  8fb4e8:	vpxor  ymm4,ymm4,ymm3
  8fb4ec:	vpxor  ymm5,ymm5,ymm0
  8fb4f0:	vpsubd ymm4,ymm4,ymm3
  8fb4f4:	vpsubd ymm6,ymm5,ymm0
  8fb4f8:	vpmulld ymm0,ymm1,ymm8
  8fb4fd:	vpmulld ymm3,ymm2,ymm7
  8fb502:	vpsrad ymm5,ymm0,0x1f
  8fb507:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff71dac8]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8fb510:	vpaddd ymm0,ymm9,ymm0
  8fb514:	vpaddd ymm5,ymm0,ymm5
  8fb518:	vpsrad ymm0,ymm3,0x1f
  8fb51d:	vpaddd ymm3,ymm9,ymm3
  8fb521:	vpaddd ymm10,ymm3,ymm0
  8fb525:	vpmulld ymm0,ymm1,ymm4
  8fb52a:	vpsrad ymm1,ymm0,0x1f
  8fb52f:	vpaddd ymm0,ymm9,ymm0
  8fb533:	vpaddd ymm11,ymm0,ymm1
  8fb537:	vmovd  xmm0,r12d
  8fb53c:	vpbroadcastd ymm0,xmm0
  8fb541:	vpmulld ymm1,ymm2,ymm6
  8fb546:	vpaddd ymm2,ymm9,ymm1
  8fb54a:	vpsrad ymm1,ymm1,0x1f
  8fb54f:	vpaddd ymm9,ymm2,ymm1
  8fb553:	vpaddd ymm1,ymm0,YMMWORD PTR [rsp+0x540]
  8fb55c:	vpaddd ymm0,ymm0,YMMWORD PTR [rsp+0x560]
  8fb565:	vpsrad ymm3,ymm5,0xe
  8fb56a:	vpsrad ymm2,ymm10,0xe
  8fb570:	vpsrad ymm10,ymm11,0xe
  8fb576:	vpsrad ymm12,ymm9,0xe
  8fb57c:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2e00],ymm8
  8fb586:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2de0],ymm7
  8fb590:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2c00],ymm3
  8fb59a:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2be0],ymm2
  8fb5a4:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2d00],ymm4
  8fb5ae:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2ce0],ymm6
  8fb5b8:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2b00],ymm10
  8fb5c2:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2ae0],ymm12
  8fb5cc:	mov    rax,QWORD PTR [rsp+0x2b0]
  8fb5d4:	test   QWORD PTR [rsp+0x1b8],rax
  8fb5dc:	jne    8fab70 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x840>
  8fb5e2:	vpabsd ymm5,ymm6
  8fb5e7:	vpabsd ymm9,ymm4
  8fb5ec:	vpabsd ymm11,ymm7
  8fb5f1:	vpor   ymm5,ymm11,ymm5
  8fb5f5:	vpabsd ymm11,ymm8
  8fb5fa:	vpor   ymm9,ymm9,ymm11
  8fb5ff:	vpabsd ymm11,ymm3
  8fb604:	vpor   ymm9,ymm9,ymm11
  8fb609:	vpabsd ymm11,ymm2
  8fb60e:	vpor   ymm5,ymm11,ymm5
  8fb612:	vpabsd ymm11,ymm12
  8fb617:	vpor   ymm5,ymm11,ymm5
  8fb61b:	vpabsd ymm11,ymm10
  8fb620:	vpor   ymm9,ymm9,ymm11
  8fb625:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff71d7fa]        # 18e28 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x13d9>
  8fb62e:	vpcmpgtd ymm5,ymm5,ymm11
  8fb633:	vpcmpgtd ymm9,ymm9,ymm11
  8fb638:	vpackssdw ymm5,ymm9,ymm5
  8fb63c:	vpmovmskb eax,ymm5
  8fb640:	test   eax,eax
  8fb642:	jne    8fab70 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x840>
  8fb648:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2a00],ymm15
  8fb652:	vmovdqu YMMWORD PTR [rdx+r11*4-0x29e0],ymm15
  8fb65c:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2900],ymm1
  8fb666:	vmovdqu YMMWORD PTR [rdx+r11*4-0x28e0],ymm0
  8fb670:	vmovdqa ymm9,ymm0
  8fb674:	vmovdqa ymm0,YMMWORD PTR [rsp+0x680]
  8fb67d:	vpaddd ymm2,ymm1,ymm0
  8fb681:	vpaddd ymm3,ymm9,ymm0
  8fb685:	vmovdqa ymm0,YMMWORD PTR [rsp+0x660]
  8fb68e:	vpor   ymm2,ymm2,ymm0
  8fb692:	vpor   ymm3,ymm3,ymm0
  8fb696:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2800],ymm2
  8fb6a0:	vmovdqu YMMWORD PTR [rdx+r11*4-0x27e0],ymm3
  8fb6aa:	vmovdqa ymm0,YMMWORD PTR [rsp+0x3c0]
  8fb6b3:	vpminud ymm2,ymm0,ymm1
  8fb6b8:	vpcmpeqd ymm2,ymm0,ymm2
  8fb6bc:	vpminud ymm3,ymm0,ymm9
  8fb6c1:	vpcmpeqd ymm4,ymm0,ymm3
  8fb6c5:	vmovdqa ymm0,YMMWORD PTR [rsp+0x6a0]
  8fb6ce:	vpandn ymm3,ymm2,ymm0
  8fb6d2:	vpandn ymm2,ymm4,ymm0
  8fb6d6:	vmovdqa ymm0,YMMWORD PTR [rsp+0x6c0]
  8fb6df:	vpminud ymm4,ymm0,ymm1
  8fb6e4:	vpcmpeqd ymm4,ymm0,ymm4
  8fb6e8:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffff71d58f]        # 18c80 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  8fb6f1:	vmovdqa ymm10,ymm1
  8fb6f5:	vmovdqa ymm1,YMMWORD PTR [rsp+0x440]
  8fb6fe:	vpandn ymm4,ymm4,ymm1
  8fb702:	vpand  ymm6,ymm3,ymm5
  8fb706:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff71d961]        # 19070 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  8fb70f:	vpand  ymm8,ymm4,ymm7
  8fb713:	vpor   ymm6,ymm8,ymm6
  8fb717:	vpminud ymm8,ymm0,ymm9
  8fb71c:	vpcmpeqd ymm8,ymm8,ymm0
  8fb720:	vpandn ymm8,ymm8,ymm1
  8fb724:	vpand  ymm5,ymm2,ymm5
  8fb728:	vpand  ymm7,ymm8,ymm7
  8fb72c:	vpor   ymm5,ymm5,ymm7
  8fb730:	vmovdqa ymm0,YMMWORD PTR [rsp+0x640]
  8fb739:	vpaddd ymm1,ymm10,ymm0
  8fb73d:	vpaddd ymm0,ymm9,ymm0
  8fb741:	vmovdqa ymm7,YMMWORD PTR [rsp+0x620]
  8fb74a:	vpor   ymm1,ymm1,ymm7
  8fb74e:	vpor   ymm0,ymm0,ymm7
  8fb752:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2700],ymm1
  8fb75c:	vmovdqu YMMWORD PTR [rdx+r11*4-0x26e0],ymm0
  8fb766:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2600],ymm1
  8fb770:	vmovdqa ymm7,YMMWORD PTR [rsp+0x460]
  8fb779:	vpminud ymm1,ymm7,ymm1
  8fb77e:	vpcmpeqd ymm1,ymm7,ymm1
  8fb782:	vpandn ymm1,ymm1,ymm3
  8fb786:	vpand  ymm3,ymm4,ymm3
  8fb78a:	vmovdqu YMMWORD PTR [rdx+r11*4-0x25e0],ymm0
  8fb794:	vpminud ymm0,ymm7,ymm0
  8fb799:	vpcmpeqd ymm0,ymm7,ymm0
  8fb79d:	vpandn ymm4,ymm0,ymm2
  8fb7a1:	vpand  ymm0,ymm8,ymm2
  8fb7a5:	vpbroadcastd ymm2,DWORD PTR [rip+0xffffffffff71d712]        # 18ec0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  8fb7ae:	vpand  ymm3,ymm3,ymm2
  8fb7b2:	vpand  ymm2,ymm0,ymm2
  8fb7b6:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff71d6e1]        # 18ea0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1451>
  8fb7bf:	vpand  ymm0,ymm1,ymm7
  8fb7c3:	vpor   ymm0,ymm0,ymm6
  8fb7c7:	vpor   ymm0,ymm0,ymm3
  8fb7cb:	vpand  ymm1,ymm4,ymm7
  8fb7cf:	vpor   ymm1,ymm1,ymm5
  8fb7d3:	vpor   ymm1,ymm1,ymm2
  8fb7d7:	jmp    8fb18f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xe5f>
  8fb7dc:	nop    DWORD PTR [rax+0x0]
  8fb7e0:	xor    edi,edi
  8fb7e2:	mov    rax,QWORD PTR [rsp+0x1a8]
  8fb7ea:	cmp    rax,0x1
  8fb7ee:	adc    rax,0x0
  8fb7f2:	bzhi   rax,rdi,rax
  8fb7f7:	test   BYTE PTR [rsp+0x1a0],0x1
  8fb7ff:	je     8fb8a0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1570>
  8fb805:	mov    rcx,QWORD PTR [rsp+0x38]
  8fb80a:	mov    r12,rcx
  8fb80d:	mov    rcx,QWORD PTR [rcx+0x130]
  8fb814:	mov    QWORD PTR [rsp+0x200],rcx
  8fb81c:	mov    rcx,QWORD PTR [rsp+0x28]
  8fb821:	movabs rdx,0x7fffffffffffffff
  8fb82b:	mov    QWORD PTR [rsp+0x1e0],rdx
  8fb833:	mov    r14,QWORD PTR [rsp+0x8]
  8fb838:	sub    rcx,QWORD PTR [r14+0x30]
  8fb83c:	mov    r13,QWORD PTR [rsp+0x30]
  8fb841:	mov    r15,QWORD PTR [rsp+0x60]
  8fb846:	jb     8fb884 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1554>
  8fb848:	imul   rcx,QWORD PTR [r14+0x58]
  8fb84d:	mov    rdx,QWORD PTR [r14+0x28]
  8fb851:	movabs rsi,0x7fffffffffffffff
  8fb85b:	mov    QWORD PTR [rsp+0x1e0],rsi
  8fb863:	cmp    rcx,rdx
  8fb866:	jae    8fb884 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1554>
  8fb868:	add    rcx,QWORD PTR [rsp+0xc0]
  8fb870:	imul   rdx,QWORD PTR [rsp+0x200]
  8fb879:	add    rdx,rcx
  8fb87c:	mov    QWORD PTR [rsp+0x1e0],rdx
  8fb884:	test   rax,rax
  8fb887:	jne    8fb93e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x160e>
  8fb88d:	jmp    8fa960 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x630>
  8fb892:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8fb8a0:	mov    rcx,QWORD PTR [rsp+0x38]
  8fb8a5:	mov    r12,rcx
  8fb8a8:	mov    rcx,QWORD PTR [rcx+0x130]
  8fb8af:	mov    QWORD PTR [rsp+0x40],rcx
  8fb8b4:	mov    rcx,QWORD PTR [rsp+0x28]
  8fb8b9:	movabs rsi,0x7fffffffffffffff
  8fb8c3:	mov    r14,QWORD PTR [rsp+0x8]
  8fb8c8:	sub    rcx,QWORD PTR [r14+0x30]
  8fb8cc:	mov    r13,QWORD PTR [rsp+0x30]
  8fb8d1:	mov    r15,QWORD PTR [rsp+0x60]
  8fb8d6:	jb     8fb8fa <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x15ca>
  8fb8d8:	imul   rcx,QWORD PTR [r14+0x58]
  8fb8dd:	mov    rdx,QWORD PTR [r14+0x28]
  8fb8e1:	cmp    rcx,rdx
  8fb8e4:	jae    8fb8fa <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x15ca>
  8fb8e6:	add    rcx,QWORD PTR [rsp+0xc0]
  8fb8ee:	imul   rdx,QWORD PTR [rsp+0x40]
  8fb8f4:	add    rdx,rcx
  8fb8f7:	mov    rsi,rdx
  8fb8fa:	mov    QWORD PTR [rsp+0x160],rsi
  8fb902:	test   rax,rax
  8fb905:	jne    8fc52a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21fa>
  8fb90b:	jmp    8fa960 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x630>
  8fb910:	movzx  r8d,BYTE PTR [rdi+0xc]
  8fb915:	mov    r9b,0x1
  8fb918:	mov    ecx,edx
  8fb91a:	shl    r9b,cl
  8fb91d:	shr    rsi,0x10
  8fb921:	mov    DWORD PTR [rdi+rdx*4],esi
  8fb924:	or     r9b,r8b
  8fb927:	mov    BYTE PTR [rdi+0xc],r9b
  8fb92b:	nop    DWORD PTR [rax+rax*1+0x0]
  8fb930:	blsr   rax,rax
  8fb935:	mov    r15,rbx
  8fb938:	je     8fa960 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x630>
  8fb93e:	tzcnt  rdx,rax
  8fb943:	mov    rbx,r15
  8fb946:	movzx  ecx,BYTE PTR [r15+rdx*1]
  8fb94b:	cmp    ecx,0x9
  8fb94e:	jae    8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fb950:	mov    r9,rcx
  8fb953:	shl    r9d,0x5
  8fb957:	add    r9,r12
  8fb95a:	mov    rcx,QWORD PTR [rsp+0x10]
  8fb95f:	movzx  edi,BYTE PTR [rcx+rdx*1+0xc40]
  8fb967:	mov    rsi,rdx
  8fb96a:	imul   rsi,r13
  8fb96e:	mov    QWORD PTR [rsp+0x40],rsi
  8fb973:	mov    r8,QWORD PTR [rsp+0x1e0]
  8fb97b:	lea    r15,[rsi+r8*1]
  8fb97f:	mov    r11d,DWORD PTR [rcx+rdx*4+0x300]
  8fb987:	mov    ecx,DWORD PTR [rcx+rdx*4+0x400]
  8fb98e:	mov    DWORD PTR [rsp+0x160],ecx
  8fb995:	xor    r10d,r10d
  8fb998:	test   dil,0x8
  8fb99c:	je     8fbb04 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17d4>
  8fb9a2:	cmp    BYTE PTR [r9],0x0
  8fb9a6:	je     8fc1da <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1eaa>
  8fb9ac:	mov    rsi,QWORD PTR [r9+0x8]
  8fb9b0:	mov    rcx,QWORD PTR [rsp+0x20]
  8fb9b5:	mov    r10d,DWORD PTR [rcx+rdx*4+0x800]
  8fb9bd:	mov    r8,QWORD PTR [r14+0x28]
  8fb9c1:	mov    QWORD PTR [rsp+0xa0],rsi
  8fb9c9:	imul   r8,rsi
  8fb9cd:	cmp    r15,QWORD PTR [r14+0x18]
  8fb9d1:	jae    8fba70 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1740>
  8fb9d7:	mov    rcx,QWORD PTR [r14+0x10]
  8fb9db:	mov    rsi,r15
  8fb9de:	shl    rsi,0x4
  8fb9e2:	mov    BYTE PTR [rsp+0x70],dil
  8fb9e7:	movzx  edi,BYTE PTR [rcx+rsi*1+0xd]
  8fb9ec:	cmp    dil,BYTE PTR [r14+0x6c]
  8fb9f0:	movzx  edi,BYTE PTR [rsp+0x70]
  8fb9f5:	jne    8fba70 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1740>
  8fb9f7:	add    rcx,rsi
  8fb9fa:	cmp    BYTE PTR [rcx+0xc],0x0
  8fb9fe:	je     8fba70 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1740>
  8fba00:	mov    QWORD PTR [rsp+0x2c0],r10
  8fba08:	mov    DWORD PTR [rsp+0x140],r11d
  8fba10:	mov    QWORD PTR [rsp+0x2e0],r8
  8fba18:	vmovdqa xmm0,XMMWORD PTR [rcx]
  8fba1c:	vmovdqa XMMWORD PTR [rsp+0x580],xmm0
  8fba25:	movzx  r14d,BYTE PTR [rsp+0x58c]
  8fba2e:	test   r14b,r14b
  8fba31:	jne    8fbb30 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1800>
  8fba37:	mov    r13,QWORD PTR [rsp+0x30]
  8fba3c:	mov    r12,QWORD PTR [rsp+0x38]
  8fba41:	mov    r14,QWORD PTR [rsp+0x8]
  8fba46:	mov    rbx,QWORD PTR [rsp+0x60]
  8fba4b:	mov    r8,QWORD PTR [rsp+0x2e0]
  8fba53:	mov    r11d,DWORD PTR [rsp+0x140]
  8fba5b:	movzx  edi,BYTE PTR [rsp+0x70]
  8fba60:	mov    r10,QWORD PTR [rsp+0x2c0]
  8fba68:	nop    DWORD PTR [rax+rax*1+0x0]
  8fba70:	add    r8,r10
  8fba73:	test   dil,0x1
  8fba77:	mov    QWORD PTR [rsp+0x2e0],r8
  8fba7f:	je     8fc1d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1ea0>
  8fba85:	cmp    r8,QWORD PTR [r14+0x18]
  8fba89:	jae    8fc1d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1ea0>
  8fba8f:	mov    rcx,QWORD PTR [r14+0x10]
  8fba93:	mov    rsi,r8
  8fba96:	shl    rsi,0x4
  8fba9a:	mov    BYTE PTR [rsp+0x70],dil
  8fba9f:	movzx  edi,BYTE PTR [rcx+rsi*1+0xd]
  8fbaa4:	cmp    dil,BYTE PTR [r14+0x6c]
  8fbaa8:	movzx  edi,BYTE PTR [rsp+0x70]
  8fbaad:	jne    8fc1d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1ea0>
  8fbab3:	add    rcx,rsi
  8fbab6:	cmp    BYTE PTR [rcx+0xc],0x0
  8fbaba:	je     8fc1d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1ea0>
  8fbac0:	mov    QWORD PTR [rsp+0x240],r15
  8fbac8:	mov    DWORD PTR [rsp+0x140],r11d
  8fbad0:	vmovdqa xmm0,XMMWORD PTR [rcx]
  8fbad4:	vmovdqa XMMWORD PTR [rsp+0x580],xmm0
  8fbadd:	movzx  ebx,BYTE PTR [rsp+0x58c]
  8fbae5:	test   bl,bl
  8fbae7:	je     8fc1aa <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1e7a>
  8fbaed:	mov    rcx,QWORD PTR [rsp+0x40]
  8fbaf2:	add    rcx,QWORD PTR [rsp+0xc0]
  8fbafa:	mov    QWORD PTR [rsp+0x40],rcx
  8fbaff:	jmp    8fbe8d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b5d>
  8fbb04:	jmp    8fc1da <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1eaa>
  8fbb09:	mov    dil,0x1
  8fbb0c:	shl    dil,cl
  8fbb0f:	mov    r8,QWORD PTR [rsp+0x1c0]
  8fbb17:	mov    DWORD PTR [rsi+rcx*4],r8d
  8fbb1b:	or     BYTE PTR [rsi+0xc],dil
  8fbb1f:	nop
  8fbb20:	lea    ecx,[r14-0x1]
  8fbb24:	and    cl,r14b
  8fbb27:	mov    r14d,ecx
  8fbb2a:	je     8fba37 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1707>
  8fbb30:	movzx  ecx,r14b
  8fbb34:	tzcnt  ecx,ecx
  8fbb38:	cmp    cl,0x3
  8fbb3b:	jae    8fba37 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1707>
  8fbb41:	mov    r8d,DWORD PTR [rsp+rcx*4+0x580]
  8fbb49:	mov    r12d,r8d
  8fbb4c:	shr    r12d,0x10
  8fbb50:	mov    r10,QWORD PTR [rsp+0x8]
  8fbb55:	mov    esi,DWORD PTR [r10+0x50]
  8fbb59:	mov    DWORD PTR [rsp+0x240],esi
  8fbb60:	andn   edi,esi,r12d
  8fbb65:	cmp    QWORD PTR [r10+0x38],0x1
  8fbb6a:	sete   sil
  8fbb6e:	mov    r11,QWORD PTR [r10+0x48]
  8fbb72:	mov    QWORD PTR [rsp+0x100],r11
  8fbb7a:	shrx   rsi,r11,rsi
  8fbb7f:	mov    QWORD PTR [rsp+0x300],rdi
  8fbb87:	mov    QWORD PTR [rsp+0x220],rsi
  8fbb8f:	sub    rdi,rsi
  8fbb92:	mov    esi,0x0
  8fbb97:	cmovae rsi,rdi
  8fbb9b:	mov    QWORD PTR [rsp+0x1c0],r8
  8fbba3:	movzx  r8d,r8w
  8fbba7:	mov    QWORD PTR [rsp+0x120],r8
  8fbbaf:	sub    r8,QWORD PTR [r10+0x30]
  8fbbb3:	jb     8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbbb9:	mov    r11,QWORD PTR [rsp+0x8]
  8fbbbe:	imul   r8,QWORD PTR [r11+0x58]
  8fbbc3:	add    r8,r12
  8fbbc6:	mov    r10,QWORD PTR [r11+0x8]
  8fbbca:	mov    rbx,QWORD PTR [r11+0x20]
  8fbbce:	imul   rbx,r8
  8fbbd2:	mov    rdi,QWORD PTR [rsp+0xa0]
  8fbbda:	lea    r11,[rbx+rdi*1]
  8fbbde:	cmp    r11,r10
  8fbbe1:	jae    8fbc01 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x18d1>
  8fbbe3:	mov    r13,QWORD PTR [rsp+0x8]
  8fbbe8:	mov    r13,QWORD PTR [r13+0x0]
  8fbbec:	mov    rdi,r15
  8fbbef:	xor    r15d,r15d
  8fbbf2:	cmp    r15w,WORD PTR [r13+r11*4+0x0]
  8fbbf8:	mov    r15,rdi
  8fbbfb:	jno    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbc01:	add    rbx,QWORD PTR [rsp+0x200]
  8fbc09:	cmp    rbx,r10
  8fbc0c:	jae    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbc12:	mov    r13,QWORD PTR [rsp+0x8]
  8fbc17:	mov    rdi,QWORD PTR [r13+0x0]
  8fbc1b:	movsx  r13d,WORD PTR [rdi+rbx*4]
  8fbc20:	cmp    r13d,0xffff8000
  8fbc27:	je     8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbc2d:	add    r13d,DWORD PTR [rsp+0x140]
  8fbc35:	cmp    r13d,0xfffff802
  8fbc3c:	jge    8fbc44 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1914>
  8fbc3e:	mov    r13d,0xfffff801
  8fbc44:	cmp    r13d,0x7ff
  8fbc4b:	jl     8fbc53 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1923>
  8fbc4d:	mov    r13d,0x7ff
  8fbc53:	mov    QWORD PTR [rsp+0x3a0],rdi
  8fbc5b:	movsx  edi,WORD PTR [rdi+rbx*4+0x2]
  8fbc60:	add    edi,DWORD PTR [rsp+0x160]
  8fbc67:	cmp    edi,0xfffff802
  8fbc6d:	jge    8fbd18 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x19e8>
  8fbc73:	mov    edi,0xfffff801
  8fbc78:	cmp    edi,0x7ff
  8fbc7e:	jge    8fbd24 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x19f4>
  8fbc84:	cmp    r11,r10
  8fbc87:	jae    8fbc9c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x196c>
  8fbc89:	mov    r10,QWORD PTR [rsp+0x3a0]
  8fbc91:	mov    WORD PTR [r10+r11*4],r13w
  8fbc96:	mov    WORD PTR [r10+r11*4+0x2],di
  8fbc9c:	mov    r10d,r13d
  8fbc9f:	neg    r10d
  8fbca2:	cmovs  r10d,r13d
  8fbca6:	mov    r11d,edi
  8fbca9:	neg    r11d
  8fbcac:	cmovs  r11d,edi
  8fbcb0:	cmp    r10d,r11d
  8fbcb3:	cmova  r11d,r10d
  8fbcb7:	cmp    r11d,0x40
  8fbcbb:	jae    8fbd37 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1a07>
  8fbcbd:	mov    rsi,QWORD PTR [rsp+0x8]
  8fbcc2:	mov    rdi,QWORD PTR [rsi+0x28]
  8fbcc6:	cmp    r8,rdi
  8fbcc9:	jae    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbccf:	imul   rdi,QWORD PTR [rsp+0xa0]
  8fbcd8:	add    rdi,r8
  8fbcdb:	mov    rsi,QWORD PTR [rsp+0x8]
  8fbce0:	cmp    rdi,QWORD PTR [rsi+0x18]
  8fbce4:	jae    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbcea:	mov    rsi,QWORD PTR [rsp+0x8]
  8fbcef:	movzx  r8d,BYTE PTR [rsi+0x6c]
  8fbcf4:	mov    r10,QWORD PTR [rsi+0x10]
  8fbcf8:	shl    rdi,0x4
  8fbcfc:	lea    rsi,[r10+rdi*1]
  8fbd00:	cmp    BYTE PTR [r10+rdi*1+0xd],r8b
  8fbd05:	je     8fbb09 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17d9>
  8fbd0b:	mov    BYTE PTR [rsi+0xd],r8b
  8fbd0f:	mov    BYTE PTR [rsi+0xc],0x0
  8fbd13:	jmp    8fbb09 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17d9>
  8fbd18:	cmp    edi,0x7ff
  8fbd1e:	jl     8fbc84 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1954>
  8fbd24:	mov    edi,0x7ff
  8fbd29:	cmp    r11,r10
  8fbd2c:	jb     8fbc89 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1959>
  8fbd32:	jmp    8fbc9c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x196c>
  8fbd37:	lea    r8d,[r13+0x3f]
  8fbd3b:	test   r13d,r13d
  8fbd3e:	cmovns r8d,r13d
  8fbd42:	movsx  r10d,r8w
  8fbd46:	sar    r10d,0x6
  8fbd4a:	add    r10d,DWORD PTR [rsp+0x120]
  8fbd52:	js     8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbd58:	mov    r8,QWORD PTR [rsp+0x8]
  8fbd5d:	cmp    QWORD PTR [r8+0x60],r10
  8fbd61:	jbe    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbd67:	lea    r8d,[rdi+0x3f]
  8fbd6b:	test   edi,edi
  8fbd6d:	cmovns r8d,edi
  8fbd71:	movsx  r8d,r8w
  8fbd75:	sar    r8d,0x6
  8fbd79:	add    r12d,r8d
  8fbd7c:	mov    r8,QWORD PTR [rsp+0x8]
  8fbd81:	mov    r8,QWORD PTR [r8+0x58]
  8fbd85:	setns  bl
  8fbd88:	mov    r11d,r12d
  8fbd8b:	cmp    r8,r11
  8fbd8e:	seta   r12b
  8fbd92:	and    r12b,bl
  8fbd95:	cmp    r12b,0x1
  8fbd99:	jne    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbd9f:	mov    rbx,QWORD PTR [rsp+0x8]
  8fbda4:	mov    ebx,DWORD PTR [rbx+0x40]
  8fbda7:	andn   r11d,ebx,r11d
  8fbdac:	cmp    r11,rsi
  8fbdaf:	jb     8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbdb5:	mov    esi,DWORD PTR [rsp+0x240]
  8fbdbc:	andn   edi,esi,DWORD PTR [rsp+0x120]
  8fbdc6:	andn   esi,ebx,r10d
  8fbdcb:	cmp    esi,edi
  8fbdcd:	jb     8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbdd3:	add    rdi,QWORD PTR [rsp+0x100]
  8fbddb:	cmp    rsi,rdi
  8fbdde:	jae    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbde4:	mov    rdi,QWORD PTR [rsp+0x100]
  8fbdec:	add    rdi,QWORD PTR [rsp+0x220]
  8fbdf4:	add    rdi,QWORD PTR [rsp+0x300]
  8fbdfc:	cmp    r11,rdi
  8fbdff:	jae    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbe05:	mov    rdi,QWORD PTR [rsp+0x8]
  8fbe0a:	sub    rsi,QWORD PTR [rdi+0x30]
  8fbe0e:	jb     8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbe14:	imul   rsi,r8
  8fbe18:	add    rsi,r11
  8fbe1b:	mov    rdi,QWORD PTR [rsp+0x8]
  8fbe20:	mov    rdi,QWORD PTR [rdi+0x28]
  8fbe24:	cmp    rsi,rdi
  8fbe27:	jae    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbe2d:	imul   rdi,QWORD PTR [rsp+0xa0]
  8fbe36:	add    rdi,rsi
  8fbe39:	mov    rsi,QWORD PTR [rsp+0x8]
  8fbe3e:	cmp    rdi,QWORD PTR [rsi+0x18]
  8fbe42:	jae    8fbb20 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f0>
  8fbe48:	jmp    8fbcea <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x19ba>
  8fbe4d:	mov    BYTE PTR [rsi+0xd],r8b
  8fbe51:	mov    rcx,QWORD PTR [rsp+0x1c0]
  8fbe59:	mov    BYTE PTR [rsi+0xc],0x0
  8fbe5d:	mov    dil,0x1
  8fbe60:	shl    dil,cl
  8fbe63:	mov    r8,QWORD PTR [rsp+0x100]
  8fbe6b:	mov    DWORD PTR [rsi+rcx*4],r8d
  8fbe6f:	or     BYTE PTR [rsi+0xc],dil
  8fbe73:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8fbe80:	lea    ecx,[rbx-0x1]
  8fbe83:	and    cl,bl
  8fbe85:	mov    ebx,ecx
  8fbe87:	je     8fc1aa <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1e7a>
  8fbe8d:	movzx  ecx,bl
  8fbe90:	tzcnt  ecx,ecx
  8fbe94:	cmp    cl,0x3
  8fbe97:	jae    8fc1aa <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1e7a>
  8fbe9d:	mov    QWORD PTR [rsp+0x1c0],rcx
  8fbea5:	mov    r15d,DWORD PTR [rsp+rcx*4+0x580]
  8fbead:	mov    QWORD PTR [rsp+0x100],r15
  8fbeb5:	shr    r15d,0x10
  8fbeb9:	mov    ecx,DWORD PTR [r14+0x50]
  8fbebd:	andn   esi,ecx,r15d
  8fbec2:	mov    r8,QWORD PTR [r14+0x48]
  8fbec6:	cmp    QWORD PTR [r14+0x38],0x1
  8fbecb:	sete   dil
  8fbecf:	mov    QWORD PTR [rsp+0x120],r8
  8fbed7:	shrx   r11,r8,rdi
  8fbedc:	mov    rdi,rsi
  8fbedf:	sub    rdi,r11
  8fbee2:	mov    r10d,0x0
  8fbee8:	cmovae r10,rdi
  8fbeec:	cmp    QWORD PTR [rsp+0x40],r10
  8fbef1:	jb     8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fbef3:	add    r11,QWORD PTR [rsp+0x120]
  8fbefb:	add    r11,rsi
  8fbefe:	cmp    QWORD PTR [rsp+0x40],r11
  8fbf03:	jae    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fbf09:	movzx  esi,WORD PTR [rsp+0x100]
  8fbf11:	mov    QWORD PTR [rsp+0x300],rsi
  8fbf19:	sub    rsi,QWORD PTR [r14+0x30]
  8fbf1d:	jb     8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fbf23:	imul   rsi,QWORD PTR [r14+0x58]
  8fbf28:	add    rsi,r15
  8fbf2b:	mov    r12,QWORD PTR [r14+0x8]
  8fbf2f:	mov    r8,QWORD PTR [r14+0x20]
  8fbf33:	imul   r8,rsi
  8fbf37:	mov    rdi,QWORD PTR [rsp+0x200]
  8fbf3f:	lea    r13,[r8+rdi*1]
  8fbf43:	mov    QWORD PTR [rsp+0x2c0],r13
  8fbf4b:	mov    QWORD PTR [rsp+0x220],r12
  8fbf53:	cmp    r13,r12
  8fbf56:	mov    r13d,ecx
  8fbf59:	jae    8fbf80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1c50>
  8fbf5b:	mov    r14,QWORD PTR [rsp+0x8]
  8fbf60:	mov    r14,QWORD PTR [r14]
  8fbf63:	xor    edi,edi
  8fbf65:	mov    r13,QWORD PTR [rsp+0x2c0]
  8fbf6d:	cmp    di,WORD PTR [r14+r13*4]
  8fbf72:	mov    r13d,ecx
  8fbf75:	mov    r14,QWORD PTR [rsp+0x8]
  8fbf7a:	jno    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fbf80:	add    r8,QWORD PTR [rsp+0xa0]
  8fbf88:	cmp    r8,QWORD PTR [rsp+0x220]
  8fbf90:	jae    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fbf96:	mov    rcx,QWORD PTR [r14]
  8fbf99:	movsx  edi,WORD PTR [rcx+r8*4]
  8fbf9e:	cmp    edi,0xffff8000
  8fbfa4:	je     8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fbfaa:	sub    edi,DWORD PTR [rsp+0x140]
  8fbfb1:	cmp    edi,0xfffff802
  8fbfb7:	jge    8fc088 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1d58>
  8fbfbd:	mov    edi,0xfffff801
  8fbfc2:	cmp    edi,0x7ff
  8fbfc8:	jge    8fc094 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1d64>
  8fbfce:	movsx  r12d,WORD PTR [rcx+r8*4+0x2]
  8fbfd4:	sub    r12d,DWORD PTR [rsp+0x160]
  8fbfdc:	cmp    r12d,0xfffff802
  8fbfe3:	jge    8fc0b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1d84>
  8fbfe9:	mov    r12d,0xfffff801
  8fbfef:	cmp    r12d,0x7ff
  8fbff6:	mov    r8,QWORD PTR [rsp+0x2c0]
  8fbffe:	jge    8fc0c9 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1d99>
  8fc004:	cmp    r8,QWORD PTR [rsp+0x220]
  8fc00c:	jae    8fc019 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1ce9>
  8fc00e:	mov    WORD PTR [rcx+r8*4],di
  8fc013:	mov    WORD PTR [rcx+r8*4+0x2],r12w
  8fc019:	mov    rcx,rdi
  8fc01c:	neg    edi
  8fc01e:	cmovs  edi,ecx
  8fc021:	mov    r8d,r12d
  8fc024:	neg    r8d
  8fc027:	cmovs  r8d,r12d
  8fc02b:	cmp    edi,r8d
  8fc02e:	cmova  r8d,edi
  8fc032:	cmp    r8d,0x40
  8fc036:	jae    8fc0e2 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1db2>
  8fc03c:	mov    rdi,QWORD PTR [r14+0x28]
  8fc040:	cmp    rsi,rdi
  8fc043:	jae    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc049:	imul   rdi,QWORD PTR [rsp+0x200]
  8fc052:	add    rdi,rsi
  8fc055:	cmp    rdi,QWORD PTR [r14+0x18]
  8fc059:	jae    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc05f:	movzx  r8d,BYTE PTR [r14+0x6c]
  8fc064:	mov    r10,QWORD PTR [r14+0x10]
  8fc068:	shl    rdi,0x4
  8fc06c:	lea    rsi,[r10+rdi*1]
  8fc070:	cmp    BYTE PTR [r10+rdi*1+0xd],r8b
  8fc075:	jne    8fbe4d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b1d>
  8fc07b:	mov    rcx,QWORD PTR [rsp+0x1c0]
  8fc083:	jmp    8fbe5d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b2d>
  8fc088:	cmp    edi,0x7ff
  8fc08e:	jl     8fbfce <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1c9e>
  8fc094:	mov    edi,0x7ff
  8fc099:	movsx  r12d,WORD PTR [rcx+r8*4+0x2]
  8fc09f:	sub    r12d,DWORD PTR [rsp+0x160]
  8fc0a7:	cmp    r12d,0xfffff802
  8fc0ae:	jl     8fbfe9 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1cb9>
  8fc0b4:	cmp    r12d,0x7ff
  8fc0bb:	mov    r8,QWORD PTR [rsp+0x2c0]
  8fc0c3:	jl     8fc004 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1cd4>
  8fc0c9:	mov    r12d,0x7ff
  8fc0cf:	cmp    r8,QWORD PTR [rsp+0x220]
  8fc0d7:	jb     8fc00e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1cde>
  8fc0dd:	jmp    8fc019 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1ce9>
  8fc0e2:	lea    esi,[rcx+0x3f]
  8fc0e5:	test   ecx,ecx
  8fc0e7:	cmovns esi,ecx
  8fc0ea:	movsx  esi,si
  8fc0ed:	sar    esi,0x6
  8fc0f0:	add    esi,DWORD PTR [rsp+0x300]
  8fc0f7:	js     8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc0fd:	cmp    QWORD PTR [r14+0x60],rsi
  8fc101:	jbe    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc107:	lea    edi,[r12+0x3f]
  8fc10c:	test   r12d,r12d
  8fc10f:	cmovns edi,r12d
  8fc113:	movsx  edi,di
  8fc116:	sar    edi,0x6
  8fc119:	add    r15d,edi
  8fc11c:	mov    rdi,QWORD PTR [r14+0x58]
  8fc120:	setns  r14b
  8fc124:	mov    r8d,r15d
  8fc127:	cmp    rdi,r8
  8fc12a:	seta   r15b
  8fc12e:	and    r15b,r14b
  8fc131:	mov    r14,QWORD PTR [rsp+0x8]
  8fc136:	cmp    r15b,0x1
  8fc13a:	jne    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc140:	mov    r15d,DWORD PTR [r14+0x40]
  8fc144:	andn   r8d,r15d,r8d
  8fc149:	cmp    r8,r11
  8fc14c:	jae    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc152:	cmp    r8,r10
  8fc155:	jb     8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc15b:	andn   r10d,r13d,DWORD PTR [rsp+0x300]
  8fc165:	andn   esi,r15d,esi
  8fc16a:	cmp    esi,r10d
  8fc16d:	jb     8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc173:	mov    r11,QWORD PTR [rsp+0x120]
  8fc17b:	add    r11,r10
  8fc17e:	cmp    rsi,r11
  8fc181:	jae    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc187:	sub    rsi,QWORD PTR [r14+0x30]
  8fc18b:	jb     8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc191:	imul   rsi,rdi
  8fc195:	add    rsi,r8
  8fc198:	mov    rdi,QWORD PTR [r14+0x28]
  8fc19c:	cmp    rsi,rdi
  8fc19f:	jae    8fbe80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1b50>
  8fc1a5:	jmp    8fc049 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1d19>
  8fc1aa:	mov    r13,QWORD PTR [rsp+0x30]
  8fc1af:	mov    r12,QWORD PTR [rsp+0x38]
  8fc1b4:	mov    rbx,QWORD PTR [rsp+0x60]
  8fc1b9:	mov    r11d,DWORD PTR [rsp+0x140]
  8fc1c1:	mov    r15,QWORD PTR [rsp+0x240]
  8fc1c9:	movzx  edi,BYTE PTR [rsp+0x70]
  8fc1ce:	xchg   ax,ax
  8fc1d0:	mov    r10d,edi
  8fc1d3:	and    r10b,0x2
  8fc1d7:	shr    r10b,1
  8fc1da:	mov    QWORD PTR [rsp+0x40],r9
  8fc1df:	test   dil,0x4
  8fc1e3:	je     8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc1e9:	mov    rcx,QWORD PTR [rsp+0x20]
  8fc1ee:	mov    ecx,DWORD PTR [rcx+rdx*4+0x600]
  8fc1f5:	mov    rsi,QWORD PTR [rsp+0x68]
  8fc1fa:	cmp    QWORD PTR [rsi+0x8],rcx
  8fc1fe:	jbe    8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc204:	mov    r9d,edi
  8fc207:	mov    rsi,QWORD PTR [rsp+0x68]
  8fc20c:	mov    rsi,QWORD PTR [rsi]
  8fc20f:	cmp    BYTE PTR [rsi+rcx*8+0x6],0x0
  8fc214:	je     8fc23d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1f0d>
  8fc216:	mov    rdi,QWORD PTR [rsp+0x40]
  8fc21b:	cmp    BYTE PTR [rdi+0x1b],0x1
  8fc21f:	jne    8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc225:	movsx  r8d,WORD PTR [rsi+rcx*8]
  8fc22a:	mov    rdi,QWORD PTR [rsp+0x40]
  8fc22f:	mov    edi,DWORD PTR [rdi+0x10]
  8fc232:	cmp    edi,r8d
  8fc235:	je     8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc23b:	jmp    8fc245 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1f15>
  8fc23d:	mov    rdi,QWORD PTR [rsp+0x40]
  8fc242:	mov    edi,DWORD PTR [rdi+0x10]
  8fc245:	mov    DWORD PTR [rsp+0xa0],edi
  8fc24c:	mov    r8d,r11d
  8fc24f:	neg    r8d
  8fc252:	mov    DWORD PTR [rsp+0x140],r11d
  8fc25a:	mov    QWORD PTR [rsp+0x240],r15
  8fc262:	mov    r15d,DWORD PTR [rsp+0x160]
  8fc26a:	mov    r11d,r15d
  8fc26d:	neg    r11d
  8fc270:	mov    rdi,QWORD PTR [rsp+0x40]
  8fc275:	cmp    BYTE PTR [rdi+0x1a],0x0
  8fc279:	cmove  r8d,DWORD PTR [rsp+0x140]
  8fc282:	cmove  r11d,r15d
  8fc286:	shl    r11d,0x10
  8fc28a:	movzx  r8d,r8w
  8fc28e:	or     r8d,r11d
  8fc291:	mov    edi,DWORD PTR [rsp+0xa0]
  8fc298:	mov    WORD PTR [rsi+rcx*8],di
  8fc29c:	mov    DWORD PTR [rsi+rcx*8+0x2],r8d
  8fc2a1:	mov    BYTE PTR [rsi+rcx*8+0x6],0x1
  8fc2a6:	test   r9b,0x10
  8fc2aa:	je     8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc2b0:	mov    rcx,QWORD PTR [rsp+0x20]
  8fc2b5:	mov    edi,DWORD PTR [rcx+rdx*4+0x700]
  8fc2bc:	cmp    QWORD PTR [r14+0x28],rdi
  8fc2c0:	jbe    8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc2c6:	mov    r11,r14
  8fc2c9:	mov    rsi,QWORD PTR [rsp+0x20]
  8fc2ce:	mov    r14d,DWORD PTR [rsi+rdx*4+0x200]
  8fc2d6:	mov    r15d,DWORD PTR [rsi+rdx*4+0x300]
  8fc2de:	mov    rcx,QWORD PTR [rsp+0x40]
  8fc2e3:	mov    rbx,QWORD PTR [rcx]
  8fc2e6:	mov    r9,QWORD PTR [rcx+0x8]
  8fc2ea:	movsxd rcx,DWORD PTR [rsi+rdx*4+0x500]
  8fc2f2:	mov    esi,DWORD PTR [rsi+rdx*4+0x400]
  8fc2f9:	movzx  edx,BYTE PTR [r11+0x68]
  8fc2fe:	shrx   rdx,rcx,rdx
  8fc303:	movabs r8,0xaaaaaaaaaaaaaaab
  8fc30d:	mulx   r8,r8,r8
  8fc312:	shr    r8,1
  8fc315:	lea    r8,[r8+r8*2]
  8fc319:	sub    rdx,r8
  8fc31c:	mov    r8d,esi
  8fc31f:	or     r8d,ecx
  8fc322:	shl    rcx,0x20
  8fc326:	shl    rsi,0x10
  8fc32a:	add    rsi,rcx
  8fc32d:	cmp    r8d,0xffff
  8fc334:	ja     8fc3b2 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2082>
  8fc336:	mov    rcx,QWORD PTR [rsp+0x240]
  8fc33e:	cmp    rcx,QWORD PTR [r11+0x18]
  8fc342:	jae    8fc3b2 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2082>
  8fc344:	movzx  ecx,BYTE PTR [r11+0x6c]
  8fc349:	mov    r13,QWORD PTR [r11+0x10]
  8fc34d:	mov    r11,QWORD PTR [rsp+0x240]
  8fc355:	shl    r11,0x4
  8fc359:	lea    r12,[r11+r13*1]
  8fc35d:	cmp    BYTE PTR [r13+r11*1+0xd],cl
  8fc362:	jne    8fc373 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2043>
  8fc364:	movzx  ecx,BYTE PTR [r12+0xc]
  8fc36a:	mov    DWORD PTR [rsp+0xa0],ecx
  8fc371:	jmp    8fc383 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2053>
  8fc373:	mov    BYTE PTR [r12+0xd],cl
  8fc378:	mov    DWORD PTR [rsp+0xa0],0x0
  8fc383:	mov    r13,rsi
  8fc386:	mov    r11b,0x1
  8fc389:	mov    ecx,edx
  8fc38b:	shl    r11b,cl
  8fc38e:	shr    r13,0x10
  8fc392:	mov    DWORD PTR [r12+rdx*4],r13d
  8fc396:	or     r11b,BYTE PTR [rsp+0xa0]
  8fc39e:	mov    BYTE PTR [r12+0xc],r11b
  8fc3a3:	mov    r13,QWORD PTR [rsp+0x30]
  8fc3a8:	mov    r12,QWORD PTR [rsp+0x38]
  8fc3ad:	mov    r11,QWORD PTR [rsp+0x8]
  8fc3b2:	mov    rcx,QWORD PTR [r11+0x20]
  8fc3b6:	imul   rcx,rdi
  8fc3ba:	add    rcx,QWORD PTR [rsp+0x200]
  8fc3c2:	cmp    rcx,QWORD PTR [r11+0x8]
  8fc3c6:	jae    8fc40a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x20da>
  8fc3c8:	vmovd  xmm0,r14d
  8fc3cd:	vpinsrd xmm0,xmm0,r15d,0x1
  8fc3d3:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71c9b4]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8fc3dc:	vpxor  xmm2,xmm2,xmm2
  8fc3e0:	vpsubd xmm0,xmm2,xmm0
  8fc3e4:	vpmaxsd xmm0,xmm0,xmm1
  8fc3e9:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71c956]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8fc3f2:	mov    r11,QWORD PTR [rsp+0x8]
  8fc3f7:	mov    r11,QWORD PTR [r11]
  8fc3fa:	vpminsd xmm0,xmm0,xmm1
  8fc3ff:	vpshuflw xmm0,xmm0,0xe8
  8fc404:	vmovd  DWORD PTR [r11+rcx*4],xmm0
  8fc40a:	test   rbx,rbx
  8fc40d:	mov    r14,QWORD PTR [rsp+0x8]
  8fc412:	mov    rbx,QWORD PTR [rsp+0x60]
  8fc417:	mov    ecx,DWORD PTR [rsp+0x140]
  8fc41e:	je     8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc424:	imul   rdi,QWORD PTR [r14+0x20]
  8fc429:	add    rdi,r9
  8fc42c:	cmp    rdi,QWORD PTR [r14+0x8]
  8fc430:	jae    8fc49a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x216a>
  8fc432:	mov    r9,QWORD PTR [rsp+0x40]
  8fc437:	vmovd  xmm0,DWORD PTR [r9+0x14]
  8fc43d:	vpbroadcastd xmm0,xmm0
  8fc442:	vmovd  xmm1,ecx
  8fc446:	vpinsrd xmm1,xmm1,DWORD PTR [rsp+0x160],0x1
  8fc451:	vpmulld xmm0,xmm0,xmm1
  8fc456:	mov    rcx,QWORD PTR [r14]
  8fc459:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71cb76]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8fc462:	vpsrad xmm2,xmm0,0x1f
  8fc467:	vpaddd xmm0,xmm0,xmm1
  8fc46b:	vpaddd xmm0,xmm0,xmm2
  8fc46f:	vpsrad xmm0,xmm0,0xe
  8fc474:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71c913]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8fc47d:	vpbroadcastd xmm2,DWORD PTR [rip+0xffffffffff71c8c2]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8fc486:	vpmaxsd xmm0,xmm0,xmm1
  8fc48b:	vpminsd xmm0,xmm0,xmm2
  8fc490:	vpshuflw xmm0,xmm0,0xe8
  8fc495:	vmovd  DWORD PTR [rcx+rdi*4],xmm0
  8fc49a:	test   r10b,r10b
  8fc49d:	je     8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc4a3:	cmp    r8d,0xffff
  8fc4aa:	ja     8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc4b0:	mov    rcx,QWORD PTR [rsp+0x2e0]
  8fc4b8:	cmp    rcx,QWORD PTR [r14+0x18]
  8fc4bc:	jae    8fb930 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1600>
  8fc4c2:	movzx  ecx,BYTE PTR [r14+0x6c]
  8fc4c7:	mov    r8,QWORD PTR [r14+0x10]
  8fc4cb:	mov    r9,QWORD PTR [rsp+0x2e0]
  8fc4d3:	shl    r9,0x4
  8fc4d7:	lea    rdi,[r8+r9*1]
  8fc4db:	cmp    BYTE PTR [r8+r9*1+0xd],cl
  8fc4e0:	je     8fb910 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x15e0>
  8fc4e6:	mov    BYTE PTR [rdi+0xd],cl
  8fc4e9:	xor    r8d,r8d
  8fc4ec:	jmp    8fb915 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x15e5>
  8fc4f1:	movzx  r8d,BYTE PTR [rsi+0xc]
  8fc4f6:	mov    dil,0x1
  8fc4f9:	mov    ecx,edx
  8fc4fb:	shl    dil,cl
  8fc4fe:	shr    r11,0x10
  8fc502:	mov    DWORD PTR [rsi+rdx*4],r11d
  8fc506:	or     dil,r8b
  8fc509:	mov    BYTE PTR [rsi+0xc],dil
  8fc50d:	nop    DWORD PTR [rax]
  8fc510:	blsr   rax,rax
  8fc515:	mov    r12,QWORD PTR [rsp+0x38]
  8fc51a:	mov    r14,QWORD PTR [rsp+0x8]
  8fc51f:	mov    r15,QWORD PTR [rsp+0x60]
  8fc524:	je     8fa960 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x630>
  8fc52a:	tzcnt  rcx,rax
  8fc52f:	movzx  r10d,BYTE PTR [r15+rcx*1]
  8fc534:	cmp    r10d,0x9
  8fc538:	jae    8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc53a:	shl    r10d,0x5
  8fc53e:	add    r10,QWORD PTR [rsp+0x38]
  8fc543:	mov    rdx,QWORD PTR [rsp+0x10]
  8fc548:	movzx  edx,BYTE PTR [rdx+rcx*1+0xc40]
  8fc550:	mov    esi,edx
  8fc552:	not    sil
  8fc555:	test   sil,0xa
  8fc559:	sete   r9b
  8fc55d:	and    r9b,BYTE PTR [r10]
  8fc560:	cmp    r9b,0x1
  8fc564:	jne    8fc584 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2254>
  8fc566:	mov    rsi,QWORD PTR [rsp+0x8]
  8fc56b:	mov    rsi,QWORD PTR [rsi+0x28]
  8fc56f:	imul   rsi,QWORD PTR [r10+0x8]
  8fc574:	mov    rdi,QWORD PTR [rsp+0x20]
  8fc579:	mov    r8d,DWORD PTR [rdi+rcx*4+0x800]
  8fc581:	add    r8,rsi
  8fc584:	test   dl,0x4
  8fc587:	je     8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc589:	mov    rsi,QWORD PTR [rsp+0x20]
  8fc58e:	mov    esi,DWORD PTR [rsi+rcx*4+0x600]
  8fc595:	mov    rdi,QWORD PTR [rsp+0x68]
  8fc59a:	cmp    QWORD PTR [rdi+0x8],rsi
  8fc59e:	jbe    8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc5a4:	mov    rdi,QWORD PTR [rsp+0x10]
  8fc5a9:	mov    ebx,DWORD PTR [rdi+rcx*4+0x300]
  8fc5b0:	mov    r14d,DWORD PTR [rdi+rcx*4+0x400]
  8fc5b8:	mov    rdi,QWORD PTR [rsp+0x68]
  8fc5bd:	mov    r11,QWORD PTR [rdi]
  8fc5c0:	cmp    BYTE PTR [r11+rsi*8+0x6],0x0
  8fc5c6:	je     8fc5e7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x22b7>
  8fc5c8:	cmp    BYTE PTR [r10+0x1b],0x1
  8fc5cd:	jne    8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc5d3:	movsx  edi,WORD PTR [r11+rsi*8]
  8fc5d8:	mov    r15d,DWORD PTR [r10+0x10]
  8fc5dc:	cmp    r15d,edi
  8fc5df:	je     8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc5e5:	jmp    8fc5eb <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x22bb>
  8fc5e7:	mov    r15d,DWORD PTR [r10+0x10]
  8fc5eb:	mov    edi,ebx
  8fc5ed:	neg    edi
  8fc5ef:	mov    r12d,r14d
  8fc5f2:	neg    r12d
  8fc5f5:	cmp    BYTE PTR [r10+0x1a],0x0
  8fc5fa:	cmove  edi,ebx
  8fc5fd:	cmove  r12d,r14d
  8fc601:	shl    r12d,0x10
  8fc605:	movzx  edi,di
  8fc608:	or     edi,r12d
  8fc60b:	mov    WORD PTR [r11+rsi*8],r15w
  8fc610:	mov    DWORD PTR [r11+rsi*8+0x2],edi
  8fc615:	mov    BYTE PTR [r11+rsi*8+0x6],0x1
  8fc61b:	test   dl,0x10
  8fc61e:	je     8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc624:	mov    rdx,QWORD PTR [rsp+0x20]
  8fc629:	mov    r15d,DWORD PTR [rdx+rcx*4+0x700]
  8fc631:	mov    rdx,QWORD PTR [rsp+0x8]
  8fc636:	cmp    QWORD PTR [rdx+0x28],r15
  8fc63a:	jbe    8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc640:	mov    rdx,QWORD PTR [rsp+0x20]
  8fc645:	mov    esi,DWORD PTR [rdx+rcx*4+0x200]
  8fc64c:	mov    DWORD PTR [rsp+0x70],esi
  8fc650:	mov    esi,DWORD PTR [rdx+rcx*4+0x300]
  8fc657:	mov    DWORD PTR [rsp+0x120],esi
  8fc65e:	mov    rsi,QWORD PTR [r10]
  8fc661:	mov    QWORD PTR [rsp+0x1e0],rsi
  8fc669:	mov    rsi,QWORD PTR [r10+0x8]
  8fc66d:	mov    QWORD PTR [rsp+0xa0],rsi
  8fc675:	movsxd rsi,DWORD PTR [rdx+rcx*4+0x500]
  8fc67d:	mov    r11d,DWORD PTR [rdx+rcx*4+0x400]
  8fc685:	mov    r12,QWORD PTR [rsp+0x8]
  8fc68a:	movzx  edx,BYTE PTR [r12+0x68]
  8fc690:	shrx   rdx,rsi,rdx
  8fc695:	movabs rdi,0xaaaaaaaaaaaaaaab
  8fc69f:	mulx   rdi,rdi,rdi
  8fc6a4:	shr    rdi,1
  8fc6a7:	lea    rdi,[rdi+rdi*2]
  8fc6ab:	sub    rdx,rdi
  8fc6ae:	mov    edi,r11d
  8fc6b1:	or     edi,esi
  8fc6b3:	shl    rsi,0x20
  8fc6b7:	shl    r11,0x10
  8fc6bb:	add    r11,rsi
  8fc6be:	cmp    edi,0xffff
  8fc6c4:	ja     8fc743 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2413>
  8fc6c6:	imul   rcx,r13
  8fc6ca:	add    rcx,QWORD PTR [rsp+0x160]
  8fc6d2:	cmp    rcx,QWORD PTR [r12+0x18]
  8fc6d7:	jae    8fc743 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2413>
  8fc6d9:	movzx  esi,BYTE PTR [r12+0x6c]
  8fc6df:	mov    r13,QWORD PTR [r12+0x10]
  8fc6e4:	shl    rcx,0x4
  8fc6e8:	lea    r12,[rcx+r13*1]
  8fc6ec:	cmp    BYTE PTR [r13+rcx*1+0xd],sil
  8fc6f1:	jne    8fc705 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x23d5>
  8fc6f3:	mov    rsi,r12
  8fc6f6:	movzx  ecx,BYTE PTR [r12+0xc]
  8fc6fc:	mov    DWORD PTR [rsp+0x100],ecx
  8fc703:	jmp    8fc71a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x23ea>
  8fc705:	mov    ecx,esi
  8fc707:	mov    rsi,r12
  8fc70a:	mov    BYTE PTR [r12+0xd],cl
  8fc70f:	mov    DWORD PTR [rsp+0x100],0x0
  8fc71a:	mov    r12,r11
  8fc71d:	mov    r13b,0x1
  8fc720:	mov    ecx,edx
  8fc722:	shl    r13b,cl
  8fc725:	shr    r12,0x10
  8fc729:	mov    DWORD PTR [rsi+rdx*4],r12d
  8fc72d:	or     r13b,BYTE PTR [rsp+0x100]
  8fc735:	mov    BYTE PTR [rsi+0xc],r13b
  8fc739:	mov    r13,QWORD PTR [rsp+0x30]
  8fc73e:	mov    r12,QWORD PTR [rsp+0x8]
  8fc743:	mov    rcx,QWORD PTR [r12+0x20]
  8fc748:	imul   rcx,r15
  8fc74c:	add    rcx,QWORD PTR [rsp+0x40]
  8fc751:	cmp    rcx,QWORD PTR [r12+0x8]
  8fc756:	jae    8fc79f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x246f>
  8fc758:	vmovd  xmm0,DWORD PTR [rsp+0x70]
  8fc75e:	vpinsrd xmm0,xmm0,DWORD PTR [rsp+0x120],0x1
  8fc769:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71c61e]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8fc772:	vpxor  xmm2,xmm2,xmm2
  8fc776:	vpsubd xmm0,xmm2,xmm0
  8fc77a:	vpmaxsd xmm0,xmm0,xmm1
  8fc77f:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71c5c0]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8fc788:	mov    rsi,QWORD PTR [rsp+0x8]
  8fc78d:	mov    rsi,QWORD PTR [rsi]
  8fc790:	vpminsd xmm0,xmm0,xmm1
  8fc795:	vpshuflw xmm0,xmm0,0xe8
  8fc79a:	vmovd  DWORD PTR [rsi+rcx*4],xmm0
  8fc79f:	cmp    QWORD PTR [rsp+0x1e0],0x0
  8fc7a8:	je     8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc7ae:	mov    rcx,QWORD PTR [rsp+0x8]
  8fc7b3:	imul   r15,QWORD PTR [rcx+0x20]
  8fc7b8:	add    r15,QWORD PTR [rsp+0xa0]
  8fc7c0:	cmp    r15,QWORD PTR [rcx+0x8]
  8fc7c4:	jae    8fc82a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x24fa>
  8fc7c6:	vmovd  xmm0,DWORD PTR [r10+0x14]
  8fc7cc:	vpbroadcastd xmm0,xmm0
  8fc7d1:	vmovd  xmm1,ebx
  8fc7d5:	vpinsrd xmm1,xmm1,r14d,0x1
  8fc7db:	vpmulld xmm0,xmm0,xmm1
  8fc7e0:	mov    rcx,QWORD PTR [rsp+0x8]
  8fc7e5:	mov    rcx,QWORD PTR [rcx]
  8fc7e8:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71c7e7]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8fc7f1:	vpsrad xmm2,xmm0,0x1f
  8fc7f6:	vpaddd xmm0,xmm0,xmm1
  8fc7fa:	vpaddd xmm0,xmm0,xmm2
  8fc7fe:	vpsrad xmm0,xmm0,0xe
  8fc803:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71c584]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8fc80c:	vpbroadcastd xmm2,DWORD PTR [rip+0xffffffffff71c533]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8fc815:	vpmaxsd xmm0,xmm0,xmm1
  8fc81a:	vpminsd xmm0,xmm0,xmm2
  8fc81f:	vpshuflw xmm0,xmm0,0xe8
  8fc824:	vmovd  DWORD PTR [rcx+r15*4],xmm0
  8fc82a:	test   r9b,r9b
  8fc82d:	je     8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc833:	cmp    edi,0xffff
  8fc839:	ja     8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc83f:	mov    rcx,QWORD PTR [rsp+0x8]
  8fc844:	cmp    r8,QWORD PTR [rcx+0x18]
  8fc848:	jae    8fc510 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21e0>
  8fc84e:	mov    rsi,QWORD PTR [rsp+0x8]
  8fc853:	movzx  ecx,BYTE PTR [rsi+0x6c]
  8fc857:	mov    rdi,QWORD PTR [rsi+0x10]
  8fc85b:	shl    r8,0x4
  8fc85f:	lea    rsi,[rdi+r8*1]
  8fc863:	cmp    BYTE PTR [rdi+r8*1+0xd],cl
  8fc868:	je     8fc4f1 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21c1>
  8fc86e:	mov    BYTE PTR [rsi+0xd],cl
  8fc871:	xor    r8d,r8d
  8fc874:	jmp    8fc4f6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x21c6>
  8fc879:	cmp    rdi,0x7fffffff
  8fc880:	ja     8fd85d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x352d>
  8fc886:	vmovaps xmm0,XMMWORD PTR [rsp+0x360]
  8fc88f:	vmovaps XMMWORD PTR [rsp+0x160],xmm0
  8fc898:	vmovaps xmm0,XMMWORD PTR [rsp+0x370]
  8fc8a1:	vmovaps XMMWORD PTR [rsp+0x1e0],xmm0
  8fc8aa:	vmovaps xmm0,XMMWORD PTR [rsp+0x380]
  8fc8b3:	vmovaps XMMWORD PTR [rsp+0x40],xmm0
  8fc8b9:	vpbroadcastd ymm0,DWORD PTR [rsp+0x390]
  8fc8c3:	vmovdqa YMMWORD PTR [rsp+0xa0],ymm0
  8fc8cc:	xor    ebx,ebx
  8fc8ce:	mov    rcx,QWORD PTR [rsp+0x98]
  8fc8d6:	cmp    r8,rcx
  8fc8d9:	cmovb  rcx,r8
  8fc8dd:	lea    r9,[rcx+rcx*2]
  8fc8e1:	mov    rax,rcx
  8fc8e4:	or     rax,r13
  8fc8e7:	shr    rax,0x20
  8fc8eb:	je     8fc8fa <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x25ca>
  8fc8ed:	mov    rax,rcx
  8fc8f0:	xor    edx,edx
  8fc8f2:	div    r13
  8fc8f5:	mov    r10,rax
  8fc8f8:	jmp    8fc904 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x25d4>
  8fc8fa:	mov    eax,ecx
  8fc8fc:	xor    edx,edx
  8fc8fe:	div    r13d
  8fc901:	mov    r10d,eax
  8fc904:	mov    rdi,QWORD PTR [rsp+0x10]
  8fc909:	sub    r8,rcx
  8fc90c:	mov    QWORD PTR [rsp+0xd8],r8
  8fc914:	lea    rax,[rbx+0x1]
  8fc918:	mov    QWORD PTR [rsp+0x120],rax
  8fc920:	shl    rbx,0x6
  8fc924:	cmp    rdx,0x1
  8fc928:	sbb    r10,0xffffffffffffffff
  8fc92c:	cmp    r10,0x40
  8fc930:	mov    eax,0x40
  8fc935:	cmovae r10,rax
  8fc939:	mov    QWORD PTR [rsp+0x70],r10
  8fc93e:	lea    rax,[rsi+r9*2]
  8fc942:	mov    QWORD PTR [rsp+0x100],rax
  8fc94a:	add    rcx,rcx
  8fc94d:	lea    rax,[rcx+rcx*2]
  8fc951:	mov    rcx,QWORD PTR [rsp+0xc8]
  8fc959:	add    rsi,rcx
  8fc95c:	sub    rax,rcx
  8fc95f:	mov    ecx,0x0
  8fc964:	cmovb  rax,rcx
  8fc968:	imul   r10,QWORD PTR [rsp+0xd0]
  8fc971:	cmp    rax,r10
  8fc974:	cmovb  r10,rax
  8fc978:	cmp    r10,0x300
  8fc97f:	mov    eax,0x300
  8fc984:	cmovae r10,rax
  8fc988:	mov    rdx,r10
  8fc98b:	vzeroupper
  8fc98e:	call   QWORD PTR [rip+0x6e810c]        # fe4aa0 <memcpy@GLIBC_2.14>
  8fc994:	mov    rax,QWORD PTR [rsp+0x70]
  8fc999:	lea    ecx,[rax+0xf]
  8fc99c:	shr    ecx,0x4
  8fc99f:	xor    eax,eax
  8fc9a1:	xor    r8d,r8d
  8fc9a4:	vmovdqa xmm14,XMMWORD PTR [rsp+0x270]
  8fc9ad:	vmovdqa xmm15,XMMWORD PTR [rip+0xffffffffff71763b]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8fc9b5:	jmp    8fcda8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2a78>
  8fc9ba:	nop    WORD PTR [rax+rax*1+0x0]
  8fc9c0:	mov    r9,rsi
  8fc9c3:	mov    rsi,r8
  8fc9c6:	vpunpckhqdq xmm7,xmm7,xmm8
  8fc9cb:	vpunpckhdq xmm5,xmm5,xmm6
  8fc9cf:	vpunpckhdq xmm3,xmm3,xmm4
  8fc9d3:	vpunpcklqdq xmm4,xmm3,xmm5
  8fc9d7:	vmovd  xmm3,edi
  8fc9db:	vpbroadcastd ymm3,xmm3
  8fc9e0:	mov    rdi,rsi
  8fc9e3:	shl    rdi,0x4
  8fc9e7:	vmovdqu XMMWORD PTR [r15+rdi*1],xmm1
  8fc9ed:	vmovdqa xmm1,XMMWORD PTR [rsp+0x160]
  8fc9f6:	vpshufb xmm1,xmm1,xmm2
  8fc9fb:	vmovdqa xmm5,XMMWORD PTR [rsp+0x1e0]
  8fca04:	vpshufb xmm2,xmm5,xmm2
  8fca09:	vpunpcklbw xmm6,xmm1,xmm2
  8fca0d:	vpunpckhbw xmm8,xmm1,xmm2
  8fca11:	vpmovsxbw ymm1,xmm7
  8fca16:	vpmovsxwd ymm2,xmm1
  8fca1b:	vextracti128 xmm1,ymm1,0x1
  8fca21:	vpmovsxwd ymm1,xmm1
  8fca26:	vpabsd ymm5,ymm2
  8fca2b:	vpabsd ymm7,ymm1
  8fca30:	vpsrld ymm9,ymm5,0x4
  8fca35:	vpbroadcastd ymm10,DWORD PTR [rip+0xffffffffff71c562]        # 18fa0 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  8fca3e:	vpsrld ymm11,ymm7,0x4
  8fca43:	vpmaxud ymm9,ymm9,ymm10
  8fca48:	vpcmpeqd ymm13,ymm13,ymm13
  8fca4d:	vpaddd ymm9,ymm9,ymm13
  8fca52:	vpmaxud ymm11,ymm11,ymm10
  8fca57:	vpaddd ymm11,ymm11,ymm13
  8fca5c:	vpslld ymm12,ymm9,0x4
  8fca62:	vpsubd ymm5,ymm5,ymm12
  8fca67:	vpslld ymm12,ymm11,0x4
  8fca6d:	vpsubd ymm7,ymm7,ymm12
  8fca72:	vpsllvd ymm5,ymm5,ymm9
  8fca77:	vpsllvd ymm7,ymm7,ymm11
  8fca7c:	vpsrad ymm2,ymm2,0x1f
  8fca81:	vpsrad ymm1,ymm1,0x1f
  8fca86:	vpxor  ymm5,ymm5,ymm2
  8fca8a:	vpxor  ymm7,ymm7,ymm1
  8fca8e:	vpsubd ymm5,ymm5,ymm2
  8fca92:	vpsubd ymm2,ymm7,ymm1
  8fca96:	vpmovsxbw ymm1,xmm4
  8fca9b:	vpmovsxwd ymm4,xmm1
  8fcaa0:	vextracti128 xmm1,ymm1,0x1
  8fcaa6:	vpmovsxwd ymm7,xmm1
  8fcaab:	vpabsd ymm1,ymm4
  8fcab0:	vpabsd ymm9,ymm7
  8fcab5:	vpsrld ymm11,ymm1,0x4
  8fcaba:	vpsrld ymm12,ymm9,0x4
  8fcac0:	vpmaxud ymm11,ymm11,ymm10
  8fcac5:	vpaddd ymm11,ymm11,ymm13
  8fcaca:	vpmaxud ymm10,ymm12,ymm10
  8fcacf:	vpaddd ymm10,ymm10,ymm13
  8fcad4:	vpslld ymm12,ymm11,0x4
  8fcada:	vpsubd ymm12,ymm1,ymm12
  8fcadf:	vpslld ymm1,ymm10,0x4
  8fcae5:	vpsubd ymm9,ymm9,ymm1
  8fcae9:	vpaddd ymm1,ymm3,YMMWORD PTR [rsp+0x540]
  8fcaf2:	vpmovsxwd ymm6,xmm6
  8fcaf7:	vpmovsxwd ymm8,xmm8
  8fcafc:	vmovdqa ymm13,YMMWORD PTR [rsp+0xa0]
  8fcb05:	vpmulld ymm6,ymm13,ymm6
  8fcb0a:	vpmulld ymm13,ymm13,ymm8
  8fcb0f:	vpsllvd ymm8,ymm12,ymm11
  8fcb14:	vpsllvd ymm9,ymm9,ymm10
  8fcb19:	vpsrad ymm4,ymm4,0x1f
  8fcb1e:	vpsrad ymm7,ymm7,0x1f
  8fcb23:	vpxor  ymm8,ymm8,ymm4
  8fcb27:	vpxor  ymm9,ymm9,ymm7
  8fcb2b:	vpsubd ymm10,ymm8,ymm4
  8fcb2f:	vpsubd ymm8,ymm9,ymm7
  8fcb33:	vpmulld ymm4,ymm6,ymm5
  8fcb38:	vpmulld ymm7,ymm13,ymm2
  8fcb3d:	vpsrad ymm9,ymm4,0x1f
  8fcb42:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff71c48d]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8fcb4b:	vpaddd ymm4,ymm11,ymm4
  8fcb4f:	vpaddd ymm4,ymm9,ymm4
  8fcb53:	vpsrad ymm9,ymm7,0x1f
  8fcb58:	vpaddd ymm7,ymm11,ymm7
  8fcb5c:	vpaddd ymm12,ymm9,ymm7
  8fcb60:	vpmulld ymm6,ymm6,ymm10
  8fcb65:	vpsrad ymm7,ymm6,0x1f
  8fcb6a:	vpaddd ymm6,ymm11,ymm6
  8fcb6e:	vpaddd ymm6,ymm6,ymm7
  8fcb72:	vpaddd ymm7,ymm3,YMMWORD PTR [rsp+0x560]
  8fcb7b:	vpmulld ymm9,ymm13,ymm8
  8fcb80:	vpaddd ymm11,ymm9,ymm11
  8fcb85:	vpsrad ymm9,ymm9,0x1f
  8fcb8b:	vpaddd ymm11,ymm11,ymm9
  8fcb90:	vpsrad ymm13,ymm4,0xe
  8fcb95:	shl    rsi,0x6
  8fcb99:	mov    rdi,QWORD PTR [rsp+0x20]
  8fcb9e:	vmovdqu YMMWORD PTR [rdi+rsi*1],ymm5
  8fcba3:	vpsrad ymm5,ymm12,0xe
  8fcba9:	vmovdqu YMMWORD PTR [rdi+rsi*1+0x20],ymm2
  8fcbaf:	vpsrad ymm9,ymm6,0xe
  8fcbb4:	vmovdqu YMMWORD PTR [rdi+rsi*1+0x100],ymm10
  8fcbbd:	vpsrad ymm10,ymm11,0xe
  8fcbc3:	vmovdqu YMMWORD PTR [rdi+rsi*1+0x120],ymm8
  8fcbcc:	vpsrad ymm2,ymm12,0x1f
  8fcbd2:	vpsrld ymm2,ymm2,0x1a
  8fcbd7:	vpaddd ymm2,ymm2,ymm5
  8fcbdb:	vpsrad ymm2,ymm2,0x6
  8fcbe0:	vmovdqa ymm12,YMMWORD PTR [rsp+0x320]
  8fcbe9:	vpaddd ymm2,ymm12,ymm2
  8fcbed:	vpbroadcastd ymm8,DWORD PTR [rsp+0x350]
  8fcbf7:	vpand  ymm5,ymm8,ymm2
  8fcbfb:	vpsrad ymm4,ymm4,0x1f
  8fcc00:	vpsrld ymm4,ymm4,0x1a
  8fcc05:	vpaddd ymm4,ymm13,ymm4
  8fcc09:	vpsrad ymm4,ymm4,0x6
  8fcc0e:	vpaddd ymm4,ymm12,ymm4
  8fcc12:	vpand  ymm12,ymm8,ymm4
  8fcc16:	vpsrad ymm11,ymm11,0x1f
  8fcc1c:	vpsrld ymm11,ymm11,0x1a
  8fcc22:	vpaddd ymm10,ymm11,ymm10
  8fcc27:	vmovdqa ymm13,YMMWORD PTR [rsp+0x4a0]
  8fcc30:	vpminud ymm11,ymm13,ymm2
  8fcc35:	vpcmpeqd ymm11,ymm13,ymm11
  8fcc3a:	vpsrad ymm10,ymm10,0x6
  8fcc40:	vpaddd ymm7,ymm10,ymm7
  8fcc44:	vpminud ymm10,ymm13,ymm4
  8fcc49:	vpcmpeqd ymm10,ymm13,ymm10
  8fcc4e:	vpsrad ymm6,ymm6,0x1f
  8fcc53:	vpsrld ymm6,ymm6,0x1a
  8fcc58:	vpaddd ymm6,ymm9,ymm6
  8fcc5c:	vpand  ymm9,ymm8,ymm7
  8fcc60:	vpsrad ymm6,ymm6,0x6
  8fcc65:	vpaddd ymm6,ymm1,ymm6
  8fcc69:	vpand  ymm8,ymm8,ymm6
  8fcc6d:	vmovdqa ymm13,YMMWORD PTR [rsp+0x3c0]
  8fcc76:	vpminud ymm1,ymm13,ymm7
  8fcc7b:	vpcmpeqd ymm1,ymm13,ymm1
  8fcc7f:	vpor   ymm1,ymm11,ymm1
  8fcc83:	vpminud ymm11,ymm13,ymm6
  8fcc88:	vpcmpeqd ymm11,ymm13,ymm11
  8fcc8d:	vpor   ymm10,ymm10,ymm11
  8fcc92:	vmovdqa ymm13,YMMWORD PTR [rsp+0x500]
  8fcc9b:	vpsubd ymm11,ymm12,ymm13
  8fcca0:	vpsubd ymm5,ymm5,ymm13
  8fcca5:	vmovdqa ymm13,YMMWORD PTR [rsp+0x4e0]
  8fccae:	vpmulld ymm12,ymm11,ymm13
  8fccb3:	vpaddd ymm8,ymm12,ymm8
  8fccb8:	vpmulld ymm12,ymm5,ymm13
  8fccbd:	vpaddd ymm9,ymm12,ymm9
  8fccc2:	vpsrad ymm11,ymm11,0x1f
  8fccc8:	vpor   ymm8,ymm8,ymm11
  8fcccd:	vpsrad ymm5,ymm5,0x1f
  8fccd2:	vpor   ymm5,ymm9,ymm5
  8fccd6:	mov    rdi,QWORD PTR [rsp+0x2a0]
  8fccde:	vmovdqu YMMWORD PTR [rdi+rsi*1],ymm8
  8fcce3:	vmovdqa ymm8,YMMWORD PTR [rsp+0x520]
  8fccec:	vpand  ymm6,ymm8,ymm6
  8fccf0:	vmovdqu YMMWORD PTR [rdi+rsi*1+0x20],ymm5
  8fccf6:	vpaddd ymm5,ymm3,YMMWORD PTR [rsp+0x700]
  8fccff:	vpsubd ymm5,ymm5,ymm6
  8fcd03:	vpand  ymm6,ymm8,ymm7
  8fcd07:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x6e0]
  8fcd10:	vpsubd ymm3,ymm3,ymm6
  8fcd14:	vpand  ymm4,ymm8,ymm4
  8fcd18:	vmovdqa ymm7,YMMWORD PTR [rsp+0x480]
  8fcd21:	vpcmpeqd ymm4,ymm4,ymm7
  8fcd25:	vmovdqa ymm6,YMMWORD PTR [rsp+0x4c0]
  8fcd2e:	vpminud ymm5,ymm6,ymm5
  8fcd33:	vpcmpeqd ymm5,ymm6,ymm5
  8fcd37:	vpandn ymm4,ymm5,ymm4
  8fcd3b:	vpandn ymm4,ymm10,ymm4
  8fcd3f:	vpand  ymm2,ymm8,ymm2
  8fcd43:	vpcmpeqd ymm2,ymm2,ymm7
  8fcd47:	vpminud ymm3,ymm6,ymm3
  8fcd4c:	vpcmpeqd ymm3,ymm6,ymm3
  8fcd50:	vpandn ymm2,ymm3,ymm2
  8fcd54:	vpbroadcastd ymm3,DWORD PTR [rip+0xffffffffff71bf23]        # 18c80 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  8fcd5d:	vpandn ymm1,ymm1,ymm2
  8fcd61:	vpand  ymm2,ymm4,ymm3
  8fcd65:	vpand  ymm1,ymm1,ymm3
  8fcd69:	vextracti128 xmm3,ymm1,0x1
  8fcd6f:	vpackusdw xmm1,xmm1,xmm3
  8fcd74:	vextracti128 xmm3,ymm2,0x1
  8fcd7a:	vpackusdw xmm2,xmm2,xmm3
  8fcd7f:	vpackuswb xmm1,xmm2,xmm1
  8fcd83:	vpand  xmm0,xmm14,xmm0
  8fcd87:	vpand  xmm0,xmm0,xmm1
  8fcd8b:	vpxor  xmm1,xmm1,xmm1
  8fcd8f:	vpcmpeqb xmm0,xmm0,xmm1
  8fcd93:	vpmovmskb esi,xmm0
  8fcd97:	xor    esi,0xffff
  8fcd9d:	shlx   rdx,rsi,rdx
  8fcda2:	or     rax,rdx
  8fcda5:	mov    r8,r9
  8fcda8:	cmp    r13,0x1
  8fcdac:	jne    8fce90 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2b60>
  8fcdb2:	cmp    r8,rcx
  8fcdb5:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fcdbb:	mov    rdx,r8
  8fcdbe:	shl    rdx,0x4
  8fcdc2:	lea    rdi,[rdx+rbx*1]
  8fcdc6:	cmp    rdi,0x7fffffff
  8fcdcd:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fcdd3:	lea    rsi,[r8+r8*2]
  8fcdd7:	shl    rsi,0x5
  8fcddb:	mov    r9,QWORD PTR [rsp+0x10]
  8fcde0:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8fcde6:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x6]
  8fcded:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8fcdf4:	vmovdqu xmm6,XMMWORD PTR [r9+rsi*1+0x36]
  8fcdfb:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8fce03:	vpblendd xmm3,xmm0,XMMWORD PTR [r9+rsi*1+0x20],0x2
  8fce0b:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8fce13:	vpblendd xmm4,xmm0,XMMWORD PTR [r9+rsi*1+0x50],0x2
  8fce1b:	vpblendd xmm0,xmm1,XMMWORD PTR [r9+rsi*1+0x16],0x4
  8fce23:	vpblendd xmm5,xmm0,XMMWORD PTR [r9+rsi*1+0x26],0x2
  8fce2b:	vpblendd xmm0,xmm6,XMMWORD PTR [r9+rsi*1+0x46],0x4
  8fce33:	vpblendd xmm6,xmm0,XMMWORD PTR [r9+rsi*1+0x56],0x2
  8fce3b:	lea    rsi,[r8+0x1]
  8fce3f:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff719939]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8fce47:	vpshufb xmm0,xmm5,xmm2
  8fce4c:	vpshufb xmm1,xmm3,xmm2
  8fce51:	vpunpcklbw xmm7,xmm1,xmm0
  8fce55:	vpshufb xmm0,xmm6,xmm2
  8fce5a:	vpshufb xmm1,xmm4,xmm2
  8fce5f:	vpunpcklbw xmm8,xmm1,xmm0
  8fce63:	vpunpcklqdq xmm1,xmm7,xmm8
  8fce68:	vpaddusb xmm2,xmm15,xmm1
  8fce6c:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fce72:	vpshufb xmm0,xmm0,xmm2
  8fce77:	vptest xmm0,xmm14
  8fce7c:	je     8fd0a8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2d78>
  8fce82:	mov    r9,rsi
  8fce85:	mov    rsi,r8
  8fce88:	jmp    8fd740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3410>
  8fce8d:	nop    DWORD PTR [rax]
  8fce90:	cmp    r8,rcx
  8fce93:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fce99:	mov    rdx,r8
  8fce9c:	shl    rdx,0x4
  8fcea0:	lea    rdi,[rdx+rbx*1]
  8fcea4:	imul   rdi,r13
  8fcea8:	cmp    rdi,0x7fffffff
  8fceaf:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fceb5:	lea    rsi,[r8+0x1]
  8fceb9:	lea    r9,[r8+r8*2]
  8fcebd:	shl    r9,0x6
  8fcec1:	mov    r10,QWORD PTR [rsp+0x10]
  8fcec6:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8fcecc:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x20]
  8fced3:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8fceda:	vmovdqu xmm4,XMMWORD PTR [r10+r9*1+0x50]
  8fcee1:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8fcee9:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71926f]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8fcef1:	vpshufb xmm1,xmm1,xmm6
  8fcef6:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71a3d2]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8fcefe:	vpshufb xmm0,xmm0,xmm7
  8fcf03:	vpor   xmm3,xmm0,xmm1
  8fcf07:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8fcf0f:	vpshufb xmm1,xmm4,xmm6
  8fcf14:	vpshufb xmm0,xmm0,xmm7
  8fcf19:	vpor   xmm4,xmm0,xmm1
  8fcf1d:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0x80]
  8fcf27:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x60]
  8fcf2e:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0x70],0x4
  8fcf36:	vpshufb xmm0,xmm0,xmm6
  8fcf3b:	vpshufb xmm1,xmm1,xmm7
  8fcf40:	vpor   xmm5,xmm1,xmm0
  8fcf44:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0xb0]
  8fcf4e:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x90]
  8fcf58:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0xa0],0x4
  8fcf63:	vpshufb xmm0,xmm0,xmm6
  8fcf68:	vpshufb xmm1,xmm1,xmm7
  8fcf6d:	vpor   xmm6,xmm1,xmm0
  8fcf71:	vpunpckldq xmm7,xmm3,xmm4
  8fcf75:	vpunpckldq xmm8,xmm5,xmm6
  8fcf79:	vpunpcklqdq xmm1,xmm7,xmm8
  8fcf7e:	vpaddusb xmm2,xmm15,xmm1
  8fcf82:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fcf88:	vpshufb xmm0,xmm0,xmm2
  8fcf8d:	vptest xmm0,xmm14
  8fcf92:	jne    8fc9c0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2690>
  8fcf98:	cmp    rsi,rcx
  8fcf9b:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fcfa1:	mov    rdx,rsi
  8fcfa4:	shl    rdx,0x4
  8fcfa8:	lea    rdi,[rdx+rbx*1]
  8fcfac:	imul   rdi,r13
  8fcfb0:	cmp    rdi,0x7fffffff
  8fcfb7:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fcfbd:	lea    r10,[r8+0x2]
  8fcfc1:	lea    r9,[rsi+rsi*2]
  8fcfc5:	shl    r9,0x6
  8fcfc9:	mov    r11,QWORD PTR [rsp+0x10]
  8fcfce:	vmovdqu xmm0,XMMWORD PTR [r11+r9*1]
  8fcfd4:	vmovdqu xmm1,XMMWORD PTR [r11+r9*1+0x20]
  8fcfdb:	vmovdqu xmm2,XMMWORD PTR [r11+r9*1+0x30]
  8fcfe2:	vmovdqu xmm4,XMMWORD PTR [r11+r9*1+0x50]
  8fcfe9:	vpblendd xmm0,xmm0,XMMWORD PTR [r11+r9*1+0x10],0x4
  8fcff1:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff719167]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8fcff9:	vpshufb xmm1,xmm1,xmm6
  8fcffe:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71a2ca]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8fd006:	vpshufb xmm0,xmm0,xmm7
  8fd00b:	vpor   xmm3,xmm0,xmm1
  8fd00f:	vpblendd xmm0,xmm2,XMMWORD PTR [r11+r9*1+0x40],0x4
  8fd017:	vpshufb xmm1,xmm4,xmm6
  8fd01c:	vpshufb xmm0,xmm0,xmm7
  8fd021:	vpor   xmm4,xmm0,xmm1
  8fd025:	vmovdqu xmm0,XMMWORD PTR [r11+r9*1+0x80]
  8fd02f:	vmovdqu xmm1,XMMWORD PTR [r11+r9*1+0x60]
  8fd036:	vpblendd xmm1,xmm1,XMMWORD PTR [r11+r9*1+0x70],0x4
  8fd03e:	vpshufb xmm0,xmm0,xmm6
  8fd043:	vpshufb xmm1,xmm1,xmm7
  8fd048:	vpor   xmm5,xmm1,xmm0
  8fd04c:	vmovdqu xmm0,XMMWORD PTR [r11+r9*1+0xb0]
  8fd056:	vmovdqu xmm1,XMMWORD PTR [r11+r9*1+0x90]
  8fd060:	vpblendd xmm1,xmm1,XMMWORD PTR [r11+r9*1+0xa0],0x4
  8fd06b:	vpshufb xmm0,xmm0,xmm6
  8fd070:	vpshufb xmm1,xmm1,xmm7
  8fd075:	vpor   xmm6,xmm1,xmm0
  8fd079:	vpunpckldq xmm7,xmm3,xmm4
  8fd07d:	vpunpckldq xmm8,xmm5,xmm6
  8fd081:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd086:	vpaddusb xmm2,xmm15,xmm1
  8fd08a:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd090:	vpshufb xmm0,xmm0,xmm2
  8fd095:	vptest xmm0,xmm14
  8fd09a:	je     8fd180 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2e50>
  8fd0a0:	mov    r9,r10
  8fd0a3:	jmp    8fc9c6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2696>
  8fd0a8:	cmp    rsi,rcx
  8fd0ab:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd0b1:	mov    rdx,rsi
  8fd0b4:	shl    rdx,0x4
  8fd0b8:	lea    rdi,[rdx+rbx*1]
  8fd0bc:	cmp    rdi,0x7fffffff
  8fd0c3:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd0c9:	lea    r9,[rsi+rsi*2]
  8fd0cd:	shl    r9,0x5
  8fd0d1:	mov    r10,QWORD PTR [rsp+0x10]
  8fd0d6:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8fd0dc:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x6]
  8fd0e3:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8fd0ea:	vmovdqu xmm6,XMMWORD PTR [r10+r9*1+0x36]
  8fd0f1:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8fd0f9:	vpblendd xmm3,xmm0,XMMWORD PTR [r10+r9*1+0x20],0x2
  8fd101:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8fd109:	vpblendd xmm4,xmm0,XMMWORD PTR [r10+r9*1+0x50],0x2
  8fd111:	vpblendd xmm0,xmm1,XMMWORD PTR [r10+r9*1+0x16],0x4
  8fd119:	vpblendd xmm5,xmm0,XMMWORD PTR [r10+r9*1+0x26],0x2
  8fd121:	vpblendd xmm0,xmm6,XMMWORD PTR [r10+r9*1+0x46],0x4
  8fd129:	vpblendd xmm6,xmm0,XMMWORD PTR [r10+r9*1+0x56],0x2
  8fd131:	lea    r10,[r8+0x2]
  8fd135:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff719643]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8fd13d:	vpshufb xmm0,xmm5,xmm2
  8fd142:	vpshufb xmm1,xmm3,xmm2
  8fd147:	vpunpcklbw xmm7,xmm1,xmm0
  8fd14b:	vpshufb xmm0,xmm6,xmm2
  8fd150:	vpshufb xmm1,xmm4,xmm2
  8fd155:	vpunpcklbw xmm8,xmm1,xmm0
  8fd159:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd15e:	vpaddusb xmm2,xmm15,xmm1
  8fd162:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd168:	vpshufb xmm0,xmm0,xmm2
  8fd16d:	vptest xmm0,xmm14
  8fd172:	je     8fd293 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2f63>
  8fd178:	mov    r9,r10
  8fd17b:	jmp    8fd740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3410>
  8fd180:	cmp    r10,rcx
  8fd183:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd189:	mov    rdx,r10
  8fd18c:	shl    rdx,0x4
  8fd190:	lea    rdi,[rdx+rbx*1]
  8fd194:	imul   rdi,r13
  8fd198:	cmp    rdi,0x7fffffff
  8fd19f:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd1a5:	lea    r11,[r8+0x3]
  8fd1a9:	lea    rsi,[r10+r10*2]
  8fd1ad:	shl    rsi,0x6
  8fd1b1:	mov    r9,QWORD PTR [rsp+0x10]
  8fd1b6:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8fd1bc:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x20]
  8fd1c3:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8fd1ca:	vmovdqu xmm4,XMMWORD PTR [r9+rsi*1+0x50]
  8fd1d1:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8fd1d9:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff718f7f]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8fd1e1:	vpshufb xmm1,xmm1,xmm6
  8fd1e6:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71a0e2]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8fd1ee:	vpshufb xmm0,xmm0,xmm7
  8fd1f3:	vpor   xmm3,xmm0,xmm1
  8fd1f7:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8fd1ff:	vpshufb xmm1,xmm4,xmm6
  8fd204:	vpshufb xmm0,xmm0,xmm7
  8fd209:	vpor   xmm4,xmm0,xmm1
  8fd20d:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1+0x80]
  8fd217:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x60]
  8fd21e:	vpblendd xmm1,xmm1,XMMWORD PTR [r9+rsi*1+0x70],0x4
  8fd226:	vpshufb xmm0,xmm0,xmm6
  8fd22b:	vpshufb xmm1,xmm1,xmm7
  8fd230:	vpor   xmm5,xmm1,xmm0
  8fd234:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1+0xb0]
  8fd23e:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x90]
  8fd248:	vpblendd xmm1,xmm1,XMMWORD PTR [r9+rsi*1+0xa0],0x4
  8fd253:	vpshufb xmm0,xmm0,xmm6
  8fd258:	vpshufb xmm1,xmm1,xmm7
  8fd25d:	vpor   xmm6,xmm1,xmm0
  8fd261:	vpunpckldq xmm7,xmm3,xmm4
  8fd265:	vpunpckldq xmm8,xmm5,xmm6
  8fd269:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd26e:	vpaddusb xmm2,xmm15,xmm1
  8fd272:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd278:	vpshufb xmm0,xmm0,xmm2
  8fd27d:	vptest xmm0,xmm14
  8fd282:	je     8fd36e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x303e>
  8fd288:	mov    r9,r11
  8fd28b:	mov    rsi,r10
  8fd28e:	jmp    8fc9c6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2696>
  8fd293:	cmp    r10,rcx
  8fd296:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd29c:	mov    rdx,r10
  8fd29f:	shl    rdx,0x4
  8fd2a3:	lea    rdi,[rdx+rbx*1]
  8fd2a7:	cmp    rdi,0x7fffffff
  8fd2ae:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd2b4:	lea    rsi,[r10+r10*2]
  8fd2b8:	shl    rsi,0x5
  8fd2bc:	mov    r9,QWORD PTR [rsp+0x10]
  8fd2c1:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8fd2c7:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x6]
  8fd2ce:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8fd2d5:	vmovdqu xmm6,XMMWORD PTR [r9+rsi*1+0x36]
  8fd2dc:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8fd2e4:	vpblendd xmm3,xmm0,XMMWORD PTR [r9+rsi*1+0x20],0x2
  8fd2ec:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8fd2f4:	vpblendd xmm4,xmm0,XMMWORD PTR [r9+rsi*1+0x50],0x2
  8fd2fc:	vpblendd xmm0,xmm1,XMMWORD PTR [r9+rsi*1+0x16],0x4
  8fd304:	vpblendd xmm5,xmm0,XMMWORD PTR [r9+rsi*1+0x26],0x2
  8fd30c:	vpblendd xmm0,xmm6,XMMWORD PTR [r9+rsi*1+0x46],0x4
  8fd314:	vpblendd xmm6,xmm0,XMMWORD PTR [r9+rsi*1+0x56],0x2
  8fd31c:	lea    r11,[r8+0x3]
  8fd320:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff719458]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8fd328:	vpshufb xmm0,xmm5,xmm2
  8fd32d:	vpshufb xmm1,xmm3,xmm2
  8fd332:	vpunpcklbw xmm7,xmm1,xmm0
  8fd336:	vpshufb xmm0,xmm6,xmm2
  8fd33b:	vpshufb xmm1,xmm4,xmm2
  8fd340:	vpunpcklbw xmm8,xmm1,xmm0
  8fd344:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd349:	vpaddusb xmm2,xmm15,xmm1
  8fd34d:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd353:	vpshufb xmm0,xmm0,xmm2
  8fd358:	vptest xmm0,xmm14
  8fd35d:	je     8fd481 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3151>
  8fd363:	mov    r9,r11
  8fd366:	mov    rsi,r10
  8fd369:	jmp    8fd740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3410>
  8fd36e:	cmp    r11,rcx
  8fd371:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd377:	mov    rdx,r11
  8fd37a:	shl    rdx,0x4
  8fd37e:	lea    rdi,[rdx+rbx*1]
  8fd382:	imul   rdi,r13
  8fd386:	cmp    rdi,0x7fffffff
  8fd38d:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd393:	lea    rsi,[r8+0x4]
  8fd397:	lea    r9,[r11+r11*2]
  8fd39b:	shl    r9,0x6
  8fd39f:	mov    r10,QWORD PTR [rsp+0x10]
  8fd3a4:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8fd3aa:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x20]
  8fd3b1:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8fd3b8:	vmovdqu xmm4,XMMWORD PTR [r10+r9*1+0x50]
  8fd3bf:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8fd3c7:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff718d91]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8fd3cf:	vpshufb xmm1,xmm1,xmm6
  8fd3d4:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff719ef4]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8fd3dc:	vpshufb xmm0,xmm0,xmm7
  8fd3e1:	vpor   xmm3,xmm0,xmm1
  8fd3e5:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8fd3ed:	vpshufb xmm1,xmm4,xmm6
  8fd3f2:	vpshufb xmm0,xmm0,xmm7
  8fd3f7:	vpor   xmm4,xmm0,xmm1
  8fd3fb:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0x80]
  8fd405:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x60]
  8fd40c:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0x70],0x4
  8fd414:	vpshufb xmm0,xmm0,xmm6
  8fd419:	vpshufb xmm1,xmm1,xmm7
  8fd41e:	vpor   xmm5,xmm1,xmm0
  8fd422:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0xb0]
  8fd42c:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x90]
  8fd436:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0xa0],0x4
  8fd441:	vpshufb xmm0,xmm0,xmm6
  8fd446:	vpshufb xmm1,xmm1,xmm7
  8fd44b:	vpor   xmm6,xmm1,xmm0
  8fd44f:	vpunpckldq xmm7,xmm3,xmm4
  8fd453:	vpunpckldq xmm8,xmm5,xmm6
  8fd457:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd45c:	vpaddusb xmm2,xmm15,xmm1
  8fd460:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd466:	vpshufb xmm0,xmm0,xmm2
  8fd46b:	vptest xmm0,xmm14
  8fd470:	je     8fd55c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x322c>
  8fd476:	mov    r9,rsi
  8fd479:	mov    rsi,r11
  8fd47c:	jmp    8fc9c6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2696>
  8fd481:	cmp    r11,rcx
  8fd484:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd48a:	mov    rdx,r11
  8fd48d:	shl    rdx,0x4
  8fd491:	lea    rdi,[rdx+rbx*1]
  8fd495:	cmp    rdi,0x7fffffff
  8fd49c:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd4a2:	lea    rsi,[r11+r11*2]
  8fd4a6:	shl    rsi,0x5
  8fd4aa:	mov    r9,QWORD PTR [rsp+0x10]
  8fd4af:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8fd4b5:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x6]
  8fd4bc:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8fd4c3:	vmovdqu xmm6,XMMWORD PTR [r9+rsi*1+0x36]
  8fd4ca:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8fd4d2:	vpblendd xmm3,xmm0,XMMWORD PTR [r9+rsi*1+0x20],0x2
  8fd4da:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8fd4e2:	vpblendd xmm4,xmm0,XMMWORD PTR [r9+rsi*1+0x50],0x2
  8fd4ea:	vpblendd xmm0,xmm1,XMMWORD PTR [r9+rsi*1+0x16],0x4
  8fd4f2:	vpblendd xmm5,xmm0,XMMWORD PTR [r9+rsi*1+0x26],0x2
  8fd4fa:	vpblendd xmm0,xmm6,XMMWORD PTR [r9+rsi*1+0x46],0x4
  8fd502:	vpblendd xmm6,xmm0,XMMWORD PTR [r9+rsi*1+0x56],0x2
  8fd50a:	lea    rsi,[r8+0x4]
  8fd50e:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71926a]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8fd516:	vpshufb xmm0,xmm5,xmm2
  8fd51b:	vpshufb xmm1,xmm3,xmm2
  8fd520:	vpunpcklbw xmm7,xmm1,xmm0
  8fd524:	vpshufb xmm0,xmm6,xmm2
  8fd529:	vpshufb xmm1,xmm4,xmm2
  8fd52e:	vpunpcklbw xmm8,xmm1,xmm0
  8fd532:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd537:	vpaddusb xmm2,xmm15,xmm1
  8fd53b:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd541:	vpshufb xmm0,xmm0,xmm2
  8fd546:	vptest xmm0,xmm14
  8fd54b:	je     8fd66c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x333c>
  8fd551:	mov    r9,rsi
  8fd554:	mov    rsi,r11
  8fd557:	jmp    8fd740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3410>
  8fd55c:	cmp    rsi,rcx
  8fd55f:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd565:	mov    rdx,rsi
  8fd568:	shl    rdx,0x4
  8fd56c:	lea    rdi,[rdx+rbx*1]
  8fd570:	imul   rdi,r13
  8fd574:	cmp    rdi,0x7fffffff
  8fd57b:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd581:	lea    r9,[rsi+rsi*2]
  8fd585:	shl    r9,0x6
  8fd589:	mov    r10,QWORD PTR [rsp+0x10]
  8fd58e:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8fd594:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x20]
  8fd59b:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8fd5a2:	vmovdqu xmm4,XMMWORD PTR [r10+r9*1+0x50]
  8fd5a9:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8fd5b1:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff718ba7]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8fd5b9:	vpshufb xmm1,xmm1,xmm6
  8fd5be:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff719d0a]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8fd5c6:	vpshufb xmm0,xmm0,xmm7
  8fd5cb:	vpor   xmm3,xmm0,xmm1
  8fd5cf:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8fd5d7:	vpshufb xmm1,xmm4,xmm6
  8fd5dc:	vpshufb xmm0,xmm0,xmm7
  8fd5e1:	vpor   xmm4,xmm0,xmm1
  8fd5e5:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0x80]
  8fd5ef:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x60]
  8fd5f6:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0x70],0x4
  8fd5fe:	vpshufb xmm0,xmm0,xmm6
  8fd603:	vpshufb xmm1,xmm1,xmm7
  8fd608:	vpor   xmm5,xmm1,xmm0
  8fd60c:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0xb0]
  8fd616:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x90]
  8fd620:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0xa0],0x4
  8fd62b:	vpshufb xmm0,xmm0,xmm6
  8fd630:	vpshufb xmm1,xmm1,xmm7
  8fd635:	vpor   xmm6,xmm1,xmm0
  8fd639:	vpunpckldq xmm7,xmm3,xmm4
  8fd63d:	vpunpckldq xmm8,xmm5,xmm6
  8fd641:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd646:	vpaddusb xmm2,xmm15,xmm1
  8fd64a:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd650:	vpshufb xmm0,xmm0,xmm2
  8fd655:	vptest xmm0,xmm14
  8fd65a:	je     8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd660:	add    r8,0x5
  8fd664:	mov    r9,r8
  8fd667:	jmp    8fc9c6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2696>
  8fd66c:	cmp    rsi,rcx
  8fd66f:	jae    8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd675:	mov    rdx,rsi
  8fd678:	shl    rdx,0x4
  8fd67c:	lea    rdi,[rdx+rbx*1]
  8fd680:	cmp    rdi,0x7fffffff
  8fd687:	ja     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd68d:	lea    r9,[rsi+rsi*2]
  8fd691:	shl    r9,0x5
  8fd695:	mov    r10,QWORD PTR [rsp+0x10]
  8fd69a:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8fd6a0:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x6]
  8fd6a7:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8fd6ae:	vmovdqu xmm6,XMMWORD PTR [r10+r9*1+0x36]
  8fd6b5:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8fd6bd:	vpblendd xmm3,xmm0,XMMWORD PTR [r10+r9*1+0x20],0x2
  8fd6c5:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8fd6cd:	vpblendd xmm4,xmm0,XMMWORD PTR [r10+r9*1+0x50],0x2
  8fd6d5:	vpblendd xmm0,xmm1,XMMWORD PTR [r10+r9*1+0x16],0x4
  8fd6dd:	vpblendd xmm5,xmm0,XMMWORD PTR [r10+r9*1+0x26],0x2
  8fd6e5:	vpblendd xmm0,xmm6,XMMWORD PTR [r10+r9*1+0x46],0x4
  8fd6ed:	vpblendd xmm6,xmm0,XMMWORD PTR [r10+r9*1+0x56],0x2
  8fd6f5:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff719083]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8fd6fd:	vpshufb xmm0,xmm5,xmm2
  8fd702:	vpshufb xmm1,xmm3,xmm2
  8fd707:	vpunpcklbw xmm7,xmm1,xmm0
  8fd70b:	vpshufb xmm0,xmm6,xmm2
  8fd710:	vpshufb xmm1,xmm4,xmm2
  8fd715:	vpunpcklbw xmm8,xmm1,xmm0
  8fd719:	vpunpcklqdq xmm1,xmm7,xmm8
  8fd71e:	vpaddusb xmm2,xmm15,xmm1
  8fd722:	vmovdqa xmm0,XMMWORD PTR [rsp+0x40]
  8fd728:	vpshufb xmm0,xmm0,xmm2
  8fd72d:	vptest xmm0,xmm14
  8fd732:	je     8fd780 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3450>
  8fd734:	add    r8,0x5
  8fd738:	mov    r9,r8
  8fd73b:	nop    DWORD PTR [rax+rax*1+0x0]
  8fd740:	vpunpckhqdq xmm7,xmm7,xmm8
  8fd745:	vmovd  xmm8,DWORD PTR [rip+0xffffffffff717183]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x510>
  8fd74d:	vpshufb xmm5,xmm5,xmm8
  8fd752:	vpshufb xmm3,xmm3,xmm8
  8fd757:	vpunpcklbw xmm3,xmm3,xmm5
  8fd75b:	vpshufb xmm5,xmm6,xmm8
  8fd760:	vpshufb xmm4,xmm4,xmm8
  8fd765:	vpunpcklbw xmm4,xmm4,xmm5
  8fd769:	vpunpcklqdq xmm4,xmm3,xmm4
  8fd76d:	jmp    8fc9d7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x26a7>
  8fd772:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8fd780:	mov    rcx,QWORD PTR [rsp+0x70]
  8fd785:	cmp    rcx,0x1
  8fd789:	adc    rcx,0x0
  8fd78d:	bzhi   rax,rax,rcx
  8fd792:	jne    8fd7d7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x34a7>
  8fd794:	mov    rsi,QWORD PTR [rsp+0x100]
  8fd79c:	mov    rbx,QWORD PTR [rsp+0x120]
  8fd7a4:	mov    r8,QWORD PTR [rsp+0xd8]
  8fd7ac:	test   r8,r8
  8fd7af:	jne    8fc8ce <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x259e>
  8fd7b5:	jmp    8fa700 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3d0>
  8fd7ba:	shl    esi,0x10
  8fd7bd:	movzx  edi,di
  8fd7c0:	or     edi,esi
  8fd7c2:	mov    WORD PTR [rdx+rcx*8],r9w
  8fd7c7:	mov    DWORD PTR [rdx+rcx*8+0x2],edi
  8fd7cb:	mov    BYTE PTR [rdx+rcx*8+0x6],0x1
  8fd7d0:	blsr   rax,rax
  8fd7d5:	je     8fd794 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3464>
  8fd7d7:	tzcnt  rdx,rax
  8fd7dc:	movzx  r8d,BYTE PTR [r15+rdx*1]
  8fd7e1:	cmp    r8d,0x8
  8fd7e5:	ja     8fd7d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x34a0>
  8fd7e7:	mov    rcx,QWORD PTR [rsp+0x20]
  8fd7ec:	mov    ecx,DWORD PTR [rcx+rdx*4+0x600]
  8fd7f3:	mov    rsi,QWORD PTR [rsp+0x68]
  8fd7f8:	cmp    QWORD PTR [rsi+0x8],rcx
  8fd7fc:	jbe    8fd7d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x34a0>
  8fd7fe:	shl    r8d,0x5
  8fd802:	add    r8,r12
  8fd805:	mov    rsi,QWORD PTR [rsp+0x20]
  8fd80a:	mov    edi,DWORD PTR [rsi+rdx*4]
  8fd80d:	mov    esi,DWORD PTR [rsi+rdx*4+0x100]
  8fd814:	mov    rdx,QWORD PTR [rsp+0x68]
  8fd819:	mov    rdx,QWORD PTR [rdx]
  8fd81c:	cmp    BYTE PTR [rdx+rcx*8+0x6],0x0
  8fd821:	je     8fd845 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3515>
  8fd823:	cmp    BYTE PTR [r8+0x1b],0x1
  8fd828:	jne    8fd7d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x34a0>
  8fd82a:	movsx  r10d,WORD PTR [rdx+rcx*8]
  8fd82f:	mov    r9d,DWORD PTR [r8+0x10]
  8fd833:	cmp    r9d,r10d
  8fd836:	je     8fd7d0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x34a0>
  8fd838:	cmp    BYTE PTR [r8+0x1a],0x0
  8fd83d:	je     8fd7ba <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x348a>
  8fd843:	jmp    8fd854 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3524>
  8fd845:	mov    r9d,DWORD PTR [r8+0x10]
  8fd849:	cmp    BYTE PTR [r8+0x1a],0x0
  8fd84e:	je     8fd7ba <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x348a>
  8fd854:	neg    edi
  8fd856:	neg    esi
  8fd858:	jmp    8fd7ba <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x348a>
  8fd85d:	mov    r9,QWORD PTR [rsp+0x98]
  8fd865:	cmp    r8,r9
  8fd868:	cmovb  r9,r8
  8fd86c:	mov    rax,r9
  8fd86f:	or     rax,r13
  8fd872:	shr    rax,0x20
  8fd876:	je     8fd882 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3552>
  8fd878:	mov    rax,r9
  8fd87b:	xor    edx,edx
  8fd87d:	div    r13
  8fd880:	jmp    8fd88a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x355a>
  8fd882:	mov    eax,r9d
  8fd885:	xor    edx,edx
  8fd887:	div    r13d
  8fd88a:	mov    rdi,QWORD PTR [rsp+0x10]
  8fd88f:	cmp    rdx,0x1
  8fd893:	sbb    rax,0xffffffffffffffff
  8fd897:	cmp    rax,0x40
  8fd89b:	mov    ecx,0x40
  8fd8a0:	cmovb  rcx,rax
  8fd8a4:	add    r9,r9
  8fd8a7:	lea    rax,[r9+r9*2]
  8fd8ab:	mov    r8,QWORD PTR [rsp+0xc8]
  8fd8b3:	add    rsi,r8
  8fd8b6:	xor    edx,edx
  8fd8b8:	sub    rax,r8
  8fd8bb:	cmovae rdx,rax
  8fd8bf:	imul   rcx,QWORD PTR [rsp+0xd0]
  8fd8c8:	cmp    rdx,rcx
  8fd8cb:	cmovb  rcx,rdx
  8fd8cf:	cmp    rcx,0x300
  8fd8d6:	mov    edx,0x300
  8fd8db:	cmovb  rdx,rcx
  8fd8df:	vzeroupper
  8fd8e2:	call   QWORD PTR [rip+0x6e71b8]        # fe4aa0 <memcpy@GLIBC_2.14>
  8fd8e8:	lea    rsp,[rbp-0x28]
  8fd8ec:	pop    rbx
  8fd8ed:	pop    r12
  8fd8ef:	pop    r13
  8fd8f1:	pop    r14
  8fd8f3:	pop    r15
  8fd8f5:	pop    rbp
  8fd8f6:	vzeroupper
  8fd8f9:	ret
  8fd8fa:	lea    rdi,[rip+0xffffffffff7587be]        # 560bf <anon.245362c1692d2350ec60721dad848e3d.1081.llvm.5944606840923237273+0x158a>
  8fd901:	lea    rdx,[rip+0x6d72a0]        # fd4ba8 <anon.245362c1692d2350ec60721dad848e3d.1039.llvm.5944606840923237273+0x5c0>
  8fd908:	mov    esi,0x1b
  8fd90d:	call   QWORD PTR [rip+0x6e72d5]        # fe4be8 <_DYNAMIC+0x390>
  8fd913:	mov    rax,QWORD PTR [rsp+0x18]
  8fd918:	mov    rcx,QWORD PTR [rax+0xe0]
  8fd91f:	mov    rsi,rcx
  8fd922:	neg    rsi
  8fd925:	xor    edi,edi
  8fd927:	jmp    8fd950 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3620>
  8fd929:	mov    rdx,QWORD PTR [rsp+0x18]
  8fd92e:	mov    rdx,QWORD PTR [rdx+0xc0]
  8fd935:	cmp    rax,rdx
  8fd938:	jbe    8fd9e9 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x36b9>
  8fd93e:	add    rbx,r13
  8fd941:	mov    QWORD PTR [rsp+0x28],rbx
  8fd946:	dec    QWORD PTR [rsp+0x1b0]
  8fd94e:	je     8fd8e8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35b8>
  8fd950:	mov    rbx,QWORD PTR [rsp+0x28]
  8fd955:	cmp    rbx,rcx
  8fd958:	jb     8fd93e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x360e>
  8fd95a:	lea    rax,[rsi+rbx*1]
  8fd95e:	mov    rdx,QWORD PTR [rsp+0x18]
  8fd963:	mov    r8,QWORD PTR [rdx+0xc8]
  8fd96a:	mul    r8
  8fd96d:	jo     8fd93e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x360e>
  8fd96f:	add    rax,r8
  8fd972:	jb     8fd93e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x360e>
  8fd974:	mov    rdx,QWORD PTR [rsp+0x18]
  8fd979:	mov    rdx,QWORD PTR [rdx+0xa8]
  8fd980:	test   rdx,rdx
  8fd983:	je     8fd929 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x35f9>
  8fd985:	cmp    edx,0x1
  8fd988:	jne    8fd99c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x366c>
  8fd98a:	mov    rdx,QWORD PTR [rsp+0x18]
  8fd98f:	mov    rdx,QWORD PTR [rdx+0xb0]
  8fd996:	mov    rdx,QWORD PTR [rdx+0x20]
  8fd99a:	jmp    8fd935 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3605>
  8fd99c:	mov    rdx,QWORD PTR [rsp+0x18]
  8fd9a1:	mov    rdx,QWORD PTR [rdx+0xc0]
  8fd9a8:	cmp    BYTE PTR [rdx+0x10],0x0
  8fd9ac:	je     8fd9b3 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3683>
  8fd9ae:	xor    r9d,r9d
  8fd9b1:	jmp    8fd9b7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3687>
  8fd9b3:	mov    r9,QWORD PTR [rdx+0x28]
  8fd9b7:	mov    rdx,QWORD PTR [rsp+0x18]
  8fd9bc:	mov    r8,QWORD PTR [rdx+0xb8]
  8fd9c3:	mov    r10,QWORD PTR [rdx+0xb0]
  8fd9ca:	mov    r11,r8
  8fd9cd:	sub    r11,r10
  8fd9d0:	mov    edx,0x0
  8fd9d5:	cmp    r8,r9
  8fd9d8:	ja     8fd9dd <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x36ad>
  8fd9da:	mov    rdx,r11
  8fd9dd:	cmp    r8,r10
  8fd9e0:	cmovb  rdx,rdi
  8fd9e4:	jmp    8fd935 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x3605>
  8fd9e9:	lea    rdi,[rip+0xffffffffff74ca89]        # 4a479 <_RNvNtNtNtCsdbBTXDzdjsm_12splot_decode9bitstream12tile_payload11coeff_state15ZERO_QUANT_SIGN+0x521>
  8fd9f0:	lea    rdx,[rip+0x6d59b9]        # fd33b0 <anon.245362c1692d2350ec60721dad848e3d.159.llvm.5944606840923237273+0x2270>
  8fd9f7:	mov    esi,0x37
  8fd9fc:	call   QWORD PTR [rip+0x6e70f6]        # fe4af8 <_DYNAMIC+0x2a0>
