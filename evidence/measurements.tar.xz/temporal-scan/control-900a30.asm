
<WORKTREES>/qualification-1882/final-integration/splot.full:     file format elf64-x86-64


Disassembly of section .text:

0000000000900a30 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_>:
  900a30:	push   rbp
  900a31:	mov    rbp,rsp
  900a34:	push   r15
  900a36:	push   r14
  900a38:	push   r13
  900a3a:	push   r12
  900a3c:	push   rbx
  900a3d:	and    rsp,0xffffffffffffffc0
  900a41:	sub    rsp,0x880
  900a48:	mov    r14,rdi
  900a4b:	mov    r12,QWORD PTR [rdi+0x8]
  900a4f:	mov    rax,QWORD PTR [rdi+0x10]
  900a53:	mov    rdx,QWORD PTR [rax]
  900a56:	lea    rdi,[rsp+0x340]
  900a5e:	mov    rsi,r12
  900a61:	call   b87920 <_RNvMs_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanINtB4_12TargetTablesNtNtNtCscIM9z48VHAb_13fearless_simd9generated4avx24Avx2E3newBe_>
  900a66:	mov    rdx,QWORD PTR [r14+0x28]
  900a6a:	mov    r15,QWORD PTR [rdx]
  900a6d:	test   r15,r15
  900a70:	je     902fe6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25b6>
  900a76:	mov    r10,QWORD PTR [r14+0x38]
  900a7a:	mov    r9,QWORD PTR [r14+0x40]
  900a7e:	mov    eax,DWORD PTR [rdx+0x8]
  900a81:	mov    DWORD PTR [rsp+0x18],eax
  900a85:	mov    r13d,DWORD PTR [rdx+0xc]
  900a89:	movsxd rax,DWORD PTR [rdx+0x10]
  900a8d:	mov    QWORD PTR [rsp+0x20],rax
  900a92:	mov    r8d,DWORD PTR [rdx+0x14]
  900a96:	mov    edi,DWORD PTR [rdx+0x18]
  900a99:	mov    esi,DWORD PTR [rdx+0x1c]
  900a9c:	mov    ecx,DWORD PTR [rdx+0x20]
  900a9f:	xor    eax,eax
  900aa1:	sub    r9,r10
  900aa4:	cmovae rax,r9
  900aa8:	mov    r9d,DWORD PTR [rdx+0x24]
  900aac:	mov    DWORD PTR [rsp+0x1c],r9d
  900ab1:	mov    r9,rax
  900ab4:	or     r9,r15
  900ab7:	shr    r9,0x20
  900abb:	mov    r9d,DWORD PTR [rdx+0x28]
  900abf:	mov    DWORD PTR [rsp+0x30],r9d
  900ac4:	vmovdqu ymm0,YMMWORD PTR [rdx+0x2c]
  900ac9:	movzx  edx,BYTE PTR [rdx+0x4c]
  900acd:	mov    QWORD PTR [rsp+0x78],rdx
  900ad2:	mov    rbx,QWORD PTR [r14+0x18]
  900ad6:	mov    rdx,QWORD PTR [r14+0x20]
  900ada:	mov    QWORD PTR [rsp+0x68],rdx
  900adf:	mov    rdx,QWORD PTR [r14+0x48]
  900ae3:	mov    QWORD PTR [rsp+0x70],rdx
  900ae8:	mov    rdx,QWORD PTR [r14+0x30]
  900aec:	mov    QWORD PTR [rsp+0x58],rdx
  900af1:	mov    r9,QWORD PTR [r12+0x138]
  900af9:	mov    QWORD PTR [rsp+0x60],r12
  900afe:	mov    QWORD PTR [rsp+0x10],r10
  900b03:	je     900b0c <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xdc>
  900b05:	xor    edx,edx
  900b07:	div    r15
  900b0a:	jmp    900b11 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xe1>
  900b0c:	xor    edx,edx
  900b0e:	div    r15d
  900b11:	xor    r10d,r10d
  900b14:	test   rdx,rdx
  900b17:	setne  r10b
  900b1b:	add    r10,rax
  900b1e:	mov    QWORD PTR [rsp+0x50],r10
  900b23:	je     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  900b29:	mov    rax,r15
  900b2c:	shl    rax,0x6
  900b30:	je     902fff <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25cf>
  900b36:	mov    QWORD PTR [rsp+0x48],rax
  900b3b:	and    r9d,0x1
  900b3f:	lea    rax,[r15+r15*1]
  900b43:	lea    rdx,[r9+r9*2]
  900b47:	mov    QWORD PTR [rsp+0x38],rdx
  900b4c:	lea    rax,[rax+rax*2]
  900b50:	mov    QWORD PTR [rsp+0x40],rax
  900b55:	cmp    QWORD PTR [rsp+0x70],0x0
  900b5b:	je     901e15 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x13e5>
  900b61:	vmovd  xmm1,r15d
  900b66:	vpbroadcastd ymm1,xmm1
  900b6b:	vpmulld xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71623c]        # 16db0 <anon.43d21acec09d19046152b53125a552af.1615.llvm.7158842796534594082+0x3e0>
  900b74:	vpmulld xmm3,xmm1,XMMWORD PTR [rip+0xffffffffff713423]        # 13fa0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6ee>
  900b7d:	vpmulld ymm4,ymm1,YMMWORD PTR [rip+0xffffffffff71985a]        # 1a3e0 <anon.db13f839740d960fd97bc530122b4c99.104.llvm.5594421697515501092+0x4c8>
  900b86:	vmovdqa YMMWORD PTR [rsp+0x7a0],ymm4
  900b8f:	not    r8d
  900b92:	vmovd  xmm4,r8d
  900b97:	mov    rax,QWORD PTR [rsp+0x78]
  900b9c:	lea    eax,[rax*8+0x0]
  900ba3:	or     al,0x4
  900ba5:	vpxor  xmm5,xmm5,xmm5
  900ba9:	vpblendd xmm1,xmm5,xmm1,0x2
  900baf:	vpermq ymm2,ymm2,0xd0
  900bb5:	vpblendd ymm1,ymm2,ymm1,0x3
  900bbb:	vpbroadcastq ymm2,xmm3
  900bc0:	vpblendd ymm1,ymm1,ymm2,0xc0
  900bc6:	vmovdqa YMMWORD PTR [rsp+0x780],ymm1
  900bcf:	vmovd  xmm1,eax
  900bd3:	vpbroadcastb xmm1,xmm1
  900bd8:	vmovdqa XMMWORD PTR [rsp+0xd0],xmm1
  900be1:	mov    rax,QWORD PTR [rsp+0x20]
  900be6:	not    eax
  900be8:	vmovd  xmm1,eax
  900bec:	vmovdqa XMMWORD PTR [rsp+0x420],xmm4
  900bf5:	vmovdqa XMMWORD PTR [rsp+0x430],xmm1
  900bfe:	vpand  xmm1,xmm4,xmm1
  900c02:	vpbroadcastd ymm1,xmm1
  900c07:	vmovdqa YMMWORD PTR [rsp+0x740],ymm1
  900c10:	vmovss xmm1,DWORD PTR [rsp+0x18]
  900c16:	vbroadcastss ymm1,xmm1
  900c1b:	vmovaps YMMWORD PTR [rsp+0x720],ymm1
  900c24:	vmovd  xmm1,r13d
  900c29:	vpbroadcastd ymm1,xmm1
  900c2e:	vmovdqa YMMWORD PTR [rsp+0x700],ymm1
  900c37:	vmovd  xmm1,edi
  900c3b:	vpbroadcastd ymm1,xmm1
  900c40:	vmovdqa YMMWORD PTR [rsp+0x6e0],ymm1
  900c49:	vmovd  xmm1,esi
  900c4d:	vpbroadcastd ymm1,xmm1
  900c52:	vmovdqa YMMWORD PTR [rsp+0x6c0],ymm1
  900c5b:	vmovd  xmm1,ecx
  900c5f:	vpbroadcastd ymm1,xmm1
  900c64:	vmovdqa YMMWORD PTR [rsp+0x4c0],ymm1
  900c6d:	vmovss xmm1,DWORD PTR [rsp+0x1c]
  900c73:	vbroadcastss ymm1,xmm1
  900c78:	vmovaps YMMWORD PTR [rsp+0x6a0],ymm1
  900c81:	vextracti128 xmm1,ymm0,0x1
  900c87:	vmovd  DWORD PTR [rsp+0x34],xmm1
  900c8d:	vpextrd DWORD PTR [rsp+0x98],xmm0,0x2
  900c98:	vmovd  DWORD PTR [rsp+0x94],xmm0
  900ca1:	vpshufd xmm1,xmm0,0x55
  900ca6:	vpbroadcastd ymm1,xmm1
  900cab:	vmovdqa YMMWORD PTR [rsp+0x680],ymm1
  900cb4:	vmovss xmm1,DWORD PTR [rsp+0x30]
  900cba:	vbroadcastss ymm1,xmm1
  900cbf:	vmovaps YMMWORD PTR [rsp+0x660],ymm1
  900cc8:	vmovq  rax,xmm0
  900ccd:	vpextrq rcx,xmm0,0x1
  900cd3:	shr    rcx,0x20
  900cd7:	vmovd  xmm1,ecx
  900cdb:	vpbroadcastd ymm1,xmm1
  900ce0:	vmovdqa YMMWORD PTR [rsp+0x4a0],ymm1
  900ce9:	vpshufd ymm1,ymm0,0x55
  900cee:	vpermq ymm1,ymm1,0xaa
  900cf4:	vmovdqa YMMWORD PTR [rsp+0x640],ymm1
  900cfd:	vpshufd ymm1,ymm0,0xaa
  900d02:	vpermq ymm1,ymm1,0xaa
  900d08:	vmovdqa YMMWORD PTR [rsp+0x620],ymm1
  900d11:	vpbroadcastd ymm1,xmm0
  900d16:	vmovdqa YMMWORD PTR [rsp+0x600],ymm1
  900d1f:	vpshufd ymm0,ymm0,0xff
  900d24:	vpermq ymm0,ymm0,0xaa
  900d2a:	vmovdqa YMMWORD PTR [rsp+0x5e0],ymm0
  900d33:	shr    rax,0x20
  900d37:	vmovd  xmm0,eax
  900d3b:	vpbroadcastd ymm0,xmm0
  900d40:	vmovdqa YMMWORD PTR [rsp+0x580],ymm0
  900d49:	mov    eax,r15d
  900d4c:	shl    eax,0x6
  900d4f:	mov    DWORD PTR [rsp+0x9c],eax
  900d56:	mov    eax,r15d
  900d59:	shl    eax,0x4
  900d5c:	mov    DWORD PTR [rsp+0xf0],eax
  900d63:	mov    rax,r15
  900d66:	shl    rax,0x4
  900d6a:	mov    QWORD PTR [rsp+0x380],rax
  900d72:	neg    rax
  900d75:	mov    QWORD PTR [rsp+0x100],rax
  900d7d:	mov    rax,QWORD PTR [rip+0x6e21bc]        # fe2f40 <_DYNAMIC+0x1a18>
  900d84:	vmovaps xmm0,XMMWORD PTR [rsp+0x340]
  900d8d:	vmovaps XMMWORD PTR [rsp+0x450],xmm0
  900d96:	vmovaps xmm0,XMMWORD PTR [rsp+0x350]
  900d9f:	vmovaps XMMWORD PTR [rsp+0x440],xmm0
  900da8:	vbroadcastss ymm0,DWORD PTR [rsp+0x370]
  900db2:	vmovaps YMMWORD PTR [rsp+0x760],ymm0
  900dbb:	vmovdqa xmm0,XMMWORD PTR [rsp+0x360]
  900dc4:	vmovdqa XMMWORD PTR [rsp+0xe0],xmm0
  900dcd:	mov    QWORD PTR [rsp+0x240],r15
  900dd5:	mov    DWORD PTR [rsp+0x2c],r13d
  900dda:	jmp    900dfa <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3ca>
  900ddc:	nop    DWORD PTR [rax+0x0]
  900de0:	add    r14,r15
  900de3:	mov    QWORD PTR [rsp+0x10],r14
  900de8:	dec    QWORD PTR [rsp+0x50]
  900ded:	mov    rax,QWORD PTR [rip+0x6e214c]        # fe2f40 <_DYNAMIC+0x1a18>
  900df4:	je     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  900dfa:	mov    rdi,QWORD PTR [rsp+0x68]
  900dff:	mov    r14,QWORD PTR [rsp+0x10]
  900e04:	mov    rsi,r14
  900e07:	vzeroupper
  900e0a:	call   rax
  900e0c:	test   rax,rax
  900e0f:	mov    rsi,QWORD PTR [rsp+0x48]
  900e14:	je     900de0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3b0>
  900e16:	test   rdx,rdx
  900e19:	je     900de0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3b0>
  900e1b:	mov    r8,rax
  900e1e:	cmp    r14d,DWORD PTR [rsp+0x1c]
  900e23:	mov    eax,0x0
  900e28:	sbb    eax,eax
  900e2a:	cmp    r14,0x7fffffff
  900e31:	ja     902f5a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x252a>
  900e37:	mov    ecx,r14d
  900e3a:	sub    ecx,DWORD PTR [rsp+0x18]
  900e3e:	mov    edi,ecx
  900e40:	sar    edi,0x1f
  900e43:	imul   ecx,r13d
  900e47:	vmovd  xmm0,r14d
  900e4c:	vpbroadcastd ymm1,xmm0
  900e51:	vmovd  xmm0,eax
  900e55:	vpbroadcastd ymm0,xmm0
  900e5a:	vmovdqa YMMWORD PTR [rsp+0x560],ymm0
  900e63:	vpand  xmm0,xmm1,XMMWORD PTR [rsp+0x420]
  900e6c:	vpbroadcastd ymm0,xmm0
  900e71:	vmovdqa YMMWORD PTR [rsp+0x5c0],ymm0
  900e7a:	vmovd  xmm0,ecx
  900e7e:	vpbroadcastd ymm0,xmm0
  900e83:	vmovdqa YMMWORD PTR [rsp+0x540],ymm0
  900e8c:	vmovd  xmm0,edi
  900e90:	vpbroadcastd ymm0,xmm0
  900e95:	vmovdqa YMMWORD PTR [rsp+0x520],ymm0
  900e9e:	mov    QWORD PTR [rsp+0x80],0x0
  900eaa:	cmp    r14d,DWORD PTR [rsp+0x98]
  900eb2:	mov    eax,0x0
  900eb7:	sbb    eax,eax
  900eb9:	vmovd  xmm0,eax
  900ebd:	vpbroadcastd ymm0,xmm0
  900ec2:	vmovdqa YMMWORD PTR [rsp+0x460],ymm0
  900ecb:	vmovd  xmm0,DWORD PTR [rsp+0x34]
  900ed1:	vpbroadcastd ymm0,xmm0
  900ed6:	vmovdqa YMMWORD PTR [rsp+0x480],ymm1
  900edf:	vpandn ymm0,ymm0,ymm1
  900ee3:	vmovdqa YMMWORD PTR [rsp+0x5a0],ymm0
  900eec:	mov    eax,r14d
  900eef:	sub    eax,DWORD PTR [rsp+0x30]
  900ef3:	mov    ecx,eax
  900ef5:	sar    ecx,0x1f
  900ef8:	imul   eax,DWORD PTR [rsp+0x94]
  900f00:	vmovd  xmm0,eax
  900f04:	vpbroadcastd ymm0,xmm0
  900f09:	vmovdqa YMMWORD PTR [rsp+0x500],ymm0
  900f12:	vmovd  xmm0,ecx
  900f16:	vpbroadcastd ymm0,xmm0
  900f1b:	vmovdqa YMMWORD PTR [rsp+0x4e0],ymm0
  900f24:	mov    rax,QWORD PTR [rsp+0x100]
  900f2c:	mov    QWORD PTR [rsp+0xc0],rax
  900f34:	xor    ecx,ecx
  900f36:	mov    QWORD PTR [rsp+0x130],rbx
  900f3e:	cmp    rdx,rsi
  900f41:	mov    rdi,rsi
  900f44:	cmovb  rdi,rdx
  900f48:	mov    rax,rdi
  900f4b:	or     rax,r15
  900f4e:	shr    rax,0x20
  900f52:	mov    QWORD PTR [rsp+0x120],rdx
  900f5a:	je     900f70 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x540>
  900f5c:	mov    rax,rdi
  900f5f:	xor    edx,edx
  900f61:	div    r15
  900f64:	mov    r14,rax
  900f67:	jmp    900f7a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x54a>
  900f69:	nop    DWORD PTR [rax+0x0]
  900f70:	mov    eax,edi
  900f72:	xor    edx,edx
  900f74:	div    r15d
  900f77:	mov    r14d,eax
  900f7a:	mov    QWORD PTR [rsp+0x118],rcx
  900f82:	imul   rcx,rsi
  900f86:	mov    QWORD PTR [rsp+0xc8],rcx
  900f8e:	cmp    rdx,0x1
  900f92:	sbb    r14,0xffffffffffffffff
  900f96:	cmp    r14,0x40
  900f9a:	mov    eax,0x40
  900f9f:	cmovae r14,rax
  900fa3:	mov    QWORD PTR [rsp+0x110],rdi
  900fab:	lea    rax,[rdi+rdi*1]
  900faf:	lea    rax,[rax+rax*2]
  900fb3:	mov    rcx,QWORD PTR [rsp+0x38]
  900fb8:	sub    rax,rcx
  900fbb:	mov    edx,0x0
  900fc0:	cmovb  rax,rdx
  900fc4:	mov    rdx,r14
  900fc7:	imul   rdx,QWORD PTR [rsp+0x40]
  900fcd:	cmp    rax,rdx
  900fd0:	cmovb  rdx,rax
  900fd4:	mov    QWORD PTR [rsp+0x128],r8
  900fdc:	lea    rsi,[r8+rcx*1]
  900fe0:	cmp    rdx,0x300
  900fe7:	mov    eax,0x300
  900fec:	cmovae rdx,rax
  900ff0:	mov    rdi,rbx
  900ff3:	vzeroupper
  900ff6:	call   QWORD PTR [rip+0x6e0764]        # fe1760 <memcpy@GLIBC_2.14>
  900ffc:	mov    QWORD PTR [rsp+0x108],r14
  901004:	lea    edx,[r14+0xf]
  901008:	shr    edx,0x4
  90100b:	mov    r14d,0x0
  901011:	vmovdqa xmm13,XMMWORD PTR [rsp+0xd0]
  90101a:	je     901d10 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x12e0>
  901020:	mov    rax,QWORD PTR [rsp+0xc8]
  901028:	or     rax,QWORD PTR [rsp+0x10]
  90102d:	mov    QWORD PTR [rsp+0x88],rax
  901035:	mov    r12d,0xc40
  90103b:	mov    r13d,0x2b
  901041:	mov    rdi,QWORD PTR [rsp+0xc0]
  901049:	mov    rax,QWORD PTR [rsp+0x80]
  901051:	mov    r15d,eax
  901054:	xor    r11d,r11d
  901057:	xor    r14d,r14d
  90105a:	mov    QWORD PTR [rsp+0x138],rdx
  901062:	jmp    901728 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xcf8>
  901067:	nop    WORD PTR [rax+rax*1+0x0]
  901070:	vpsrld ymm5,ymm2,0x1a
  901075:	vpaddd ymm2,ymm5,ymm2
  901079:	vpsrad ymm2,ymm2,0x6
  90107e:	vmovdqa ymm5,YMMWORD PTR [rsp+0x480]
  901087:	vpaddd ymm0,ymm2,ymm5
  90108b:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm0
  901094:	vpbroadcastd ymm11,DWORD PTR [rsp+0x430]
  90109e:	vpand  ymm0,ymm11,ymm0
  9010a2:	vpsrld ymm9,ymm3,0x1a
  9010a7:	vpaddd ymm3,ymm9,ymm3
  9010ab:	vpsrad ymm3,ymm3,0x6
  9010b0:	vpaddd ymm9,ymm3,ymm5
  9010b4:	vpand  ymm2,ymm9,ymm11
  9010b9:	vmovdqa YMMWORD PTR [rsp+0x180],ymm2
  9010c2:	vmovdqa YMMWORD PTR [rsp+0x7c0],ymm2
  9010cb:	vmovdqa YMMWORD PTR [rsp+0x1a0],ymm0
  9010d4:	vmovdqa YMMWORD PTR [rsp+0x7e0],ymm0
  9010dd:	vmovdqu YMMWORD PTR [rbx+r12*4-0x29e0],ymm0
  9010e7:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2a00],ymm2
  9010f1:	vpsrad ymm13,ymm8,0x1f
  9010f7:	vpsrld ymm13,ymm13,0x1a
  9010fd:	vpaddd ymm13,ymm13,ymm8
  901102:	vpsrad ymm8,ymm7,0x1f
  901107:	vpsrld ymm8,ymm8,0x1a
  90110d:	vmovdqa XMMWORD PTR [rsp+0x400],xmm14
  901116:	vpaddd ymm14,ymm8,ymm7
  90111a:	vpsrld ymm7,ymm12,0x1a
  901120:	vpaddd ymm7,ymm12,ymm7
  901124:	vpsrad ymm7,ymm7,0x6
  901129:	vpaddd ymm12,ymm15,ymm7
  90112d:	vpand  ymm0,ymm12,ymm11
  901132:	vmovdqa YMMWORD PTR [rsp+0x160],ymm0
  90113b:	vpsrld ymm8,ymm10,0x1a
  901141:	vpaddd ymm8,ymm8,ymm10
  901146:	vpsrad ymm8,ymm8,0x6
  90114c:	vpaddd ymm10,ymm8,ymm1
  901150:	vpand  ymm8,ymm10,ymm11
  901155:	vmovdqa YMMWORD PTR [rsp+0x800],ymm8
  90115e:	vmovdqa YMMWORD PTR [rsp+0x820],ymm0
  901167:	lea    rax,[rsp+0x800]
  90116f:	vmovdqa ymm3,ymm15
  901173:	vmovdqa YMMWORD PTR [rsp+0x140],ymm15
  90117c:	vmovaps ymm15,YMMWORD PTR [rax]
  901180:	vmovaps ymm0,YMMWORD PTR [rax+0x20]
  901185:	vmovups YMMWORD PTR [rbx+r12*4-0x28e0],ymm0
  90118f:	vpsrad ymm0,ymm14,0x6
  901195:	vpaddd ymm0,ymm0,ymm5
  901199:	vmovups YMMWORD PTR [rbx+r12*4-0x2900],ymm15
  9011a3:	vpsrad ymm14,ymm6,0x1f
  9011a8:	vpsrld ymm14,ymm14,0x1a
  9011ae:	vpaddd ymm6,ymm14,ymm6
  9011b2:	vpsrad ymm14,ymm4,0x1f
  9011b7:	vpsrld ymm14,ymm14,0x1a
  9011bd:	vpaddd ymm14,ymm14,ymm4
  9011c1:	vmovdqa ymm2,YMMWORD PTR [rsp+0x6a0]
  9011ca:	vpminud ymm4,ymm2,ymm0
  9011cf:	vpcmpeqd ymm4,ymm2,ymm4
  9011d3:	vpsrad ymm6,ymm6,0x6
  9011d8:	vpaddd ymm6,ymm6,ymm3
  9011dc:	vmovdqa ymm7,ymm1
  9011e0:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4c0]
  9011e9:	vpminud ymm15,ymm1,ymm6
  9011ee:	vpcmpeqd ymm15,ymm15,ymm1
  9011f2:	vpor   ymm3,ymm15,ymm4
  9011f6:	vmovdqa YMMWORD PTR [rsp+0x200],ymm3
  9011ff:	vpsrad ymm13,ymm13,0x6
  901205:	vpaddd ymm13,ymm13,ymm5
  901209:	vpminud ymm15,ymm2,ymm13
  90120e:	vpcmpeqd ymm15,ymm15,ymm2
  901212:	vpand  ymm3,ymm13,ymm11
  901217:	vmovdqa YMMWORD PTR [rsp+0x260],ymm3
  901220:	vpand  ymm0,ymm11,ymm0
  901224:	vmovdqa YMMWORD PTR [rsp+0x280],ymm0
  90122d:	vpand  ymm0,ymm11,ymm6
  901231:	vmovdqa YMMWORD PTR [rsp+0xa0],ymm0
  90123a:	vpsrad ymm0,ymm14,0x6
  901240:	vpaddd ymm0,ymm0,ymm7
  901244:	vpand  ymm3,ymm11,ymm0
  901248:	vmovdqa YMMWORD PTR [rsp+0x2a0],ymm3
  901251:	vpminud ymm0,ymm1,ymm0
  901256:	vpcmpeqd ymm0,ymm1,ymm0
  90125a:	vpor   ymm0,ymm15,ymm0
  90125e:	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm0
  901267:	vpminud ymm0,ymm2,ymm9
  90126c:	vpcmpeqd ymm0,ymm2,ymm0
  901270:	vpminud ymm11,ymm1,ymm10
  901275:	vpcmpeqd ymm11,ymm11,ymm1
  901279:	vpor   ymm5,ymm11,ymm0
  90127d:	vmovdqa ymm3,YMMWORD PTR [rsp+0x1c0]
  901286:	vpminud ymm0,ymm2,ymm3
  90128b:	vpcmpeqd ymm0,ymm2,ymm0
  90128f:	vpminud ymm11,ymm1,ymm12
  901294:	vpcmpeqd ymm11,ymm11,ymm1
  901298:	vpor   ymm11,ymm11,ymm0
  90129c:	vmovdqa ymm15,YMMWORD PTR [rsp+0x720]
  9012a5:	vmovdqa ymm13,YMMWORD PTR [rsp+0x180]
  9012ae:	vpsubd ymm0,ymm13,ymm15
  9012b3:	vmovdqa ymm1,YMMWORD PTR [rsp+0x700]
  9012bc:	vpmulld ymm14,ymm0,ymm1
  9012c1:	vpaddd ymm14,ymm14,ymm8
  9012c6:	vpsrad ymm0,ymm0,0x1f
  9012cb:	vpor   ymm0,ymm14,ymm0
  9012cf:	vmovdqa ymm4,YMMWORD PTR [rsp+0x1a0]
  9012d8:	vpsubd ymm14,ymm4,ymm15
  9012dd:	vpmulld ymm15,ymm14,ymm1
  9012e2:	vmovdqa ymm6,YMMWORD PTR [rsp+0x160]
  9012eb:	vpaddd ymm15,ymm15,ymm6
  9012ef:	vpsrad ymm14,ymm14,0x1f
  9012f5:	vpor   ymm14,ymm15,ymm14
  9012fa:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2800],ymm0
  901304:	vmovdqu YMMWORD PTR [rbx+r12*4-0x27e0],ymm14
  90130e:	vmovdqa ymm14,YMMWORD PTR [rsp+0x740]
  901317:	vpand  ymm0,ymm10,ymm14
  90131c:	vmovdqa ymm1,YMMWORD PTR [rsp+0x6e0]
  901325:	vpaddd ymm10,ymm7,ymm1
  901329:	vpsubd ymm0,ymm10,ymm0
  90132d:	vpand  ymm10,ymm12,ymm14
  901332:	vmovdqa ymm15,YMMWORD PTR [rsp+0x140]
  90133b:	vpaddd ymm12,ymm15,ymm1
  90133f:	vpsubd ymm10,ymm12,ymm10
  901344:	vpand  ymm9,ymm9,ymm14
  901349:	vmovdqa ymm2,YMMWORD PTR [rsp+0x5c0]
  901352:	vpcmpeqd ymm9,ymm9,ymm2
  901356:	vmovdqa ymm1,YMMWORD PTR [rsp+0x6c0]
  90135f:	vpminud ymm0,ymm1,ymm0
  901364:	vpcmpeqd ymm0,ymm1,ymm0
  901368:	vpandn ymm0,ymm0,ymm9
  90136d:	vpandn ymm12,ymm5,ymm0
  901371:	vmovdqa YMMWORD PTR [rsp+0x3e0],ymm12
  90137a:	vpand  ymm0,ymm14,ymm3
  90137e:	vpcmpeqd ymm0,ymm0,ymm2
  901382:	vpminud ymm5,ymm1,ymm10
  901387:	vpcmpeqd ymm5,ymm1,ymm5
  90138b:	vpandn ymm0,ymm5,ymm0
  90138f:	vpandn ymm10,ymm11,ymm0
  901393:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm10
  90139c:	vmovdqa ymm1,YMMWORD PTR [rsp+0x660]
  9013a5:	vpsubd ymm0,ymm13,ymm1
  9013a9:	vpsubd ymm2,ymm4,ymm1
  9013ad:	vmovdqa ymm9,YMMWORD PTR [rsp+0x600]
  9013b6:	vpmulld ymm3,ymm0,ymm9
  9013bb:	vpaddd ymm3,ymm8,ymm3
  9013bf:	vpmulld ymm5,ymm2,ymm9
  9013c4:	vpaddd ymm5,ymm5,ymm6
  9013c8:	vpsrad ymm0,ymm0,0x1f
  9013cd:	vpor   ymm0,ymm3,ymm0
  9013d1:	vpbroadcastd ymm3,DWORD PTR [rip+0xffffffffff717876]        # 18c50 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  9013da:	vpsrad ymm2,ymm2,0x1f
  9013df:	vpor   ymm2,ymm5,ymm2
  9013e3:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2700],ymm0
  9013ed:	vmovdqu YMMWORD PTR [rbx+r12*4-0x26e0],ymm2
  9013f7:	vmovdqa ymm6,YMMWORD PTR [rsp+0x260]
  901400:	vpsubd ymm0,ymm6,ymm1
  901404:	vmovdqa ymm4,YMMWORD PTR [rsp+0x280]
  90140d:	vpsubd ymm2,ymm4,ymm1
  901411:	vpmulld ymm5,ymm0,ymm9
  901416:	vpaddd ymm5,ymm5,YMMWORD PTR [rsp+0x2a0]
  90141f:	vpsrad ymm0,ymm0,0x1f
  901424:	vpor   ymm0,ymm5,ymm0
  901428:	vpmulld ymm5,ymm2,ymm9
  90142d:	vpaddd ymm5,ymm5,YMMWORD PTR [rsp+0xa0]
  901436:	vpsrad ymm2,ymm2,0x1f
  90143b:	vpor   ymm2,ymm5,ymm2
  90143f:	vpand  ymm1,ymm12,ymm3
  901443:	vmovdqa YMMWORD PTR [rsp+0x180],ymm1
  90144c:	vpand  ymm1,ymm10,ymm3
  901450:	vmovdqa YMMWORD PTR [rsp+0x1a0],ymm1
  901459:	vmovdqa ymm5,YMMWORD PTR [rsp+0x680]
  901462:	vpminud ymm1,ymm5,ymm7
  901467:	vpcmpeqd ymm1,ymm5,ymm1
  90146b:	vpminud ymm3,ymm5,ymm15
  901470:	vpcmpeqd ymm3,ymm5,ymm3
  901474:	vmovdqa ymm5,YMMWORD PTR [rsp+0x460]
  90147d:	vpandn ymm1,ymm1,ymm5
  901481:	vmovdqa YMMWORD PTR [rsp+0x140],ymm1
  90148a:	vpandn ymm1,ymm3,ymm5
  90148e:	vmovdqa YMMWORD PTR [rsp+0x160],ymm1
  901497:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2600],ymm0
  9014a1:	vmovdqu YMMWORD PTR [rbx+r12*4-0x25e0],ymm2
  9014ab:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4a0]
  9014b4:	vpminud ymm0,ymm1,ymm0
  9014b9:	vpcmpeqd ymm0,ymm1,ymm0
  9014bd:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0x1e0]
  9014c6:	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm0
  9014cf:	vpminud ymm0,ymm1,ymm2
  9014d4:	vpcmpeqd ymm0,ymm1,ymm0
  9014d8:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0x200]
  9014e1:	vmovdqa YMMWORD PTR [rsp+0x3c0],ymm0
  9014ea:	mov    edx,DWORD PTR [rsp+0x34]
  9014ee:	mov    eax,edx
  9014f0:	not    eax
  9014f2:	vmovd  xmm0,eax
  9014f6:	vpbroadcastd ymm0,xmm0
  9014fb:	vpand  ymm1,ymm6,ymm0
  9014ff:	vpand  ymm0,ymm4,ymm0
  901503:	vmovdqa ymm2,YMMWORD PTR [rsp+0x5a0]
  90150c:	vpcmpeqd ymm1,ymm2,ymm1
  901510:	vmovdqa YMMWORD PTR [rsp+0x3a0],ymm1
  901519:	vpcmpeqd ymm0,ymm2,ymm0
  90151d:	vmovdqa YMMWORD PTR [rsp+0x220],ymm0
  901526:	mov    QWORD PTR [rsp+0x200],rdi
  90152e:	lea    rdi,[rsp+0x2c0]
  901536:	lea    rsi,[rsp+0x7c0]
  90153e:	mov    rbx,r11
  901541:	vzeroupper
  901544:	call   4be3c0 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAINtNtNtCscIM9z48VHAb_13fearless_simd9generated10simd_types6i32x16NtNtBD_4avx24Avx2Ej2_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitBy_ENCINvMB27_B24_10wrap_mut_1By_NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesB1B_Kb1_Es4_0E0EB3x_>
  901549:	vmovdqa xmm14,XMMWORD PTR [rsp+0x400]
  901552:	mov    r11,rbx
  901555:	mov    rdi,QWORD PTR [rsp+0x200]
  90155d:	mov    rbx,QWORD PTR [rsp+0x130]
  901565:	mov    rdx,QWORD PTR [rsp+0x138]
  90156d:	vmovdqa xmm13,XMMWORD PTR [rsp+0xd0]
  901576:	vmovdqa ymm0,YMMWORD PTR [rsp+0x260]
  90157f:	vpsubd ymm0,ymm0,YMMWORD PTR [rsp+0x2c0]
  901588:	vmovdqa ymm2,YMMWORD PTR [rsp+0x620]
  901591:	vpaddd ymm1,ymm2,YMMWORD PTR [rsp+0x2a0]
  90159a:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x300]
  9015a3:	vmovdqa ymm3,YMMWORD PTR [rsp+0x640]
  9015ac:	vpminud ymm0,ymm3,ymm0
  9015b1:	vpcmpeqd ymm0,ymm3,ymm0
  9015b5:	vmovdqa ymm4,YMMWORD PTR [rsp+0x5e0]
  9015be:	vpminud ymm1,ymm4,ymm1
  9015c3:	vpcmpeqd ymm1,ymm4,ymm1
  9015c7:	vpor   ymm0,ymm0,ymm1
  9015cb:	vmovdqa ymm1,YMMWORD PTR [rsp+0x280]
  9015d4:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x2e0]
  9015dd:	vpaddd ymm2,ymm2,YMMWORD PTR [rsp+0xa0]
  9015e6:	vpsubd ymm2,ymm2,YMMWORD PTR [rsp+0x320]
  9015ef:	vpminud ymm1,ymm3,ymm1
  9015f4:	vpcmpeqd ymm1,ymm3,ymm1
  9015f8:	vpminud ymm2,ymm4,ymm2
  9015fd:	vpcmpeqd ymm2,ymm4,ymm2
  901601:	vpor   ymm1,ymm1,ymm2
  901605:	vmovdqa ymm4,YMMWORD PTR [rsp+0x1e0]
  90160e:	vpandn ymm2,ymm4,YMMWORD PTR [rsp+0x3a0]
  901617:	vmovdqa ymm5,YMMWORD PTR [rsp+0x3c0]
  901620:	vpandn ymm3,ymm5,YMMWORD PTR [rsp+0x220]
  901629:	vpsrld ymm2,ymm2,0x1f
  90162e:	vpor   ymm0,ymm0,ymm4
  901632:	vpor   ymm1,ymm1,ymm5
  901636:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff717829]        # 18e68 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1449>
  90163f:	vpandn ymm0,ymm0,ymm4
  901643:	vpandn ymm1,ymm1,ymm4
  901647:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff7179f0]        # 19040 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  901650:	vmovdqa ymm7,YMMWORD PTR [rsp+0x140]
  901659:	vpand  ymm5,ymm7,ymm4
  90165d:	vpor   ymm2,ymm2,ymm5
  901661:	vpor   ymm2,ymm2,YMMWORD PTR [rsp+0x180]
  90166a:	vpsrld ymm3,ymm3,0x1f
  90166f:	vmovdqa ymm6,YMMWORD PTR [rsp+0x160]
  901678:	vpand  ymm4,ymm6,ymm4
  90167c:	vpor   ymm3,ymm3,ymm4
  901680:	vpor   ymm3,ymm3,YMMWORD PTR [rsp+0x1a0]
  901689:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff7177fe]        # 18e90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  901692:	vpand  ymm5,ymm7,ymm4
  901696:	vpand  ymm5,ymm5,YMMWORD PTR [rsp+0x3e0]
  90169f:	vpor   ymm0,ymm5,ymm0
  9016a3:	vpor   ymm0,ymm2,ymm0
  9016a7:	vpand  ymm2,ymm6,ymm4
  9016ab:	vpand  ymm2,ymm2,YMMWORD PTR [rsp+0x1c0]
  9016b4:	vpor   ymm1,ymm2,ymm1
  9016b8:	vpor   ymm1,ymm3,ymm1
  9016bc:	lea    rax,[r12-0xc40]
  9016c4:	vpor   xmm2,xmm14,XMMWORD PTR [rip+0xffffffffff713b24]        # 151f0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0xeb0>
  9016cc:	vextracti128 xmm3,ymm1,0x1
  9016d2:	vpackssdw xmm1,xmm1,xmm3
  9016d6:	vextracti128 xmm3,ymm0,0x1
  9016dc:	vpackssdw xmm0,xmm0,xmm3
  9016e0:	vpacksswb xmm0,xmm0,xmm1
  9016e4:	vpand  xmm0,xmm2,xmm0
  9016e8:	vmovdqu XMMWORD PTR [rbx+r12*1],xmm0
  9016ee:	vpand  xmm0,xmm13,xmm0
  9016f2:	vpxor  xmm1,xmm1,xmm1
  9016f6:	vpcmpeqb xmm0,xmm0,xmm1
  9016fa:	vpmovmskb ecx,xmm0
  9016fe:	xor    ecx,0xffff
  901704:	shlx   rax,rcx,rax
  901709:	or     r14,rax
  90170c:	inc    r11
  90170f:	add    r12,0x10
  901713:	add    r13,0x30
  901717:	add    r15d,DWORD PTR [rsp+0xf0]
  90171f:	cmp    r11,rdx
  901722:	jae    901d10 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x12e0>
  901728:	add    rdi,QWORD PTR [rsp+0x380]
  901730:	cmp    rdi,0x7fffffff
  901737:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  90173d:	cmp    QWORD PTR [rsp+0x240],0x1
  901746:	jne    901800 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xdd0>
  90174c:	vmovdqu xmm0,XMMWORD PTR [rbx+r13*2-0x56]
  901753:	vmovdqu xmm1,XMMWORD PTR [rbx+r13*2-0x50]
  90175a:	vmovdqu xmm2,XMMWORD PTR [rbx+r13*2-0x26]
  901761:	vmovdqu xmm3,XMMWORD PTR [rbx+r13*2-0x20]
  901768:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r13*2-0x46],0x4
  901770:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r13*2-0x36],0x2
  901778:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r13*2-0x16],0x4
  901780:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r13*2-0x6],0x2
  901788:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r13*2-0x40],0x4
  901790:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r13*2-0x30],0x2
  901798:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r13*2-0x10],0x4
  9017a0:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r13*2],0x2
  9017a7:	vmovq  xmm6,QWORD PTR [rip+0xffffffffff714fb1]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  9017af:	vpshufb xmm4,xmm1,xmm6
  9017b4:	vpshufb xmm5,xmm0,xmm6
  9017b9:	vpunpcklbw xmm4,xmm5,xmm4
  9017bd:	vpshufb xmm5,xmm3,xmm6
  9017c2:	vpshufb xmm6,xmm2,xmm6
  9017c7:	vpunpcklbw xmm5,xmm6,xmm5
  9017cb:	vmovd  xmm6,DWORD PTR [rip+0xffffffffff7130fd]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x590>
  9017d3:	vpshufb xmm1,xmm1,xmm6
  9017d8:	vpshufb xmm0,xmm0,xmm6
  9017dd:	vpunpcklbw xmm0,xmm0,xmm1
  9017e1:	vpshufb xmm1,xmm3,xmm6
  9017e6:	vpshufb xmm2,xmm2,xmm6
  9017eb:	vpunpcklbw xmm1,xmm2,xmm1
  9017ef:	jmp    9018b9 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xe89>
  9017f4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  901800:	vmovdqu xmm0,XMMWORD PTR [rbx+r13*4-0xac]
  90180a:	vmovdqu xmm1,XMMWORD PTR [rbx+r13*4-0x8c]
  901814:	vmovdqu xmm2,XMMWORD PTR [rbx+r13*4-0x7c]
  90181b:	vmovdqu xmm3,XMMWORD PTR [rbx+r13*4-0x5c]
  901822:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r13*4-0x9c],0x4
  90182d:	vmovdqa xmm5,XMMWORD PTR [rip+0xffffffffff7148db]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  901835:	vpshufb xmm1,xmm1,xmm5
  90183a:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff715ade]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  901842:	vpshufb xmm0,xmm0,xmm6
  901847:	vpor   xmm0,xmm0,xmm1
  90184b:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+r13*4-0x6c],0x4
  901853:	vpshufb xmm2,xmm3,xmm5
  901858:	vpshufb xmm1,xmm1,xmm6
  90185d:	vpor   xmm1,xmm1,xmm2
  901861:	vmovdqu xmm2,XMMWORD PTR [rbx+r13*4-0x2c]
  901868:	vmovdqu xmm3,XMMWORD PTR [rbx+r13*4-0x4c]
  90186f:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r13*4-0x3c],0x4
  901877:	vpshufb xmm2,xmm2,xmm5
  90187c:	vpshufb xmm3,xmm3,xmm6
  901881:	vpor   xmm2,xmm3,xmm2
  901885:	vmovdqu xmm3,XMMWORD PTR [rbx+r13*4+0x4]
  90188c:	vmovdqu xmm4,XMMWORD PTR [rbx+r13*4-0x1c]
  901893:	vpblendd xmm4,xmm4,XMMWORD PTR [rbx+r13*4-0xc],0x4
  90189b:	vpshufb xmm3,xmm3,xmm5
  9018a0:	vpshufb xmm4,xmm4,xmm6
  9018a5:	vpor   xmm3,xmm4,xmm3
  9018a9:	vpunpckldq xmm4,xmm0,xmm1
  9018ad:	vpunpckldq xmm5,xmm2,xmm3
  9018b1:	vpunpckhdq xmm0,xmm0,xmm1
  9018b5:	vpunpckhdq xmm1,xmm2,xmm3
  9018b9:	vpunpcklqdq xmm0,xmm0,xmm1
  9018bd:	vpunpcklqdq xmm1,xmm4,xmm5
  9018c1:	vpunpckhqdq xmm3,xmm4,xmm5
  9018c5:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff7126e3]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  9018cd:	vmovdqa xmm4,XMMWORD PTR [rsp+0xe0]
  9018d6:	vpshufb xmm14,xmm4,xmm2
  9018db:	vptest xmm14,xmm13
  9018e0:	je     90170c <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xcdc>
  9018e6:	vmovdqu XMMWORD PTR [rbx+r12*1-0x40],xmm1
  9018ed:	vmovdqa xmm1,XMMWORD PTR [rsp+0x450]
  9018f6:	vpshufb xmm4,xmm1,xmm2
  9018fb:	vmovdqa xmm1,XMMWORD PTR [rsp+0x440]
  901904:	vpshufb xmm2,xmm1,xmm2
  901909:	vpunpcklbw xmm1,xmm4,xmm2
  90190d:	vpunpckhbw xmm2,xmm4,xmm2
  901911:	vpmovsxbw ymm3,xmm3
  901916:	vpmovsxwd ymm4,xmm3
  90191b:	vextracti128 xmm3,ymm3,0x1
  901921:	vpmovsxwd ymm3,xmm3
  901926:	vpabsd ymm5,ymm4
  90192b:	vpabsd ymm6,ymm3
  901930:	vpsrld ymm7,ymm5,0x4
  901935:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff717632]        # 18f70 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  90193e:	vpsrld ymm8,ymm6,0x4
  901943:	vpmaxud ymm7,ymm7,ymm9
  901948:	vpcmpeqd ymm11,ymm11,ymm11
  90194d:	vpaddd ymm7,ymm11,ymm7
  901951:	vpmaxud ymm8,ymm8,ymm9
  901956:	vpaddd ymm8,ymm8,ymm11
  90195b:	vpslld ymm10,ymm7,0x4
  901960:	vpsubd ymm5,ymm5,ymm10
  901965:	vpslld ymm10,ymm8,0x4
  90196b:	vpsubd ymm6,ymm6,ymm10
  901970:	vpsllvd ymm5,ymm5,ymm7
  901975:	vpsllvd ymm6,ymm6,ymm8
  90197a:	vpsrad ymm4,ymm4,0x1f
  90197f:	vpsrad ymm3,ymm3,0x1f
  901984:	vpxor  ymm5,ymm5,ymm4
  901988:	vpxor  ymm6,ymm6,ymm3
  90198c:	vpsubd ymm8,ymm5,ymm4
  901990:	vpsubd ymm7,ymm6,ymm3
  901994:	vpmovsxbw ymm0,xmm0
  901999:	vpmovsxwd ymm3,xmm0
  90199e:	vextracti128 xmm0,ymm0,0x1
  9019a4:	vpmovsxwd ymm0,xmm0
  9019a9:	vpabsd ymm4,ymm3
  9019ae:	vpabsd ymm5,ymm0
  9019b3:	vpsrld ymm6,ymm4,0x4
  9019b8:	vpsrld ymm10,ymm5,0x4
  9019bd:	vpmaxud ymm6,ymm6,ymm9
  9019c2:	vpaddd ymm6,ymm11,ymm6
  9019c6:	vpmaxud ymm9,ymm10,ymm9
  9019cb:	vpaddd ymm9,ymm9,ymm11
  9019d0:	vpslld ymm10,ymm6,0x4
  9019d5:	vpsubd ymm4,ymm4,ymm10
  9019da:	vpslld ymm10,ymm9,0x4
  9019e0:	vpsubd ymm5,ymm5,ymm10
  9019e5:	vpmovsxwd ymm1,xmm1
  9019ea:	vpmovsxwd ymm2,xmm2
  9019ef:	vmovdqa ymm10,YMMWORD PTR [rsp+0x760]
  9019f8:	vpmulld ymm1,ymm10,ymm1
  9019fd:	vpmulld ymm2,ymm10,ymm2
  901a02:	vpsllvd ymm4,ymm4,ymm6
  901a07:	vpsllvd ymm5,ymm5,ymm9
  901a0c:	vpsrad ymm3,ymm3,0x1f
  901a11:	vpsrad ymm0,ymm0,0x1f
  901a16:	vpxor  ymm4,ymm4,ymm3
  901a1a:	vpxor  ymm5,ymm5,ymm0
  901a1e:	vpsubd ymm4,ymm4,ymm3
  901a22:	vpsubd ymm6,ymm5,ymm0
  901a26:	vpmulld ymm0,ymm1,ymm8
  901a2b:	vpmulld ymm3,ymm2,ymm7
  901a30:	vpsrad ymm5,ymm0,0x1f
  901a35:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff71756a]        # 18fa8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  901a3e:	vpaddd ymm0,ymm9,ymm0
  901a42:	vpaddd ymm5,ymm0,ymm5
  901a46:	vpsrad ymm0,ymm3,0x1f
  901a4b:	vpaddd ymm3,ymm9,ymm3
  901a4f:	vpaddd ymm10,ymm3,ymm0
  901a53:	vpmulld ymm0,ymm1,ymm4
  901a58:	vpsrad ymm1,ymm0,0x1f
  901a5d:	vpaddd ymm0,ymm9,ymm0
  901a61:	vpaddd ymm11,ymm0,ymm1
  901a65:	vmovd  xmm0,r15d
  901a6a:	vpbroadcastd ymm0,xmm0
  901a6f:	vpmulld ymm1,ymm2,ymm6
  901a74:	vpaddd ymm2,ymm9,ymm1
  901a78:	vpsrad ymm1,ymm1,0x1f
  901a7d:	vpaddd ymm9,ymm2,ymm1
  901a81:	vpaddd ymm1,ymm0,YMMWORD PTR [rsp+0x780]
  901a8a:	vpaddd ymm15,ymm0,YMMWORD PTR [rsp+0x7a0]
  901a93:	vpsrad ymm3,ymm5,0xe
  901a98:	vpsrad ymm2,ymm10,0xe
  901a9e:	vpsrad ymm10,ymm11,0xe
  901aa4:	vpsrad ymm12,ymm9,0xe
  901aaa:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2e00],ymm8
  901ab4:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2de0],ymm7
  901abe:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2c00],ymm3
  901ac8:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2be0],ymm2
  901ad2:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2d00],ymm4
  901adc:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2ce0],ymm6
  901ae6:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2b00],ymm10
  901af0:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2ae0],ymm12
  901afa:	mov    rax,QWORD PTR [rsp+0x88]
  901b02:	test   QWORD PTR [rsp+0x20],rax
  901b07:	jne    901070 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x640>
  901b0d:	vpabsd ymm5,ymm6
  901b12:	vpabsd ymm9,ymm4
  901b17:	vpabsd ymm11,ymm7
  901b1c:	vpor   ymm5,ymm11,ymm5
  901b20:	vpabsd ymm11,ymm8
  901b25:	vpor   ymm9,ymm9,ymm11
  901b2a:	vpabsd ymm11,ymm3
  901b2f:	vpor   ymm9,ymm9,ymm11
  901b34:	vpabsd ymm11,ymm2
  901b39:	vpor   ymm5,ymm11,ymm5
  901b3d:	vpabsd ymm11,ymm12
  901b42:	vpor   ymm5,ymm11,ymm5
  901b46:	vpabsd ymm11,ymm10
  901b4b:	vpor   ymm9,ymm9,ymm11
  901b50:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff71729f]        # 18df8 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x13d9>
  901b59:	vpcmpgtd ymm5,ymm5,ymm11
  901b5e:	vpcmpgtd ymm9,ymm9,ymm11
  901b63:	vpackssdw ymm5,ymm9,ymm5
  901b67:	vpmovmskb eax,ymm5
  901b6b:	test   eax,eax
  901b6d:	jne    901070 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x640>
  901b73:	vmovaps ymm0,YMMWORD PTR [rsp+0x480]
  901b7c:	vmovups YMMWORD PTR [rbx+r12*4-0x2a00],ymm0
  901b86:	vmovups YMMWORD PTR [rbx+r12*4-0x29e0],ymm0
  901b90:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2900],ymm1
  901b9a:	vmovdqu YMMWORD PTR [rbx+r12*4-0x28e0],ymm15
  901ba4:	vmovdqa ymm0,YMMWORD PTR [rsp+0x540]
  901bad:	vpaddd ymm2,ymm1,ymm0
  901bb1:	vpaddd ymm3,ymm15,ymm0
  901bb5:	vmovdqa ymm0,YMMWORD PTR [rsp+0x520]
  901bbe:	vpor   ymm2,ymm2,ymm0
  901bc2:	vpor   ymm3,ymm3,ymm0
  901bc6:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2800],ymm2
  901bd0:	vmovdqu YMMWORD PTR [rbx+r12*4-0x27e0],ymm3
  901bda:	vmovdqa ymm0,YMMWORD PTR [rsp+0x4c0]
  901be3:	vpminud ymm2,ymm0,ymm1
  901be8:	vpcmpeqd ymm2,ymm0,ymm2
  901bec:	vpminud ymm3,ymm0,ymm15
  901bf1:	vpcmpeqd ymm4,ymm0,ymm3
  901bf5:	vmovdqa ymm0,YMMWORD PTR [rsp+0x560]
  901bfe:	vpandn ymm3,ymm2,ymm0
  901c02:	vpandn ymm2,ymm4,ymm0
  901c06:	vmovdqa ymm0,YMMWORD PTR [rsp+0x580]
  901c0f:	vpminud ymm4,ymm0,ymm1
  901c14:	vpcmpeqd ymm4,ymm0,ymm4
  901c18:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffff71702f]        # 18c50 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  901c21:	vmovdqa ymm9,ymm1
  901c25:	vmovdqa ymm1,YMMWORD PTR [rsp+0x460]
  901c2e:	vpandn ymm4,ymm4,ymm1
  901c32:	vpand  ymm6,ymm3,ymm5
  901c36:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff717401]        # 19040 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  901c3f:	vpand  ymm8,ymm4,ymm7
  901c43:	vpor   ymm6,ymm8,ymm6
  901c47:	vpminud ymm8,ymm0,ymm15
  901c4c:	vpcmpeqd ymm8,ymm8,ymm0
  901c50:	vpandn ymm8,ymm8,ymm1
  901c54:	vpand  ymm5,ymm2,ymm5
  901c58:	vpand  ymm7,ymm8,ymm7
  901c5c:	vpor   ymm5,ymm7,ymm5
  901c60:	vmovdqa ymm0,YMMWORD PTR [rsp+0x500]
  901c69:	vpaddd ymm1,ymm9,ymm0
  901c6d:	vpaddd ymm0,ymm15,ymm0
  901c71:	vmovdqa ymm7,YMMWORD PTR [rsp+0x4e0]
  901c7a:	vpor   ymm1,ymm1,ymm7
  901c7e:	vpor   ymm0,ymm0,ymm7
  901c82:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2700],ymm1
  901c8c:	vmovdqu YMMWORD PTR [rbx+r12*4-0x26e0],ymm0
  901c96:	vmovdqu YMMWORD PTR [rbx+r12*4-0x2600],ymm1
  901ca0:	vmovdqa ymm7,YMMWORD PTR [rsp+0x4a0]
  901ca9:	vpminud ymm1,ymm7,ymm1
  901cae:	vpcmpeqd ymm1,ymm7,ymm1
  901cb2:	vpandn ymm1,ymm1,ymm3
  901cb6:	vpand  ymm3,ymm4,ymm3
  901cba:	vmovdqu YMMWORD PTR [rbx+r12*4-0x25e0],ymm0
  901cc4:	vpminud ymm0,ymm7,ymm0
  901cc9:	vpcmpeqd ymm0,ymm7,ymm0
  901ccd:	vpandn ymm4,ymm0,ymm2
  901cd1:	vpand  ymm0,ymm8,ymm2
  901cd5:	vpbroadcastd ymm2,DWORD PTR [rip+0xffffffffff7171b2]        # 18e90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  901cde:	vpand  ymm3,ymm3,ymm2
  901ce2:	vpor   ymm3,ymm6,ymm3
  901ce6:	vpand  ymm0,ymm0,ymm2
  901cea:	vpor   ymm2,ymm5,ymm0
  901cee:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffff717179]        # 18e70 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1451>
  901cf7:	vpand  ymm0,ymm1,ymm5
  901cfb:	vpor   ymm0,ymm3,ymm0
  901cff:	vpand  ymm1,ymm4,ymm5
  901d03:	vpor   ymm1,ymm2,ymm1
  901d07:	jmp    9016bc <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xc8c>
  901d0c:	nop    DWORD PTR [rax+0x0]
  901d10:	mov    rax,QWORD PTR [rsp+0x108]
  901d18:	cmp    rax,0x1
  901d1c:	adc    rax,0x0
  901d20:	bzhi   rax,r14,rax
  901d25:	mov    QWORD PTR [rsp+0x2c0],rbx
  901d2d:	mov    QWORD PTR [rsp+0x2c8],rax
  901d35:	mov    r14,QWORD PTR [rsp+0x10]
  901d3a:	mov    QWORD PTR [rsp+0x2d0],r14
  901d42:	mov    rax,QWORD PTR [rsp+0xc8]
  901d4a:	mov    QWORD PTR [rsp+0x2d8],rax
  901d52:	mov    r15,QWORD PTR [rsp+0x240]
  901d5a:	mov    QWORD PTR [rsp+0x2e0],r15
  901d62:	test   BYTE PTR [rsp+0x78],0x1
  901d67:	je     901d90 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1360>
  901d69:	lea    rdi,[rsp+0x2c0]
  901d71:	mov    rsi,QWORD PTR [rsp+0x60]
  901d76:	mov    rdx,QWORD PTR [rsp+0x70]
  901d7b:	mov    rcx,QWORD PTR [rsp+0x58]
  901d80:	vzeroupper
  901d83:	call   QWORD PTR [rip+0x6e0fef]        # fe2d78 <_DYNAMIC+0x1850>
  901d89:	jmp    901db0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1380>
  901d8b:	nop    DWORD PTR [rax+rax*1+0x0]
  901d90:	lea    rdi,[rsp+0x2c0]
  901d98:	mov    rsi,QWORD PTR [rsp+0x60]
  901d9d:	mov    rdx,QWORD PTR [rsp+0x70]
  901da2:	mov    rcx,QWORD PTR [rsp+0x58]
  901da7:	vzeroupper
  901daa:	call   QWORD PTR [rip+0x6e0fc0]        # fe2d70 <_DYNAMIC+0x1848>
  901db0:	mov    r13d,DWORD PTR [rsp+0x2c]
  901db5:	mov    rcx,QWORD PTR [rsp+0x110]
  901dbd:	lea    rax,[rcx+rcx*2]
  901dc1:	mov    r8,QWORD PTR [rsp+0x128]
  901dc9:	lea    r8,[r8+rax*2]
  901dcd:	mov    rdx,QWORD PTR [rsp+0x120]
  901dd5:	sub    rdx,rcx
  901dd8:	mov    rcx,QWORD PTR [rsp+0x118]
  901de0:	inc    rcx
  901de3:	mov    rax,QWORD PTR [rsp+0x80]
  901deb:	add    eax,DWORD PTR [rsp+0x9c]
  901df2:	mov    QWORD PTR [rsp+0x80],rax
  901dfa:	mov    rsi,QWORD PTR [rsp+0x48]
  901dff:	add    QWORD PTR [rsp+0xc0],rsi
  901e07:	test   rdx,rdx
  901e0a:	jne    900f3e <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x50e>
  901e10:	jmp    900de0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3b0>
  901e15:	vmovd  xmm0,r15d
  901e1a:	vpbroadcastd ymm0,xmm0
  901e1f:	vpmulld ymm4,ymm0,YMMWORD PTR [rip+0xffffffffff7185b8]        # 1a3e0 <anon.db13f839740d960fd97bc530122b4c99.104.llvm.5594421697515501092+0x4c8>
  901e28:	vpmulld xmm1,xmm0,XMMWORD PTR [rip+0xffffffffff71216f]        # 13fa0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6ee>
  901e31:	vpmulld xmm2,xmm0,XMMWORD PTR [rip+0xffffffffff714f76]        # 16db0 <anon.43d21acec09d19046152b53125a552af.1615.llvm.7158842796534594082+0x3e0>
  901e3a:	not    r8d
  901e3d:	vmovd  xmm5,r8d
  901e42:	mov    rax,QWORD PTR [rsp+0x78]
  901e47:	shl    al,0x3
  901e4a:	or     al,0x4
  901e4c:	vmovd  xmm3,eax
  901e50:	vpbroadcastb xmm3,xmm3
  901e55:	vpxor  xmm6,xmm6,xmm6
  901e59:	vpblendd xmm0,xmm6,xmm0,0x2
  901e5f:	vpermq ymm2,ymm2,0xd0
  901e65:	vpblendd ymm0,ymm2,ymm0,0x3
  901e6b:	vpbroadcastq ymm1,xmm1
  901e70:	vpblendd ymm1,ymm0,ymm1,0xc0
  901e76:	lea    r14,[rbx+0x300]
  901e7d:	mov    rax,QWORD PTR [rsp+0x20]
  901e82:	not    eax
  901e84:	vmovd  xmm0,eax
  901e88:	vmovdqa XMMWORD PTR [rsp+0xd0],xmm5
  901e91:	vmovdqa XMMWORD PTR [rsp+0x280],xmm0
  901e9a:	vpand  xmm0,xmm5,xmm0
  901e9e:	vpbroadcastd ymm0,xmm0
  901ea3:	vmovdqa YMMWORD PTR [rsp+0x260],ymm0
  901eac:	vmovss xmm0,DWORD PTR [rsp+0x18]
  901eb2:	vbroadcastss ymm0,xmm0
  901eb7:	vmovaps YMMWORD PTR [rsp+0x240],ymm0
  901ec0:	vmovd  xmm0,r13d
  901ec5:	vpbroadcastd ymm0,xmm0
  901eca:	vmovdqa YMMWORD PTR [rsp+0x200],ymm0
  901ed3:	vmovd  xmm0,edi
  901ed7:	vpbroadcastd ymm0,xmm0
  901edc:	vmovdqa YMMWORD PTR [rsp+0x2a0],ymm1
  901ee5:	vpaddd ymm1,ymm1,ymm0
  901ee9:	vmovdqa YMMWORD PTR [rsp+0x400],ymm1
  901ef2:	vpaddd ymm0,ymm4,ymm0
  901ef6:	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm0
  901eff:	vmovd  xmm0,esi
  901f03:	vpbroadcastd ymm0,xmm0
  901f08:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm0
  901f11:	vmovss xmm0,DWORD PTR [rsp+0x1c]
  901f17:	vbroadcastss ymm0,xmm0
  901f1c:	vmovaps YMMWORD PTR [rsp+0x1a0],ymm0
  901f25:	vmovd  xmm0,ecx
  901f29:	vpbroadcastd ymm0,xmm0
  901f2e:	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
  901f37:	vmovaps xmm0,XMMWORD PTR [rsp+0x340]
  901f40:	vmovaps XMMWORD PTR [rsp+0x3e0],xmm0
  901f49:	vmovaps xmm0,XMMWORD PTR [rsp+0x350]
  901f52:	vmovaps XMMWORD PTR [rsp+0x160],xmm0
  901f5b:	vmovaps xmm0,XMMWORD PTR [rsp+0x360]
  901f64:	vmovaps XMMWORD PTR [rsp+0xa0],xmm0
  901f6d:	vpbroadcastd ymm0,DWORD PTR [rsp+0x370]
  901f77:	vmovdqa YMMWORD PTR [rsp+0x140],ymm0
  901f80:	vmovdqa YMMWORD PTR [rsp+0x380],ymm4
  901f89:	vmovdqa XMMWORD PTR [rsp+0xf0],xmm3
  901f92:	mov    rdi,QWORD PTR [rsp+0x68]
  901f97:	mov    r12,QWORD PTR [rsp+0x10]
  901f9c:	mov    rsi,r12
  901f9f:	vzeroupper
  901fa2:	call   QWORD PTR [rip+0x6e0f98]        # fe2f40 <_DYNAMIC+0x1a18>
  901fa8:	test   rax,rax
  901fab:	je     902f40 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2510>
  901fb1:	test   rdx,rdx
  901fb4:	je     902f40 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2510>
  901fba:	mov    r8,rax
  901fbd:	cmp    r12,0x7fffffff
  901fc4:	ja     902f55 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2525>
  901fca:	vmovd  xmm0,r12d
  901fcf:	vpbroadcastd ymm0,xmm0
  901fd4:	vmovdqa YMMWORD PTR [rsp+0x3c0],ymm0
  901fdd:	vpand  xmm0,xmm0,XMMWORD PTR [rsp+0xd0]
  901fe6:	vpbroadcastd ymm0,xmm0
  901feb:	vmovdqa YMMWORD PTR [rsp+0x3a0],ymm0
  901ff4:	mov    QWORD PTR [rsp+0x220],0x0
  902000:	mov    rcx,QWORD PTR [rsp+0x48]
  902005:	cmp    rdx,rcx
  902008:	mov    rsi,rcx
  90200b:	cmovb  rsi,rdx
  90200f:	mov    rax,rsi
  902012:	or     rax,r15
  902015:	shr    rax,0x20
  902019:	mov    QWORD PTR [rsp+0x20],rdx
  90201e:	je     90202d <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x15fd>
  902020:	mov    rax,rsi
  902023:	xor    edx,edx
  902025:	div    r15
  902028:	mov    r12,rax
  90202b:	jmp    902037 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1607>
  90202d:	mov    eax,esi
  90202f:	xor    edx,edx
  902031:	div    r15d
  902034:	mov    r12d,eax
  902037:	mov    r13,QWORD PTR [rsp+0x220]
  90203f:	imul   r13,rcx
  902043:	cmp    rdx,0x1
  902047:	sbb    r12,0xffffffffffffffff
  90204b:	cmp    r12,0x40
  90204f:	mov    eax,0x40
  902054:	cmovae r12,rax
  902058:	mov    QWORD PTR [rsp+0x88],rsi
  902060:	lea    rax,[rsi+rsi*1]
  902064:	lea    rax,[rax+rax*2]
  902068:	mov    rcx,QWORD PTR [rsp+0x38]
  90206d:	sub    rax,rcx
  902070:	mov    edx,0x0
  902075:	cmovb  rax,rdx
  902079:	mov    rdx,r12
  90207c:	imul   rdx,QWORD PTR [rsp+0x40]
  902082:	cmp    rax,rdx
  902085:	cmovb  rdx,rax
  902089:	mov    QWORD PTR [rsp+0xe0],r8
  902091:	lea    rsi,[r8+rcx*1]
  902095:	cmp    rdx,0x300
  90209c:	mov    eax,0x300
  9020a1:	cmovae rdx,rax
  9020a5:	mov    rdi,rbx
  9020a8:	vzeroupper
  9020ab:	call   QWORD PTR [rip+0x6df6af]        # fe1760 <memcpy@GLIBC_2.14>
  9020b1:	lea    ecx,[r12+0xf]
  9020b6:	shr    ecx,0x4
  9020b9:	xor    eax,eax
  9020bb:	xor    r8d,r8d
  9020be:	vmovdqa ymm14,YMMWORD PTR [rsp+0x380]
  9020c7:	vmovdqa xmm15,XMMWORD PTR [rsp+0xf0]
  9020d0:	jmp    9024c8 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a98>
  9020d5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
  9020e0:	mov    r9,rdi
  9020e3:	mov    rdi,r8
  9020e6:	vpunpckhqdq xmm7,xmm7,xmm8
  9020eb:	vpunpckhdq xmm5,xmm5,xmm6
  9020ef:	vpunpckhdq xmm3,xmm3,xmm4
  9020f3:	vpunpcklqdq xmm4,xmm3,xmm5
  9020f7:	vmovd  xmm3,esi
  9020fb:	vpbroadcastd ymm3,xmm3
  902100:	mov    rsi,rdi
  902103:	shl    rsi,0x4
  902107:	lea    r8,[rbx+0xc00]
  90210e:	vmovdqu XMMWORD PTR [r8+rsi*1],xmm1
  902114:	vmovdqa xmm1,XMMWORD PTR [rsp+0x3e0]
  90211d:	vpshufb xmm1,xmm1,xmm2
  902122:	vmovdqa xmm5,XMMWORD PTR [rsp+0x160]
  90212b:	vpshufb xmm2,xmm5,xmm2
  902130:	vpunpcklbw xmm6,xmm1,xmm2
  902134:	vpunpckhbw xmm8,xmm1,xmm2
  902138:	vpmovsxbw ymm1,xmm7
  90213d:	vpmovsxwd ymm2,xmm1
  902142:	vextracti128 xmm1,ymm1,0x1
  902148:	vpmovsxwd ymm1,xmm1
  90214d:	vpabsd ymm5,ymm2
  902152:	vpabsd ymm7,ymm1
  902157:	vpsrld ymm9,ymm5,0x4
  90215c:	vpbroadcastd ymm10,DWORD PTR [rip+0xffffffffff716e0b]        # 18f70 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  902165:	vpsrld ymm11,ymm7,0x4
  90216a:	vpmaxud ymm9,ymm9,ymm10
  90216f:	vpcmpeqd ymm13,ymm13,ymm13
  902174:	vpaddd ymm9,ymm9,ymm13
  902179:	vpmaxud ymm11,ymm11,ymm10
  90217e:	vpaddd ymm11,ymm11,ymm13
  902183:	vpslld ymm12,ymm9,0x4
  902189:	vpsubd ymm5,ymm5,ymm12
  90218e:	vpslld ymm12,ymm11,0x4
  902194:	vpsubd ymm7,ymm7,ymm12
  902199:	vpsllvd ymm5,ymm5,ymm9
  90219e:	vpsllvd ymm7,ymm7,ymm11
  9021a3:	vpsrad ymm2,ymm2,0x1f
  9021a8:	vpsrad ymm1,ymm1,0x1f
  9021ad:	vpxor  ymm5,ymm2,ymm5
  9021b1:	vpxor  ymm7,ymm1,ymm7
  9021b5:	vpsubd ymm5,ymm5,ymm2
  9021b9:	vpsubd ymm2,ymm7,ymm1
  9021bd:	vpmovsxbw ymm1,xmm4
  9021c2:	vpmovsxwd ymm4,xmm1
  9021c7:	vextracti128 xmm1,ymm1,0x1
  9021cd:	vpmovsxwd ymm7,xmm1
  9021d2:	vpabsd ymm1,ymm4
  9021d7:	vpabsd ymm9,ymm7
  9021dc:	vpsrld ymm11,ymm1,0x4
  9021e1:	vpsrld ymm12,ymm9,0x4
  9021e7:	vpmaxud ymm11,ymm11,ymm10
  9021ec:	vpaddd ymm11,ymm11,ymm13
  9021f1:	vpmaxud ymm10,ymm12,ymm10
  9021f6:	vpaddd ymm10,ymm10,ymm13
  9021fb:	vpslld ymm12,ymm11,0x4
  902201:	vpsubd ymm12,ymm1,ymm12
  902206:	vpslld ymm1,ymm10,0x4
  90220c:	vpsubd ymm9,ymm9,ymm1
  902210:	vpaddd ymm1,ymm3,YMMWORD PTR [rsp+0x2a0]
  902219:	vpmovsxwd ymm6,xmm6
  90221e:	vpmovsxwd ymm8,xmm8
  902223:	vmovdqa ymm13,YMMWORD PTR [rsp+0x140]
  90222c:	vpmulld ymm6,ymm13,ymm6
  902231:	vpmulld ymm13,ymm13,ymm8
  902236:	vpsllvd ymm8,ymm12,ymm11
  90223b:	vpsllvd ymm9,ymm9,ymm10
  902240:	vpsrad ymm4,ymm4,0x1f
  902245:	vpsrad ymm7,ymm7,0x1f
  90224a:	vpxor  ymm8,ymm8,ymm4
  90224e:	vpxor  ymm9,ymm9,ymm7
  902252:	vpsubd ymm10,ymm8,ymm4
  902256:	vpsubd ymm8,ymm9,ymm7
  90225a:	vpmulld ymm4,ymm6,ymm5
  90225f:	vpmulld ymm7,ymm13,ymm2
  902264:	vpsrad ymm9,ymm4,0x1f
  902269:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff716d36]        # 18fa8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  902272:	vpaddd ymm4,ymm11,ymm4
  902276:	vpaddd ymm4,ymm9,ymm4
  90227a:	vpsrad ymm9,ymm7,0x1f
  90227f:	vpaddd ymm7,ymm11,ymm7
  902283:	vpaddd ymm12,ymm9,ymm7
  902287:	vpmulld ymm6,ymm6,ymm10
  90228c:	vpsrad ymm7,ymm6,0x1f
  902291:	vpaddd ymm6,ymm11,ymm6
  902295:	vpaddd ymm6,ymm6,ymm7
  902299:	vpaddd ymm7,ymm14,ymm3
  90229d:	vpmulld ymm9,ymm13,ymm8
  9022a2:	vpaddd ymm11,ymm9,ymm11
  9022a7:	vpsrad ymm9,ymm9,0x1f
  9022ad:	vpaddd ymm11,ymm11,ymm9
  9022b2:	vpsrad ymm13,ymm4,0xe
  9022b7:	shl    rdi,0x6
  9022bb:	vmovdqu YMMWORD PTR [r14+rdi*1],ymm5
  9022c1:	vpsrad ymm5,ymm12,0xe
  9022c7:	vmovdqu YMMWORD PTR [r14+rdi*1+0x20],ymm2
  9022ce:	vpsrad ymm9,ymm6,0xe
  9022d3:	vmovdqu YMMWORD PTR [r14+rdi*1+0x100],ymm10
  9022dd:	vpsrad ymm10,ymm11,0xe
  9022e3:	vmovdqu YMMWORD PTR [r14+rdi*1+0x120],ymm8
  9022ed:	vpsrad ymm2,ymm12,0x1f
  9022f3:	vpsrld ymm2,ymm2,0x1a
  9022f8:	vpaddd ymm2,ymm2,ymm5
  9022fc:	vpsrad ymm2,ymm2,0x6
  902301:	vmovdqa ymm12,YMMWORD PTR [rsp+0x3c0]
  90230a:	vpaddd ymm2,ymm12,ymm2
  90230e:	vpbroadcastd ymm8,DWORD PTR [rsp+0x280]
  902318:	vpand  ymm5,ymm8,ymm2
  90231c:	vpsrad ymm4,ymm4,0x1f
  902321:	vpsrld ymm4,ymm4,0x1a
  902326:	vpaddd ymm4,ymm13,ymm4
  90232a:	vpsrad ymm4,ymm4,0x6
  90232f:	vpaddd ymm4,ymm12,ymm4
  902333:	vpand  ymm12,ymm8,ymm4
  902337:	vpsrad ymm11,ymm11,0x1f
  90233d:	vpsrld ymm11,ymm11,0x1a
  902343:	vpaddd ymm10,ymm11,ymm10
  902348:	vmovdqa ymm13,YMMWORD PTR [rsp+0x1a0]
  902351:	vpminud ymm11,ymm13,ymm2
  902356:	vpcmpeqd ymm11,ymm13,ymm11
  90235b:	vpsrad ymm10,ymm10,0x6
  902361:	vpaddd ymm7,ymm10,ymm7
  902365:	vpminud ymm10,ymm13,ymm4
  90236a:	vpcmpeqd ymm10,ymm13,ymm10
  90236f:	vpsrad ymm6,ymm6,0x1f
  902374:	vpsrld ymm6,ymm6,0x1a
  902379:	vpaddd ymm6,ymm9,ymm6
  90237d:	vpand  ymm9,ymm8,ymm7
  902381:	vpsrad ymm6,ymm6,0x6
  902386:	vpaddd ymm6,ymm1,ymm6
  90238a:	vpand  ymm8,ymm8,ymm6
  90238e:	vmovdqa ymm13,YMMWORD PTR [rsp+0x180]
  902397:	vpminud ymm1,ymm13,ymm7
  90239c:	vpcmpeqd ymm1,ymm13,ymm1
  9023a0:	vpor   ymm1,ymm11,ymm1
  9023a4:	vpminud ymm11,ymm13,ymm6
  9023a9:	vpcmpeqd ymm11,ymm13,ymm11
  9023ae:	vpor   ymm10,ymm10,ymm11
  9023b3:	vmovdqa ymm13,YMMWORD PTR [rsp+0x240]
  9023bc:	vpsubd ymm11,ymm12,ymm13
  9023c1:	vpsubd ymm5,ymm5,ymm13
  9023c6:	vmovdqa ymm13,YMMWORD PTR [rsp+0x200]
  9023cf:	vpmulld ymm12,ymm11,ymm13
  9023d4:	vpaddd ymm8,ymm12,ymm8
  9023d9:	vpmulld ymm12,ymm5,ymm13
  9023de:	vpaddd ymm9,ymm12,ymm9
  9023e3:	vpsrad ymm11,ymm11,0x1f
  9023e9:	vpor   ymm8,ymm8,ymm11
  9023ee:	vpsrad ymm5,ymm5,0x1f
  9023f3:	vpor   ymm5,ymm9,ymm5
  9023f7:	lea    rsi,[rbx+0x900]
  9023fe:	vmovdqu YMMWORD PTR [rsi+rdi*1],ymm8
  902403:	vmovdqa ymm8,YMMWORD PTR [rsp+0x260]
  90240c:	vpand  ymm6,ymm8,ymm6
  902410:	vmovdqu YMMWORD PTR [rsi+rdi*1+0x20],ymm5
  902416:	vpaddd ymm5,ymm3,YMMWORD PTR [rsp+0x400]
  90241f:	vpsubd ymm5,ymm5,ymm6
  902423:	vpand  ymm6,ymm8,ymm7
  902427:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x1e0]
  902430:	vpsubd ymm3,ymm3,ymm6
  902434:	vpand  ymm4,ymm8,ymm4
  902438:	vmovdqa ymm7,YMMWORD PTR [rsp+0x3a0]
  902441:	vpcmpeqd ymm4,ymm4,ymm7
  902445:	vmovdqa ymm6,YMMWORD PTR [rsp+0x1c0]
  90244e:	vpminud ymm5,ymm6,ymm5
  902453:	vpcmpeqd ymm5,ymm6,ymm5
  902457:	vpandn ymm4,ymm5,ymm4
  90245b:	vpandn ymm4,ymm10,ymm4
  90245f:	vpand  ymm2,ymm8,ymm2
  902463:	vpcmpeqd ymm2,ymm2,ymm7
  902467:	vpminud ymm3,ymm6,ymm3
  90246c:	vpcmpeqd ymm3,ymm6,ymm3
  902470:	vpandn ymm2,ymm3,ymm2
  902474:	vpbroadcastd ymm3,DWORD PTR [rip+0xffffffffff7167d3]        # 18c50 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  90247d:	vpandn ymm1,ymm1,ymm2
  902481:	vpand  ymm2,ymm4,ymm3
  902485:	vpand  ymm1,ymm1,ymm3
  902489:	vextracti128 xmm3,ymm1,0x1
  90248f:	vpackusdw xmm1,xmm1,xmm3
  902494:	vextracti128 xmm3,ymm2,0x1
  90249a:	vpackusdw xmm2,xmm2,xmm3
  90249f:	vpackuswb xmm1,xmm2,xmm1
  9024a3:	vpand  xmm0,xmm15,xmm0
  9024a7:	vpand  xmm0,xmm0,xmm1
  9024ab:	vpxor  xmm1,xmm1,xmm1
  9024af:	vpcmpeqb xmm0,xmm0,xmm1
  9024b3:	vpmovmskb esi,xmm0
  9024b7:	xor    esi,0xffff
  9024bd:	shlx   rdx,rsi,rdx
  9024c2:	or     rax,rdx
  9024c5:	mov    r8,r9
  9024c8:	cmp    r15,0x1
  9024cc:	jne    9025b0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1b80>
  9024d2:	cmp    r8,rcx
  9024d5:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  9024db:	mov    rdx,r8
  9024de:	shl    rdx,0x4
  9024e2:	lea    rsi,[rdx+r13*1]
  9024e6:	cmp    rsi,0x7fffffff
  9024ed:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  9024f3:	lea    rdi,[r8+r8*2]
  9024f7:	shl    rdi,0x5
  9024fb:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  902500:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x6]
  902506:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  90250c:	vmovdqu xmm6,XMMWORD PTR [rbx+rdi*1+0x36]
  902512:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  90251a:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+rdi*1+0x20],0x2
  902522:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  90252a:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+rdi*1+0x50],0x2
  902532:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+rdi*1+0x16],0x4
  90253a:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+rdi*1+0x26],0x2
  902542:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+rdi*1+0x46],0x4
  90254a:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+rdi*1+0x56],0x2
  902552:	lea    rdi,[r8+0x1]
  902556:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff714202]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  90255e:	vpshufb xmm0,xmm5,xmm2
  902563:	vpshufb xmm1,xmm3,xmm2
  902568:	vpunpcklbw xmm7,xmm1,xmm0
  90256c:	vpshufb xmm0,xmm6,xmm2
  902571:	vpshufb xmm1,xmm4,xmm2
  902576:	vpunpcklbw xmm8,xmm1,xmm0
  90257a:	vpunpcklqdq xmm1,xmm7,xmm8
  90257f:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff711a29]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902587:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  902590:	vpshufb xmm0,xmm0,xmm2
  902595:	vptest xmm0,xmm15
  90259a:	je     9027d0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1da0>
  9025a0:	mov    r9,rdi
  9025a3:	mov    rdi,r8
  9025a6:	jmp    902e70 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2440>
  9025ab:	nop    DWORD PTR [rax+rax*1+0x0]
  9025b0:	cmp    r8,rcx
  9025b3:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  9025b9:	mov    rdx,r8
  9025bc:	shl    rdx,0x4
  9025c0:	mov    rsi,rdx
  9025c3:	imul   rsi,r15
  9025c7:	add    rsi,r13
  9025ca:	cmp    rsi,0x7fffffff
  9025d1:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  9025d7:	lea    rdi,[r8+0x1]
  9025db:	lea    r9,[r8+r8*2]
  9025df:	shl    r9,0x6
  9025e3:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  9025e9:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  9025f0:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  9025f7:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  9025fe:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  902606:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff713b02]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  90260e:	vpshufb xmm1,xmm1,xmm6
  902613:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff714d05]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  90261b:	vpshufb xmm0,xmm0,xmm7
  902620:	vpor   xmm3,xmm0,xmm1
  902624:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  90262c:	vpshufb xmm1,xmm4,xmm6
  902631:	vpshufb xmm0,xmm0,xmm7
  902636:	vpor   xmm4,xmm0,xmm1
  90263a:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  902644:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  90264b:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  902653:	vpshufb xmm0,xmm0,xmm6
  902658:	vpshufb xmm1,xmm1,xmm7
  90265d:	vpor   xmm5,xmm1,xmm0
  902661:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  90266b:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  902675:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  902680:	vpshufb xmm0,xmm0,xmm6
  902685:	vpshufb xmm1,xmm1,xmm7
  90268a:	vpor   xmm6,xmm1,xmm0
  90268e:	vpunpckldq xmm7,xmm3,xmm4
  902692:	vpunpckldq xmm8,xmm5,xmm6
  902696:	vpunpcklqdq xmm1,xmm7,xmm8
  90269b:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71190d]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  9026a3:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  9026ac:	vpshufb xmm0,xmm0,xmm2
  9026b1:	vptest xmm0,xmm15
  9026b6:	jne    9020e0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x16b0>
  9026bc:	cmp    rdi,rcx
  9026bf:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  9026c5:	mov    rdx,rdi
  9026c8:	shl    rdx,0x4
  9026cc:	mov    rsi,rdx
  9026cf:	imul   rsi,r15
  9026d3:	add    rsi,r13
  9026d6:	cmp    rsi,0x7fffffff
  9026dd:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  9026e3:	lea    r10,[r8+0x2]
  9026e7:	lea    r9,[rdi+rdi*2]
  9026eb:	shl    r9,0x6
  9026ef:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  9026f5:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  9026fc:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  902703:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  90270a:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  902712:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff7139f6]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  90271a:	vpshufb xmm1,xmm1,xmm6
  90271f:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff714bf9]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  902727:	vpshufb xmm0,xmm0,xmm7
  90272c:	vpor   xmm3,xmm0,xmm1
  902730:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  902738:	vpshufb xmm1,xmm4,xmm6
  90273d:	vpshufb xmm0,xmm0,xmm7
  902742:	vpor   xmm4,xmm0,xmm1
  902746:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  902750:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  902757:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  90275f:	vpshufb xmm0,xmm0,xmm6
  902764:	vpshufb xmm1,xmm1,xmm7
  902769:	vpor   xmm5,xmm1,xmm0
  90276d:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  902777:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  902781:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  90278c:	vpshufb xmm0,xmm0,xmm6
  902791:	vpshufb xmm1,xmm1,xmm7
  902796:	vpor   xmm6,xmm1,xmm0
  90279a:	vpunpckldq xmm7,xmm3,xmm4
  90279e:	vpunpckldq xmm8,xmm5,xmm6
  9027a2:	vpunpcklqdq xmm1,xmm7,xmm8
  9027a7:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff711801]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  9027af:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  9027b8:	vpshufb xmm0,xmm0,xmm2
  9027bd:	vptest xmm0,xmm15
  9027c2:	je     9028aa <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e7a>
  9027c8:	mov    r9,r10
  9027cb:	jmp    9020e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x16b6>
  9027d0:	cmp    rdi,rcx
  9027d3:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  9027d9:	mov    rdx,rdi
  9027dc:	shl    rdx,0x4
  9027e0:	lea    rsi,[rdx+r13*1]
  9027e4:	cmp    rsi,0x7fffffff
  9027eb:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  9027f1:	lea    r9,[rdi+rdi*2]
  9027f5:	shl    r9,0x5
  9027f9:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  9027ff:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x6]
  902806:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  90280d:	vmovdqu xmm6,XMMWORD PTR [rbx+r9*1+0x36]
  902814:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  90281c:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+r9*1+0x20],0x2
  902824:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  90282c:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+r9*1+0x50],0x2
  902834:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+r9*1+0x16],0x4
  90283c:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+r9*1+0x26],0x2
  902844:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+r9*1+0x46],0x4
  90284c:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+r9*1+0x56],0x2
  902854:	lea    r10,[r8+0x2]
  902858:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff713f00]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  902860:	vpshufb xmm0,xmm5,xmm2
  902865:	vpshufb xmm1,xmm3,xmm2
  90286a:	vpunpcklbw xmm7,xmm1,xmm0
  90286e:	vpshufb xmm0,xmm6,xmm2
  902873:	vpshufb xmm1,xmm4,xmm2
  902878:	vpunpcklbw xmm8,xmm1,xmm0
  90287c:	vpunpcklqdq xmm1,xmm7,xmm8
  902881:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff711727]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902889:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  902892:	vpshufb xmm0,xmm0,xmm2
  902897:	vptest xmm0,xmm15
  90289c:	je     9029b9 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1f89>
  9028a2:	mov    r9,r10
  9028a5:	jmp    902e70 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2440>
  9028aa:	cmp    r10,rcx
  9028ad:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  9028b3:	mov    rdx,r10
  9028b6:	shl    rdx,0x4
  9028ba:	mov    rsi,rdx
  9028bd:	imul   rsi,r15
  9028c1:	add    rsi,r13
  9028c4:	cmp    rsi,0x7fffffff
  9028cb:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  9028d1:	lea    r11,[r8+0x3]
  9028d5:	lea    rdi,[r10+r10*2]
  9028d9:	shl    rdi,0x6
  9028dd:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  9028e2:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x20]
  9028e8:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  9028ee:	vmovdqu xmm4,XMMWORD PTR [rbx+rdi*1+0x50]
  9028f4:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  9028fc:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71380c]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  902904:	vpshufb xmm1,xmm1,xmm6
  902909:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff714a0f]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  902911:	vpshufb xmm0,xmm0,xmm7
  902916:	vpor   xmm3,xmm0,xmm1
  90291a:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  902922:	vpshufb xmm1,xmm4,xmm6
  902927:	vpshufb xmm0,xmm0,xmm7
  90292c:	vpor   xmm4,xmm0,xmm1
  902930:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1+0x80]
  902939:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x60]
  90293f:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdi*1+0x70],0x4
  902947:	vpshufb xmm0,xmm0,xmm6
  90294c:	vpshufb xmm1,xmm1,xmm7
  902951:	vpor   xmm5,xmm1,xmm0
  902955:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1+0xb0]
  90295e:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x90]
  902967:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdi*1+0xa0],0x4
  902972:	vpshufb xmm0,xmm0,xmm6
  902977:	vpshufb xmm1,xmm1,xmm7
  90297c:	vpor   xmm6,xmm1,xmm0
  902980:	vpunpckldq xmm7,xmm3,xmm4
  902984:	vpunpckldq xmm8,xmm5,xmm6
  902988:	vpunpcklqdq xmm1,xmm7,xmm8
  90298d:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71161b]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902995:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  90299e:	vpshufb xmm0,xmm0,xmm2
  9029a3:	vptest xmm0,xmm15
  9029a8:	je     902a92 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2062>
  9029ae:	mov    r9,r11
  9029b1:	mov    rdi,r10
  9029b4:	jmp    9020e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x16b6>
  9029b9:	cmp    r10,rcx
  9029bc:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  9029c2:	mov    rdx,r10
  9029c5:	shl    rdx,0x4
  9029c9:	lea    rsi,[rdx+r13*1]
  9029cd:	cmp    rsi,0x7fffffff
  9029d4:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  9029da:	lea    rdi,[r10+r10*2]
  9029de:	shl    rdi,0x5
  9029e2:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  9029e7:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x6]
  9029ed:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  9029f3:	vmovdqu xmm6,XMMWORD PTR [rbx+rdi*1+0x36]
  9029f9:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  902a01:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+rdi*1+0x20],0x2
  902a09:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  902a11:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+rdi*1+0x50],0x2
  902a19:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+rdi*1+0x16],0x4
  902a21:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+rdi*1+0x26],0x2
  902a29:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+rdi*1+0x46],0x4
  902a31:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+rdi*1+0x56],0x2
  902a39:	lea    r11,[r8+0x3]
  902a3d:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff713d1b]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  902a45:	vpshufb xmm0,xmm5,xmm2
  902a4a:	vpshufb xmm1,xmm3,xmm2
  902a4f:	vpunpcklbw xmm7,xmm1,xmm0
  902a53:	vpshufb xmm0,xmm6,xmm2
  902a58:	vpshufb xmm1,xmm4,xmm2
  902a5d:	vpunpcklbw xmm8,xmm1,xmm0
  902a61:	vpunpcklqdq xmm1,xmm7,xmm8
  902a66:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff711542]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902a6e:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  902a77:	vpshufb xmm0,xmm0,xmm2
  902a7c:	vptest xmm0,xmm15
  902a81:	je     902ba9 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2179>
  902a87:	mov    r9,r11
  902a8a:	mov    rdi,r10
  902a8d:	jmp    902e70 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2440>
  902a92:	cmp    r11,rcx
  902a95:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  902a9b:	mov    rdx,r11
  902a9e:	shl    rdx,0x4
  902aa2:	mov    rsi,rdx
  902aa5:	imul   rsi,r15
  902aa9:	add    rsi,r13
  902aac:	cmp    rsi,0x7fffffff
  902ab3:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  902ab9:	lea    rdi,[r8+0x4]
  902abd:	lea    r9,[r11+r11*2]
  902ac1:	shl    r9,0x6
  902ac5:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  902acb:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  902ad2:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  902ad9:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  902ae0:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  902ae8:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff713620]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  902af0:	vpshufb xmm1,xmm1,xmm6
  902af5:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff714823]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  902afd:	vpshufb xmm0,xmm0,xmm7
  902b02:	vpor   xmm3,xmm0,xmm1
  902b06:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  902b0e:	vpshufb xmm1,xmm4,xmm6
  902b13:	vpshufb xmm0,xmm0,xmm7
  902b18:	vpor   xmm4,xmm0,xmm1
  902b1c:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  902b26:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  902b2d:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  902b35:	vpshufb xmm0,xmm0,xmm6
  902b3a:	vpshufb xmm1,xmm1,xmm7
  902b3f:	vpor   xmm5,xmm1,xmm0
  902b43:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  902b4d:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  902b57:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  902b62:	vpshufb xmm0,xmm0,xmm6
  902b67:	vpshufb xmm1,xmm1,xmm7
  902b6c:	vpor   xmm6,xmm1,xmm0
  902b70:	vpunpckldq xmm7,xmm3,xmm4
  902b74:	vpunpckldq xmm8,xmm5,xmm6
  902b78:	vpunpcklqdq xmm1,xmm7,xmm8
  902b7d:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71142b]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902b85:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  902b8e:	vpshufb xmm0,xmm0,xmm2
  902b93:	vptest xmm0,xmm15
  902b98:	je     902c82 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2252>
  902b9e:	mov    r9,rdi
  902ba1:	mov    rdi,r11
  902ba4:	jmp    9020e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x16b6>
  902ba9:	cmp    r11,rcx
  902bac:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  902bb2:	mov    rdx,r11
  902bb5:	shl    rdx,0x4
  902bb9:	lea    rsi,[rdx+r13*1]
  902bbd:	cmp    rsi,0x7fffffff
  902bc4:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  902bca:	lea    rdi,[r11+r11*2]
  902bce:	shl    rdi,0x5
  902bd2:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  902bd7:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x6]
  902bdd:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  902be3:	vmovdqu xmm6,XMMWORD PTR [rbx+rdi*1+0x36]
  902be9:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  902bf1:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+rdi*1+0x20],0x2
  902bf9:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  902c01:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+rdi*1+0x50],0x2
  902c09:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+rdi*1+0x16],0x4
  902c11:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+rdi*1+0x26],0x2
  902c19:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+rdi*1+0x46],0x4
  902c21:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+rdi*1+0x56],0x2
  902c29:	lea    rdi,[r8+0x4]
  902c2d:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff713b2b]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  902c35:	vpshufb xmm0,xmm5,xmm2
  902c3a:	vpshufb xmm1,xmm3,xmm2
  902c3f:	vpunpcklbw xmm7,xmm1,xmm0
  902c43:	vpshufb xmm0,xmm6,xmm2
  902c48:	vpshufb xmm1,xmm4,xmm2
  902c4d:	vpunpcklbw xmm8,xmm1,xmm0
  902c51:	vpunpcklqdq xmm1,xmm7,xmm8
  902c56:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff711352]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902c5e:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  902c67:	vpshufb xmm0,xmm0,xmm2
  902c6c:	vptest xmm0,xmm15
  902c71:	je     902d96 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2366>
  902c77:	mov    r9,rdi
  902c7a:	mov    rdi,r11
  902c7d:	jmp    902e70 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2440>
  902c82:	cmp    rdi,rcx
  902c85:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  902c8b:	mov    rdx,rdi
  902c8e:	shl    rdx,0x4
  902c92:	mov    rsi,rdx
  902c95:	imul   rsi,r15
  902c99:	add    rsi,r13
  902c9c:	cmp    rsi,0x7fffffff
  902ca3:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  902ca9:	lea    r9,[rdi+rdi*2]
  902cad:	shl    r9,0x6
  902cb1:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  902cb7:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  902cbe:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  902cc5:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  902ccc:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  902cd4:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff713434]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  902cdc:	vpshufb xmm1,xmm1,xmm6
  902ce1:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff714637]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  902ce9:	vpshufb xmm0,xmm0,xmm7
  902cee:	vpor   xmm3,xmm0,xmm1
  902cf2:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  902cfa:	vpshufb xmm1,xmm4,xmm6
  902cff:	vpshufb xmm0,xmm0,xmm7
  902d04:	vpor   xmm4,xmm0,xmm1
  902d08:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  902d12:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  902d19:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  902d21:	vpshufb xmm0,xmm0,xmm6
  902d26:	vpshufb xmm1,xmm1,xmm7
  902d2b:	vpor   xmm5,xmm1,xmm0
  902d2f:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  902d39:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  902d43:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  902d4e:	vpshufb xmm0,xmm0,xmm6
  902d53:	vpshufb xmm1,xmm1,xmm7
  902d58:	vpor   xmm6,xmm1,xmm0
  902d5c:	vpunpckldq xmm7,xmm3,xmm4
  902d60:	vpunpckldq xmm8,xmm5,xmm6
  902d64:	vpunpcklqdq xmm1,xmm7,xmm8
  902d69:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71123f]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902d71:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  902d7a:	vpshufb xmm0,xmm0,xmm2
  902d7f:	vptest xmm0,xmm15
  902d84:	je     902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  902d8a:	add    r8,0x5
  902d8e:	mov    r9,r8
  902d91:	jmp    9020e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x16b6>
  902d96:	cmp    rdi,rcx
  902d99:	jae    902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  902d9f:	mov    rdx,rdi
  902da2:	shl    rdx,0x4
  902da6:	lea    rsi,[rdx+r13*1]
  902daa:	cmp    rsi,0x7fffffff
  902db1:	ja     902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  902db7:	lea    r9,[rdi+rdi*2]
  902dbb:	shl    r9,0x5
  902dbf:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  902dc5:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x6]
  902dcc:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  902dd3:	vmovdqu xmm6,XMMWORD PTR [rbx+r9*1+0x36]
  902dda:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  902de2:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+r9*1+0x20],0x2
  902dea:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  902df2:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+r9*1+0x50],0x2
  902dfa:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+r9*1+0x16],0x4
  902e02:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+r9*1+0x26],0x2
  902e0a:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+r9*1+0x46],0x4
  902e12:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+r9*1+0x56],0x2
  902e1a:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71393e]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  902e22:	vpshufb xmm0,xmm5,xmm2
  902e27:	vpshufb xmm1,xmm3,xmm2
  902e2c:	vpunpcklbw xmm7,xmm1,xmm0
  902e30:	vpshufb xmm0,xmm6,xmm2
  902e35:	vpshufb xmm1,xmm4,xmm2
  902e3a:	vpunpcklbw xmm8,xmm1,xmm0
  902e3e:	vpunpcklqdq xmm1,xmm7,xmm8
  902e43:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff711165]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  902e4b:	vmovdqa xmm0,XMMWORD PTR [rsp+0xa0]
  902e54:	vpshufb xmm0,xmm0,xmm2
  902e59:	vptest xmm0,xmm15
  902e5e:	je     902eb0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2480>
  902e60:	add    r8,0x5
  902e64:	mov    r9,r8
  902e67:	nop    WORD PTR [rax+rax*1+0x0]
  902e70:	vpunpckhqdq xmm7,xmm7,xmm8
  902e75:	vmovd  xmm8,DWORD PTR [rip+0xffffffffff711a53]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x590>
  902e7d:	vpshufb xmm5,xmm5,xmm8
  902e82:	vpshufb xmm3,xmm3,xmm8
  902e87:	vpunpcklbw xmm3,xmm3,xmm5
  902e8b:	vpshufb xmm5,xmm6,xmm8
  902e90:	vpshufb xmm4,xmm4,xmm8
  902e95:	vpunpcklbw xmm4,xmm4,xmm5
  902e99:	vpunpcklqdq xmm4,xmm3,xmm4
  902e9d:	jmp    9020f7 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x16c7>
  902ea2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  902eb0:	cmp    r12,0x1
  902eb4:	adc    r12,0x0
  902eb8:	bzhi   rax,rax,r12
  902ebd:	inc    QWORD PTR [rsp+0x220]
  902ec5:	mov    QWORD PTR [rsp+0x2c0],rbx
  902ecd:	mov    QWORD PTR [rsp+0x2c8],rax
  902ed5:	mov    r12,QWORD PTR [rsp+0x10]
  902eda:	mov    QWORD PTR [rsp+0x2d0],r12
  902ee2:	mov    QWORD PTR [rsp+0x2d8],r13
  902eea:	mov    QWORD PTR [rsp+0x2e0],r15
  902ef2:	lea    rdi,[rsp+0x2c0]
  902efa:	mov    rsi,QWORD PTR [rsp+0x60]
  902eff:	mov    rdx,QWORD PTR [rsp+0x58]
  902f04:	vzeroupper
  902f07:	call   QWORD PTR [rip+0x6e003b]        # fe2f48 <_DYNAMIC+0x1a20>
  902f0d:	mov    rcx,QWORD PTR [rsp+0x88]
  902f15:	lea    rax,[rcx+rcx*2]
  902f19:	mov    r8,QWORD PTR [rsp+0xe0]
  902f21:	lea    r8,[r8+rax*2]
  902f25:	mov    rdx,QWORD PTR [rsp+0x20]
  902f2a:	sub    rdx,rcx
  902f2d:	jne    902000 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x15d0>
  902f33:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  902f40:	add    r12,r15
  902f43:	mov    QWORD PTR [rsp+0x10],r12
  902f48:	dec    QWORD PTR [rsp+0x50]
  902f4d:	jne    901f92 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1562>
  902f53:	jmp    902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  902f55:	mov    rsi,QWORD PTR [rsp+0x48]
  902f5a:	cmp    rdx,rsi
  902f5d:	cmovb  rsi,rdx
  902f61:	mov    rax,rsi
  902f64:	or     rax,r15
  902f67:	shr    rax,0x20
  902f6b:	je     902f77 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2547>
  902f6d:	mov    rax,rsi
  902f70:	xor    edx,edx
  902f72:	div    r15
  902f75:	jmp    902f7e <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x254e>
  902f77:	mov    eax,esi
  902f79:	xor    edx,edx
  902f7b:	div    r15d
  902f7e:	cmp    rdx,0x1
  902f82:	sbb    rax,0xffffffffffffffff
  902f86:	cmp    rax,0x40
  902f8a:	mov    ecx,0x40
  902f8f:	cmovb  rcx,rax
  902f93:	add    rsi,rsi
  902f96:	lea    rax,[rsi+rsi*2]
  902f9a:	mov    rsi,QWORD PTR [rsp+0x38]
  902f9f:	add    r8,rsi
  902fa2:	xor    edx,edx
  902fa4:	sub    rax,rsi
  902fa7:	cmovae rdx,rax
  902fab:	imul   rcx,QWORD PTR [rsp+0x40]
  902fb1:	cmp    rdx,rcx
  902fb4:	cmovb  rcx,rdx
  902fb8:	cmp    rcx,0x300
  902fbf:	mov    edx,0x300
  902fc4:	cmovb  rdx,rcx
  902fc8:	mov    rdi,rbx
  902fcb:	mov    rsi,r8
  902fce:	call   QWORD PTR [rip+0x6de78c]        # fe1760 <memcpy@GLIBC_2.14>
  902fd4:	lea    rsp,[rbp-0x28]
  902fd8:	pop    rbx
  902fd9:	pop    r12
  902fdb:	pop    r13
  902fdd:	pop    r14
  902fdf:	pop    r15
  902fe1:	pop    rbp
  902fe2:	vzeroupper
  902fe5:	ret
  902fe6:	lea    rdi,[rip+0xffffffffff7530b2]        # 5609f <anon.43d21acec09d19046152b53125a552af.1081.llvm.7158842796534594082+0x158a>
  902fed:	lea    rdx,[rip+0x6ce884]        # fd1878 <anon.43d21acec09d19046152b53125a552af.1039.llvm.7158842796534594082+0x5c0>
  902ff4:	mov    esi,0x1b
  902ff9:	call   QWORD PTR [rip+0x6de8d1]        # fe18d0 <_DYNAMIC+0x3a8>
  902fff:	mov    rbx,QWORD PTR [rip+0x6dff3a]        # fe2f40 <_DYNAMIC+0x1a18>
  903006:	mov    rdi,QWORD PTR [rsp+0x68]
  90300b:	mov    r14,QWORD PTR [rsp+0x10]
  903010:	mov    rsi,r14
  903013:	vzeroupper
  903016:	call   rbx
  903018:	test   rax,rax
  90301b:	jne    90302e <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25fe>
  90301d:	add    r14,r15
  903020:	mov    QWORD PTR [rsp+0x10],r14
  903025:	dec    QWORD PTR [rsp+0x50]
  90302a:	jne    903006 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25d6>
  90302c:	jmp    902fd4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25a4>
  90302e:	lea    rdi,[rip+0xffffffffff747424]        # 4a459 <_RNvNtNtNtCsiiWGwn0QfU0_12splot_decode9bitstream12tile_payload11coeff_state15ZERO_QUANT_SIGN+0x521>
  903035:	lea    rdx,[rip+0x6cd044]        # fd0080 <anon.43d21acec09d19046152b53125a552af.157.llvm.7158842796534594082+0x2288>
  90303c:	mov    esi,0x37
  903041:	call   QWORD PTR [rip+0x6de799]        # fe17e0 <_DYNAMIC+0x2b8>
