
<WORKTREES>/qualification-1882/temporal-scan/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

00000000008f6cc0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_>:
  8f6cc0:	push   rbp
  8f6cc1:	mov    rbp,rsp
  8f6cc4:	push   r15
  8f6cc6:	push   r14
  8f6cc8:	push   r13
  8f6cca:	push   r12
  8f6ccc:	push   rbx
  8f6ccd:	and    rsp,0xffffffffffffffc0
  8f6cd1:	sub    rsp,0x8c0
  8f6cd8:	mov    r15,rdi
  8f6cdb:	mov    rbx,QWORD PTR [rdi+0x8]
  8f6cdf:	mov    rax,QWORD PTR [rdi+0x10]
  8f6ce3:	mov    rdx,QWORD PTR [rax]
  8f6ce6:	lea    rdi,[rsp+0x380]
  8f6cee:	mov    rsi,rbx
  8f6cf1:	call   b8ac50 <_RNvMs_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanINtB4_12TargetTablesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2E3newBe_>
  8f6cf6:	mov    rdx,QWORD PTR [r15+0x28]
  8f6cfa:	mov    r14,QWORD PTR [rdx]
  8f6cfd:	test   r14,r14
  8f6d00:	je     8fa2c6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3606>
  8f6d06:	mov    r10,QWORD PTR [r15+0x38]
  8f6d0a:	mov    r9,QWORD PTR [r15+0x40]
  8f6d0e:	mov    eax,DWORD PTR [rdx+0x8]
  8f6d11:	mov    DWORD PTR [rsp+0x90],eax
  8f6d18:	mov    eax,DWORD PTR [rdx+0xc]
  8f6d1b:	mov    DWORD PTR [rsp+0x8c],eax
  8f6d22:	movsxd rax,DWORD PTR [rdx+0x10]
  8f6d26:	mov    QWORD PTR [rsp+0x1f8],rax
  8f6d2e:	mov    r8d,DWORD PTR [rdx+0x14]
  8f6d32:	mov    edi,DWORD PTR [rdx+0x18]
  8f6d35:	mov    esi,DWORD PTR [rdx+0x1c]
  8f6d38:	mov    ecx,DWORD PTR [rdx+0x20]
  8f6d3b:	mov    eax,DWORD PTR [rdx+0x24]
  8f6d3e:	mov    DWORD PTR [rsp+0x74],eax
  8f6d42:	xor    eax,eax
  8f6d44:	sub    r9,r10
  8f6d47:	cmovae rax,r9
  8f6d4b:	mov    r9,rax
  8f6d4e:	or     r9,r14
  8f6d51:	shr    r9,0x20
  8f6d55:	mov    r9d,DWORD PTR [rdx+0x28]
  8f6d59:	mov    DWORD PTR [rsp+0x88],r9d
  8f6d61:	vmovq  xmm0,QWORD PTR [rdx+0x2c]
  8f6d66:	vmovq  xmm1,QWORD PTR [rdx+0x40]
  8f6d6b:	vpinsrd xmm1,xmm1,DWORD PTR [rdx+0x48],0x2
  8f6d72:	vmovq  xmm2,QWORD PTR [rdx+0x34]
  8f6d77:	mov    r9d,DWORD PTR [rdx+0x3c]
  8f6d7b:	mov    DWORD PTR [rsp+0x94],r9d
  8f6d83:	movzx  edx,BYTE PTR [rdx+0x4c]
  8f6d87:	mov    QWORD PTR [rsp+0x1e8],rdx
  8f6d8f:	mov    rdx,QWORD PTR [r15+0x18]
  8f6d93:	mov    QWORD PTR [rsp+0x18],rdx
  8f6d98:	mov    rdx,QWORD PTR [r15+0x20]
  8f6d9c:	mov    QWORD PTR [rsp+0x108],rdx
  8f6da4:	mov    rdx,QWORD PTR [r15+0x48]
  8f6da8:	mov    QWORD PTR [rsp+0x20],rdx
  8f6dad:	mov    rdx,QWORD PTR [r15+0x30]
  8f6db1:	mov    QWORD PTR [rsp+0x78],rdx
  8f6db6:	mov    r9,QWORD PTR [rbx+0x138]
  8f6dbd:	mov    QWORD PTR [rsp+0x48],r10
  8f6dc2:	mov    QWORD PTR [rsp+0x80],rbx
  8f6dca:	je     8f6dd3 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x113>
  8f6dcc:	xor    edx,edx
  8f6dce:	div    r14
  8f6dd1:	jmp    8f6dd8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x118>
  8f6dd3:	xor    edx,edx
  8f6dd5:	div    r14d
  8f6dd8:	xor    r10d,r10d
  8f6ddb:	test   rdx,rdx
  8f6dde:	setne  r10b
  8f6de2:	add    r10,rax
  8f6de5:	mov    QWORD PTR [rsp+0xe8],r10
  8f6ded:	je     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f6df3:	mov    rbx,r14
  8f6df6:	shl    rbx,0x6
  8f6dfa:	je     8fa2df <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x361f>
  8f6e00:	not    r8d
  8f6e03:	vmovd  xmm11,r8d
  8f6e08:	mov    rax,QWORD PTR [rsp+0x1e8]
  8f6e10:	lea    eax,[rax*8+0x0]
  8f6e17:	or     al,0x4
  8f6e19:	vmovd  xmm3,eax
  8f6e1d:	mov    rax,QWORD PTR [rsp+0x1f8]
  8f6e25:	not    eax
  8f6e27:	vmovd  xmm12,eax
  8f6e2b:	and    r9d,0x1
  8f6e2f:	vmovd  xmm4,edi
  8f6e33:	lea    rax,[r14+r14*1]
  8f6e37:	vmovd  xmm5,esi
  8f6e3b:	mov    rdx,QWORD PTR [rsp+0x18]
  8f6e40:	lea    rsi,[rdx+0xc00]
  8f6e47:	mov    QWORD PTR [rsp+0x98],rsi
  8f6e4f:	vmovd  xmm6,ecx
  8f6e53:	lea    rcx,[rdx+0x300]
  8f6e5a:	mov    QWORD PTR [rsp+0x50],rcx
  8f6e5f:	lea    rcx,[r9+r9*2]
  8f6e63:	mov    QWORD PTR [rsp+0xf8],rcx
  8f6e6b:	vmovd  xmm7,r14d
  8f6e70:	vpbroadcastd ymm7,xmm7
  8f6e75:	vpmulld xmm8,xmm7,XMMWORD PTR [rip+0xffffffffff71ff32]        # 16db0 <anon.245362c1692d2350ec60721dad848e3d.1615.llvm.5944606840923237273+0x3c0>
  8f6e7e:	vpmulld xmm9,xmm7,XMMWORD PTR [rip+0xffffffffff71d159]        # 13fe0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x72e>
  8f6e87:	lea    rax,[rax+rax*2]
  8f6e8b:	mov    QWORD PTR [rsp+0xf0],rax
  8f6e93:	vpmulld ymm13,ymm7,YMMWORD PTR [rip+0xffffffffff723564]        # 1a400 <anon.db13f839740d960fd97bc530122b4c99.104.llvm.5594421697515501092+0x4b8>
  8f6e9c:	vpxor  xmm10,xmm10,xmm10
  8f6ea1:	vpblendd xmm7,xmm10,xmm7,0x2
  8f6ea7:	vpermq ymm8,ymm8,0xd0
  8f6ead:	vpblendd ymm7,ymm8,ymm7,0x3
  8f6eb3:	vpbroadcastq ymm8,xmm9
  8f6eb8:	vpblendd ymm7,ymm7,ymm8,0xc0
  8f6ebe:	vpbroadcastb xmm3,xmm3
  8f6ec3:	vmovdqa XMMWORD PTR [rsp+0x2a0],xmm3
  8f6ecc:	vmovdqa XMMWORD PTR [rsp+0x350],xmm11
  8f6ed5:	vmovdqa XMMWORD PTR [rsp+0x370],xmm12
  8f6ede:	vpand  xmm3,xmm11,xmm12
  8f6ee3:	vpbroadcastd ymm3,xmm3
  8f6ee8:	vmovdqa YMMWORD PTR [rsp+0x520],ymm3
  8f6ef1:	vmovss xmm3,DWORD PTR [rsp+0x90]
  8f6efa:	vbroadcastss ymm3,xmm3
  8f6eff:	vmovaps YMMWORD PTR [rsp+0x500],ymm3
  8f6f08:	vmovss xmm3,DWORD PTR [rsp+0x8c]
  8f6f11:	vbroadcastss ymm3,xmm3
  8f6f16:	vmovaps YMMWORD PTR [rsp+0x4e0],ymm3
  8f6f1f:	vpbroadcastd ymm4,xmm4
  8f6f24:	vpbroadcastd ymm3,xmm5
  8f6f29:	vmovdqa YMMWORD PTR [rsp+0x4c0],ymm3
  8f6f32:	vpbroadcastd ymm3,xmm6
  8f6f37:	vmovdqa YMMWORD PTR [rsp+0x420],ymm3
  8f6f40:	cmp    QWORD PTR [rsp+0x20],0x0
  8f6f46:	vmovdqa YMMWORD PTR [rsp+0x3e0],ymm13
  8f6f4f:	vmovdqa YMMWORD PTR [rsp+0x3c0],ymm7
  8f6f58:	je     8f917c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x24bc>
  8f6f5e:	vmovdqa YMMWORD PTR [rsp+0x780],ymm4
  8f6f67:	vpshufd xmm3,xmm2,0x55
  8f6f6c:	vpbroadcastd ymm3,xmm3
  8f6f71:	vmovdqa YMMWORD PTR [rsp+0x460],ymm3
  8f6f7a:	vmovd  xmm3,DWORD PTR [rsp+0x74]
  8f6f80:	vpbroadcastd ymm3,xmm3
  8f6f85:	vmovdqa YMMWORD PTR [rsp+0x760],ymm3
  8f6f8e:	vmovd  DWORD PTR [rsp+0x114],xmm2
  8f6f97:	vmovd  DWORD PTR [rsp+0x110],xmm0
  8f6fa0:	vpshufd xmm2,xmm0,0x55
  8f6fa5:	vpbroadcastd ymm2,xmm2
  8f6faa:	vmovdqa YMMWORD PTR [rsp+0x740],ymm2
  8f6fb3:	vmovss xmm2,DWORD PTR [rsp+0x88]
  8f6fbc:	vbroadcastss ymm2,xmm2
  8f6fc1:	vmovaps YMMWORD PTR [rsp+0x720],ymm2
  8f6fca:	vpbroadcastd ymm2,xmm0
  8f6fcf:	vmovdqa YMMWORD PTR [rsp+0x700],ymm2
  8f6fd8:	vpbroadcastd ymm2,xmm1
  8f6fdd:	vmovdqa YMMWORD PTR [rsp+0x6e0],ymm2
  8f6fe6:	vpshufd xmm2,xmm1,0x55
  8f6feb:	vpbroadcastd ymm2,xmm2
  8f6ff0:	vmovdqa YMMWORD PTR [rsp+0x6c0],ymm2
  8f6ff9:	vpshufd xmm1,xmm1,0xee
  8f6ffe:	vpbroadcastd ymm1,xmm1
  8f7003:	vmovdqa YMMWORD PTR [rsp+0x6a0],ymm1
  8f700c:	vmovq  rax,xmm0
  8f7011:	shr    rax,0x20
  8f7015:	vmovd  xmm0,eax
  8f7019:	vpbroadcastd ymm0,xmm0
  8f701e:	vmovdqa YMMWORD PTR [rsp+0x5e0],ymm0
  8f7027:	mov    eax,r14d
  8f702a:	shl    eax,0x6
  8f702d:	mov    DWORD PTR [rsp+0x118],eax
  8f7034:	mov    eax,r14d
  8f7037:	shl    eax,0x4
  8f703a:	mov    DWORD PTR [rsp+0x11c],eax
  8f7041:	mov    rax,r14
  8f7044:	shl    rax,0x4
  8f7048:	mov    QWORD PTR [rsp+0x2f8],rax
  8f7050:	neg    rax
  8f7053:	mov    QWORD PTR [rsp+0x2c0],rax
  8f705b:	mov    rcx,QWORD PTR [rip+0x6f0356]        # fe73b8 <_DYNAMIC+0x2b60>
  8f7062:	mov    eax,DWORD PTR [rsp+0x94]
  8f7069:	not    eax
  8f706b:	vmovd  xmm0,eax
  8f706f:	vmovdqa XMMWORD PTR [rsp+0x360],xmm0
  8f7078:	mov    QWORD PTR [rsp+0x58],r14
  8f707d:	mov    QWORD PTR [rsp+0x2c8],rbx
  8f7085:	jmp    8f70ad <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3ed>
  8f7087:	nop    WORD PTR [rax+rax*1+0x0]
  8f7090:	add    r15,r14
  8f7093:	mov    QWORD PTR [rsp+0x48],r15
  8f7098:	dec    QWORD PTR [rsp+0xe8]
  8f70a0:	mov    rcx,QWORD PTR [rip+0x6f0311]        # fe73b8 <_DYNAMIC+0x2b60>
  8f70a7:	je     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f70ad:	mov    rdi,QWORD PTR [rsp+0x108]
  8f70b5:	mov    r15,QWORD PTR [rsp+0x48]
  8f70ba:	mov    rsi,r15
  8f70bd:	vzeroupper
  8f70c0:	call   rcx
  8f70c2:	test   rax,rax
  8f70c5:	je     8f7090 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3d0>
  8f70c7:	test   rdx,rdx
  8f70ca:	je     8f7090 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3d0>
  8f70cc:	mov    r8,rax
  8f70cf:	vmovd  xmm0,r15d
  8f70d4:	mov    eax,r15d
  8f70d7:	sub    eax,DWORD PTR [rsp+0x90]
  8f70de:	mov    ecx,eax
  8f70e0:	imul   ecx,DWORD PTR [rsp+0x8c]
  8f70e8:	sar    eax,0x1f
  8f70eb:	mov    QWORD PTR [rsp+0x100],0x0
  8f70f7:	cmp    r15d,DWORD PTR [rsp+0x74]
  8f70fc:	mov    esi,0x0
  8f7101:	sbb    esi,esi
  8f7103:	vpbroadcastd ymm1,xmm0
  8f7108:	vmovd  xmm0,esi
  8f710c:	vpbroadcastd ymm0,xmm0
  8f7111:	vmovdqa YMMWORD PTR [rsp+0x680],ymm0
  8f711a:	vpand  xmm0,xmm1,XMMWORD PTR [rsp+0x350]
  8f7123:	vpbroadcastd ymm0,xmm0
  8f7128:	vmovdqa YMMWORD PTR [rsp+0x7c0],ymm0
  8f7131:	vmovdqa YMMWORD PTR [rsp+0x4a0],ymm1
  8f713a:	vpand  xmm0,xmm1,XMMWORD PTR [rsp+0x360]
  8f7143:	vpbroadcastd ymm0,xmm0
  8f7148:	vmovdqa YMMWORD PTR [rsp+0x7a0],ymm0
  8f7151:	cmp    r15d,DWORD PTR [rsp+0x114]
  8f7159:	mov    esi,0x0
  8f715e:	sbb    esi,esi
  8f7160:	vmovd  xmm0,esi
  8f7164:	vpbroadcastd ymm0,xmm0
  8f7169:	vmovdqa YMMWORD PTR [rsp+0x480],ymm0
  8f7172:	vmovd  xmm0,ecx
  8f7176:	vpbroadcastd ymm0,xmm0
  8f717b:	vmovdqa YMMWORD PTR [rsp+0x660],ymm0
  8f7184:	vmovd  xmm0,eax
  8f7188:	vpbroadcastd ymm0,xmm0
  8f718d:	vmovdqa YMMWORD PTR [rsp+0x640],ymm0
  8f7196:	mov    eax,r15d
  8f7199:	sub    eax,DWORD PTR [rsp+0x88]
  8f71a0:	mov    ecx,eax
  8f71a2:	sar    ecx,0x1f
  8f71a5:	imul   eax,DWORD PTR [rsp+0x110]
  8f71ad:	vmovd  xmm0,eax
  8f71b1:	vpbroadcastd ymm0,xmm0
  8f71b6:	vmovdqa YMMWORD PTR [rsp+0x620],ymm0
  8f71bf:	vmovd  xmm0,ecx
  8f71c3:	vpbroadcastd ymm0,xmm0
  8f71c8:	vmovdqa YMMWORD PTR [rsp+0x600],ymm0
  8f71d1:	mov    rax,QWORD PTR [rsp+0x2c0]
  8f71d9:	mov    QWORD PTR [rsp+0x1d8],rax
  8f71e1:	mov    QWORD PTR [rsp+0x1e0],0x0
  8f71ed:	jmp    8f7250 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x590>
  8f71ef:	nop
  8f71f0:	mov    rcx,QWORD PTR [rsp+0x2d0]
  8f71f8:	lea    rax,[rcx+rcx*2]
  8f71fc:	mov    r8,QWORD PTR [rsp+0x2e0]
  8f7204:	lea    r8,[r8+rax*2]
  8f7208:	mov    rdx,QWORD PTR [rsp+0x2d8]
  8f7210:	sub    rdx,rcx
  8f7213:	inc    QWORD PTR [rsp+0x1e0]
  8f721b:	mov    rax,QWORD PTR [rsp+0x100]
  8f7223:	add    eax,DWORD PTR [rsp+0x118]
  8f722a:	mov    QWORD PTR [rsp+0x100],rax
  8f7232:	mov    rbx,QWORD PTR [rsp+0x2c8]
  8f723a:	add    QWORD PTR [rsp+0x1d8],rbx
  8f7242:	test   rdx,rdx
  8f7245:	mov    r15,QWORD PTR [rsp+0x48]
  8f724a:	je     8f7090 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3d0>
  8f7250:	cmp    rdx,rbx
  8f7253:	cmovb  rbx,rdx
  8f7257:	mov    rax,rbx
  8f725a:	or     rax,r14
  8f725d:	shr    rax,0x20
  8f7261:	mov    QWORD PTR [rsp+0x2d8],rdx
  8f7269:	je     8f7280 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x5c0>
  8f726b:	mov    rax,rbx
  8f726e:	xor    edx,edx
  8f7270:	div    r14
  8f7273:	mov    r9,rax
  8f7276:	jmp    8f728a <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x5ca>
  8f7278:	nop    DWORD PTR [rax+rax*1+0x0]
  8f7280:	mov    eax,ebx
  8f7282:	xor    edx,edx
  8f7284:	div    r14d
  8f7287:	mov    r9d,eax
  8f728a:	mov    rdi,QWORD PTR [rsp+0x18]
  8f728f:	cmp    rdx,0x1
  8f7293:	sbb    r9,0xffffffffffffffff
  8f7297:	cmp    r9,0x40
  8f729b:	mov    eax,0x40
  8f72a0:	cmovae r9,rax
  8f72a4:	mov    QWORD PTR [rsp+0x2d0],rbx
  8f72ac:	lea    rax,[rbx+rbx*1]
  8f72b0:	lea    rax,[rax+rax*2]
  8f72b4:	mov    rsi,QWORD PTR [rsp+0xf8]
  8f72bc:	sub    rax,rsi
  8f72bf:	mov    ecx,0x0
  8f72c4:	cmovae rcx,rax
  8f72c8:	mov    QWORD PTR [rsp+0x1f0],r9
  8f72d0:	imul   r9,QWORD PTR [rsp+0xf0]
  8f72d9:	cmp    rcx,r9
  8f72dc:	cmovb  r9,rcx
  8f72e0:	mov    QWORD PTR [rsp+0x2e0],r8
  8f72e8:	add    rsi,r8
  8f72eb:	cmp    r9,0x300
  8f72f2:	mov    eax,0x300
  8f72f7:	cmovae r9,rax
  8f72fb:	mov    rdx,r9
  8f72fe:	vzeroupper
  8f7301:	call   QWORD PTR [rip+0x6ed799]        # fe4aa0 <memcpy@GLIBC_2.14>
  8f7307:	mov    rdx,QWORD PTR [rsp+0x18]
  8f730c:	cmp    r15,0x7fffffff
  8f7313:	vmovdqa ymm13,YMMWORD PTR [rsp+0x3e0]
  8f731c:	vmovdqa ymm14,YMMWORD PTR [rsp+0x3c0]
  8f7325:	vmovdqa xmm7,XMMWORD PTR [rsp+0x2a0]
  8f732e:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f7334:	mov    rax,QWORD PTR [rsp+0x1e0]
  8f733c:	imul   rax,QWORD PTR [rsp+0x58]
  8f7342:	shl    rax,0x6
  8f7346:	mov    rcx,QWORD PTR [rsp+0x1f0]
  8f734e:	lea    rsi,[rcx+0xf]
  8f7352:	shr    rsi,0x4
  8f7356:	mov    QWORD PTR [rsp+0xe0],rax
  8f735e:	je     8f8090 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x13d0>
  8f7364:	or     rax,QWORD PTR [rsp+0x48]
  8f7369:	mov    QWORD PTR [rsp+0x2f0],rax
  8f7371:	vmovaps xmm0,XMMWORD PTR [rsp+0x380]
  8f737a:	vmovaps XMMWORD PTR [rsp+0x450],xmm0
  8f7383:	vmovaps xmm0,XMMWORD PTR [rsp+0x390]
  8f738c:	vmovaps XMMWORD PTR [rsp+0x440],xmm0
  8f7395:	vmovaps xmm0,XMMWORD PTR [rsp+0x3a0]
  8f739e:	vmovaps XMMWORD PTR [rsp+0x2b0],xmm0
  8f73a7:	mov    r11d,0xc40
  8f73ad:	mov    r12d,0x2b
  8f73b3:	vbroadcastss ymm0,DWORD PTR [rsp+0x3b0]
  8f73bd:	vmovaps YMMWORD PTR [rsp+0x7e0],ymm0
  8f73c6:	mov    r15,QWORD PTR [rsp+0x1d8]
  8f73ce:	mov    rax,QWORD PTR [rsp+0x100]
  8f73d6:	mov    r14d,eax
  8f73d9:	xor    r13d,r13d
  8f73dc:	xor    edi,edi
  8f73de:	mov    QWORD PTR [rsp+0x2e8],rsi
  8f73e6:	jmp    8f7aab <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xdeb>
  8f73eb:	nop    DWORD PTR [rax+rax*1+0x0]
  8f73f0:	vpsrld ymm5,ymm2,0x1a
  8f73f5:	vpaddd ymm2,ymm5,ymm2
  8f73f9:	vpsrad ymm2,ymm2,0x6
  8f73fe:	vmovdqa ymm5,YMMWORD PTR [rsp+0x4a0]
  8f7407:	vpaddd ymm0,ymm2,ymm5
  8f740b:	vmovdqa YMMWORD PTR [rsp+0x260],ymm0
  8f7414:	vpbroadcastd ymm11,DWORD PTR [rsp+0x370]
  8f741e:	vpand  ymm0,ymm11,ymm0
  8f7422:	vpsrld ymm9,ymm3,0x1a
  8f7427:	vpaddd ymm3,ymm9,ymm3
  8f742b:	vpsrad ymm3,ymm3,0x6
  8f7430:	vpaddd ymm9,ymm3,ymm5
  8f7434:	vpand  ymm2,ymm9,ymm11
  8f7439:	vmovdqa YMMWORD PTR [rsp+0x140],ymm2
  8f7442:	vmovdqa YMMWORD PTR [rsp+0x800],ymm2
  8f744b:	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
  8f7454:	vmovdqa YMMWORD PTR [rsp+0x820],ymm0
  8f745d:	vmovdqu YMMWORD PTR [rdx+r11*4-0x29e0],ymm0
  8f7467:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2a00],ymm2
  8f7471:	vpsrad ymm13,ymm8,0x1f
  8f7477:	vpsrld ymm13,ymm13,0x1a
  8f747d:	vpaddd ymm13,ymm13,ymm8
  8f7482:	vpsrad ymm8,ymm7,0x1f
  8f7487:	vpsrld ymm8,ymm8,0x1a
  8f748d:	vpaddd ymm14,ymm8,ymm7
  8f7491:	vpsrld ymm7,ymm12,0x1a
  8f7497:	vpaddd ymm7,ymm12,ymm7
  8f749b:	vpsrad ymm7,ymm7,0x6
  8f74a0:	vpaddd ymm12,ymm7,ymm1
  8f74a4:	vpand  ymm0,ymm12,ymm11
  8f74a9:	vpsrld ymm8,ymm10,0x1a
  8f74af:	vpaddd ymm8,ymm8,ymm10
  8f74b4:	vpsrad ymm8,ymm8,0x6
  8f74ba:	vmovdqa ymm3,ymm15
  8f74be:	vpaddd ymm10,ymm8,ymm15
  8f74c3:	vpand  ymm7,ymm10,ymm11
  8f74c8:	vmovdqa YMMWORD PTR [rsp+0x840],ymm7
  8f74d1:	vmovdqa YMMWORD PTR [rsp+0x860],ymm0
  8f74da:	vmovdqa ymm8,ymm0
  8f74de:	vmovdqa YMMWORD PTR [rsp+0x200],ymm0
  8f74e7:	lea    rax,[rsp+0x840]
  8f74ef:	vmovaps ymm15,YMMWORD PTR [rax]
  8f74f3:	vmovaps ymm0,YMMWORD PTR [rax+0x20]
  8f74f8:	vmovups YMMWORD PTR [rdx+r11*4-0x28e0],ymm0
  8f7502:	vpsrad ymm0,ymm14,0x6
  8f7508:	vpaddd ymm0,ymm0,ymm5
  8f750c:	vmovups YMMWORD PTR [rdx+r11*4-0x2900],ymm15
  8f7516:	vpsrad ymm14,ymm6,0x1f
  8f751b:	vpsrld ymm14,ymm14,0x1a
  8f7521:	vpaddd ymm6,ymm14,ymm6
  8f7525:	vpsrad ymm14,ymm4,0x1f
  8f752a:	vpsrld ymm14,ymm14,0x1a
  8f7530:	vpaddd ymm14,ymm14,ymm4
  8f7534:	vmovdqa ymm2,YMMWORD PTR [rsp+0x760]
  8f753d:	vpminud ymm4,ymm2,ymm0
  8f7542:	vpcmpeqd ymm4,ymm2,ymm4
  8f7546:	vpsrad ymm6,ymm6,0x6
  8f754b:	vpaddd ymm6,ymm6,ymm1
  8f754f:	vmovdqa YMMWORD PTR [rsp+0x280],ymm1
  8f7558:	vmovdqa ymm1,YMMWORD PTR [rsp+0x420]
  8f7561:	vpminud ymm15,ymm1,ymm6
  8f7566:	vpcmpeqd ymm15,ymm15,ymm1
  8f756a:	vpor   ymm4,ymm15,ymm4
  8f756e:	vmovdqa YMMWORD PTR [rsp+0x160],ymm4
  8f7577:	vpsrad ymm13,ymm13,0x6
  8f757d:	vpaddd ymm13,ymm13,ymm5
  8f7581:	vpminud ymm15,ymm2,ymm13
  8f7586:	vpcmpeqd ymm15,ymm15,ymm2
  8f758a:	vpand  ymm4,ymm13,ymm11
  8f758f:	vmovdqa YMMWORD PTR [rsp+0x180],ymm4
  8f7598:	vpand  ymm0,ymm11,ymm0
  8f759c:	vmovdqa YMMWORD PTR [rsp+0xc0],ymm0
  8f75a5:	vpand  ymm0,ymm11,ymm6
  8f75a9:	vmovdqa YMMWORD PTR [rsp+0x1a0],ymm0
  8f75b2:	vpsrad ymm0,ymm14,0x6
  8f75b8:	vpaddd ymm0,ymm0,ymm3
  8f75bc:	vpand  ymm4,ymm11,ymm0
  8f75c0:	vmovdqa YMMWORD PTR [rsp+0x120],ymm4
  8f75c9:	vpminud ymm0,ymm1,ymm0
  8f75ce:	vpcmpeqd ymm0,ymm1,ymm0
  8f75d2:	vpor   ymm0,ymm15,ymm0
  8f75d6:	vmovdqa YMMWORD PTR [rsp+0xa0],ymm0
  8f75df:	vpminud ymm0,ymm2,ymm9
  8f75e4:	vpcmpeqd ymm0,ymm2,ymm0
  8f75e8:	vpminud ymm11,ymm1,ymm10
  8f75ed:	vpcmpeqd ymm11,ymm11,ymm1
  8f75f1:	vpor   ymm5,ymm11,ymm0
  8f75f5:	vmovdqa ymm4,YMMWORD PTR [rsp+0x260]
  8f75fe:	vpminud ymm0,ymm2,ymm4
  8f7603:	vpcmpeqd ymm0,ymm2,ymm0
  8f7607:	vpminud ymm11,ymm1,ymm12
  8f760c:	vpcmpeqd ymm11,ymm11,ymm1
  8f7610:	vpor   ymm11,ymm11,ymm0
  8f7614:	vmovdqa ymm15,YMMWORD PTR [rsp+0x500]
  8f761d:	vmovdqa ymm6,YMMWORD PTR [rsp+0x140]
  8f7626:	vpsubd ymm0,ymm6,ymm15
  8f762b:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4e0]
  8f7634:	vpmulld ymm14,ymm0,ymm1
  8f7639:	vpaddd ymm14,ymm14,ymm7
  8f763d:	vpsrad ymm0,ymm0,0x1f
  8f7642:	vpor   ymm0,ymm14,ymm0
  8f7646:	vmovdqa ymm13,YMMWORD PTR [rsp+0x240]
  8f764f:	vpsubd ymm14,ymm13,ymm15
  8f7654:	vpmulld ymm15,ymm14,ymm1
  8f7659:	vpaddd ymm15,ymm15,ymm8
  8f765e:	vpsrad ymm14,ymm14,0x1f
  8f7664:	vpor   ymm14,ymm15,ymm14
  8f7669:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2800],ymm0
  8f7673:	vmovdqu YMMWORD PTR [rdx+r11*4-0x27e0],ymm14
  8f767d:	vmovdqa ymm14,YMMWORD PTR [rsp+0x520]
  8f7686:	vpand  ymm0,ymm10,ymm14
  8f768b:	vmovdqa ymm1,YMMWORD PTR [rsp+0x780]
  8f7694:	vpaddd ymm10,ymm3,ymm1
  8f7698:	vmovdqa ymm15,ymm3
  8f769c:	vpsubd ymm0,ymm10,ymm0
  8f76a0:	vpand  ymm10,ymm12,ymm14
  8f76a5:	vmovdqa ymm8,YMMWORD PTR [rsp+0x280]
  8f76ae:	vpaddd ymm12,ymm8,ymm1
  8f76b2:	vpsubd ymm10,ymm12,ymm10
  8f76b7:	vpand  ymm9,ymm9,ymm14
  8f76bc:	vmovdqa ymm2,YMMWORD PTR [rsp+0x7c0]
  8f76c5:	vpcmpeqd ymm9,ymm9,ymm2
  8f76c9:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4c0]
  8f76d2:	vpminud ymm0,ymm1,ymm0
  8f76d7:	vpcmpeqd ymm0,ymm1,ymm0
  8f76db:	vpandn ymm0,ymm0,ymm9
  8f76e0:	vpandn ymm12,ymm5,ymm0
  8f76e4:	vmovdqa YMMWORD PTR [rsp+0x220],ymm12
  8f76ed:	vpand  ymm0,ymm14,ymm4
  8f76f1:	vpcmpeqd ymm0,ymm0,ymm2
  8f76f5:	vpminud ymm5,ymm1,ymm10
  8f76fa:	vpcmpeqd ymm5,ymm1,ymm5
  8f76fe:	vpandn ymm0,ymm5,ymm0
  8f7702:	vpandn ymm10,ymm11,ymm0
  8f7706:	vmovdqa YMMWORD PTR [rsp+0x260],ymm10
  8f770f:	vmovdqa ymm1,YMMWORD PTR [rsp+0x720]
  8f7718:	vpsubd ymm0,ymm6,ymm1
  8f771c:	vpsubd ymm2,ymm13,ymm1
  8f7720:	vmovdqa ymm9,YMMWORD PTR [rsp+0x700]
  8f7729:	vpmulld ymm3,ymm9,ymm0
  8f772e:	vpaddd ymm3,ymm3,ymm7
  8f7732:	vpmulld ymm5,ymm9,ymm2
  8f7737:	vpaddd ymm5,ymm5,YMMWORD PTR [rsp+0x200]
  8f7740:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff721537]        # 18c80 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  8f7749:	vpsrad ymm0,ymm0,0x1f
  8f774e:	vpor   ymm0,ymm3,ymm0
  8f7752:	vpsrad ymm2,ymm2,0x1f
  8f7757:	vpor   ymm2,ymm5,ymm2
  8f775b:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2700],ymm0
  8f7765:	vmovdqu YMMWORD PTR [rdx+r11*4-0x26e0],ymm2
  8f776f:	vmovdqa ymm6,YMMWORD PTR [rsp+0x180]
  8f7778:	vpsubd ymm0,ymm6,ymm1
  8f777c:	vmovdqa ymm4,YMMWORD PTR [rsp+0xc0]
  8f7785:	vpsubd ymm2,ymm4,ymm1
  8f7789:	vpmulld ymm3,ymm0,ymm9
  8f778e:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x120]
  8f7797:	vpsrad ymm0,ymm0,0x1f
  8f779c:	vpor   ymm0,ymm3,ymm0
  8f77a0:	vpmulld ymm3,ymm2,ymm9
  8f77a5:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x1a0]
  8f77ae:	vpsrad ymm2,ymm2,0x1f
  8f77b3:	vpor   ymm2,ymm3,ymm2
  8f77b7:	vpand  ymm1,ymm12,ymm7
  8f77bb:	vmovdqa YMMWORD PTR [rsp+0x140],ymm1
  8f77c4:	vpand  ymm1,ymm10,ymm7
  8f77c8:	vmovdqa YMMWORD PTR [rsp+0x240],ymm1
  8f77d1:	vmovdqa ymm5,YMMWORD PTR [rsp+0x740]
  8f77da:	vpminud ymm1,ymm5,ymm15
  8f77df:	vpcmpeqd ymm1,ymm5,ymm1
  8f77e3:	vpminud ymm3,ymm5,ymm8
  8f77e8:	vpcmpeqd ymm3,ymm5,ymm3
  8f77ec:	vmovdqa ymm5,YMMWORD PTR [rsp+0x480]
  8f77f5:	vpandn ymm1,ymm1,ymm5
  8f77f9:	vmovdqa YMMWORD PTR [rsp+0x200],ymm1
  8f7802:	vpandn ymm1,ymm3,ymm5
  8f7806:	vmovdqa YMMWORD PTR [rsp+0x280],ymm1
  8f780f:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2600],ymm0
  8f7819:	vmovdqu YMMWORD PTR [rdx+r11*4-0x25e0],ymm2
  8f7823:	vmovdqa ymm1,YMMWORD PTR [rsp+0x460]
  8f782c:	vpminud ymm0,ymm1,ymm0
  8f7831:	vpcmpeqd ymm0,ymm1,ymm0
  8f7835:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0xa0]
  8f783e:	vmovdqa YMMWORD PTR [rsp+0xa0],ymm0
  8f7847:	vpminud ymm0,ymm1,ymm2
  8f784c:	vpcmpeqd ymm0,ymm1,ymm0
  8f7850:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0x160]
  8f7859:	vmovdqa YMMWORD PTR [rsp+0x400],ymm0
  8f7862:	vpbroadcastd ymm0,DWORD PTR [rsp+0x360]
  8f786c:	vpand  ymm1,ymm6,ymm0
  8f7870:	vpand  ymm0,ymm4,ymm0
  8f7874:	vmovdqa ymm2,YMMWORD PTR [rsp+0x7a0]
  8f787d:	vpcmpeqd ymm1,ymm2,ymm1
  8f7881:	vmovdqa YMMWORD PTR [rsp+0x320],ymm1
  8f788a:	vpcmpeqd ymm0,ymm2,ymm0
  8f788e:	vmovdqa YMMWORD PTR [rsp+0x300],ymm0
  8f7897:	mov    QWORD PTR [rsp+0x160],rdi
  8f789f:	lea    rdi,[rsp+0x540]
  8f78a7:	lea    rsi,[rsp+0x800]
  8f78af:	mov    edx,DWORD PTR [rsp+0x94]
  8f78b6:	mov    rbx,r11
  8f78b9:	vzeroupper
  8f78bc:	call   4b8bd0 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAINtNtNtCs9DW4HO7zhlu_13fearless_simd9generated10simd_types6i32x16NtNtBD_4avx24Avx2Ej2_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitBy_ENCINvMB27_B24_10wrap_mut_1By_NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesB1B_Kb1_Es4_0E0EB3x_>
  8f78c1:	mov    r11,rbx
  8f78c4:	mov    rdi,QWORD PTR [rsp+0x160]
  8f78cc:	mov    rsi,QWORD PTR [rsp+0x2e8]
  8f78d4:	vmovdqa ymm14,YMMWORD PTR [rsp+0x3c0]
  8f78dd:	vmovdqa ymm13,YMMWORD PTR [rsp+0x3e0]
  8f78e6:	mov    rdx,QWORD PTR [rsp+0x18]
  8f78eb:	vmovdqa ymm0,YMMWORD PTR [rsp+0x180]
  8f78f4:	vpsubd ymm0,ymm0,YMMWORD PTR [rsp+0x540]
  8f78fd:	vmovdqa ymm2,YMMWORD PTR [rsp+0x6c0]
  8f7906:	vpaddd ymm1,ymm2,YMMWORD PTR [rsp+0x120]
  8f790f:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x580]
  8f7918:	vmovdqa ymm3,YMMWORD PTR [rsp+0x6e0]
  8f7921:	vpminud ymm0,ymm3,ymm0
  8f7926:	vpcmpeqd ymm0,ymm3,ymm0
  8f792a:	vmovdqa ymm4,YMMWORD PTR [rsp+0x6a0]
  8f7933:	vpminud ymm1,ymm4,ymm1
  8f7938:	vpcmpeqd ymm1,ymm4,ymm1
  8f793c:	vpor   ymm0,ymm0,ymm1
  8f7940:	vmovdqa ymm1,YMMWORD PTR [rsp+0xc0]
  8f7949:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x560]
  8f7952:	vpaddd ymm2,ymm2,YMMWORD PTR [rsp+0x1a0]
  8f795b:	vpsubd ymm2,ymm2,YMMWORD PTR [rsp+0x5a0]
  8f7964:	vpminud ymm1,ymm3,ymm1
  8f7969:	vpcmpeqd ymm1,ymm3,ymm1
  8f796d:	vpminud ymm2,ymm4,ymm2
  8f7972:	vpcmpeqd ymm2,ymm4,ymm2
  8f7976:	vpor   ymm1,ymm1,ymm2
  8f797a:	vmovdqa ymm4,YMMWORD PTR [rsp+0xa0]
  8f7983:	vpandn ymm2,ymm4,YMMWORD PTR [rsp+0x320]
  8f798c:	vmovdqa ymm5,YMMWORD PTR [rsp+0x400]
  8f7995:	vpandn ymm3,ymm5,YMMWORD PTR [rsp+0x300]
  8f799e:	vpor   ymm0,ymm0,ymm4
  8f79a2:	vpor   ymm1,ymm1,ymm5
  8f79a6:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff7214e9]        # 18e98 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1449>
  8f79af:	vpandn ymm0,ymm0,ymm4
  8f79b3:	vpandn ymm1,ymm1,ymm4
  8f79b7:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff7216b0]        # 19070 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  8f79c0:	vmovdqa ymm7,YMMWORD PTR [rsp+0x200]
  8f79c9:	vpand  ymm5,ymm7,ymm4
  8f79cd:	vpor   ymm5,ymm5,YMMWORD PTR [rsp+0x140]
  8f79d6:	vmovdqa ymm8,YMMWORD PTR [rsp+0x280]
  8f79df:	vpand  ymm4,ymm8,ymm4
  8f79e3:	vpor   ymm4,ymm4,YMMWORD PTR [rsp+0x240]
  8f79ec:	vpbroadcastd ymm6,DWORD PTR [rip+0xffffffffff7214cb]        # 18ec0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  8f79f5:	vpand  ymm7,ymm7,ymm6
  8f79f9:	vpand  ymm7,ymm7,YMMWORD PTR [rsp+0x220]
  8f7a02:	vpsrld ymm2,ymm2,0x1f
  8f7a07:	vpor   ymm2,ymm7,ymm2
  8f7a0b:	vpor   ymm2,ymm5,ymm2
  8f7a0f:	vpor   ymm0,ymm2,ymm0
  8f7a13:	vpand  ymm2,ymm8,ymm6
  8f7a17:	vpand  ymm2,ymm2,YMMWORD PTR [rsp+0x260]
  8f7a20:	vpsrld ymm3,ymm3,0x1f
  8f7a25:	vpor   ymm2,ymm2,ymm3
  8f7a29:	vpor   ymm2,ymm4,ymm2
  8f7a2d:	vpor   ymm1,ymm2,ymm1
  8f7a31:	lea    rax,[r11-0xc40]
  8f7a38:	vmovdqa xmm2,XMMWORD PTR [rsp+0x60]
  8f7a3e:	vpor   xmm2,xmm2,XMMWORD PTR [rip+0xffffffffff71d84a]        # 15290 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0xed0>
  8f7a46:	vextracti128 xmm3,ymm1,0x1
  8f7a4c:	vpackssdw xmm1,xmm1,xmm3
  8f7a50:	vextracti128 xmm3,ymm0,0x1
  8f7a56:	vpackssdw xmm0,xmm0,xmm3
  8f7a5a:	vpacksswb xmm0,xmm0,xmm1
  8f7a5e:	vpand  xmm0,xmm2,xmm0
  8f7a62:	vmovdqu XMMWORD PTR [rdx+r11*1],xmm0
  8f7a68:	vmovdqa xmm7,XMMWORD PTR [rsp+0x2a0]
  8f7a71:	vpand  xmm0,xmm0,xmm7
  8f7a75:	vpxor  xmm1,xmm1,xmm1
  8f7a79:	vpcmpeqb xmm0,xmm0,xmm1
  8f7a7d:	vpmovmskb ecx,xmm0
  8f7a81:	xor    ecx,0xffff
  8f7a87:	shlx   rax,rcx,rax
  8f7a8c:	or     rdi,rax
  8f7a8f:	inc    r13
  8f7a92:	add    r11,0x10
  8f7a96:	add    r12,0x30
  8f7a9a:	add    r14d,DWORD PTR [rsp+0x11c]
  8f7aa2:	cmp    r13,rsi
  8f7aa5:	jae    8f8092 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x13d2>
  8f7aab:	add    r15,QWORD PTR [rsp+0x2f8]
  8f7ab3:	cmp    r15,0x7fffffff
  8f7aba:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f7ac0:	cmp    QWORD PTR [rsp+0x58],0x1
  8f7ac6:	jne    8f7b80 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xec0>
  8f7acc:	vmovdqu xmm0,XMMWORD PTR [rdx+r12*2-0x56]
  8f7ad3:	vmovdqu xmm1,XMMWORD PTR [rdx+r12*2-0x50]
  8f7ada:	vmovdqu xmm2,XMMWORD PTR [rdx+r12*2-0x26]
  8f7ae1:	vmovdqu xmm3,XMMWORD PTR [rdx+r12*2-0x20]
  8f7ae8:	vpblendd xmm0,xmm0,XMMWORD PTR [rdx+r12*2-0x46],0x4
  8f7af0:	vpblendd xmm0,xmm0,XMMWORD PTR [rdx+r12*2-0x36],0x2
  8f7af8:	vpblendd xmm2,xmm2,XMMWORD PTR [rdx+r12*2-0x16],0x4
  8f7b00:	vpblendd xmm2,xmm2,XMMWORD PTR [rdx+r12*2-0x6],0x2
  8f7b08:	vpblendd xmm1,xmm1,XMMWORD PTR [rdx+r12*2-0x40],0x4
  8f7b10:	vpblendd xmm1,xmm1,XMMWORD PTR [rdx+r12*2-0x30],0x2
  8f7b18:	vpblendd xmm3,xmm3,XMMWORD PTR [rdx+r12*2-0x10],0x4
  8f7b20:	vpblendd xmm3,xmm3,XMMWORD PTR [rdx+r12*2],0x2
  8f7b27:	vmovq  xmm6,QWORD PTR [rip+0xffffffffff71ec51]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8f7b2f:	vpshufb xmm4,xmm1,xmm6
  8f7b34:	vpshufb xmm5,xmm0,xmm6
  8f7b39:	vpunpcklbw xmm4,xmm5,xmm4
  8f7b3d:	vpshufb xmm5,xmm3,xmm6
  8f7b42:	vpshufb xmm6,xmm2,xmm6
  8f7b47:	vpunpcklbw xmm5,xmm6,xmm5
  8f7b4b:	vmovd  xmm6,DWORD PTR [rip+0xffffffffff71cd7d]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x510>
  8f7b53:	vpshufb xmm1,xmm1,xmm6
  8f7b58:	vpshufb xmm0,xmm0,xmm6
  8f7b5d:	vpunpcklbw xmm0,xmm0,xmm1
  8f7b61:	vpshufb xmm1,xmm3,xmm6
  8f7b66:	vpshufb xmm2,xmm2,xmm6
  8f7b6b:	vpunpcklbw xmm1,xmm2,xmm1
  8f7b6f:	jmp    8f7c39 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xf79>
  8f7b74:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8f7b80:	vmovdqu xmm0,XMMWORD PTR [rdx+r12*4-0xac]
  8f7b8a:	vmovdqu xmm1,XMMWORD PTR [rdx+r12*4-0x8c]
  8f7b94:	vmovdqu xmm2,XMMWORD PTR [rdx+r12*4-0x7c]
  8f7b9b:	vmovdqu xmm3,XMMWORD PTR [rdx+r12*4-0x5c]
  8f7ba2:	vpblendd xmm0,xmm0,XMMWORD PTR [rdx+r12*4-0x9c],0x4
  8f7bad:	vmovdqa xmm5,XMMWORD PTR [rip+0xffffffffff71e5ab]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8f7bb5:	vpshufb xmm1,xmm1,xmm5
  8f7bba:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71f70e]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8f7bc2:	vpshufb xmm0,xmm0,xmm6
  8f7bc7:	vpor   xmm0,xmm0,xmm1
  8f7bcb:	vpblendd xmm1,xmm2,XMMWORD PTR [rdx+r12*4-0x6c],0x4
  8f7bd3:	vpshufb xmm2,xmm3,xmm5
  8f7bd8:	vpshufb xmm1,xmm1,xmm6
  8f7bdd:	vpor   xmm1,xmm1,xmm2
  8f7be1:	vmovdqu xmm2,XMMWORD PTR [rdx+r12*4-0x2c]
  8f7be8:	vmovdqu xmm3,XMMWORD PTR [rdx+r12*4-0x4c]
  8f7bef:	vpblendd xmm3,xmm3,XMMWORD PTR [rdx+r12*4-0x3c],0x4
  8f7bf7:	vpshufb xmm2,xmm2,xmm5
  8f7bfc:	vpshufb xmm3,xmm3,xmm6
  8f7c01:	vpor   xmm2,xmm3,xmm2
  8f7c05:	vmovdqu xmm3,XMMWORD PTR [rdx+r12*4+0x4]
  8f7c0c:	vmovdqu xmm4,XMMWORD PTR [rdx+r12*4-0x1c]
  8f7c13:	vpblendd xmm4,xmm4,XMMWORD PTR [rdx+r12*4-0xc],0x4
  8f7c1b:	vpshufb xmm3,xmm3,xmm5
  8f7c20:	vpshufb xmm4,xmm4,xmm6
  8f7c25:	vpor   xmm3,xmm4,xmm3
  8f7c29:	vpunpckldq xmm4,xmm0,xmm1
  8f7c2d:	vpunpckldq xmm5,xmm2,xmm3
  8f7c31:	vpunpckhdq xmm0,xmm0,xmm1
  8f7c35:	vpunpckhdq xmm1,xmm2,xmm3
  8f7c39:	vpunpcklqdq xmm0,xmm0,xmm1
  8f7c3d:	vpunpcklqdq xmm1,xmm4,xmm5
  8f7c41:	vpunpckhqdq xmm3,xmm4,xmm5
  8f7c45:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71c3a3]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f7c4d:	vmovdqa xmm4,XMMWORD PTR [rsp+0x2b0]
  8f7c56:	vpshufb xmm4,xmm4,xmm2
  8f7c5b:	vmovdqa XMMWORD PTR [rsp+0x60],xmm4
  8f7c61:	vptest xmm4,xmm7
  8f7c66:	je     8f7a8f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xdcf>
  8f7c6c:	vmovdqu XMMWORD PTR [rdx+r11*1-0x40],xmm1
  8f7c73:	vmovdqa xmm1,XMMWORD PTR [rsp+0x450]
  8f7c7c:	vpshufb xmm4,xmm1,xmm2
  8f7c81:	vmovdqa xmm1,XMMWORD PTR [rsp+0x440]
  8f7c8a:	vpshufb xmm2,xmm1,xmm2
  8f7c8f:	vpunpcklbw xmm1,xmm4,xmm2
  8f7c93:	vpunpckhbw xmm2,xmm4,xmm2
  8f7c97:	vpmovsxbw ymm3,xmm3
  8f7c9c:	vpmovsxwd ymm4,xmm3
  8f7ca1:	vextracti128 xmm3,ymm3,0x1
  8f7ca7:	vpmovsxwd ymm3,xmm3
  8f7cac:	vpabsd ymm5,ymm4
  8f7cb1:	vpabsd ymm6,ymm3
  8f7cb6:	vpsrld ymm7,ymm5,0x4
  8f7cbb:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff7212dc]        # 18fa0 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  8f7cc4:	vpsrld ymm8,ymm6,0x4
  8f7cc9:	vpmaxud ymm7,ymm7,ymm9
  8f7cce:	vpcmpeqd ymm11,ymm11,ymm11
  8f7cd3:	vpaddd ymm7,ymm11,ymm7
  8f7cd7:	vpmaxud ymm8,ymm8,ymm9
  8f7cdc:	vpaddd ymm8,ymm8,ymm11
  8f7ce1:	vpslld ymm10,ymm7,0x4
  8f7ce6:	vpsubd ymm5,ymm5,ymm10
  8f7ceb:	vpslld ymm10,ymm8,0x4
  8f7cf1:	vpsubd ymm6,ymm6,ymm10
  8f7cf6:	vpsllvd ymm5,ymm5,ymm7
  8f7cfb:	vpsllvd ymm6,ymm6,ymm8
  8f7d00:	vpsrad ymm4,ymm4,0x1f
  8f7d05:	vpsrad ymm3,ymm3,0x1f
  8f7d0a:	vpxor  ymm5,ymm5,ymm4
  8f7d0e:	vpxor  ymm6,ymm6,ymm3
  8f7d12:	vpsubd ymm8,ymm5,ymm4
  8f7d16:	vpsubd ymm7,ymm6,ymm3
  8f7d1a:	vpmovsxbw ymm0,xmm0
  8f7d1f:	vpmovsxwd ymm3,xmm0
  8f7d24:	vextracti128 xmm0,ymm0,0x1
  8f7d2a:	vpmovsxwd ymm0,xmm0
  8f7d2f:	vpabsd ymm4,ymm3
  8f7d34:	vpabsd ymm5,ymm0
  8f7d39:	vpsrld ymm6,ymm4,0x4
  8f7d3e:	vpsrld ymm10,ymm5,0x4
  8f7d43:	vpmaxud ymm6,ymm6,ymm9
  8f7d48:	vpaddd ymm6,ymm11,ymm6
  8f7d4c:	vpmaxud ymm9,ymm10,ymm9
  8f7d51:	vpaddd ymm9,ymm9,ymm11
  8f7d56:	vpslld ymm10,ymm6,0x4
  8f7d5b:	vpsubd ymm4,ymm4,ymm10
  8f7d60:	vpslld ymm10,ymm9,0x4
  8f7d66:	vpsubd ymm5,ymm5,ymm10
  8f7d6b:	vpmovsxwd ymm1,xmm1
  8f7d70:	vpmovsxwd ymm2,xmm2
  8f7d75:	vmovdqa ymm10,YMMWORD PTR [rsp+0x7e0]
  8f7d7e:	vpmulld ymm1,ymm10,ymm1
  8f7d83:	vpmulld ymm2,ymm10,ymm2
  8f7d88:	vpsllvd ymm4,ymm4,ymm6
  8f7d8d:	vpsllvd ymm5,ymm5,ymm9
  8f7d92:	vpsrad ymm3,ymm3,0x1f
  8f7d97:	vpsrad ymm0,ymm0,0x1f
  8f7d9c:	vpxor  ymm4,ymm4,ymm3
  8f7da0:	vpxor  ymm5,ymm5,ymm0
  8f7da4:	vpsubd ymm4,ymm4,ymm3
  8f7da8:	vpsubd ymm6,ymm5,ymm0
  8f7dac:	vpmulld ymm0,ymm1,ymm8
  8f7db1:	vpmulld ymm3,ymm2,ymm7
  8f7db6:	vpsrad ymm5,ymm0,0x1f
  8f7dbb:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff721214]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8f7dc4:	vpaddd ymm0,ymm9,ymm0
  8f7dc8:	vpaddd ymm5,ymm0,ymm5
  8f7dcc:	vpsrad ymm0,ymm3,0x1f
  8f7dd1:	vpaddd ymm3,ymm9,ymm3
  8f7dd5:	vpaddd ymm10,ymm3,ymm0
  8f7dd9:	vpmulld ymm0,ymm1,ymm4
  8f7dde:	vpsrad ymm1,ymm0,0x1f
  8f7de3:	vpaddd ymm0,ymm9,ymm0
  8f7de7:	vpaddd ymm11,ymm0,ymm1
  8f7deb:	vmovd  xmm0,r14d
  8f7df0:	vpbroadcastd ymm0,xmm0
  8f7df5:	vpmulld ymm1,ymm2,ymm6
  8f7dfa:	vpaddd ymm2,ymm9,ymm1
  8f7dfe:	vpsrad ymm1,ymm1,0x1f
  8f7e03:	vpaddd ymm9,ymm2,ymm1
  8f7e07:	vpaddd ymm15,ymm14,ymm0
  8f7e0b:	vpaddd ymm1,ymm13,ymm0
  8f7e0f:	vpsrad ymm3,ymm5,0xe
  8f7e14:	vpsrad ymm2,ymm10,0xe
  8f7e1a:	vpsrad ymm10,ymm11,0xe
  8f7e20:	vpsrad ymm12,ymm9,0xe
  8f7e26:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2e00],ymm8
  8f7e30:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2de0],ymm7
  8f7e3a:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2c00],ymm3
  8f7e44:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2be0],ymm2
  8f7e4e:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2d00],ymm4
  8f7e58:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2ce0],ymm6
  8f7e62:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2b00],ymm10
  8f7e6c:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2ae0],ymm12
  8f7e76:	mov    rax,QWORD PTR [rsp+0x2f0]
  8f7e7e:	test   QWORD PTR [rsp+0x1f8],rax
  8f7e86:	jne    8f73f0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x730>
  8f7e8c:	vpabsd ymm5,ymm6
  8f7e91:	vpabsd ymm9,ymm4
  8f7e96:	vpabsd ymm11,ymm7
  8f7e9b:	vpor   ymm5,ymm11,ymm5
  8f7e9f:	vpabsd ymm11,ymm8
  8f7ea4:	vpor   ymm9,ymm9,ymm11
  8f7ea9:	vpabsd ymm11,ymm3
  8f7eae:	vpor   ymm9,ymm9,ymm11
  8f7eb3:	vpabsd ymm11,ymm2
  8f7eb8:	vpor   ymm5,ymm11,ymm5
  8f7ebc:	vpabsd ymm11,ymm12
  8f7ec1:	vpor   ymm5,ymm11,ymm5
  8f7ec5:	vpabsd ymm11,ymm10
  8f7eca:	vpor   ymm9,ymm9,ymm11
  8f7ecf:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff720f50]        # 18e28 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x13d9>
  8f7ed8:	vpcmpgtd ymm5,ymm5,ymm11
  8f7edd:	vpcmpgtd ymm9,ymm9,ymm11
  8f7ee2:	vpackssdw ymm5,ymm9,ymm5
  8f7ee6:	vpmovmskb eax,ymm5
  8f7eea:	test   eax,eax
  8f7eec:	jne    8f73f0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x730>
  8f7ef2:	vmovaps ymm0,YMMWORD PTR [rsp+0x4a0]
  8f7efb:	vmovups YMMWORD PTR [rdx+r11*4-0x2a00],ymm0
  8f7f05:	vmovups YMMWORD PTR [rdx+r11*4-0x29e0],ymm0
  8f7f0f:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2900],ymm15
  8f7f19:	vmovdqu YMMWORD PTR [rdx+r11*4-0x28e0],ymm1
  8f7f23:	vmovdqa ymm0,YMMWORD PTR [rsp+0x660]
  8f7f2c:	vpaddd ymm2,ymm15,ymm0
  8f7f30:	vpaddd ymm3,ymm1,ymm0
  8f7f34:	vmovdqa ymm0,YMMWORD PTR [rsp+0x640]
  8f7f3d:	vpor   ymm2,ymm2,ymm0
  8f7f41:	vpor   ymm3,ymm3,ymm0
  8f7f45:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2800],ymm2
  8f7f4f:	vmovdqu YMMWORD PTR [rdx+r11*4-0x27e0],ymm3
  8f7f59:	vmovdqa ymm0,YMMWORD PTR [rsp+0x420]
  8f7f62:	vpminud ymm2,ymm0,ymm15
  8f7f67:	vpcmpeqd ymm2,ymm0,ymm2
  8f7f6b:	vpminud ymm3,ymm0,ymm1
  8f7f70:	vpcmpeqd ymm4,ymm0,ymm3
  8f7f74:	vmovdqa ymm0,YMMWORD PTR [rsp+0x680]
  8f7f7d:	vpandn ymm3,ymm2,ymm0
  8f7f81:	vpandn ymm2,ymm4,ymm0
  8f7f85:	vmovdqa ymm0,YMMWORD PTR [rsp+0x5e0]
  8f7f8e:	vpminud ymm4,ymm0,ymm15
  8f7f93:	vpcmpeqd ymm4,ymm0,ymm4
  8f7f97:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffff720ce0]        # 18c80 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  8f7fa0:	vmovdqa ymm9,ymm1
  8f7fa4:	vmovdqa ymm1,YMMWORD PTR [rsp+0x480]
  8f7fad:	vpandn ymm4,ymm4,ymm1
  8f7fb1:	vpand  ymm6,ymm3,ymm5
  8f7fb5:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff7210b2]        # 19070 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  8f7fbe:	vpand  ymm8,ymm4,ymm7
  8f7fc2:	vpor   ymm6,ymm8,ymm6
  8f7fc6:	vpminud ymm8,ymm0,ymm9
  8f7fcb:	vpcmpeqd ymm8,ymm8,ymm0
  8f7fcf:	vpandn ymm8,ymm8,ymm1
  8f7fd3:	vpand  ymm5,ymm2,ymm5
  8f7fd7:	vpand  ymm7,ymm8,ymm7
  8f7fdb:	vpor   ymm5,ymm5,ymm7
  8f7fdf:	vmovdqa ymm0,YMMWORD PTR [rsp+0x620]
  8f7fe8:	vpaddd ymm1,ymm15,ymm0
  8f7fec:	vpaddd ymm0,ymm9,ymm0
  8f7ff0:	vmovdqa ymm7,YMMWORD PTR [rsp+0x600]
  8f7ff9:	vpor   ymm1,ymm1,ymm7
  8f7ffd:	vpor   ymm0,ymm0,ymm7
  8f8001:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2700],ymm1
  8f800b:	vmovdqu YMMWORD PTR [rdx+r11*4-0x26e0],ymm0
  8f8015:	vmovdqu YMMWORD PTR [rdx+r11*4-0x2600],ymm1
  8f801f:	vmovdqa ymm7,YMMWORD PTR [rsp+0x460]
  8f8028:	vpminud ymm1,ymm7,ymm1
  8f802d:	vpcmpeqd ymm1,ymm7,ymm1
  8f8031:	vpandn ymm1,ymm1,ymm3
  8f8035:	vpand  ymm3,ymm4,ymm3
  8f8039:	vmovdqu YMMWORD PTR [rdx+r11*4-0x25e0],ymm0
  8f8043:	vpminud ymm0,ymm7,ymm0
  8f8048:	vpcmpeqd ymm0,ymm7,ymm0
  8f804c:	vpandn ymm4,ymm0,ymm2
  8f8050:	vpand  ymm0,ymm8,ymm2
  8f8054:	vpbroadcastd ymm2,DWORD PTR [rip+0xffffffffff720e63]        # 18ec0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  8f805d:	vpand  ymm3,ymm3,ymm2
  8f8061:	vpand  ymm2,ymm0,ymm2
  8f8065:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff720e32]        # 18ea0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1451>
  8f806e:	vpand  ymm0,ymm1,ymm7
  8f8072:	vpor   ymm0,ymm0,ymm6
  8f8076:	vpor   ymm0,ymm0,ymm3
  8f807a:	vpand  ymm1,ymm4,ymm7
  8f807e:	vpor   ymm1,ymm1,ymm5
  8f8082:	vpor   ymm1,ymm1,ymm2
  8f8086:	jmp    8f7a31 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0xd71>
  8f808b:	nop    DWORD PTR [rax+rax*1+0x0]
  8f8090:	xor    edi,edi
  8f8092:	mov    rax,QWORD PTR [rsp+0x1f0]
  8f809a:	cmp    rax,0x1
  8f809e:	adc    rax,0x0
  8f80a2:	bzhi   rax,rdi,rax
  8f80a7:	test   BYTE PTR [rsp+0x1e8],0x1
  8f80af:	je     8f8130 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1470>
  8f80b1:	mov    rcx,QWORD PTR [rsp+0x80]
  8f80b9:	mov    rcx,QWORD PTR [rcx+0x130]
  8f80c0:	mov    QWORD PTR [rsp+0x140],rcx
  8f80c8:	mov    rcx,QWORD PTR [rsp+0x48]
  8f80cd:	movabs r12,0x7fffffffffffffff
  8f80d7:	mov    rdx,QWORD PTR [rsp+0x20]
  8f80dc:	sub    rcx,QWORD PTR [rdx+0x30]
  8f80e0:	mov    r14,QWORD PTR [rsp+0x58]
  8f80e5:	jb     8f810c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x144c>
  8f80e7:	imul   rcx,QWORD PTR [rdx+0x58]
  8f80ec:	mov    rdx,QWORD PTR [rdx+0x28]
  8f80f0:	cmp    rcx,rdx
  8f80f3:	jae    8f810c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x144c>
  8f80f5:	add    rcx,QWORD PTR [rsp+0xe0]
  8f80fd:	imul   rdx,QWORD PTR [rsp+0x140]
  8f8106:	add    rdx,rcx
  8f8109:	mov    r12,rdx
  8f810c:	test   rax,rax
  8f810f:	je     8f71f0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x530>
  8f8115:	mov    QWORD PTR [rsp+0x300],r12
  8f811d:	jmp    8f81bb <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14fb>
  8f8122:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8f8130:	mov    rcx,QWORD PTR [rsp+0x80]
  8f8138:	mov    r13,QWORD PTR [rcx+0x130]
  8f813f:	mov    rcx,QWORD PTR [rsp+0x48]
  8f8144:	movabs rsi,0x7fffffffffffffff
  8f814e:	mov    rdx,QWORD PTR [rsp+0x20]
  8f8153:	sub    rcx,QWORD PTR [rdx+0x30]
  8f8157:	mov    r14,QWORD PTR [rsp+0x58]
  8f815c:	jb     8f817e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14be>
  8f815e:	imul   rcx,QWORD PTR [rdx+0x58]
  8f8163:	mov    rdx,QWORD PTR [rdx+0x28]
  8f8167:	cmp    rcx,rdx
  8f816a:	jae    8f817e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14be>
  8f816c:	add    rcx,QWORD PTR [rsp+0xe0]
  8f8174:	imul   rdx,r13
  8f8178:	add    rdx,rcx
  8f817b:	mov    rsi,rdx
  8f817e:	mov    QWORD PTR [rsp+0x60],rsi
  8f8183:	test   rax,rax
  8f8186:	jne    8f8e10 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2150>
  8f818c:	jmp    8f71f0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x530>
  8f8191:	movzx  r8d,BYTE PTR [rdi+0xc]
  8f8196:	mov    r9b,0x1
  8f8199:	mov    ecx,edx
  8f819b:	shl    r9b,cl
  8f819e:	shr    rsi,0x10
  8f81a2:	mov    DWORD PTR [rdi+rdx*4],esi
  8f81a5:	or     r9b,r8b
  8f81a8:	mov    BYTE PTR [rdi+0xc],r9b
  8f81ac:	nop    DWORD PTR [rax+0x0]
  8f81b0:	blsr   rax,rax
  8f81b5:	je     8f71f0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x530>
  8f81bb:	tzcnt  rdx,rax
  8f81c0:	mov    rcx,QWORD PTR [rsp+0x98]
  8f81c8:	movzx  r9d,BYTE PTR [rcx+rdx*1]
  8f81cd:	cmp    r9d,0x9
  8f81d1:	jae    8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f81d3:	shl    r9d,0x5
  8f81d7:	add    r9,QWORD PTR [rsp+0x80]
  8f81df:	mov    rcx,QWORD PTR [rsp+0x18]
  8f81e4:	movzx  edi,BYTE PTR [rcx+rdx*1+0xc40]
  8f81ec:	mov    rsi,rdx
  8f81ef:	imul   rsi,r14
  8f81f3:	mov    QWORD PTR [rsp+0x60],rsi
  8f81f8:	lea    r15,[rsi+r12*1]
  8f81fc:	mov    r11d,DWORD PTR [rcx+rdx*4+0x300]
  8f8204:	mov    ecx,DWORD PTR [rcx+rdx*4+0x400]
  8f820b:	mov    DWORD PTR [rsp+0x1a0],ecx
  8f8212:	xor    ebx,ebx
  8f8214:	test   dil,0x8
  8f8218:	je     8f82d7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1617>
  8f821e:	cmp    BYTE PTR [r9],0x0
  8f8222:	je     8f8ad7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e17>
  8f8228:	mov    r13,QWORD PTR [r9+0x8]
  8f822c:	mov    rcx,QWORD PTR [rsp+0x50]
  8f8231:	mov    ebx,DWORD PTR [rcx+rdx*4+0x800]
  8f8238:	mov    r10,QWORD PTR [rsp+0x20]
  8f823d:	mov    r8,QWORD PTR [r10+0x28]
  8f8241:	imul   r8,r13
  8f8245:	cmp    r15,QWORD PTR [r10+0x18]
  8f8249:	jae    8f8680 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x19c0>
  8f824f:	mov    rcx,QWORD PTR [r10+0x10]
  8f8253:	mov    rsi,r15
  8f8256:	shl    rsi,0x4
  8f825a:	mov    BYTE PTR [rsp+0x120],dil
  8f8262:	movzx  edi,BYTE PTR [rcx+rsi*1+0xd]
  8f8267:	cmp    dil,BYTE PTR [r10+0x6c]
  8f826b:	movzx  edi,BYTE PTR [rsp+0x120]
  8f8273:	jne    8f8680 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x19c0>
  8f8279:	add    rcx,rsi
  8f827c:	cmp    BYTE PTR [rcx+0xc],0x0
  8f8280:	je     8f8680 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x19c0>
  8f8286:	mov    QWORD PTR [rsp+0x2b0],rbx
  8f828e:	mov    QWORD PTR [rsp+0x220],r15
  8f8296:	mov    DWORD PTR [rsp+0x280],r11d
  8f829e:	mov    QWORD PTR [rsp+0x240],r8
  8f82a6:	vmovdqa xmm0,XMMWORD PTR [rcx]
  8f82aa:	vmovdqa XMMWORD PTR [rsp+0x540],xmm0
  8f82b3:	movzx  r14d,BYTE PTR [rsp+0x54c]
  8f82bc:	test   r14b,r14b
  8f82bf:	je     8f8649 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1989>
  8f82c5:	mov    QWORD PTR [rsp+0x320],r13
  8f82cd:	mov    QWORD PTR [rsp+0x400],rdx
  8f82d5:	jmp    8f8315 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1655>
  8f82d7:	jmp    8f8ad7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e17>
  8f82dc:	mov    dil,0x1
  8f82df:	shl    dil,cl
  8f82e2:	mov    r8,QWORD PTR [rsp+0x180]
  8f82ea:	mov    DWORD PTR [rsi+rcx*4],r8d
  8f82ee:	or     BYTE PTR [rsi+0xc],dil
  8f82f2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8f8300:	lea    ecx,[r14-0x1]
  8f8304:	and    cl,r14b
  8f8307:	mov    r14d,ecx
  8f830a:	mov    r10,QWORD PTR [rsp+0x20]
  8f830f:	je     8f8649 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1989>
  8f8315:	movzx  ecx,r14b
  8f8319:	tzcnt  ecx,ecx
  8f831d:	cmp    cl,0x3
  8f8320:	jae    8f8649 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1989>
  8f8326:	mov    r8d,DWORD PTR [rsp+rcx*4+0x540]
  8f832e:	mov    r12d,r8d
  8f8331:	shr    r12d,0x10
  8f8335:	mov    esi,DWORD PTR [r10+0x50]
  8f8339:	mov    DWORD PTR [rsp+0x160],esi
  8f8340:	andn   edi,esi,r12d
  8f8345:	cmp    QWORD PTR [r10+0x38],0x1
  8f834a:	sete   sil
  8f834e:	mov    r11,QWORD PTR [r10+0x48]
  8f8352:	mov    QWORD PTR [rsp+0xc0],r11
  8f835a:	shrx   rsi,r11,rsi
  8f835f:	mov    QWORD PTR [rsp+0xa0],rdi
  8f8367:	mov    QWORD PTR [rsp+0x260],rsi
  8f836f:	sub    rdi,rsi
  8f8372:	mov    esi,0x0
  8f8377:	cmovae rsi,rdi
  8f837b:	mov    QWORD PTR [rsp+0x180],r8
  8f8383:	movzx  edi,r8w
  8f8387:	mov    r8,rdi
  8f838a:	sub    r8,QWORD PTR [r10+0x30]
  8f838e:	jb     8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f8394:	mov    r10,QWORD PTR [rsp+0x20]
  8f8399:	imul   r8,QWORD PTR [r10+0x58]
  8f839e:	add    r8,r12
  8f83a1:	mov    r15,QWORD PTR [r10+0x8]
  8f83a5:	mov    rbx,QWORD PTR [r10+0x20]
  8f83a9:	imul   rbx,r8
  8f83ad:	lea    r11,[rbx+r13*1]
  8f83b1:	cmp    r11,r15
  8f83b4:	jae    8f83e6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1726>
  8f83b6:	mov    r10,QWORD PTR [rsp+0x20]
  8f83bb:	mov    r10,QWORD PTR [r10]
  8f83be:	mov    rdx,r9
  8f83c1:	mov    r9,rdi
  8f83c4:	mov    rdi,r13
  8f83c7:	xor    r13d,r13d
  8f83ca:	cmp    r13w,WORD PTR [r10+r11*4]
  8f83cf:	mov    r13,rdi
  8f83d2:	mov    rdi,r9
  8f83d5:	mov    r9,rdx
  8f83d8:	mov    rdx,QWORD PTR [rsp+0x400]
  8f83e0:	jno    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f83e6:	add    rbx,QWORD PTR [rsp+0x140]
  8f83ee:	cmp    rbx,r15
  8f83f1:	jae    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f83f7:	mov    r10,QWORD PTR [rsp+0x20]
  8f83fc:	mov    r10,QWORD PTR [r10]
  8f83ff:	mov    QWORD PTR [rsp+0x200],r10
  8f8407:	movsx  r10d,WORD PTR [r10+rbx*4]
  8f840c:	cmp    r10d,0xffff8000
  8f8413:	je     8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f8419:	add    r10d,DWORD PTR [rsp+0x280]
  8f8421:	cmp    r10d,0xfffff802
  8f8428:	jge    8f8430 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1770>
  8f842a:	mov    r10d,0xfffff801
  8f8430:	cmp    r10d,0x7ff
  8f8437:	jl     8f843f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x177f>
  8f8439:	mov    r10d,0x7ff
  8f843f:	mov    r13,QWORD PTR [rsp+0x200]
  8f8447:	movsx  ebx,WORD PTR [r13+rbx*4+0x2]
  8f844d:	add    ebx,DWORD PTR [rsp+0x1a0]
  8f8454:	cmp    ebx,0xfffff802
  8f845a:	jl     8f850d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x184d>
  8f8460:	cmp    ebx,0x7ff
  8f8466:	jge    8f851e <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x185e>
  8f846c:	cmp    r11,r15
  8f846f:	mov    r13,QWORD PTR [rsp+0x320]
  8f8477:	jae    8f848c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x17cc>
  8f8479:	mov    r15,QWORD PTR [rsp+0x200]
  8f8481:	mov    WORD PTR [r15+r11*4],r10w
  8f8486:	mov    WORD PTR [r15+r11*4+0x2],bx
  8f848c:	mov    r11d,r10d
  8f848f:	neg    r11d
  8f8492:	cmovs  r11d,r10d
  8f8496:	mov    r15,rbx
  8f8499:	neg    ebx
  8f849b:	mov    QWORD PTR [rsp+0x200],r15
  8f84a3:	cmovs  ebx,r15d
  8f84a7:	cmp    r11d,ebx
  8f84aa:	cmova  ebx,r11d
  8f84ae:	cmp    ebx,0x40
  8f84b1:	jae    8f8539 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1879>
  8f84b7:	mov    rsi,QWORD PTR [rsp+0x20]
  8f84bc:	mov    rdi,QWORD PTR [rsi+0x28]
  8f84c0:	cmp    r8,rdi
  8f84c3:	jae    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f84c9:	imul   rdi,r13
  8f84cd:	add    rdi,r8
  8f84d0:	mov    rsi,QWORD PTR [rsp+0x20]
  8f84d5:	cmp    rdi,QWORD PTR [rsi+0x18]
  8f84d9:	jae    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f84df:	mov    rsi,QWORD PTR [rsp+0x20]
  8f84e4:	movzx  r8d,BYTE PTR [rsi+0x6c]
  8f84e9:	mov    r10,QWORD PTR [rsi+0x10]
  8f84ed:	shl    rdi,0x4
  8f84f1:	lea    rsi,[r10+rdi*1]
  8f84f5:	cmp    BYTE PTR [r10+rdi*1+0xd],r8b
  8f84fa:	je     8f82dc <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x161c>
  8f8500:	mov    BYTE PTR [rsi+0xd],r8b
  8f8504:	mov    BYTE PTR [rsi+0xc],0x0
  8f8508:	jmp    8f82dc <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x161c>
  8f850d:	mov    ebx,0xfffff801
  8f8512:	cmp    ebx,0x7ff
  8f8518:	jl     8f846c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x17ac>
  8f851e:	mov    ebx,0x7ff
  8f8523:	cmp    r11,r15
  8f8526:	mov    r13,QWORD PTR [rsp+0x320]
  8f852e:	jb     8f8479 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x17b9>
  8f8534:	jmp    8f848c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x17cc>
  8f8539:	lea    r8d,[r10+0x3f]
  8f853d:	test   r10d,r10d
  8f8540:	cmovns r8d,r10d
  8f8544:	movsx  r10d,r8w
  8f8548:	sar    r10d,0x6
  8f854c:	add    r10d,edi
  8f854f:	js     8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f8555:	mov    r8,QWORD PTR [rsp+0x20]
  8f855a:	cmp    QWORD PTR [r8+0x60],r10
  8f855e:	jbe    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f8564:	mov    r11,QWORD PTR [rsp+0x200]
  8f856c:	lea    r8d,[r11+0x3f]
  8f8570:	test   r11d,r11d
  8f8573:	cmovns r8d,r11d
  8f8577:	movsx  r8d,r8w
  8f857b:	sar    r8d,0x6
  8f857f:	add    r12d,r8d
  8f8582:	mov    r8,QWORD PTR [rsp+0x20]
  8f8587:	mov    r8,QWORD PTR [r8+0x58]
  8f858b:	setns  bl
  8f858e:	mov    r11d,r12d
  8f8591:	cmp    r8,r11
  8f8594:	seta   r15b
  8f8598:	and    r15b,bl
  8f859b:	cmp    r15b,0x1
  8f859f:	jne    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f85a5:	mov    rbx,QWORD PTR [rsp+0x20]
  8f85aa:	mov    ebx,DWORD PTR [rbx+0x40]
  8f85ad:	andn   r11d,ebx,r11d
  8f85b2:	cmp    r11,rsi
  8f85b5:	jb     8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f85bb:	mov    esi,DWORD PTR [rsp+0x160]
  8f85c2:	andn   edi,esi,edi
  8f85c7:	andn   esi,ebx,r10d
  8f85cc:	cmp    esi,edi
  8f85ce:	jb     8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f85d4:	add    rdi,QWORD PTR [rsp+0xc0]
  8f85dc:	cmp    rsi,rdi
  8f85df:	jae    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f85e5:	mov    rdi,QWORD PTR [rsp+0xc0]
  8f85ed:	add    rdi,QWORD PTR [rsp+0x260]
  8f85f5:	add    rdi,QWORD PTR [rsp+0xa0]
  8f85fd:	cmp    r11,rdi
  8f8600:	jae    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f8606:	mov    rdi,QWORD PTR [rsp+0x20]
  8f860b:	sub    rsi,QWORD PTR [rdi+0x30]
  8f860f:	jb     8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f8615:	imul   rsi,r8
  8f8619:	add    rsi,r11
  8f861c:	mov    rdi,QWORD PTR [rsp+0x20]
  8f8621:	mov    rdi,QWORD PTR [rdi+0x28]
  8f8625:	cmp    rsi,rdi
  8f8628:	jae    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f862e:	imul   rdi,r13
  8f8632:	add    rdi,rsi
  8f8635:	mov    rsi,QWORD PTR [rsp+0x20]
  8f863a:	cmp    rdi,QWORD PTR [rsi+0x18]
  8f863e:	jae    8f8300 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1640>
  8f8644:	jmp    8f84df <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x181f>
  8f8649:	mov    r14,QWORD PTR [rsp+0x58]
  8f864e:	mov    r12,QWORD PTR [rsp+0x300]
  8f8656:	mov    r8,QWORD PTR [rsp+0x240]
  8f865e:	mov    r11d,DWORD PTR [rsp+0x280]
  8f8666:	mov    r15,QWORD PTR [rsp+0x220]
  8f866e:	movzx  edi,BYTE PTR [rsp+0x120]
  8f8676:	mov    rbx,QWORD PTR [rsp+0x2b0]
  8f867e:	xchg   ax,ax
  8f8680:	add    r8,rbx
  8f8683:	test   dil,0x1
  8f8687:	mov    QWORD PTR [rsp+0x240],r8
  8f868f:	je     8f8ad0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e10>
  8f8695:	cmp    r8,QWORD PTR [r10+0x18]
  8f8699:	jae    8f8ad0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e10>
  8f869f:	mov    rcx,QWORD PTR [r10+0x10]
  8f86a3:	mov    rsi,r8
  8f86a6:	shl    rsi,0x4
  8f86aa:	mov    BYTE PTR [rsp+0x120],dil
  8f86b2:	movzx  edi,BYTE PTR [rcx+rsi*1+0xd]
  8f86b7:	cmp    dil,BYTE PTR [r10+0x6c]
  8f86bb:	movzx  edi,BYTE PTR [rsp+0x120]
  8f86c3:	jne    8f8ad0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e10>
  8f86c9:	add    rcx,rsi
  8f86cc:	cmp    BYTE PTR [rcx+0xc],0x0
  8f86d0:	je     8f8ad0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e10>
  8f86d6:	mov    QWORD PTR [rsp+0x320],r13
  8f86de:	mov    QWORD PTR [rsp+0x220],r15
  8f86e6:	mov    DWORD PTR [rsp+0x280],r11d
  8f86ee:	vmovdqa xmm0,XMMWORD PTR [rcx]
  8f86f2:	vmovdqa XMMWORD PTR [rsp+0x540],xmm0
  8f86fb:	movzx  ebx,BYTE PTR [rsp+0x54c]
  8f8703:	test   bl,bl
  8f8705:	je     8f8aa5 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1de5>
  8f870b:	mov    rcx,QWORD PTR [rsp+0x60]
  8f8710:	add    rcx,QWORD PTR [rsp+0xe0]
  8f8718:	mov    QWORD PTR [rsp+0x60],rcx
  8f871d:	jmp    8f874d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a8d>
  8f871f:	mov    dil,0x1
  8f8722:	shl    dil,cl
  8f8725:	mov    r8,QWORD PTR [rsp+0x180]
  8f872d:	mov    DWORD PTR [rsi+rcx*4],r8d
  8f8731:	or     BYTE PTR [rsi+0xc],dil
  8f8735:	data16 cs nop WORD PTR [rax+rax*1+0x0]
  8f8740:	lea    ecx,[rbx-0x1]
  8f8743:	and    cl,bl
  8f8745:	mov    ebx,ecx
  8f8747:	je     8f8aa5 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1de5>
  8f874d:	movzx  ecx,bl
  8f8750:	tzcnt  ecx,ecx
  8f8754:	cmp    cl,0x3
  8f8757:	jae    8f8aa5 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1de5>
  8f875d:	mov    r13d,DWORD PTR [rsp+rcx*4+0x540]
  8f8765:	mov    QWORD PTR [rsp+0x180],r13
  8f876d:	shr    r13d,0x10
  8f8771:	mov    rdi,QWORD PTR [rsp+0x20]
  8f8776:	mov    r12d,DWORD PTR [rdi+0x50]
  8f877a:	andn   esi,r12d,r13d
  8f877f:	mov    r8,QWORD PTR [rdi+0x48]
  8f8783:	cmp    QWORD PTR [rdi+0x38],0x1
  8f8788:	sete   dil
  8f878c:	mov    QWORD PTR [rsp+0xc0],r8
  8f8794:	shrx   r15,r8,rdi
  8f8799:	mov    rdi,rsi
  8f879c:	sub    rdi,r15
  8f879f:	mov    r11d,0x0
  8f87a5:	cmovae r11,rdi
  8f87a9:	cmp    QWORD PTR [rsp+0x60],r11
  8f87ae:	jb     8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f87b0:	add    r15,QWORD PTR [rsp+0xc0]
  8f87b8:	add    r15,rsi
  8f87bb:	cmp    QWORD PTR [rsp+0x60],r15
  8f87c0:	jae    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f87c6:	movzx  esi,WORD PTR [rsp+0x180]
  8f87ce:	mov    QWORD PTR [rsp+0x160],rsi
  8f87d6:	mov    rdi,QWORD PTR [rsp+0x20]
  8f87db:	sub    rsi,QWORD PTR [rdi+0x30]
  8f87df:	jb     8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f87e5:	mov    rdi,QWORD PTR [rsp+0x20]
  8f87ea:	imul   rsi,QWORD PTR [rdi+0x58]
  8f87ef:	add    rsi,r13
  8f87f2:	mov    r14,QWORD PTR [rdi+0x8]
  8f87f6:	mov    r8,QWORD PTR [rdi+0x20]
  8f87fa:	imul   r8,rsi
  8f87fe:	mov    rdi,QWORD PTR [rsp+0x140]
  8f8806:	lea    r10,[r8+rdi*1]
  8f880a:	mov    QWORD PTR [rsp+0x260],r10
  8f8812:	mov    QWORD PTR [rsp+0xa0],r14
  8f881a:	cmp    r10,r14
  8f881d:	mov    r14,QWORD PTR [rsp+0x58]
  8f8822:	mov    r10d,r12d
  8f8825:	jae    8f884c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1b8c>
  8f8827:	mov    r14,QWORD PTR [rsp+0x20]
  8f882c:	mov    r14,QWORD PTR [r14]
  8f882f:	xor    edi,edi
  8f8831:	mov    r10,QWORD PTR [rsp+0x260]
  8f8839:	cmp    di,WORD PTR [r14+r10*4]
  8f883e:	mov    r10d,r12d
  8f8841:	mov    r14,QWORD PTR [rsp+0x58]
  8f8846:	jno    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f884c:	add    r8,QWORD PTR [rsp+0x320]
  8f8854:	cmp    r8,QWORD PTR [rsp+0xa0]
  8f885c:	jae    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8862:	mov    rdi,QWORD PTR [rsp+0x20]
  8f8867:	mov    r12,QWORD PTR [rdi]
  8f886a:	movsx  edi,WORD PTR [r12+r8*4]
  8f886f:	cmp    edi,0xffff8000
  8f8875:	je     8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f887b:	sub    edi,DWORD PTR [rsp+0x280]
  8f8882:	cmp    edi,0xfffff802
  8f8888:	jge    8f888f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1bcf>
  8f888a:	mov    edi,0xfffff801
  8f888f:	cmp    edi,0x7ff
  8f8895:	jl     8f889c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1bdc>
  8f8897:	mov    edi,0x7ff
  8f889c:	mov    QWORD PTR [rsp+0x200],r12
  8f88a4:	movsx  r12d,WORD PTR [r12+r8*4+0x2]
  8f88aa:	sub    r12d,DWORD PTR [rsp+0x1a0]
  8f88b2:	cmp    r12d,0xfffff802
  8f88b9:	jl     8f8988 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1cc8>
  8f88bf:	cmp    r12d,0x7ff
  8f88c6:	mov    r8,QWORD PTR [rsp+0x260]
  8f88ce:	jge    8f89a3 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1ce3>
  8f88d4:	cmp    r8,QWORD PTR [rsp+0xa0]
  8f88dc:	jae    8f8901 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1c41>
  8f88de:	mov    DWORD PTR [rsp+0xa0],r10d
  8f88e6:	mov    r10,QWORD PTR [rsp+0x200]
  8f88ee:	mov    WORD PTR [r10+r8*4],di
  8f88f3:	mov    WORD PTR [r10+r8*4+0x2],r12w
  8f88f9:	mov    r10d,DWORD PTR [rsp+0xa0]
  8f8901:	mov    r8,rdi
  8f8904:	neg    edi
  8f8906:	mov    QWORD PTR [rsp+0xa0],r8
  8f890e:	cmovs  edi,r8d
  8f8912:	mov    r8d,r12d
  8f8915:	neg    r8d
  8f8918:	cmovs  r8d,r12d
  8f891c:	cmp    edi,r8d
  8f891f:	cmova  r8d,edi
  8f8923:	cmp    r8d,0x40
  8f8927:	jae    8f89bc <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1cfc>
  8f892d:	mov    rdi,QWORD PTR [rsp+0x20]
  8f8932:	mov    rdi,QWORD PTR [rdi+0x28]
  8f8936:	cmp    rsi,rdi
  8f8939:	jae    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f893f:	imul   rdi,QWORD PTR [rsp+0x140]
  8f8948:	add    rdi,rsi
  8f894b:	mov    rsi,QWORD PTR [rsp+0x20]
  8f8950:	cmp    rdi,QWORD PTR [rsi+0x18]
  8f8954:	jae    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f895a:	mov    rsi,QWORD PTR [rsp+0x20]
  8f895f:	movzx  r8d,BYTE PTR [rsi+0x6c]
  8f8964:	mov    r10,QWORD PTR [rsi+0x10]
  8f8968:	shl    rdi,0x4
  8f896c:	lea    rsi,[r10+rdi*1]
  8f8970:	cmp    BYTE PTR [r10+rdi*1+0xd],r8b
  8f8975:	je     8f871f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a5f>
  8f897b:	mov    BYTE PTR [rsi+0xd],r8b
  8f897f:	mov    BYTE PTR [rsi+0xc],0x0
  8f8983:	jmp    8f871f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a5f>
  8f8988:	mov    r12d,0xfffff801
  8f898e:	cmp    r12d,0x7ff
  8f8995:	mov    r8,QWORD PTR [rsp+0x260]
  8f899d:	jl     8f88d4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1c14>
  8f89a3:	mov    r12d,0x7ff
  8f89a9:	cmp    r8,QWORD PTR [rsp+0xa0]
  8f89b1:	jb     8f88de <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1c1e>
  8f89b7:	jmp    8f8901 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1c41>
  8f89bc:	mov    rdi,QWORD PTR [rsp+0xa0]
  8f89c4:	lea    esi,[rdi+0x3f]
  8f89c7:	test   edi,edi
  8f89c9:	cmovns esi,edi
  8f89cc:	movsx  esi,si
  8f89cf:	sar    esi,0x6
  8f89d2:	add    esi,DWORD PTR [rsp+0x160]
  8f89d9:	js     8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f89df:	mov    rdi,QWORD PTR [rsp+0x20]
  8f89e4:	cmp    QWORD PTR [rdi+0x60],rsi
  8f89e8:	jbe    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f89ee:	lea    edi,[r12+0x3f]
  8f89f3:	test   r12d,r12d
  8f89f6:	cmovns edi,r12d
  8f89fa:	movsx  edi,di
  8f89fd:	sar    edi,0x6
  8f8a00:	add    r13d,edi
  8f8a03:	mov    rdi,QWORD PTR [rsp+0x20]
  8f8a08:	mov    rdi,QWORD PTR [rdi+0x58]
  8f8a0c:	setns  r14b
  8f8a10:	mov    r8d,r13d
  8f8a13:	cmp    rdi,r8
  8f8a16:	seta   r13b
  8f8a1a:	and    r13b,r14b
  8f8a1d:	mov    r14,QWORD PTR [rsp+0x58]
  8f8a22:	cmp    r13b,0x1
  8f8a26:	jne    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8a2c:	mov    r13,QWORD PTR [rsp+0x20]
  8f8a31:	mov    r13d,DWORD PTR [r13+0x40]
  8f8a35:	andn   r8d,r13d,r8d
  8f8a3a:	cmp    r8,r15
  8f8a3d:	jae    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8a43:	cmp    r8,r11
  8f8a46:	jb     8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8a4c:	andn   r10d,r10d,DWORD PTR [rsp+0x160]
  8f8a56:	andn   esi,r13d,esi
  8f8a5b:	cmp    esi,r10d
  8f8a5e:	jb     8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8a64:	mov    r11,QWORD PTR [rsp+0xc0]
  8f8a6c:	add    r11,r10
  8f8a6f:	cmp    rsi,r11
  8f8a72:	jae    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8a78:	mov    r10,QWORD PTR [rsp+0x20]
  8f8a7d:	sub    rsi,QWORD PTR [r10+0x30]
  8f8a81:	jb     8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8a87:	imul   rsi,rdi
  8f8a8b:	add    rsi,r8
  8f8a8e:	mov    rdi,QWORD PTR [rsp+0x20]
  8f8a93:	mov    rdi,QWORD PTR [rdi+0x28]
  8f8a97:	cmp    rsi,rdi
  8f8a9a:	jae    8f8740 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1a80>
  8f8aa0:	jmp    8f893f <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1c7f>
  8f8aa5:	mov    r12,QWORD PTR [rsp+0x300]
  8f8aad:	mov    r11d,DWORD PTR [rsp+0x280]
  8f8ab5:	mov    r15,QWORD PTR [rsp+0x220]
  8f8abd:	movzx  edi,BYTE PTR [rsp+0x120]
  8f8ac5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
  8f8ad0:	mov    ebx,edi
  8f8ad2:	and    bl,0x2
  8f8ad5:	shr    bl,1
  8f8ad7:	test   dil,0x4
  8f8adb:	je     8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8ae1:	mov    rcx,QWORD PTR [rsp+0x50]
  8f8ae6:	mov    ecx,DWORD PTR [rcx+rdx*4+0x600]
  8f8aed:	mov    rsi,QWORD PTR [rsp+0x78]
  8f8af2:	cmp    QWORD PTR [rsi+0x8],rcx
  8f8af6:	jbe    8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8afc:	mov    r13d,edi
  8f8aff:	mov    rsi,QWORD PTR [rsp+0x78]
  8f8b04:	mov    rsi,QWORD PTR [rsi]
  8f8b07:	cmp    BYTE PTR [rsi+rcx*8+0x6],0x0
  8f8b0c:	je     8f8b2d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e6d>
  8f8b0e:	cmp    BYTE PTR [r9+0x1b],0x1
  8f8b13:	jne    8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8b19:	movsx  r8d,WORD PTR [rsi+rcx*8]
  8f8b1e:	mov    edi,DWORD PTR [r9+0x10]
  8f8b22:	cmp    edi,r8d
  8f8b25:	je     8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8b2b:	jmp    8f8b31 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1e71>
  8f8b2d:	mov    edi,DWORD PTR [r9+0x10]
  8f8b31:	mov    r8d,r11d
  8f8b34:	neg    r8d
  8f8b37:	mov    QWORD PTR [rsp+0x220],r15
  8f8b3f:	mov    r15d,DWORD PTR [rsp+0x1a0]
  8f8b47:	mov    r10d,r15d
  8f8b4a:	neg    r10d
  8f8b4d:	cmp    BYTE PTR [r9+0x1a],0x0
  8f8b52:	cmove  r8d,r11d
  8f8b56:	cmove  r10d,r15d
  8f8b5a:	shl    r10d,0x10
  8f8b5e:	movzx  r8d,r8w
  8f8b62:	or     r8d,r10d
  8f8b65:	mov    WORD PTR [rsi+rcx*8],di
  8f8b69:	mov    DWORD PTR [rsi+rcx*8+0x2],r8d
  8f8b6e:	mov    BYTE PTR [rsi+rcx*8+0x6],0x1
  8f8b73:	test   r13b,0x10
  8f8b77:	je     8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8b7d:	mov    rcx,QWORD PTR [rsp+0x50]
  8f8b82:	mov    edi,DWORD PTR [rcx+rdx*4+0x700]
  8f8b89:	mov    rcx,QWORD PTR [rsp+0x20]
  8f8b8e:	cmp    QWORD PTR [rcx+0x28],rdi
  8f8b92:	jbe    8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8b98:	mov    r15d,r11d
  8f8b9b:	mov    rsi,QWORD PTR [rsp+0x50]
  8f8ba0:	mov    r14d,DWORD PTR [rsi+rdx*4+0x200]
  8f8ba8:	mov    ecx,DWORD PTR [rsi+rdx*4+0x300]
  8f8baf:	mov    DWORD PTR [rsp+0x60],ecx
  8f8bb3:	mov    r11,QWORD PTR [r9]
  8f8bb6:	mov    r13,QWORD PTR [r9+0x8]
  8f8bba:	movsxd rcx,DWORD PTR [rsi+rdx*4+0x500]
  8f8bc2:	mov    esi,DWORD PTR [rsi+rdx*4+0x400]
  8f8bc9:	mov    r10,QWORD PTR [rsp+0x20]
  8f8bce:	movzx  edx,BYTE PTR [r10+0x68]
  8f8bd3:	shrx   rdx,rcx,rdx
  8f8bd8:	movabs r8,0xaaaaaaaaaaaaaaab
  8f8be2:	mulx   r8,r8,r8
  8f8be7:	shr    r8,1
  8f8bea:	lea    r8,[r8+r8*2]
  8f8bee:	sub    rdx,r8
  8f8bf1:	mov    r8d,esi
  8f8bf4:	or     r8d,ecx
  8f8bf7:	shl    rcx,0x20
  8f8bfb:	shl    rsi,0x10
  8f8bff:	add    rsi,rcx
  8f8c02:	cmp    r8d,0xffff
  8f8c09:	ja     8f8c99 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1fd9>
  8f8c0f:	mov    rcx,QWORD PTR [rsp+0x220]
  8f8c17:	cmp    rcx,QWORD PTR [r10+0x18]
  8f8c1b:	jae    8f8c99 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1fd9>
  8f8c1d:	mov    QWORD PTR [rsp+0x120],r13
  8f8c25:	movzx  ecx,BYTE PTR [r10+0x6c]
  8f8c2a:	mov    r13,QWORD PTR [r10+0x10]
  8f8c2e:	mov    r10,QWORD PTR [rsp+0x220]
  8f8c36:	shl    r10,0x4
  8f8c3a:	lea    r12,[r10+r13*1]
  8f8c3e:	cmp    BYTE PTR [r13+r10*1+0xd],cl
  8f8c43:	jne    8f8c54 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1f94>
  8f8c45:	movzx  ecx,BYTE PTR [r12+0xc]
  8f8c4b:	mov    DWORD PTR [rsp+0xc0],ecx
  8f8c52:	jmp    8f8c64 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x1fa4>
  8f8c54:	mov    BYTE PTR [r12+0xd],cl
  8f8c59:	mov    DWORD PTR [rsp+0xc0],0x0
  8f8c64:	mov    r13,rsi
  8f8c67:	mov    r10b,0x1
  8f8c6a:	mov    ecx,edx
  8f8c6c:	shl    r10b,cl
  8f8c6f:	shr    r13,0x10
  8f8c73:	mov    DWORD PTR [r12+rdx*4],r13d
  8f8c77:	or     r10b,BYTE PTR [rsp+0xc0]
  8f8c7f:	mov    BYTE PTR [r12+0xc],r10b
  8f8c84:	mov    r10,QWORD PTR [rsp+0x20]
  8f8c89:	mov    r12,QWORD PTR [rsp+0x300]
  8f8c91:	mov    r13,QWORD PTR [rsp+0x120]
  8f8c99:	mov    rcx,QWORD PTR [r10+0x20]
  8f8c9d:	imul   rcx,rdi
  8f8ca1:	add    rcx,QWORD PTR [rsp+0x140]
  8f8ca9:	cmp    rcx,QWORD PTR [r10+0x8]
  8f8cad:	jae    8f8cf3 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2033>
  8f8caf:	vmovd  xmm0,r14d
  8f8cb4:	vpinsrd xmm0,xmm0,DWORD PTR [rsp+0x60],0x1
  8f8cbc:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff7200cb]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8f8cc5:	vpxor  xmm2,xmm2,xmm2
  8f8cc9:	vpsubd xmm0,xmm2,xmm0
  8f8ccd:	vpmaxsd xmm0,xmm0,xmm1
  8f8cd2:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff72006d]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8f8cdb:	mov    r10,QWORD PTR [rsp+0x20]
  8f8ce0:	mov    r10,QWORD PTR [r10]
  8f8ce3:	vpminsd xmm0,xmm0,xmm1
  8f8ce8:	vpshuflw xmm0,xmm0,0xe8
  8f8ced:	vmovd  DWORD PTR [r10+rcx*4],xmm0
  8f8cf3:	test   r11,r11
  8f8cf6:	mov    r14,QWORD PTR [rsp+0x58]
  8f8cfb:	je     8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8d01:	mov    rcx,QWORD PTR [rsp+0x20]
  8f8d06:	imul   rdi,QWORD PTR [rcx+0x20]
  8f8d0b:	add    rdi,r13
  8f8d0e:	cmp    rdi,QWORD PTR [rcx+0x8]
  8f8d12:	jae    8f8d7d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x20bd>
  8f8d14:	vmovd  xmm0,DWORD PTR [r9+0x14]
  8f8d1a:	vpbroadcastd xmm0,xmm0
  8f8d1f:	vmovd  xmm1,r15d
  8f8d24:	vpinsrd xmm1,xmm1,DWORD PTR [rsp+0x1a0],0x1
  8f8d2f:	vpmulld xmm0,xmm0,xmm1
  8f8d34:	mov    rcx,QWORD PTR [rsp+0x20]
  8f8d39:	mov    rcx,QWORD PTR [rcx]
  8f8d3c:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff720293]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8f8d45:	vpsrad xmm2,xmm0,0x1f
  8f8d4a:	vpaddd xmm0,xmm0,xmm1
  8f8d4e:	vpaddd xmm0,xmm0,xmm2
  8f8d52:	vpsrad xmm0,xmm0,0xe
  8f8d57:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff720030]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8f8d60:	vpbroadcastd xmm2,DWORD PTR [rip+0xffffffffff71ffdf]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8f8d69:	vpmaxsd xmm0,xmm0,xmm1
  8f8d6e:	vpminsd xmm0,xmm0,xmm2
  8f8d73:	vpshuflw xmm0,xmm0,0xe8
  8f8d78:	vmovd  DWORD PTR [rcx+rdi*4],xmm0
  8f8d7d:	test   bl,bl
  8f8d7f:	je     8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8d85:	cmp    r8d,0xffff
  8f8d8c:	ja     8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8d92:	mov    rcx,QWORD PTR [rsp+0x20]
  8f8d97:	mov    rdi,QWORD PTR [rsp+0x240]
  8f8d9f:	cmp    rdi,QWORD PTR [rcx+0x18]
  8f8da3:	jae    8f81b0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14f0>
  8f8da9:	mov    rdi,QWORD PTR [rsp+0x20]
  8f8dae:	movzx  ecx,BYTE PTR [rdi+0x6c]
  8f8db2:	mov    r8,QWORD PTR [rdi+0x10]
  8f8db6:	mov    r9,QWORD PTR [rsp+0x240]
  8f8dbe:	shl    r9,0x4
  8f8dc2:	lea    rdi,[r8+r9*1]
  8f8dc6:	cmp    BYTE PTR [r8+r9*1+0xd],cl
  8f8dcb:	je     8f8191 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14d1>
  8f8dd1:	mov    BYTE PTR [rdi+0xd],cl
  8f8dd4:	xor    r8d,r8d
  8f8dd7:	jmp    8f8196 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x14d6>
  8f8ddc:	movzx  r8d,BYTE PTR [rsi+0xc]
  8f8de1:	mov    dil,0x1
  8f8de4:	mov    ecx,edx
  8f8de6:	shl    dil,cl
  8f8de9:	shr    r11,0x10
  8f8ded:	mov    DWORD PTR [rsi+rdx*4],r11d
  8f8df1:	or     dil,r8b
  8f8df4:	mov    BYTE PTR [rsi+0xc],dil
  8f8df8:	nop    DWORD PTR [rax+rax*1+0x0]
  8f8e00:	blsr   rax,rax
  8f8e05:	mov    r14,QWORD PTR [rsp+0x58]
  8f8e0a:	je     8f71f0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x530>
  8f8e10:	tzcnt  rcx,rax
  8f8e15:	mov    rdx,QWORD PTR [rsp+0x98]
  8f8e1d:	movzx  r10d,BYTE PTR [rdx+rcx*1]
  8f8e22:	cmp    r10d,0x9
  8f8e26:	jae    8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f8e28:	shl    r10d,0x5
  8f8e2c:	add    r10,QWORD PTR [rsp+0x80]
  8f8e34:	mov    rdx,QWORD PTR [rsp+0x18]
  8f8e39:	movzx  edx,BYTE PTR [rdx+rcx*1+0xc40]
  8f8e41:	mov    esi,edx
  8f8e43:	not    sil
  8f8e46:	test   sil,0xa
  8f8e4a:	sete   r9b
  8f8e4e:	and    r9b,BYTE PTR [r10]
  8f8e51:	cmp    r9b,0x1
  8f8e55:	jne    8f8e75 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x21b5>
  8f8e57:	mov    rsi,QWORD PTR [rsp+0x20]
  8f8e5c:	mov    rsi,QWORD PTR [rsi+0x28]
  8f8e60:	imul   rsi,QWORD PTR [r10+0x8]
  8f8e65:	mov    rdi,QWORD PTR [rsp+0x50]
  8f8e6a:	mov    r8d,DWORD PTR [rdi+rcx*4+0x800]
  8f8e72:	add    r8,rsi
  8f8e75:	test   dl,0x4
  8f8e78:	je     8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f8e7a:	mov    rsi,QWORD PTR [rsp+0x50]
  8f8e7f:	mov    esi,DWORD PTR [rsi+rcx*4+0x600]
  8f8e86:	mov    rdi,QWORD PTR [rsp+0x78]
  8f8e8b:	cmp    QWORD PTR [rdi+0x8],rsi
  8f8e8f:	jbe    8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f8e95:	mov    rdi,QWORD PTR [rsp+0x18]
  8f8e9a:	mov    ebx,DWORD PTR [rdi+rcx*4+0x300]
  8f8ea1:	mov    r14d,DWORD PTR [rdi+rcx*4+0x400]
  8f8ea9:	mov    rdi,QWORD PTR [rsp+0x78]
  8f8eae:	mov    r11,QWORD PTR [rdi]
  8f8eb1:	cmp    BYTE PTR [r11+rsi*8+0x6],0x0
  8f8eb7:	je     8f8ed8 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2218>
  8f8eb9:	cmp    BYTE PTR [r10+0x1b],0x1
  8f8ebe:	jne    8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f8ec4:	movsx  edi,WORD PTR [r11+rsi*8]
  8f8ec9:	mov    r15d,DWORD PTR [r10+0x10]
  8f8ecd:	cmp    r15d,edi
  8f8ed0:	je     8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f8ed6:	jmp    8f8edc <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x221c>
  8f8ed8:	mov    r15d,DWORD PTR [r10+0x10]
  8f8edc:	mov    edi,ebx
  8f8ede:	neg    edi
  8f8ee0:	mov    r12d,r14d
  8f8ee3:	neg    r12d
  8f8ee6:	cmp    BYTE PTR [r10+0x1a],0x0
  8f8eeb:	cmove  edi,ebx
  8f8eee:	cmove  r12d,r14d
  8f8ef2:	shl    r12d,0x10
  8f8ef6:	movzx  edi,di
  8f8ef9:	or     edi,r12d
  8f8efc:	mov    WORD PTR [r11+rsi*8],r15w
  8f8f01:	mov    DWORD PTR [r11+rsi*8+0x2],edi
  8f8f06:	mov    BYTE PTR [r11+rsi*8+0x6],0x1
  8f8f0c:	test   dl,0x10
  8f8f0f:	je     8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f8f15:	mov    rdx,QWORD PTR [rsp+0x50]
  8f8f1a:	mov    r15d,DWORD PTR [rdx+rcx*4+0x700]
  8f8f22:	mov    rdx,QWORD PTR [rsp+0x20]
  8f8f27:	cmp    QWORD PTR [rdx+0x28],r15
  8f8f2b:	jbe    8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f8f31:	mov    rdx,QWORD PTR [rsp+0x50]
  8f8f36:	mov    esi,DWORD PTR [rdx+rcx*4+0x200]
  8f8f3d:	mov    DWORD PTR [rsp+0xc0],esi
  8f8f44:	mov    esi,DWORD PTR [rdx+rcx*4+0x300]
  8f8f4b:	mov    DWORD PTR [rsp+0x180],esi
  8f8f52:	mov    rsi,QWORD PTR [r10]
  8f8f55:	mov    QWORD PTR [rsp+0x1a0],rsi
  8f8f5d:	mov    rsi,QWORD PTR [r10+0x8]
  8f8f61:	mov    QWORD PTR [rsp+0x120],rsi
  8f8f69:	movsxd rsi,DWORD PTR [rdx+rcx*4+0x500]
  8f8f71:	mov    r11d,DWORD PTR [rdx+rcx*4+0x400]
  8f8f79:	mov    r12,QWORD PTR [rsp+0x20]
  8f8f7e:	movzx  edx,BYTE PTR [r12+0x68]
  8f8f84:	shrx   rdx,rsi,rdx
  8f8f89:	movabs rdi,0xaaaaaaaaaaaaaaab
  8f8f93:	mulx   rdi,rdi,rdi
  8f8f98:	shr    rdi,1
  8f8f9b:	lea    rdi,[rdi+rdi*2]
  8f8f9f:	sub    rdx,rdi
  8f8fa2:	mov    edi,r11d
  8f8fa5:	or     edi,esi
  8f8fa7:	shl    rsi,0x20
  8f8fab:	shl    r11,0x10
  8f8faf:	add    r11,rsi
  8f8fb2:	cmp    edi,0xffff
  8f8fb8:	ja     8f9045 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2385>
  8f8fbe:	imul   rcx,QWORD PTR [rsp+0x58]
  8f8fc4:	add    rcx,QWORD PTR [rsp+0x60]
  8f8fc9:	cmp    rcx,QWORD PTR [r12+0x18]
  8f8fce:	jae    8f9045 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2385>
  8f8fd0:	mov    QWORD PTR [rsp+0x160],r13
  8f8fd8:	movzx  esi,BYTE PTR [r12+0x6c]
  8f8fde:	mov    r13,QWORD PTR [r12+0x10]
  8f8fe3:	shl    rcx,0x4
  8f8fe7:	lea    r12,[rcx+r13*1]
  8f8feb:	cmp    BYTE PTR [r13+rcx*1+0xd],sil
  8f8ff0:	jne    8f9004 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2344>
  8f8ff2:	mov    rsi,r12
  8f8ff5:	movzx  ecx,BYTE PTR [r12+0xc]
  8f8ffb:	mov    DWORD PTR [rsp+0xa0],ecx
  8f9002:	jmp    8f9019 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2359>
  8f9004:	mov    ecx,esi
  8f9006:	mov    rsi,r12
  8f9009:	mov    BYTE PTR [r12+0xd],cl
  8f900e:	mov    DWORD PTR [rsp+0xa0],0x0
  8f9019:	mov    r12,r11
  8f901c:	mov    r13b,0x1
  8f901f:	mov    ecx,edx
  8f9021:	shl    r13b,cl
  8f9024:	shr    r12,0x10
  8f9028:	mov    DWORD PTR [rsi+rdx*4],r12d
  8f902c:	or     r13b,BYTE PTR [rsp+0xa0]
  8f9034:	mov    BYTE PTR [rsi+0xc],r13b
  8f9038:	mov    r12,QWORD PTR [rsp+0x20]
  8f903d:	mov    r13,QWORD PTR [rsp+0x160]
  8f9045:	mov    rcx,QWORD PTR [r12+0x20]
  8f904a:	imul   rcx,r15
  8f904e:	add    rcx,r13
  8f9051:	cmp    rcx,QWORD PTR [r12+0x8]
  8f9056:	jae    8f90a2 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x23e2>
  8f9058:	vmovd  xmm0,DWORD PTR [rsp+0xc0]
  8f9061:	vpinsrd xmm0,xmm0,DWORD PTR [rsp+0x180],0x1
  8f906c:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71fd1b]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8f9075:	vpxor  xmm2,xmm2,xmm2
  8f9079:	vpsubd xmm0,xmm2,xmm0
  8f907d:	vpmaxsd xmm0,xmm0,xmm1
  8f9082:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71fcbd]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8f908b:	mov    rsi,QWORD PTR [rsp+0x20]
  8f9090:	mov    rsi,QWORD PTR [rsi]
  8f9093:	vpminsd xmm0,xmm0,xmm1
  8f9098:	vpshuflw xmm0,xmm0,0xe8
  8f909d:	vmovd  DWORD PTR [rsi+rcx*4],xmm0
  8f90a2:	cmp    QWORD PTR [rsp+0x1a0],0x0
  8f90ab:	je     8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f90b1:	mov    rcx,QWORD PTR [rsp+0x20]
  8f90b6:	imul   r15,QWORD PTR [rcx+0x20]
  8f90bb:	add    r15,QWORD PTR [rsp+0x120]
  8f90c3:	cmp    r15,QWORD PTR [rcx+0x8]
  8f90c7:	jae    8f912d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x246d>
  8f90c9:	vmovd  xmm0,DWORD PTR [r10+0x14]
  8f90cf:	vpbroadcastd xmm0,xmm0
  8f90d4:	vmovd  xmm1,ebx
  8f90d8:	vpinsrd xmm1,xmm1,r14d,0x1
  8f90de:	vpmulld xmm0,xmm0,xmm1
  8f90e3:	mov    rcx,QWORD PTR [rsp+0x20]
  8f90e8:	mov    rcx,QWORD PTR [rcx]
  8f90eb:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71fee4]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8f90f4:	vpsrad xmm2,xmm0,0x1f
  8f90f9:	vpaddd xmm0,xmm0,xmm1
  8f90fd:	vpaddd xmm0,xmm0,xmm2
  8f9101:	vpsrad xmm0,xmm0,0xe
  8f9106:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffff71fc81]        # 18d90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1341>
  8f910f:	vpbroadcastd xmm2,DWORD PTR [rip+0xffffffffff71fc30]        # 18d48 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12f9>
  8f9118:	vpmaxsd xmm0,xmm0,xmm1
  8f911d:	vpminsd xmm0,xmm0,xmm2
  8f9122:	vpshuflw xmm0,xmm0,0xe8
  8f9127:	vmovd  DWORD PTR [rcx+r15*4],xmm0
  8f912d:	test   r9b,r9b
  8f9130:	je     8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f9136:	cmp    edi,0xffff
  8f913c:	ja     8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f9142:	mov    rcx,QWORD PTR [rsp+0x20]
  8f9147:	cmp    r8,QWORD PTR [rcx+0x18]
  8f914b:	jae    8f8e00 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2140>
  8f9151:	mov    rsi,QWORD PTR [rsp+0x20]
  8f9156:	movzx  ecx,BYTE PTR [rsi+0x6c]
  8f915a:	mov    rdi,QWORD PTR [rsi+0x10]
  8f915e:	shl    r8,0x4
  8f9162:	lea    rsi,[rdi+r8*1]
  8f9166:	cmp    BYTE PTR [rdi+r8*1+0xd],cl
  8f916b:	je     8f8ddc <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x211c>
  8f9171:	mov    BYTE PTR [rsi+0xd],cl
  8f9174:	xor    r8d,r8d
  8f9177:	jmp    8f8de1 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2121>
  8f917c:	lea    r15,[rdx+0x900]
  8f9183:	vpaddd ymm0,ymm7,ymm4
  8f9187:	vmovdqa YMMWORD PTR [rsp+0x1a0],ymm0
  8f9190:	vpaddd ymm0,ymm13,ymm4
  8f9194:	vmovdqa YMMWORD PTR [rsp+0x120],ymm0
  8f919d:	vmovaps xmm0,XMMWORD PTR [rsp+0x380]
  8f91a6:	vmovaps XMMWORD PTR [rsp+0xc0],xmm0
  8f91af:	vmovaps xmm0,XMMWORD PTR [rsp+0x390]
  8f91b8:	vmovaps XMMWORD PTR [rsp+0x180],xmm0
  8f91c1:	vmovaps xmm0,XMMWORD PTR [rsp+0x3a0]
  8f91ca:	vmovaps XMMWORD PTR [rsp+0x60],xmm0
  8f91d0:	vbroadcastss ymm0,DWORD PTR [rsp+0x3b0]
  8f91da:	vmovaps YMMWORD PTR [rsp+0x20],ymm0
  8f91e0:	vmovd  xmm0,DWORD PTR [rsp+0x74]
  8f91e6:	vpbroadcastd ymm0,xmm0
  8f91eb:	vmovdqa YMMWORD PTR [rsp+0x160],ymm0
  8f91f4:	jmp    8f9213 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2553>
  8f91f6:	cs nop WORD PTR [rax+rax*1+0x0]
  8f9200:	add    QWORD PTR [rsp+0x48],r14
  8f9205:	dec    QWORD PTR [rsp+0xe8]
  8f920d:	je     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9213:	mov    rdi,QWORD PTR [rsp+0x108]
  8f921b:	mov    rsi,QWORD PTR [rsp+0x48]
  8f9220:	vzeroupper
  8f9223:	call   QWORD PTR [rip+0x6ee18f]        # fe73b8 <_DYNAMIC+0x2b60>
  8f9229:	test   rax,rax
  8f922c:	je     8f9200 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2540>
  8f922e:	mov    r9,rdx
  8f9231:	test   rdx,rdx
  8f9234:	je     8f9200 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2540>
  8f9236:	mov    rsi,rax
  8f9239:	mov    rax,QWORD PTR [rsp+0x48]
  8f923e:	cmp    rax,0x7fffffff
  8f9244:	ja     8fa235 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3575>
  8f924a:	vmovd  xmm0,eax
  8f924e:	vpbroadcastd ymm0,xmm0
  8f9253:	vmovdqa YMMWORD PTR [rsp+0xa0],ymm0
  8f925c:	vpand  xmm0,xmm0,XMMWORD PTR [rsp+0x350]
  8f9265:	vpbroadcastd ymm0,xmm0
  8f926a:	vmovdqa YMMWORD PTR [rsp+0x260],ymm0
  8f9273:	xor    r13d,r13d
  8f9276:	cmp    r9,rbx
  8f9279:	mov    rcx,rbx
  8f927c:	cmovb  rcx,r9
  8f9280:	lea    r8,[rcx+rcx*2]
  8f9284:	mov    rax,rcx
  8f9287:	or     rax,r14
  8f928a:	shr    rax,0x20
  8f928e:	je     8f929d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25dd>
  8f9290:	mov    rax,rcx
  8f9293:	xor    edx,edx
  8f9295:	div    r14
  8f9298:	mov    r12,rax
  8f929b:	jmp    8f92a7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25e7>
  8f929d:	mov    eax,ecx
  8f929f:	xor    edx,edx
  8f92a1:	div    r14d
  8f92a4:	mov    r12d,eax
  8f92a7:	mov    rdi,QWORD PTR [rsp+0x18]
  8f92ac:	sub    r9,rcx
  8f92af:	mov    QWORD PTR [rsp+0x240],r9
  8f92b7:	lea    rax,[r13+0x1]
  8f92bb:	mov    QWORD PTR [rsp+0x140],rax
  8f92c3:	shl    r13,0x6
  8f92c7:	cmp    rdx,0x1
  8f92cb:	sbb    r12,0xffffffffffffffff
  8f92cf:	cmp    r12,0x40
  8f92d3:	mov    eax,0x40
  8f92d8:	cmovae r12,rax
  8f92dc:	lea    rax,[rsi+r8*2]
  8f92e0:	mov    QWORD PTR [rsp+0x220],rax
  8f92e8:	add    rcx,rcx
  8f92eb:	lea    rax,[rcx+rcx*2]
  8f92ef:	mov    rcx,QWORD PTR [rsp+0xf8]
  8f92f7:	add    rsi,rcx
  8f92fa:	sub    rax,rcx
  8f92fd:	mov    ecx,0x0
  8f9302:	cmovb  rax,rcx
  8f9306:	mov    rdx,r12
  8f9309:	imul   rdx,QWORD PTR [rsp+0xf0]
  8f9312:	cmp    rax,rdx
  8f9315:	cmovb  rdx,rax
  8f9319:	cmp    rdx,0x300
  8f9320:	mov    eax,0x300
  8f9325:	cmovae rdx,rax
  8f9329:	vzeroupper
  8f932c:	call   QWORD PTR [rip+0x6eb76e]        # fe4aa0 <memcpy@GLIBC_2.14>
  8f9332:	lea    ecx,[r12+0xf]
  8f9337:	shr    ecx,0x4
  8f933a:	xor    eax,eax
  8f933c:	xor    r8d,r8d
  8f933f:	vmovdqa ymm14,YMMWORD PTR [rsp+0x3e0]
  8f9348:	vmovdqa ymm15,YMMWORD PTR [rsp+0x3c0]
  8f9351:	vmovdqa xmm9,XMMWORD PTR [rsp+0x2a0]
  8f935a:	jmp    8f9746 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2a86>
  8f935f:	nop
  8f9360:	mov    r9,rsi
  8f9363:	mov    rsi,r8
  8f9366:	vpunpckhqdq xmm7,xmm7,xmm8
  8f936b:	vpunpckhdq xmm5,xmm5,xmm6
  8f936f:	vpunpckhdq xmm3,xmm3,xmm4
  8f9373:	vpunpcklqdq xmm4,xmm3,xmm5
  8f9377:	vmovd  xmm3,edi
  8f937b:	vpbroadcastd ymm3,xmm3
  8f9380:	mov    rdi,rsi
  8f9383:	shl    rdi,0x4
  8f9387:	mov    r8,QWORD PTR [rsp+0x98]
  8f938f:	vmovdqu XMMWORD PTR [r8+rdi*1],xmm1
  8f9395:	vmovdqa xmm1,XMMWORD PTR [rsp+0xc0]
  8f939e:	vpshufb xmm1,xmm1,xmm2
  8f93a3:	vmovdqa xmm5,XMMWORD PTR [rsp+0x180]
  8f93ac:	vpshufb xmm2,xmm5,xmm2
  8f93b1:	vpunpcklbw xmm6,xmm1,xmm2
  8f93b5:	vpunpckhbw xmm8,xmm1,xmm2
  8f93b9:	vpmovsxbw ymm1,xmm7
  8f93be:	vpmovsxwd ymm2,xmm1
  8f93c3:	vextracti128 xmm1,ymm1,0x1
  8f93c9:	vpmovsxwd ymm1,xmm1
  8f93ce:	vpabsd ymm5,ymm2
  8f93d3:	vpabsd ymm7,ymm1
  8f93d8:	vpsrld ymm9,ymm5,0x4
  8f93dd:	vpbroadcastd ymm10,DWORD PTR [rip+0xffffffffff71fbba]        # 18fa0 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  8f93e6:	vpsrld ymm11,ymm7,0x4
  8f93eb:	vpmaxud ymm9,ymm9,ymm10
  8f93f0:	vpcmpeqd ymm13,ymm13,ymm13
  8f93f5:	vpaddd ymm9,ymm9,ymm13
  8f93fa:	vpmaxud ymm11,ymm11,ymm10
  8f93ff:	vpaddd ymm11,ymm11,ymm13
  8f9404:	vpslld ymm12,ymm9,0x4
  8f940a:	vpsubd ymm5,ymm5,ymm12
  8f940f:	vpslld ymm12,ymm11,0x4
  8f9415:	vpsubd ymm7,ymm7,ymm12
  8f941a:	vpsllvd ymm5,ymm5,ymm9
  8f941f:	vpsllvd ymm7,ymm7,ymm11
  8f9424:	vpsrad ymm2,ymm2,0x1f
  8f9429:	vpsrad ymm1,ymm1,0x1f
  8f942e:	vpxor  ymm5,ymm5,ymm2
  8f9432:	vpxor  ymm7,ymm7,ymm1
  8f9436:	vpsubd ymm5,ymm5,ymm2
  8f943a:	vpsubd ymm2,ymm7,ymm1
  8f943e:	vpmovsxbw ymm1,xmm4
  8f9443:	vpmovsxwd ymm4,xmm1
  8f9448:	vextracti128 xmm1,ymm1,0x1
  8f944e:	vpmovsxwd ymm7,xmm1
  8f9453:	vpabsd ymm1,ymm4
  8f9458:	vpabsd ymm9,ymm7
  8f945d:	vpsrld ymm11,ymm1,0x4
  8f9462:	vpsrld ymm12,ymm9,0x4
  8f9468:	vpmaxud ymm11,ymm11,ymm10
  8f946d:	vpaddd ymm11,ymm11,ymm13
  8f9472:	vpmaxud ymm10,ymm12,ymm10
  8f9477:	vpaddd ymm10,ymm10,ymm13
  8f947c:	vpslld ymm12,ymm11,0x4
  8f9482:	vpsubd ymm12,ymm1,ymm12
  8f9487:	vpslld ymm1,ymm10,0x4
  8f948d:	vpsubd ymm9,ymm9,ymm1
  8f9491:	vpaddd ymm1,ymm15,ymm3
  8f9495:	vpmovsxwd ymm6,xmm6
  8f949a:	vpmovsxwd ymm8,xmm8
  8f949f:	vmovdqa ymm13,YMMWORD PTR [rsp+0x20]
  8f94a5:	vpmulld ymm6,ymm13,ymm6
  8f94aa:	vpmulld ymm13,ymm13,ymm8
  8f94af:	vpsllvd ymm8,ymm12,ymm11
  8f94b4:	vpsllvd ymm9,ymm9,ymm10
  8f94b9:	vpsrad ymm4,ymm4,0x1f
  8f94be:	vpsrad ymm7,ymm7,0x1f
  8f94c3:	vpxor  ymm8,ymm8,ymm4
  8f94c7:	vpxor  ymm9,ymm9,ymm7
  8f94cb:	vpsubd ymm10,ymm8,ymm4
  8f94cf:	vpsubd ymm8,ymm9,ymm7
  8f94d3:	vpmulld ymm4,ymm6,ymm5
  8f94d8:	vpmulld ymm7,ymm13,ymm2
  8f94dd:	vpsrad ymm9,ymm4,0x1f
  8f94e2:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff71faed]        # 18fd8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  8f94eb:	vpaddd ymm4,ymm11,ymm4
  8f94ef:	vpaddd ymm4,ymm9,ymm4
  8f94f3:	vpsrad ymm9,ymm7,0x1f
  8f94f8:	vpaddd ymm7,ymm11,ymm7
  8f94fc:	vpaddd ymm12,ymm9,ymm7
  8f9500:	vpmulld ymm6,ymm6,ymm10
  8f9505:	vpsrad ymm7,ymm6,0x1f
  8f950a:	vpaddd ymm6,ymm11,ymm6
  8f950e:	vpaddd ymm6,ymm6,ymm7
  8f9512:	vpaddd ymm7,ymm14,ymm3
  8f9516:	vpmulld ymm9,ymm13,ymm8
  8f951b:	vpaddd ymm11,ymm9,ymm11
  8f9520:	vpsrad ymm9,ymm9,0x1f
  8f9526:	vpaddd ymm11,ymm11,ymm9
  8f952b:	vpsrad ymm13,ymm4,0xe
  8f9530:	shl    rsi,0x6
  8f9534:	mov    rdi,QWORD PTR [rsp+0x50]
  8f9539:	vmovdqu YMMWORD PTR [rdi+rsi*1],ymm5
  8f953e:	vpsrad ymm5,ymm12,0xe
  8f9544:	vmovdqu YMMWORD PTR [rdi+rsi*1+0x20],ymm2
  8f954a:	vpsrad ymm9,ymm6,0xe
  8f954f:	vmovdqu YMMWORD PTR [rdi+rsi*1+0x100],ymm10
  8f9558:	vpsrad ymm10,ymm11,0xe
  8f955e:	vmovdqu YMMWORD PTR [rdi+rsi*1+0x120],ymm8
  8f9567:	vpsrad ymm2,ymm12,0x1f
  8f956d:	vpsrld ymm2,ymm2,0x1a
  8f9572:	vpaddd ymm2,ymm2,ymm5
  8f9576:	vpsrad ymm2,ymm2,0x6
  8f957b:	vmovdqa ymm12,YMMWORD PTR [rsp+0xa0]
  8f9584:	vpaddd ymm2,ymm12,ymm2
  8f9588:	vpbroadcastd ymm8,DWORD PTR [rsp+0x370]
  8f9592:	vpand  ymm5,ymm8,ymm2
  8f9596:	vpsrad ymm4,ymm4,0x1f
  8f959b:	vpsrld ymm4,ymm4,0x1a
  8f95a0:	vpaddd ymm4,ymm13,ymm4
  8f95a4:	vpsrad ymm4,ymm4,0x6
  8f95a9:	vpaddd ymm4,ymm12,ymm4
  8f95ad:	vpand  ymm12,ymm8,ymm4
  8f95b1:	vpsrad ymm11,ymm11,0x1f
  8f95b7:	vpsrld ymm11,ymm11,0x1a
  8f95bd:	vpaddd ymm10,ymm11,ymm10
  8f95c2:	vmovdqa ymm13,YMMWORD PTR [rsp+0x160]
  8f95cb:	vpminud ymm11,ymm13,ymm2
  8f95d0:	vpcmpeqd ymm11,ymm13,ymm11
  8f95d5:	vpsrad ymm10,ymm10,0x6
  8f95db:	vpaddd ymm7,ymm10,ymm7
  8f95df:	vpminud ymm10,ymm13,ymm4
  8f95e4:	vpcmpeqd ymm10,ymm13,ymm10
  8f95e9:	vpsrad ymm6,ymm6,0x1f
  8f95ee:	vpsrld ymm6,ymm6,0x1a
  8f95f3:	vpaddd ymm6,ymm9,ymm6
  8f95f7:	vpand  ymm9,ymm8,ymm7
  8f95fb:	vpsrad ymm6,ymm6,0x6
  8f9600:	vpaddd ymm6,ymm1,ymm6
  8f9604:	vpand  ymm8,ymm8,ymm6
  8f9608:	vmovdqa ymm13,YMMWORD PTR [rsp+0x420]
  8f9611:	vpminud ymm1,ymm13,ymm7
  8f9616:	vpcmpeqd ymm1,ymm13,ymm1
  8f961a:	vpor   ymm1,ymm11,ymm1
  8f961e:	vpminud ymm11,ymm13,ymm6
  8f9623:	vpcmpeqd ymm11,ymm13,ymm11
  8f9628:	vpor   ymm10,ymm10,ymm11
  8f962d:	vmovdqa ymm13,YMMWORD PTR [rsp+0x500]
  8f9636:	vpsubd ymm11,ymm12,ymm13
  8f963b:	vpsubd ymm5,ymm5,ymm13
  8f9640:	vmovdqa ymm13,YMMWORD PTR [rsp+0x4e0]
  8f9649:	vpmulld ymm12,ymm11,ymm13
  8f964e:	vpaddd ymm8,ymm12,ymm8
  8f9653:	vpmulld ymm12,ymm5,ymm13
  8f9658:	vpaddd ymm9,ymm12,ymm9
  8f965d:	vpsrad ymm11,ymm11,0x1f
  8f9663:	vpor   ymm8,ymm8,ymm11
  8f9668:	vpsrad ymm5,ymm5,0x1f
  8f966d:	vpor   ymm5,ymm9,ymm5
  8f9671:	vmovdqu YMMWORD PTR [r15+rsi*1],ymm8
  8f9677:	vmovdqa ymm8,YMMWORD PTR [rsp+0x520]
  8f9680:	vpand  ymm6,ymm8,ymm6
  8f9684:	vmovdqu YMMWORD PTR [r15+rsi*1+0x20],ymm5
  8f968b:	vpaddd ymm5,ymm3,YMMWORD PTR [rsp+0x1a0]
  8f9694:	vpsubd ymm5,ymm5,ymm6
  8f9698:	vpand  ymm6,ymm8,ymm7
  8f969c:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x120]
  8f96a5:	vpsubd ymm3,ymm3,ymm6
  8f96a9:	vpand  ymm4,ymm8,ymm4
  8f96ad:	vmovdqa ymm7,YMMWORD PTR [rsp+0x260]
  8f96b6:	vpcmpeqd ymm4,ymm4,ymm7
  8f96ba:	vmovdqa ymm6,YMMWORD PTR [rsp+0x4c0]
  8f96c3:	vpminud ymm5,ymm6,ymm5
  8f96c8:	vpcmpeqd ymm5,ymm6,ymm5
  8f96cc:	vpandn ymm4,ymm5,ymm4
  8f96d0:	vpandn ymm4,ymm10,ymm4
  8f96d4:	vpand  ymm2,ymm8,ymm2
  8f96d8:	vpcmpeqd ymm2,ymm2,ymm7
  8f96dc:	vpminud ymm3,ymm6,ymm3
  8f96e1:	vpcmpeqd ymm3,ymm6,ymm3
  8f96e5:	vpandn ymm2,ymm3,ymm2
  8f96e9:	vpbroadcastd ymm3,DWORD PTR [rip+0xffffffffff71f58e]        # 18c80 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  8f96f2:	vpandn ymm1,ymm1,ymm2
  8f96f6:	vpand  ymm2,ymm4,ymm3
  8f96fa:	vpand  ymm1,ymm1,ymm3
  8f96fe:	vextracti128 xmm3,ymm1,0x1
  8f9704:	vpackusdw xmm1,xmm1,xmm3
  8f9709:	vextracti128 xmm3,ymm2,0x1
  8f970f:	vpackusdw xmm2,xmm2,xmm3
  8f9714:	vpackuswb xmm1,xmm2,xmm1
  8f9718:	vmovdqa xmm9,XMMWORD PTR [rsp+0x2a0]
  8f9721:	vpand  xmm0,xmm9,xmm0
  8f9725:	vpand  xmm0,xmm0,xmm1
  8f9729:	vpxor  xmm1,xmm1,xmm1
  8f972d:	vpcmpeqb xmm0,xmm0,xmm1
  8f9731:	vpmovmskb esi,xmm0
  8f9735:	xor    esi,0xffff
  8f973b:	shlx   rdx,rsi,rdx
  8f9740:	or     rax,rdx
  8f9743:	mov    r8,r9
  8f9746:	cmp    r14,0x1
  8f974a:	jne    8f9830 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2b70>
  8f9750:	cmp    r8,rcx
  8f9753:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9759:	mov    rdx,r8
  8f975c:	shl    rdx,0x4
  8f9760:	lea    rdi,[rdx+r13*1]
  8f9764:	cmp    rdi,0x7fffffff
  8f976b:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9771:	lea    rsi,[r8+r8*2]
  8f9775:	shl    rsi,0x5
  8f9779:	mov    r9,QWORD PTR [rsp+0x18]
  8f977e:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8f9784:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x6]
  8f978b:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8f9792:	vmovdqu xmm6,XMMWORD PTR [r9+rsi*1+0x36]
  8f9799:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8f97a1:	vpblendd xmm3,xmm0,XMMWORD PTR [r9+rsi*1+0x20],0x2
  8f97a9:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8f97b1:	vpblendd xmm4,xmm0,XMMWORD PTR [r9+rsi*1+0x50],0x2
  8f97b9:	vpblendd xmm0,xmm1,XMMWORD PTR [r9+rsi*1+0x16],0x4
  8f97c1:	vpblendd xmm5,xmm0,XMMWORD PTR [r9+rsi*1+0x26],0x2
  8f97c9:	vpblendd xmm0,xmm6,XMMWORD PTR [r9+rsi*1+0x46],0x4
  8f97d1:	vpblendd xmm6,xmm0,XMMWORD PTR [r9+rsi*1+0x56],0x2
  8f97d9:	lea    rsi,[r8+0x1]
  8f97dd:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71cf9b]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8f97e5:	vpshufb xmm0,xmm5,xmm2
  8f97ea:	vpshufb xmm1,xmm3,xmm2
  8f97ef:	vpunpcklbw xmm7,xmm1,xmm0
  8f97f3:	vpshufb xmm0,xmm6,xmm2
  8f97f8:	vpshufb xmm1,xmm4,xmm2
  8f97fd:	vpunpcklbw xmm8,xmm1,xmm0
  8f9801:	vpunpcklqdq xmm1,xmm7,xmm8
  8f9806:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a7e2]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f980e:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f9814:	vpshufb xmm0,xmm0,xmm2
  8f9819:	vptest xmm0,xmm9
  8f981e:	je     8f9a50 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2d90>
  8f9824:	mov    r9,rsi
  8f9827:	mov    rsi,r8
  8f982a:	jmp    8fa100 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3440>
  8f982f:	nop
  8f9830:	cmp    r8,rcx
  8f9833:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9839:	mov    rdx,r8
  8f983c:	shl    rdx,0x4
  8f9840:	lea    rdi,[rdx+r13*1]
  8f9844:	imul   rdi,r14
  8f9848:	cmp    rdi,0x7fffffff
  8f984f:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9855:	lea    rsi,[r8+0x1]
  8f9859:	lea    r9,[r8+r8*2]
  8f985d:	shl    r9,0x6
  8f9861:	mov    r10,QWORD PTR [rsp+0x18]
  8f9866:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8f986c:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x20]
  8f9873:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8f987a:	vmovdqu xmm4,XMMWORD PTR [r10+r9*1+0x50]
  8f9881:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8f9889:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71c8cf]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8f9891:	vpshufb xmm1,xmm1,xmm6
  8f9896:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71da32]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8f989e:	vpshufb xmm0,xmm0,xmm7
  8f98a3:	vpor   xmm3,xmm0,xmm1
  8f98a7:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8f98af:	vpshufb xmm1,xmm4,xmm6
  8f98b4:	vpshufb xmm0,xmm0,xmm7
  8f98b9:	vpor   xmm4,xmm0,xmm1
  8f98bd:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0x80]
  8f98c7:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x60]
  8f98ce:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0x70],0x4
  8f98d6:	vpshufb xmm0,xmm0,xmm6
  8f98db:	vpshufb xmm1,xmm1,xmm7
  8f98e0:	vpor   xmm5,xmm1,xmm0
  8f98e4:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0xb0]
  8f98ee:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x90]
  8f98f8:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0xa0],0x4
  8f9903:	vpshufb xmm0,xmm0,xmm6
  8f9908:	vpshufb xmm1,xmm1,xmm7
  8f990d:	vpor   xmm6,xmm1,xmm0
  8f9911:	vpunpckldq xmm7,xmm3,xmm4
  8f9915:	vpunpckldq xmm8,xmm5,xmm6
  8f9919:	vpunpcklqdq xmm1,xmm7,xmm8
  8f991e:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a6ca]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f9926:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f992c:	vpshufb xmm0,xmm0,xmm2
  8f9931:	vptest xmm0,xmm9
  8f9936:	jne    8f9360 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x26a0>
  8f993c:	cmp    rsi,rcx
  8f993f:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9945:	mov    rdx,rsi
  8f9948:	shl    rdx,0x4
  8f994c:	lea    rdi,[rdx+r13*1]
  8f9950:	imul   rdi,r14
  8f9954:	cmp    rdi,0x7fffffff
  8f995b:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9961:	lea    r10,[r8+0x2]
  8f9965:	lea    r9,[rsi+rsi*2]
  8f9969:	shl    r9,0x6
  8f996d:	mov    r11,QWORD PTR [rsp+0x18]
  8f9972:	vmovdqu xmm0,XMMWORD PTR [r11+r9*1]
  8f9978:	vmovdqu xmm1,XMMWORD PTR [r11+r9*1+0x20]
  8f997f:	vmovdqu xmm2,XMMWORD PTR [r11+r9*1+0x30]
  8f9986:	vmovdqu xmm4,XMMWORD PTR [r11+r9*1+0x50]
  8f998d:	vpblendd xmm0,xmm0,XMMWORD PTR [r11+r9*1+0x10],0x4
  8f9995:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71c7c3]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8f999d:	vpshufb xmm1,xmm1,xmm6
  8f99a2:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71d926]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8f99aa:	vpshufb xmm0,xmm0,xmm7
  8f99af:	vpor   xmm3,xmm0,xmm1
  8f99b3:	vpblendd xmm0,xmm2,XMMWORD PTR [r11+r9*1+0x40],0x4
  8f99bb:	vpshufb xmm1,xmm4,xmm6
  8f99c0:	vpshufb xmm0,xmm0,xmm7
  8f99c5:	vpor   xmm4,xmm0,xmm1
  8f99c9:	vmovdqu xmm0,XMMWORD PTR [r11+r9*1+0x80]
  8f99d3:	vmovdqu xmm1,XMMWORD PTR [r11+r9*1+0x60]
  8f99da:	vpblendd xmm1,xmm1,XMMWORD PTR [r11+r9*1+0x70],0x4
  8f99e2:	vpshufb xmm0,xmm0,xmm6
  8f99e7:	vpshufb xmm1,xmm1,xmm7
  8f99ec:	vpor   xmm5,xmm1,xmm0
  8f99f0:	vmovdqu xmm0,XMMWORD PTR [r11+r9*1+0xb0]
  8f99fa:	vmovdqu xmm1,XMMWORD PTR [r11+r9*1+0x90]
  8f9a04:	vpblendd xmm1,xmm1,XMMWORD PTR [r11+r9*1+0xa0],0x4
  8f9a0f:	vpshufb xmm0,xmm0,xmm6
  8f9a14:	vpshufb xmm1,xmm1,xmm7
  8f9a19:	vpor   xmm6,xmm1,xmm0
  8f9a1d:	vpunpckldq xmm7,xmm3,xmm4
  8f9a21:	vpunpckldq xmm8,xmm5,xmm6
  8f9a25:	vpunpcklqdq xmm1,xmm7,xmm8
  8f9a2a:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a5be]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f9a32:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f9a38:	vpshufb xmm0,xmm0,xmm2
  8f9a3d:	vptest xmm0,xmm9
  8f9a42:	je     8f9b2c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2e6c>
  8f9a48:	mov    r9,r10
  8f9a4b:	jmp    8f9366 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x26a6>
  8f9a50:	cmp    rsi,rcx
  8f9a53:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9a59:	mov    rdx,rsi
  8f9a5c:	shl    rdx,0x4
  8f9a60:	lea    rdi,[rdx+r13*1]
  8f9a64:	cmp    rdi,0x7fffffff
  8f9a6b:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9a71:	lea    r9,[rsi+rsi*2]
  8f9a75:	shl    r9,0x5
  8f9a79:	mov    r10,QWORD PTR [rsp+0x18]
  8f9a7e:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8f9a84:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x6]
  8f9a8b:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8f9a92:	vmovdqu xmm6,XMMWORD PTR [r10+r9*1+0x36]
  8f9a99:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8f9aa1:	vpblendd xmm3,xmm0,XMMWORD PTR [r10+r9*1+0x20],0x2
  8f9aa9:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8f9ab1:	vpblendd xmm4,xmm0,XMMWORD PTR [r10+r9*1+0x50],0x2
  8f9ab9:	vpblendd xmm0,xmm1,XMMWORD PTR [r10+r9*1+0x16],0x4
  8f9ac1:	vpblendd xmm5,xmm0,XMMWORD PTR [r10+r9*1+0x26],0x2
  8f9ac9:	vpblendd xmm0,xmm6,XMMWORD PTR [r10+r9*1+0x46],0x4
  8f9ad1:	vpblendd xmm6,xmm0,XMMWORD PTR [r10+r9*1+0x56],0x2
  8f9ad9:	lea    r10,[r8+0x2]
  8f9add:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71cc9b]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8f9ae5:	vpshufb xmm0,xmm5,xmm2
  8f9aea:	vpshufb xmm1,xmm3,xmm2
  8f9aef:	vpunpcklbw xmm7,xmm1,xmm0
  8f9af3:	vpshufb xmm0,xmm6,xmm2
  8f9af8:	vpshufb xmm1,xmm4,xmm2
  8f9afd:	vpunpcklbw xmm8,xmm1,xmm0
  8f9b01:	vpunpcklqdq xmm1,xmm7,xmm8
  8f9b06:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a4e2]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f9b0e:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f9b14:	vpshufb xmm0,xmm0,xmm2
  8f9b19:	vptest xmm0,xmm9
  8f9b1e:	je     8f9c43 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2f83>
  8f9b24:	mov    r9,r10
  8f9b27:	jmp    8fa100 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3440>
  8f9b2c:	cmp    r10,rcx
  8f9b2f:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9b35:	mov    rdx,r10
  8f9b38:	shl    rdx,0x4
  8f9b3c:	lea    rdi,[rdx+r13*1]
  8f9b40:	imul   rdi,r14
  8f9b44:	cmp    rdi,0x7fffffff
  8f9b4b:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9b51:	lea    r11,[r8+0x3]
  8f9b55:	lea    rsi,[r10+r10*2]
  8f9b59:	shl    rsi,0x6
  8f9b5d:	mov    r9,QWORD PTR [rsp+0x18]
  8f9b62:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8f9b68:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x20]
  8f9b6f:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8f9b76:	vmovdqu xmm4,XMMWORD PTR [r9+rsi*1+0x50]
  8f9b7d:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8f9b85:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71c5d3]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8f9b8d:	vpshufb xmm1,xmm1,xmm6
  8f9b92:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71d736]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8f9b9a:	vpshufb xmm0,xmm0,xmm7
  8f9b9f:	vpor   xmm3,xmm0,xmm1
  8f9ba3:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8f9bab:	vpshufb xmm1,xmm4,xmm6
  8f9bb0:	vpshufb xmm0,xmm0,xmm7
  8f9bb5:	vpor   xmm4,xmm0,xmm1
  8f9bb9:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1+0x80]
  8f9bc3:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x60]
  8f9bca:	vpblendd xmm1,xmm1,XMMWORD PTR [r9+rsi*1+0x70],0x4
  8f9bd2:	vpshufb xmm0,xmm0,xmm6
  8f9bd7:	vpshufb xmm1,xmm1,xmm7
  8f9bdc:	vpor   xmm5,xmm1,xmm0
  8f9be0:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1+0xb0]
  8f9bea:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x90]
  8f9bf4:	vpblendd xmm1,xmm1,XMMWORD PTR [r9+rsi*1+0xa0],0x4
  8f9bff:	vpshufb xmm0,xmm0,xmm6
  8f9c04:	vpshufb xmm1,xmm1,xmm7
  8f9c09:	vpor   xmm6,xmm1,xmm0
  8f9c0d:	vpunpckldq xmm7,xmm3,xmm4
  8f9c11:	vpunpckldq xmm8,xmm5,xmm6
  8f9c15:	vpunpcklqdq xmm1,xmm7,xmm8
  8f9c1a:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a3ce]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f9c22:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f9c28:	vpshufb xmm0,xmm0,xmm2
  8f9c2d:	vptest xmm0,xmm9
  8f9c32:	je     8f9d22 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3062>
  8f9c38:	mov    r9,r11
  8f9c3b:	mov    rsi,r10
  8f9c3e:	jmp    8f9366 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x26a6>
  8f9c43:	cmp    r10,rcx
  8f9c46:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9c4c:	mov    rdx,r10
  8f9c4f:	shl    rdx,0x4
  8f9c53:	lea    rdi,[rdx+r13*1]
  8f9c57:	cmp    rdi,0x7fffffff
  8f9c5e:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9c64:	lea    rsi,[r10+r10*2]
  8f9c68:	shl    rsi,0x5
  8f9c6c:	mov    r9,QWORD PTR [rsp+0x18]
  8f9c71:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8f9c77:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x6]
  8f9c7e:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8f9c85:	vmovdqu xmm6,XMMWORD PTR [r9+rsi*1+0x36]
  8f9c8c:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8f9c94:	vpblendd xmm3,xmm0,XMMWORD PTR [r9+rsi*1+0x20],0x2
  8f9c9c:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8f9ca4:	vpblendd xmm4,xmm0,XMMWORD PTR [r9+rsi*1+0x50],0x2
  8f9cac:	vpblendd xmm0,xmm1,XMMWORD PTR [r9+rsi*1+0x16],0x4
  8f9cb4:	vpblendd xmm5,xmm0,XMMWORD PTR [r9+rsi*1+0x26],0x2
  8f9cbc:	vpblendd xmm0,xmm6,XMMWORD PTR [r9+rsi*1+0x46],0x4
  8f9cc4:	vpblendd xmm6,xmm0,XMMWORD PTR [r9+rsi*1+0x56],0x2
  8f9ccc:	lea    r11,[r8+0x3]
  8f9cd0:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71caa8]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8f9cd8:	vpshufb xmm0,xmm5,xmm2
  8f9cdd:	vpshufb xmm1,xmm3,xmm2
  8f9ce2:	vpunpcklbw xmm7,xmm1,xmm0
  8f9ce6:	vpshufb xmm0,xmm6,xmm2
  8f9ceb:	vpshufb xmm1,xmm4,xmm2
  8f9cf0:	vpunpcklbw xmm8,xmm1,xmm0
  8f9cf4:	vpunpcklqdq xmm1,xmm7,xmm8
  8f9cf9:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a2ef]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f9d01:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f9d07:	vpshufb xmm0,xmm0,xmm2
  8f9d0c:	vptest xmm0,xmm9
  8f9d11:	je     8f9e39 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3179>
  8f9d17:	mov    r9,r11
  8f9d1a:	mov    rsi,r10
  8f9d1d:	jmp    8fa100 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3440>
  8f9d22:	cmp    r11,rcx
  8f9d25:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9d2b:	mov    rdx,r11
  8f9d2e:	shl    rdx,0x4
  8f9d32:	lea    rdi,[rdx+r13*1]
  8f9d36:	imul   rdi,r14
  8f9d3a:	cmp    rdi,0x7fffffff
  8f9d41:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9d47:	lea    rsi,[r8+0x4]
  8f9d4b:	lea    r9,[r11+r11*2]
  8f9d4f:	shl    r9,0x6
  8f9d53:	mov    r10,QWORD PTR [rsp+0x18]
  8f9d58:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8f9d5e:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x20]
  8f9d65:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8f9d6c:	vmovdqu xmm4,XMMWORD PTR [r10+r9*1+0x50]
  8f9d73:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8f9d7b:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71c3dd]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8f9d83:	vpshufb xmm1,xmm1,xmm6
  8f9d88:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71d540]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8f9d90:	vpshufb xmm0,xmm0,xmm7
  8f9d95:	vpor   xmm3,xmm0,xmm1
  8f9d99:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8f9da1:	vpshufb xmm1,xmm4,xmm6
  8f9da6:	vpshufb xmm0,xmm0,xmm7
  8f9dab:	vpor   xmm4,xmm0,xmm1
  8f9daf:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0x80]
  8f9db9:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x60]
  8f9dc0:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0x70],0x4
  8f9dc8:	vpshufb xmm0,xmm0,xmm6
  8f9dcd:	vpshufb xmm1,xmm1,xmm7
  8f9dd2:	vpor   xmm5,xmm1,xmm0
  8f9dd6:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0xb0]
  8f9de0:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x90]
  8f9dea:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0xa0],0x4
  8f9df5:	vpshufb xmm0,xmm0,xmm6
  8f9dfa:	vpshufb xmm1,xmm1,xmm7
  8f9dff:	vpor   xmm6,xmm1,xmm0
  8f9e03:	vpunpckldq xmm7,xmm3,xmm4
  8f9e07:	vpunpckldq xmm8,xmm5,xmm6
  8f9e0b:	vpunpcklqdq xmm1,xmm7,xmm8
  8f9e10:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a1d8]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f9e18:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f9e1e:	vpshufb xmm0,xmm0,xmm2
  8f9e23:	vptest xmm0,xmm9
  8f9e28:	je     8f9f18 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3258>
  8f9e2e:	mov    r9,rsi
  8f9e31:	mov    rsi,r11
  8f9e34:	jmp    8f9366 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x26a6>
  8f9e39:	cmp    r11,rcx
  8f9e3c:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9e42:	mov    rdx,r11
  8f9e45:	shl    rdx,0x4
  8f9e49:	lea    rdi,[rdx+r13*1]
  8f9e4d:	cmp    rdi,0x7fffffff
  8f9e54:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9e5a:	lea    rsi,[r11+r11*2]
  8f9e5e:	shl    rsi,0x5
  8f9e62:	mov    r9,QWORD PTR [rsp+0x18]
  8f9e67:	vmovdqu xmm0,XMMWORD PTR [r9+rsi*1]
  8f9e6d:	vmovdqu xmm1,XMMWORD PTR [r9+rsi*1+0x6]
  8f9e74:	vmovdqu xmm2,XMMWORD PTR [r9+rsi*1+0x30]
  8f9e7b:	vmovdqu xmm6,XMMWORD PTR [r9+rsi*1+0x36]
  8f9e82:	vpblendd xmm0,xmm0,XMMWORD PTR [r9+rsi*1+0x10],0x4
  8f9e8a:	vpblendd xmm3,xmm0,XMMWORD PTR [r9+rsi*1+0x20],0x2
  8f9e92:	vpblendd xmm0,xmm2,XMMWORD PTR [r9+rsi*1+0x40],0x4
  8f9e9a:	vpblendd xmm4,xmm0,XMMWORD PTR [r9+rsi*1+0x50],0x2
  8f9ea2:	vpblendd xmm0,xmm1,XMMWORD PTR [r9+rsi*1+0x16],0x4
  8f9eaa:	vpblendd xmm5,xmm0,XMMWORD PTR [r9+rsi*1+0x26],0x2
  8f9eb2:	vpblendd xmm0,xmm6,XMMWORD PTR [r9+rsi*1+0x46],0x4
  8f9eba:	vpblendd xmm6,xmm0,XMMWORD PTR [r9+rsi*1+0x56],0x2
  8f9ec2:	lea    rsi,[r8+0x4]
  8f9ec6:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71c8b2]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8f9ece:	vpshufb xmm0,xmm5,xmm2
  8f9ed3:	vpshufb xmm1,xmm3,xmm2
  8f9ed8:	vpunpcklbw xmm7,xmm1,xmm0
  8f9edc:	vpshufb xmm0,xmm6,xmm2
  8f9ee1:	vpshufb xmm1,xmm4,xmm2
  8f9ee6:	vpunpcklbw xmm8,xmm1,xmm0
  8f9eea:	vpunpcklqdq xmm1,xmm7,xmm8
  8f9eef:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff71a0f9]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8f9ef7:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8f9efd:	vpshufb xmm0,xmm0,xmm2
  8f9f02:	vptest xmm0,xmm9
  8f9f07:	je     8fa02c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x336c>
  8f9f0d:	mov    r9,rsi
  8f9f10:	mov    rsi,r11
  8f9f13:	jmp    8fa100 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3440>
  8f9f18:	cmp    rsi,rcx
  8f9f1b:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8f9f21:	mov    rdx,rsi
  8f9f24:	shl    rdx,0x4
  8f9f28:	lea    rdi,[rdx+r13*1]
  8f9f2c:	imul   rdi,r14
  8f9f30:	cmp    rdi,0x7fffffff
  8f9f37:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8f9f3d:	lea    r9,[rsi+rsi*2]
  8f9f41:	shl    r9,0x6
  8f9f45:	mov    r10,QWORD PTR [rsp+0x18]
  8f9f4a:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8f9f50:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x20]
  8f9f57:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8f9f5e:	vmovdqu xmm4,XMMWORD PTR [r10+r9*1+0x50]
  8f9f65:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8f9f6d:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71c1eb]        # 16160 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1da0>
  8f9f75:	vpshufb xmm1,xmm1,xmm6
  8f9f7a:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71d34e]        # 172d0 <anon.3e20b93f55cdd0a4e46c5dcac61833fb.113.llvm.5736877698748593523+0x1e0>
  8f9f82:	vpshufb xmm0,xmm0,xmm7
  8f9f87:	vpor   xmm3,xmm0,xmm1
  8f9f8b:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8f9f93:	vpshufb xmm1,xmm4,xmm6
  8f9f98:	vpshufb xmm0,xmm0,xmm7
  8f9f9d:	vpor   xmm4,xmm0,xmm1
  8f9fa1:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0x80]
  8f9fab:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x60]
  8f9fb2:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0x70],0x4
  8f9fba:	vpshufb xmm0,xmm0,xmm6
  8f9fbf:	vpshufb xmm1,xmm1,xmm7
  8f9fc4:	vpor   xmm5,xmm1,xmm0
  8f9fc8:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1+0xb0]
  8f9fd2:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x90]
  8f9fdc:	vpblendd xmm1,xmm1,XMMWORD PTR [r10+r9*1+0xa0],0x4
  8f9fe7:	vpshufb xmm0,xmm0,xmm6
  8f9fec:	vpshufb xmm1,xmm1,xmm7
  8f9ff1:	vpor   xmm6,xmm1,xmm0
  8f9ff5:	vpunpckldq xmm7,xmm3,xmm4
  8f9ff9:	vpunpckldq xmm8,xmm5,xmm6
  8f9ffd:	vpunpcklqdq xmm1,xmm7,xmm8
  8fa002:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff719fe6]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8fa00a:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8fa010:	vpshufb xmm0,xmm0,xmm2
  8fa015:	vptest xmm0,xmm9
  8fa01a:	je     8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8fa020:	add    r8,0x5
  8fa024:	mov    r9,r8
  8fa027:	jmp    8f9366 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x26a6>
  8fa02c:	cmp    rsi,rcx
  8fa02f:	jae    8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8fa035:	mov    rdx,rsi
  8fa038:	shl    rdx,0x4
  8fa03c:	lea    rdi,[rdx+r13*1]
  8fa040:	cmp    rdi,0x7fffffff
  8fa047:	ja     8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8fa04d:	lea    r9,[rsi+rsi*2]
  8fa051:	shl    r9,0x5
  8fa055:	mov    r10,QWORD PTR [rsp+0x18]
  8fa05a:	vmovdqu xmm0,XMMWORD PTR [r10+r9*1]
  8fa060:	vmovdqu xmm1,XMMWORD PTR [r10+r9*1+0x6]
  8fa067:	vmovdqu xmm2,XMMWORD PTR [r10+r9*1+0x30]
  8fa06e:	vmovdqu xmm6,XMMWORD PTR [r10+r9*1+0x36]
  8fa075:	vpblendd xmm0,xmm0,XMMWORD PTR [r10+r9*1+0x10],0x4
  8fa07d:	vpblendd xmm3,xmm0,XMMWORD PTR [r10+r9*1+0x20],0x2
  8fa085:	vpblendd xmm0,xmm2,XMMWORD PTR [r10+r9*1+0x40],0x4
  8fa08d:	vpblendd xmm4,xmm0,XMMWORD PTR [r10+r9*1+0x50],0x2
  8fa095:	vpblendd xmm0,xmm1,XMMWORD PTR [r10+r9*1+0x16],0x4
  8fa09d:	vpblendd xmm5,xmm0,XMMWORD PTR [r10+r9*1+0x26],0x2
  8fa0a5:	vpblendd xmm0,xmm6,XMMWORD PTR [r10+r9*1+0x46],0x4
  8fa0ad:	vpblendd xmm6,xmm0,XMMWORD PTR [r10+r9*1+0x56],0x2
  8fa0b5:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71c6c3]        # 16780 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x23c0>
  8fa0bd:	vpshufb xmm0,xmm5,xmm2
  8fa0c2:	vpshufb xmm1,xmm3,xmm2
  8fa0c7:	vpunpcklbw xmm7,xmm1,xmm0
  8fa0cb:	vpshufb xmm0,xmm6,xmm2
  8fa0d0:	vpshufb xmm1,xmm4,xmm2
  8fa0d5:	vpunpcklbw xmm8,xmm1,xmm0
  8fa0d9:	vpunpcklqdq xmm1,xmm7,xmm8
  8fa0de:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff719f0a]        # 13ff0 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.1453164598040546060+0x73e>
  8fa0e6:	vmovdqa xmm0,XMMWORD PTR [rsp+0x60]
  8fa0ec:	vpshufb xmm0,xmm0,xmm2
  8fa0f1:	vptest xmm0,xmm9
  8fa0f6:	je     8fa140 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3480>
  8fa0f8:	add    r8,0x5
  8fa0fc:	mov    r9,r8
  8fa0ff:	nop
  8fa100:	vpunpckhqdq xmm7,xmm7,xmm8
  8fa105:	vmovd  xmm8,DWORD PTR [rip+0xffffffffff71a7c3]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x510>
  8fa10d:	vpshufb xmm5,xmm5,xmm8
  8fa112:	vpshufb xmm3,xmm3,xmm8
  8fa117:	vpunpcklbw xmm3,xmm3,xmm5
  8fa11b:	vpshufb xmm5,xmm6,xmm8
  8fa120:	vpshufb xmm4,xmm4,xmm8
  8fa125:	vpunpcklbw xmm4,xmm4,xmm5
  8fa129:	vpunpcklqdq xmm4,xmm3,xmm4
  8fa12d:	jmp    8f9377 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x26b7>
  8fa132:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8fa140:	cmp    r12,0x1
  8fa144:	adc    r12,0x0
  8fa148:	bzhi   rax,rax,r12
  8fa14d:	mov    r11,QWORD PTR [rsp+0x80]
  8fa155:	jne    8fa1a7 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34e7>
  8fa157:	mov    rsi,QWORD PTR [rsp+0x220]
  8fa15f:	mov    r13,QWORD PTR [rsp+0x140]
  8fa167:	mov    r9,QWORD PTR [rsp+0x240]
  8fa16f:	test   r9,r9
  8fa172:	jne    8f9276 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x25b6>
  8fa178:	jmp    8f9200 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x2540>
  8fa17d:	shl    esi,0x10
  8fa180:	movzx  edi,di
  8fa183:	or     edi,esi
  8fa185:	mov    WORD PTR [rdx+rcx*8],r9w
  8fa18a:	mov    DWORD PTR [rdx+rcx*8+0x2],edi
  8fa18e:	mov    BYTE PTR [rdx+rcx*8+0x6],0x1
  8fa193:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  8fa1a0:	blsr   rax,rax
  8fa1a5:	je     8fa157 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3497>
  8fa1a7:	tzcnt  rdx,rax
  8fa1ac:	mov    rcx,QWORD PTR [rsp+0x98]
  8fa1b4:	movzx  r8d,BYTE PTR [rcx+rdx*1]
  8fa1b9:	cmp    r8d,0x8
  8fa1bd:	ja     8fa1a0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34e0>
  8fa1bf:	mov    rcx,QWORD PTR [rsp+0x50]
  8fa1c4:	mov    ecx,DWORD PTR [rcx+rdx*4+0x600]
  8fa1cb:	mov    rsi,QWORD PTR [rsp+0x78]
  8fa1d0:	cmp    QWORD PTR [rsi+0x8],rcx
  8fa1d4:	jbe    8fa1a0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34e0>
  8fa1d6:	shl    r8d,0x5
  8fa1da:	add    r8,r11
  8fa1dd:	mov    rsi,QWORD PTR [rsp+0x50]
  8fa1e2:	mov    edi,DWORD PTR [rsi+rdx*4]
  8fa1e5:	mov    esi,DWORD PTR [rsi+rdx*4+0x100]
  8fa1ec:	mov    rdx,QWORD PTR [rsp+0x78]
  8fa1f1:	mov    rdx,QWORD PTR [rdx]
  8fa1f4:	cmp    BYTE PTR [rdx+rcx*8+0x6],0x0
  8fa1f9:	je     8fa21d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x355d>
  8fa1fb:	cmp    BYTE PTR [r8+0x1b],0x1
  8fa200:	jne    8fa1a0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34e0>
  8fa202:	movsx  r10d,WORD PTR [rdx+rcx*8]
  8fa207:	mov    r9d,DWORD PTR [r8+0x10]
  8fa20b:	cmp    r9d,r10d
  8fa20e:	je     8fa1a0 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34e0>
  8fa210:	cmp    BYTE PTR [r8+0x1a],0x0
  8fa215:	je     8fa17d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34bd>
  8fa21b:	jmp    8fa22c <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x356c>
  8fa21d:	mov    r9d,DWORD PTR [r8+0x10]
  8fa221:	cmp    BYTE PTR [r8+0x1a],0x0
  8fa226:	je     8fa17d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34bd>
  8fa22c:	neg    edi
  8fa22e:	neg    esi
  8fa230:	jmp    8fa17d <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x34bd>
  8fa235:	cmp    r9,rbx
  8fa238:	cmovb  rbx,r9
  8fa23c:	mov    rax,rbx
  8fa23f:	or     rax,r14
  8fa242:	shr    rax,0x20
  8fa246:	je     8fa252 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3592>
  8fa248:	mov    rax,rbx
  8fa24b:	xor    edx,edx
  8fa24d:	div    r14
  8fa250:	jmp    8fa259 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3599>
  8fa252:	mov    eax,ebx
  8fa254:	xor    edx,edx
  8fa256:	div    r14d
  8fa259:	mov    rdi,QWORD PTR [rsp+0x18]
  8fa25e:	cmp    rdx,0x1
  8fa262:	sbb    rax,0xffffffffffffffff
  8fa266:	cmp    rax,0x40
  8fa26a:	mov    ecx,0x40
  8fa26f:	cmovb  rcx,rax
  8fa273:	add    rbx,rbx
  8fa276:	lea    rax,[rbx+rbx*2]
  8fa27a:	mov    r8,QWORD PTR [rsp+0xf8]
  8fa282:	add    rsi,r8
  8fa285:	xor    edx,edx
  8fa287:	sub    rax,r8
  8fa28a:	cmovae rdx,rax
  8fa28e:	imul   rcx,QWORD PTR [rsp+0xf0]
  8fa297:	cmp    rdx,rcx
  8fa29a:	cmovb  rcx,rdx
  8fa29e:	cmp    rcx,0x300
  8fa2a5:	mov    edx,0x300
  8fa2aa:	cmovb  rdx,rcx
  8fa2ae:	call   QWORD PTR [rip+0x6ea7ec]        # fe4aa0 <memcpy@GLIBC_2.14>
  8fa2b4:	lea    rsp,[rbp-0x28]
  8fa2b8:	pop    rbx
  8fa2b9:	pop    r12
  8fa2bb:	pop    r13
  8fa2bd:	pop    r14
  8fa2bf:	pop    r15
  8fa2c1:	pop    rbp
  8fa2c2:	vzeroupper
  8fa2c5:	ret
  8fa2c6:	lea    rdi,[rip+0xffffffffff75bdf2]        # 560bf <anon.245362c1692d2350ec60721dad848e3d.1081.llvm.5944606840923237273+0x158a>
  8fa2cd:	lea    rdx,[rip+0x6da8d4]        # fd4ba8 <anon.245362c1692d2350ec60721dad848e3d.1039.llvm.5944606840923237273+0x5c0>
  8fa2d4:	mov    esi,0x1b
  8fa2d9:	call   QWORD PTR [rip+0x6ea909]        # fe4be8 <_DYNAMIC+0x390>
  8fa2df:	mov    rbx,QWORD PTR [rip+0x6ed0d2]        # fe73b8 <_DYNAMIC+0x2b60>
  8fa2e6:	mov    rdi,QWORD PTR [rsp+0x108]
  8fa2ee:	mov    r15,QWORD PTR [rsp+0x48]
  8fa2f3:	mov    rsi,r15
  8fa2f6:	call   rbx
  8fa2f8:	test   rax,rax
  8fa2fb:	jne    8fa311 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3651>
  8fa2fd:	add    r15,r14
  8fa300:	mov    QWORD PTR [rsp+0x48],r15
  8fa305:	dec    QWORD PTR [rsp+0xe8]
  8fa30d:	jne    8fa2e6 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x3626>
  8fa30f:	jmp    8fa2b4 <_RINvNvXs2_NtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCscBm8GepV0TW_10splot_core4simd11Avx2BackendNtB1Z_19TemporalMotionFieldEs0_0uEB27_+0x35f4>
  8fa311:	lea    rdi,[rip+0xffffffffff750161]        # 4a479 <_RNvNtNtNtCsdbBTXDzdjsm_12splot_decode9bitstream12tile_payload11coeff_state15ZERO_QUANT_SIGN+0x521>
  8fa318:	lea    rdx,[rip+0x6d9091]        # fd33b0 <anon.245362c1692d2350ec60721dad848e3d.159.llvm.5944606840923237273+0x2270>
  8fa31f:	mov    esi,0x37
  8fa324:	call   QWORD PTR [rip+0x6ea7ce]        # fe4af8 <_DYNAMIC+0x2a0>
