
<WORKTREES>/qualification-1882/final-integration/splot.full:     file format elf64-x86-64


Disassembly of section .text:

0000000000b187a0 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project>:
  b187a0:	mov    rax,QWORD PTR [rdi+0x8]
  b187a4:	test   rax,rax
  b187a7:	je     b18866 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xc6>
  b187ad:	push   rbp
  b187ae:	push   rbx
  b187af:	mov    rcx,QWORD PTR [rdi]
  b187b2:	mov    rdi,QWORD PTR [rdx]
  b187b5:	mov    rdx,QWORD PTR [rdx+0x8]
  b187b9:	jmp    b187e9 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x49>
  b187bb:	shl    r9d,0x10
  b187bf:	movzx  r10d,r10w
  b187c3:	or     r10d,r9d
  b187c6:	mov    WORD PTR [rdi+r8*8],bx
  b187cb:	mov    DWORD PTR [rdi+r8*8+0x2],r10d
  b187d0:	mov    BYTE PTR [rdi+r8*8+0x6],0x1
  b187d6:	cs nop WORD PTR [rax+rax*1+0x0]
  b187e0:	lea    r8,[rax-0x1]
  b187e4:	and    rax,r8
  b187e7:	je     b18864 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xc4>
  b187e9:	tzcnt  r9,rax
  b187ee:	movzx  r11d,BYTE PTR [rcx+r9*1+0xc00]
  b187f7:	cmp    r11d,0x8
  b187fb:	ja     b187e0 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  b187fd:	mov    r8d,DWORD PTR [rcx+r9*4+0x900]
  b18805:	cmp    rdx,r8
  b18808:	jbe    b187e0 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  b1880a:	shl    r11d,0x5
  b1880e:	add    r11,rsi
  b18811:	mov    r10d,DWORD PTR [rcx+r9*4+0x300]
  b18819:	mov    r9d,DWORD PTR [rcx+r9*4+0x400]
  b18821:	cmp    BYTE PTR [rdi+r8*8+0x6],0x0
  b18827:	je     b1884a <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xaa>
  b18829:	cmp    BYTE PTR [r11+0x1b],0x1
  b1882e:	jne    b187e0 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  b18830:	movsx  ebp,WORD PTR [rdi+r8*8]
  b18835:	mov    ebx,DWORD PTR [r11+0x10]
  b18839:	cmp    ebx,ebp
  b1883b:	je     b187e0 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  b1883d:	cmp    BYTE PTR [r11+0x1a],0x0
  b18842:	je     b187bb <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x1b>
  b18848:	jmp    b18859 <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xb9>
  b1884a:	mov    ebx,DWORD PTR [r11+0x10]
  b1884e:	cmp    BYTE PTR [r11+0x1a],0x0
  b18853:	je     b187bb <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x1b>
  b18859:	neg    r10d
  b1885c:	neg    r9d
  b1885f:	jmp    b187bb <_RNvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x1b>
  b18864:	pop    rbx
  b18865:	pop    rbp
  b18866:	ret
