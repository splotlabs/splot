"""Summarize linked full-scan symbols and BMI instructions."""

from collections import Counter
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
bins = (("control", OUT.parent / "final-integration/splot.full"),
        ("scan", OUT / "target/release/splot"))
for label, bin_path in bins:
    listing = subprocess.check_output(["nm", "-n", "-S", "--demangle=rust", bin_path], text=True)
    for row in listing.splitlines():
        columns = row.split(None, 3)
        if len(columns) != 4:
            continue
        address, size, _, name = columns
        if "temporal::scan::ChunkWalk" not in name and not (
            "::vectorize_avx2::" in name and "::scan::project_temporal_motion_field" in name
        ):
            continue
        start = int(address, 16)
        length = int(size, 16)
        assembly = subprocess.check_output([
            "objdump", "-d", "-Mintel", "--no-show-raw-insn", f"--start-address={start}",
            f"--stop-address={start + length}", bin_path,
        ], text=True)
        (OUT / f"{label}-{start:x}.asm").write_text(assembly)
        counts = Counter(match[1] for line in assembly.splitlines()
                         if (match := re.match(r"\s*[0-9a-f]+:\s+(\S+)", line)))
        print(label, f"address={start:x}", f"bytes={length}",
              *(f"{key}={counts[key]}" for key in ("blsr", "shrx", "tzcnt", "call")),
              f"VEX={sum(count for key, count in counts.items() if key.startswith('v'))}", name)
