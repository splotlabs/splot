
<WORKTREES>/qualification-1882/final-integration/splot.full:     file format elf64-x86-64


Disassembly of section .text:

0000000000903050 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_>:
  903050:	push   rbp
  903051:	mov    rbp,rsp
  903054:	push   r15
  903056:	push   r14
  903058:	push   r13
  90305a:	push   r12
  90305c:	push   rbx
  90305d:	and    rsp,0xffffffffffffffc0
  903061:	sub    rsp,0x8c0
  903068:	mov    r14,rdi
  90306b:	mov    r15,QWORD PTR [rdi+0x8]
  90306f:	mov    rax,QWORD PTR [rdi+0x10]
  903073:	mov    rdx,QWORD PTR [rax]
  903076:	lea    rdi,[rsp+0x380]
  90307e:	mov    rsi,r15
  903081:	call   b87920 <_RNvMs_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanINtB4_12TargetTablesNtNtNtCscIM9z48VHAb_13fearless_simd9generated4avx24Avx2E3newBe_>
  903086:	mov    rdx,QWORD PTR [r14+0x28]
  90308a:	mov    r13,QWORD PTR [rdx]
  90308d:	test   r13,r13
  903090:	je     9057c6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2776>
  903096:	mov    r10,QWORD PTR [r14+0x38]
  90309a:	mov    r9,QWORD PTR [r14+0x40]
  90309e:	mov    eax,DWORD PTR [rdx+0x8]
  9030a1:	mov    DWORD PTR [rsp+0x30],eax
  9030a5:	mov    r12d,DWORD PTR [rdx+0xc]
  9030a9:	movsxd rax,DWORD PTR [rdx+0x10]
  9030ad:	mov    QWORD PTR [rsp+0x58],rax
  9030b2:	mov    r8d,DWORD PTR [rdx+0x14]
  9030b6:	mov    edi,DWORD PTR [rdx+0x18]
  9030b9:	mov    esi,DWORD PTR [rdx+0x1c]
  9030bc:	mov    ecx,DWORD PTR [rdx+0x20]
  9030bf:	xor    eax,eax
  9030c1:	mov    QWORD PTR [rsp+0x18],r10
  9030c6:	sub    r9,r10
  9030c9:	cmovae rax,r9
  9030cd:	mov    r9d,DWORD PTR [rdx+0x24]
  9030d1:	mov    DWORD PTR [rsp+0x34],r9d
  9030d6:	mov    r9,rax
  9030d9:	or     r9,r13
  9030dc:	shr    r9,0x20
  9030e0:	mov    r9d,DWORD PTR [rdx+0x28]
  9030e4:	mov    DWORD PTR [rsp+0x68],r9d
  9030e9:	vmovdqu ymm0,YMMWORD PTR [rdx+0x2c]
  9030ee:	movzx  edx,BYTE PTR [rdx+0x4c]
  9030f2:	mov    QWORD PTR [rsp+0xb8],rdx
  9030fa:	mov    rbx,QWORD PTR [r14+0x18]
  9030fe:	mov    r10,QWORD PTR [r14+0x20]
  903102:	mov    rdx,QWORD PTR [r14+0x48]
  903106:	mov    QWORD PTR [rsp+0xc0],rdx
  90310e:	mov    rdx,QWORD PTR [r14+0x30]
  903112:	mov    QWORD PTR [rsp+0xa8],rdx
  90311a:	mov    r9,QWORD PTR [r15+0x138]
  903121:	mov    QWORD PTR [rsp+0xb0],r15
  903129:	je     903132 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xe2>
  90312b:	xor    edx,edx
  90312d:	div    r13
  903130:	jmp    903137 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xe7>
  903132:	xor    edx,edx
  903134:	div    r13d
  903137:	xor    r11d,r11d
  90313a:	test   rdx,rdx
  90313d:	setne  r11b
  903141:	add    r11,rax
  903144:	mov    QWORD PTR [rsp+0x88],r11
  90314c:	je     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  903152:	mov    rax,QWORD PTR [r10+0xe0]
  903159:	mov    QWORD PTR [rsp+0x40],rax
  90315e:	mov    rax,QWORD PTR [r10+0xc8]
  903165:	mov    rdx,QWORD PTR [r10+0xa8]
  90316c:	mov    QWORD PTR [rsp+0x80],rdx
  903174:	mov    r11,QWORD PTR [r10+0xb0]
  90317b:	mov    rdx,QWORD PTR [r10+0xc0]
  903182:	mov    QWORD PTR [rsp+0x28],rdx
  903187:	mov    r10,QWORD PTR [r10+0xb8]
  90318e:	mov    QWORD PTR [rsp+0x48],r10
  903193:	mov    QWORD PTR [rsp+0x38],r11
  903198:	sub    r10,r11
  90319b:	mov    QWORD PTR [rsp+0x90],r10
  9031a3:	setb   BYTE PTR [rsp+0x17]
  9031a8:	mov    rdx,r13
  9031ab:	shl    rdx,0x6
  9031af:	mov    QWORD PTR [rsp+0x50],rdx
  9031b4:	je     9057df <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x278f>
  9031ba:	mov    QWORD PTR [rsp+0x20],rax
  9031bf:	test   rax,rax
  9031c2:	je     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  9031c8:	and    r9d,0x1
  9031cc:	lea    rax,[r13*2+0x0]
  9031d4:	lea    rdx,[r9+r9*2]
  9031d8:	mov    QWORD PTR [rsp+0x70],rdx
  9031dd:	lea    rax,[rax+rax*2]
  9031e1:	mov    QWORD PTR [rsp+0x78],rax
  9031e6:	cmp    QWORD PTR [rsp+0xc0],0x0
  9031ef:	je     904566 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1516>
  9031f5:	vmovd  xmm1,r13d
  9031fa:	vpbroadcastd ymm1,xmm1
  9031ff:	vpmulld xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff713ba8]        # 16db0 <anon.43d21acec09d19046152b53125a552af.1615.llvm.7158842796534594082+0x3e0>
  903208:	vpmulld xmm3,xmm1,XMMWORD PTR [rip+0xffffffffff710d8f]        # 13fa0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6ee>
  903211:	vpmulld ymm4,ymm1,YMMWORD PTR [rip+0xffffffffff7171c6]        # 1a3e0 <anon.db13f839740d960fd97bc530122b4c99.104.llvm.5594421697515501092+0x4c8>
  90321a:	vmovdqa YMMWORD PTR [rsp+0x7e0],ymm4
  903223:	not    r8d
  903226:	vmovd  xmm4,r8d
  90322b:	mov    rax,QWORD PTR [rsp+0xb8]
  903233:	lea    eax,[rax*8+0x0]
  90323a:	or     al,0x4
  90323c:	vpxor  xmm5,xmm5,xmm5
  903240:	vpblendd xmm1,xmm5,xmm1,0x2
  903246:	vpermq ymm2,ymm2,0xd0
  90324c:	vpblendd ymm1,ymm2,ymm1,0x3
  903252:	vpbroadcastq ymm2,xmm3
  903257:	vpblendd ymm1,ymm1,ymm2,0xc0
  90325d:	vmovdqa YMMWORD PTR [rsp+0x7c0],ymm1
  903266:	vmovd  xmm1,eax
  90326a:	vpbroadcastb xmm1,xmm1
  90326f:	vmovdqa XMMWORD PTR [rsp+0x110],xmm1
  903278:	mov    rax,QWORD PTR [rsp+0x58]
  90327d:	not    eax
  90327f:	vmovd  xmm1,eax
  903283:	vmovdqa XMMWORD PTR [rsp+0x460],xmm4
  90328c:	vmovdqa XMMWORD PTR [rsp+0x470],xmm1
  903295:	vpand  xmm1,xmm4,xmm1
  903299:	vpbroadcastd ymm1,xmm1
  90329e:	vmovdqa YMMWORD PTR [rsp+0x780],ymm1
  9032a7:	vmovss xmm1,DWORD PTR [rsp+0x30]
  9032ad:	vbroadcastss ymm1,xmm1
  9032b2:	vmovaps YMMWORD PTR [rsp+0x760],ymm1
  9032bb:	vmovd  xmm1,r12d
  9032c0:	vpbroadcastd ymm1,xmm1
  9032c5:	vmovdqa YMMWORD PTR [rsp+0x740],ymm1
  9032ce:	vmovd  xmm1,edi
  9032d2:	vpbroadcastd ymm1,xmm1
  9032d7:	vmovdqa YMMWORD PTR [rsp+0x720],ymm1
  9032e0:	vmovd  xmm1,esi
  9032e4:	vpbroadcastd ymm1,xmm1
  9032e9:	vmovdqa YMMWORD PTR [rsp+0x700],ymm1
  9032f2:	vmovd  xmm1,ecx
  9032f6:	vpbroadcastd ymm1,xmm1
  9032fb:	vmovdqa YMMWORD PTR [rsp+0x500],ymm1
  903304:	vmovss xmm1,DWORD PTR [rsp+0x34]
  90330a:	vbroadcastss ymm1,xmm1
  90330f:	vmovaps YMMWORD PTR [rsp+0x6e0],ymm1
  903318:	vextracti128 xmm1,ymm0,0x1
  90331e:	vmovd  DWORD PTR [rsp+0x6c],xmm1
  903324:	vpextrd DWORD PTR [rsp+0xd8],xmm0,0x2
  90332f:	vmovd  DWORD PTR [rsp+0xd4],xmm0
  903338:	vpshufd xmm1,xmm0,0x55
  90333d:	vpbroadcastd ymm1,xmm1
  903342:	vmovdqa YMMWORD PTR [rsp+0x6c0],ymm1
  90334b:	vmovss xmm1,DWORD PTR [rsp+0x68]
  903351:	vbroadcastss ymm1,xmm1
  903356:	vmovaps YMMWORD PTR [rsp+0x6a0],ymm1
  90335f:	vmovq  rax,xmm0
  903364:	vpextrq rcx,xmm0,0x1
  90336a:	shr    rcx,0x20
  90336e:	vmovd  xmm1,ecx
  903372:	vpbroadcastd ymm1,xmm1
  903377:	vmovdqa YMMWORD PTR [rsp+0x4e0],ymm1
  903380:	vpshufd ymm1,ymm0,0x55
  903385:	vpermq ymm1,ymm1,0xaa
  90338b:	vmovdqa YMMWORD PTR [rsp+0x680],ymm1
  903394:	vpshufd ymm1,ymm0,0xaa
  903399:	vpermq ymm1,ymm1,0xaa
  90339f:	vmovdqa YMMWORD PTR [rsp+0x660],ymm1
  9033a8:	vpbroadcastd ymm1,xmm0
  9033ad:	vmovdqa YMMWORD PTR [rsp+0x640],ymm1
  9033b6:	vpshufd ymm0,ymm0,0xff
  9033bb:	vpermq ymm0,ymm0,0xaa
  9033c1:	vmovdqa YMMWORD PTR [rsp+0x620],ymm0
  9033ca:	shr    rax,0x20
  9033ce:	vmovd  xmm0,eax
  9033d2:	vpbroadcastd ymm0,xmm0
  9033d7:	vmovdqa YMMWORD PTR [rsp+0x5c0],ymm0
  9033e0:	mov    eax,r13d
  9033e3:	shl    eax,0x6
  9033e6:	mov    DWORD PTR [rsp+0xdc],eax
  9033ed:	mov    eax,r13d
  9033f0:	shl    eax,0x4
  9033f3:	mov    DWORD PTR [rsp+0x130],eax
  9033fa:	mov    rax,r13
  9033fd:	shl    rax,0x4
  903401:	mov    QWORD PTR [rsp+0x3c0],rax
  903409:	neg    rax
  90340c:	mov    QWORD PTR [rsp+0x140],rax
  903414:	vmovaps xmm0,XMMWORD PTR [rsp+0x380]
  90341d:	vmovaps XMMWORD PTR [rsp+0x490],xmm0
  903426:	vmovaps xmm0,XMMWORD PTR [rsp+0x390]
  90342f:	vmovaps XMMWORD PTR [rsp+0x480],xmm0
  903438:	vbroadcastss ymm0,DWORD PTR [rsp+0x3b0]
  903442:	vmovaps YMMWORD PTR [rsp+0x7a0],ymm0
  90344b:	vmovdqa xmm0,XMMWORD PTR [rsp+0x3a0]
  903454:	vmovdqa XMMWORD PTR [rsp+0x120],xmm0
  90345d:	mov    QWORD PTR [rsp+0x280],r13
  903465:	mov    DWORD PTR [rsp+0x64],r12d
  90346a:	jmp    903486 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x436>
  90346c:	nop    DWORD PTR [rax+0x0]
  903470:	add    r14,r13
  903473:	mov    QWORD PTR [rsp+0x18],r14
  903478:	dec    QWORD PTR [rsp+0x88]
  903480:	je     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  903486:	mov    r14,QWORD PTR [rsp+0x18]
  90348b:	mov    rax,r14
  90348e:	sub    rax,QWORD PTR [rsp+0x40]
  903493:	jb     903470 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x420>
  903495:	mul    QWORD PTR [rsp+0x20]
  90349a:	jo     903470 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x420>
  90349c:	mov    rcx,rax
  90349f:	add    rcx,QWORD PTR [rsp+0x20]
  9034a4:	jb     903470 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x420>
  9034a6:	mov    rdx,QWORD PTR [rsp+0x80]
  9034ae:	test   rdx,rdx
  9034b1:	je     9034cc <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x47c>
  9034b3:	cmp    edx,0x2
  9034b6:	jne    9034dd <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x48d>
  9034b8:	mov    rdx,QWORD PTR [rsp+0x28]
  9034bd:	cmp    BYTE PTR [rdx+0x10],0x0
  9034c1:	je     9034f1 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x4a1>
  9034c3:	mov    edx,0x1
  9034c8:	xor    esi,esi
  9034ca:	jmp    9034fc <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x4ac>
  9034cc:	mov    rsi,QWORD PTR [rsp+0x28]
  9034d1:	mov    rdx,QWORD PTR [rsp+0x48]
  9034d6:	cmp    rcx,rsi
  9034d9:	ja     903470 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x420>
  9034db:	jmp    90353a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x4ea>
  9034dd:	mov    rsi,QWORD PTR [rsp+0x38]
  9034e2:	mov    rdx,QWORD PTR [rsi+0x18]
  9034e6:	mov    rsi,QWORD PTR [rsi+0x20]
  9034ea:	cmp    rcx,rsi
  9034ed:	ja     903470 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x420>
  9034ef:	jmp    90353a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x4ea>
  9034f1:	mov    rsi,rdx
  9034f4:	mov    rdx,QWORD PTR [rdx+0x20]
  9034f8:	mov    rsi,QWORD PTR [rsi+0x28]
  9034fc:	cmp    QWORD PTR [rsp+0x48],rsi
  903501:	seta   sil
  903505:	or     sil,BYTE PTR [rsp+0x17]
  90350a:	mov    rsi,QWORD PTR [rsp+0x38]
  90350f:	lea    rsi,[rsi+rsi*2]
  903513:	lea    rdx,[rdx+rsi*2]
  903517:	mov    rsi,QWORD PTR [rsp+0x90]
  90351f:	mov    edi,0x0
  903524:	cmovne rsi,rdi
  903528:	mov    edi,0x1
  90352d:	cmovne rdx,rdi
  903531:	cmp    rcx,rsi
  903534:	ja     903470 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x420>
  90353a:	lea    rax,[rax+rax*2]
  90353e:	lea    rsi,[rdx+rax*2]
  903542:	cmp    r14d,DWORD PTR [rsp+0x34]
  903547:	mov    eax,0x0
  90354c:	sbb    eax,eax
  90354e:	cmp    r14,0x7fffffff
  903555:	ja     905730 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x26e0>
  90355b:	mov    ecx,r14d
  90355e:	sub    ecx,DWORD PTR [rsp+0x30]
  903562:	mov    edx,ecx
  903564:	sar    edx,0x1f
  903567:	imul   ecx,r12d
  90356b:	vmovd  xmm0,r14d
  903570:	vpbroadcastd ymm1,xmm0
  903575:	vmovd  xmm0,eax
  903579:	vpbroadcastd ymm0,xmm0
  90357e:	vmovdqa YMMWORD PTR [rsp+0x5a0],ymm0
  903587:	vpand  xmm0,xmm1,XMMWORD PTR [rsp+0x460]
  903590:	vpbroadcastd ymm0,xmm0
  903595:	vmovdqa YMMWORD PTR [rsp+0x600],ymm0
  90359e:	vmovd  xmm0,ecx
  9035a2:	vpbroadcastd ymm0,xmm0
  9035a7:	vmovdqa YMMWORD PTR [rsp+0x580],ymm0
  9035b0:	vmovd  xmm0,edx
  9035b4:	vpbroadcastd ymm0,xmm0
  9035b9:	vmovdqa YMMWORD PTR [rsp+0x560],ymm0
  9035c2:	mov    QWORD PTR [rsp+0xa0],0x0
  9035ce:	cmp    r14d,DWORD PTR [rsp+0xd8]
  9035d6:	mov    eax,0x0
  9035db:	sbb    eax,eax
  9035dd:	vmovd  xmm0,eax
  9035e1:	vpbroadcastd ymm0,xmm0
  9035e6:	vmovdqa YMMWORD PTR [rsp+0x4a0],ymm0
  9035ef:	vmovd  xmm0,DWORD PTR [rsp+0x6c]
  9035f5:	vpbroadcastd ymm0,xmm0
  9035fa:	vmovdqa YMMWORD PTR [rsp+0x4c0],ymm1
  903603:	vpandn ymm0,ymm0,ymm1
  903607:	vmovdqa YMMWORD PTR [rsp+0x5e0],ymm0
  903610:	mov    eax,r14d
  903613:	sub    eax,DWORD PTR [rsp+0x68]
  903617:	mov    ecx,eax
  903619:	sar    ecx,0x1f
  90361c:	imul   eax,DWORD PTR [rsp+0xd4]
  903624:	vmovd  xmm0,eax
  903628:	vpbroadcastd ymm0,xmm0
  90362d:	vmovdqa YMMWORD PTR [rsp+0x540],ymm0
  903636:	vmovd  xmm0,ecx
  90363a:	vpbroadcastd ymm0,xmm0
  90363f:	vmovdqa YMMWORD PTR [rsp+0x520],ymm0
  903648:	mov    rax,QWORD PTR [rsp+0x140]
  903650:	mov    QWORD PTR [rsp+0x98],rax
  903658:	xor    edi,edi
  90365a:	mov    rdx,QWORD PTR [rsp+0x20]
  90365f:	mov    QWORD PTR [rsp+0x170],rbx
  903667:	mov    rcx,QWORD PTR [rsp+0x50]
  90366c:	cmp    rdx,rcx
  90366f:	mov    r8,rcx
  903672:	mov    QWORD PTR [rsp+0x158],rdx
  90367a:	cmovb  r8,rdx
  90367e:	mov    rax,r8
  903681:	or     rax,r13
  903684:	shr    rax,0x20
  903688:	je     9036a0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x650>
  90368a:	mov    rax,r8
  90368d:	xor    edx,edx
  90368f:	div    r13
  903692:	mov    r14,rax
  903695:	jmp    9036ab <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x65b>
  903697:	nop    WORD PTR [rax+rax*1+0x0]
  9036a0:	mov    eax,r8d
  9036a3:	xor    edx,edx
  9036a5:	div    r13d
  9036a8:	mov    r14d,eax
  9036ab:	mov    QWORD PTR [rsp+0x160],rdi
  9036b3:	imul   rdi,rcx
  9036b7:	mov    QWORD PTR [rsp+0x108],rdi
  9036bf:	cmp    rdx,0x1
  9036c3:	sbb    r14,0xffffffffffffffff
  9036c7:	cmp    r14,0x40
  9036cb:	mov    eax,0x40
  9036d0:	cmovae r14,rax
  9036d4:	mov    QWORD PTR [rsp+0x150],r8
  9036dc:	lea    rax,[r8+r8*1]
  9036e0:	lea    rax,[rax+rax*2]
  9036e4:	mov    rcx,QWORD PTR [rsp+0x70]
  9036e9:	sub    rax,rcx
  9036ec:	mov    edx,0x0
  9036f1:	cmovb  rax,rdx
  9036f5:	mov    rdx,r14
  9036f8:	imul   rdx,QWORD PTR [rsp+0x78]
  9036fe:	cmp    rax,rdx
  903701:	cmovb  rdx,rax
  903705:	mov    QWORD PTR [rsp+0x168],rsi
  90370d:	add    rsi,rcx
  903710:	cmp    rdx,0x300
  903717:	mov    eax,0x300
  90371c:	cmovae rdx,rax
  903720:	mov    rdi,rbx
  903723:	vzeroupper
  903726:	call   QWORD PTR [rip+0x6de034]        # fe1760 <memcpy@GLIBC_2.14>
  90372c:	mov    QWORD PTR [rsp+0x148],r14
  903734:	lea    edx,[r14+0xf]
  903738:	shr    edx,0x4
  90373b:	mov    r12d,0x0
  903741:	vmovdqa xmm13,XMMWORD PTR [rsp+0x110]
  90374a:	je     904440 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x13f0>
  903750:	mov    rax,QWORD PTR [rsp+0x108]
  903758:	or     rax,QWORD PTR [rsp+0x18]
  90375d:	mov    QWORD PTR [rsp+0xc8],rax
  903765:	mov    r14d,0xc40
  90376b:	mov    r15d,0x2b
  903771:	mov    rdi,QWORD PTR [rsp+0x98]
  903779:	mov    rax,QWORD PTR [rsp+0xa0]
  903781:	mov    r13d,eax
  903784:	xor    r11d,r11d
  903787:	xor    r12d,r12d
  90378a:	mov    QWORD PTR [rsp+0x178],rdx
  903792:	jmp    903e57 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xe07>
  903797:	nop    WORD PTR [rax+rax*1+0x0]
  9037a0:	vpsrld ymm5,ymm2,0x1a
  9037a5:	vpaddd ymm2,ymm5,ymm2
  9037a9:	vpsrad ymm2,ymm2,0x6
  9037ae:	vmovdqa ymm5,YMMWORD PTR [rsp+0x4c0]
  9037b7:	vpaddd ymm0,ymm2,ymm5
  9037bb:	vmovdqa YMMWORD PTR [rsp+0x200],ymm0
  9037c4:	vpbroadcastd ymm11,DWORD PTR [rsp+0x470]
  9037ce:	vpand  ymm0,ymm11,ymm0
  9037d2:	vpsrld ymm9,ymm3,0x1a
  9037d7:	vpaddd ymm3,ymm9,ymm3
  9037db:	vpsrad ymm3,ymm3,0x6
  9037e0:	vpaddd ymm9,ymm3,ymm5
  9037e4:	vpand  ymm2,ymm9,ymm11
  9037e9:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm2
  9037f2:	vmovdqa YMMWORD PTR [rsp+0x800],ymm2
  9037fb:	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm0
  903804:	vmovdqa YMMWORD PTR [rsp+0x820],ymm0
  90380d:	vmovdqu YMMWORD PTR [rbx+r14*4-0x29e0],ymm0
  903817:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2a00],ymm2
  903821:	vpsrad ymm13,ymm8,0x1f
  903827:	vpsrld ymm13,ymm13,0x1a
  90382d:	vpaddd ymm13,ymm13,ymm8
  903832:	vpsrad ymm8,ymm7,0x1f
  903837:	vpsrld ymm8,ymm8,0x1a
  90383d:	vmovdqa XMMWORD PTR [rsp+0x440],xmm14
  903846:	vpaddd ymm14,ymm8,ymm7
  90384a:	vpsrld ymm7,ymm12,0x1a
  903850:	vpaddd ymm7,ymm12,ymm7
  903854:	vpsrad ymm7,ymm7,0x6
  903859:	vpaddd ymm12,ymm15,ymm7
  90385d:	vpand  ymm0,ymm12,ymm11
  903862:	vmovdqa YMMWORD PTR [rsp+0x1a0],ymm0
  90386b:	vpsrld ymm8,ymm10,0x1a
  903871:	vpaddd ymm8,ymm8,ymm10
  903876:	vpsrad ymm8,ymm8,0x6
  90387c:	vpaddd ymm10,ymm8,ymm1
  903880:	vpand  ymm8,ymm10,ymm11
  903885:	vmovdqa YMMWORD PTR [rsp+0x840],ymm8
  90388e:	vmovdqa YMMWORD PTR [rsp+0x860],ymm0
  903897:	lea    rax,[rsp+0x840]
  90389f:	vmovdqa ymm3,ymm15
  9038a3:	vmovdqa YMMWORD PTR [rsp+0x180],ymm15
  9038ac:	vmovaps ymm15,YMMWORD PTR [rax]
  9038b0:	vmovaps ymm0,YMMWORD PTR [rax+0x20]
  9038b5:	vmovups YMMWORD PTR [rbx+r14*4-0x28e0],ymm0
  9038bf:	vpsrad ymm0,ymm14,0x6
  9038c5:	vpaddd ymm0,ymm0,ymm5
  9038c9:	vmovups YMMWORD PTR [rbx+r14*4-0x2900],ymm15
  9038d3:	vpsrad ymm14,ymm6,0x1f
  9038d8:	vpsrld ymm14,ymm14,0x1a
  9038de:	vpaddd ymm6,ymm14,ymm6
  9038e2:	vpsrad ymm14,ymm4,0x1f
  9038e7:	vpsrld ymm14,ymm14,0x1a
  9038ed:	vpaddd ymm14,ymm14,ymm4
  9038f1:	vmovdqa ymm2,YMMWORD PTR [rsp+0x6e0]
  9038fa:	vpminud ymm4,ymm2,ymm0
  9038ff:	vpcmpeqd ymm4,ymm2,ymm4
  903903:	vpsrad ymm6,ymm6,0x6
  903908:	vpaddd ymm6,ymm6,ymm3
  90390c:	vmovdqa ymm7,ymm1
  903910:	vmovdqa ymm1,YMMWORD PTR [rsp+0x500]
  903919:	vpminud ymm15,ymm1,ymm6
  90391e:	vpcmpeqd ymm15,ymm15,ymm1
  903922:	vpor   ymm3,ymm15,ymm4
  903926:	vmovdqa YMMWORD PTR [rsp+0x240],ymm3
  90392f:	vpsrad ymm13,ymm13,0x6
  903935:	vpaddd ymm13,ymm13,ymm5
  903939:	vpminud ymm15,ymm2,ymm13
  90393e:	vpcmpeqd ymm15,ymm15,ymm2
  903942:	vpand  ymm3,ymm13,ymm11
  903947:	vmovdqa YMMWORD PTR [rsp+0x2a0],ymm3
  903950:	vpand  ymm0,ymm11,ymm0
  903954:	vmovdqa YMMWORD PTR [rsp+0x2c0],ymm0
  90395d:	vpand  ymm0,ymm11,ymm6
  903961:	vmovdqa YMMWORD PTR [rsp+0xe0],ymm0
  90396a:	vpsrad ymm0,ymm14,0x6
  903970:	vpaddd ymm0,ymm0,ymm7
  903974:	vpand  ymm3,ymm11,ymm0
  903978:	vmovdqa YMMWORD PTR [rsp+0x2e0],ymm3
  903981:	vpminud ymm0,ymm1,ymm0
  903986:	vpcmpeqd ymm0,ymm1,ymm0
  90398a:	vpor   ymm0,ymm15,ymm0
  90398e:	vmovdqa YMMWORD PTR [rsp+0x220],ymm0
  903997:	vpminud ymm0,ymm2,ymm9
  90399c:	vpcmpeqd ymm0,ymm2,ymm0
  9039a0:	vpminud ymm11,ymm1,ymm10
  9039a5:	vpcmpeqd ymm11,ymm11,ymm1
  9039a9:	vpor   ymm5,ymm11,ymm0
  9039ad:	vmovdqa ymm3,YMMWORD PTR [rsp+0x200]
  9039b6:	vpminud ymm0,ymm2,ymm3
  9039bb:	vpcmpeqd ymm0,ymm2,ymm0
  9039bf:	vpminud ymm11,ymm1,ymm12
  9039c4:	vpcmpeqd ymm11,ymm11,ymm1
  9039c8:	vpor   ymm11,ymm11,ymm0
  9039cc:	vmovdqa ymm15,YMMWORD PTR [rsp+0x760]
  9039d5:	vmovdqa ymm13,YMMWORD PTR [rsp+0x1c0]
  9039de:	vpsubd ymm0,ymm13,ymm15
  9039e3:	vmovdqa ymm1,YMMWORD PTR [rsp+0x740]
  9039ec:	vpmulld ymm14,ymm0,ymm1
  9039f1:	vpaddd ymm14,ymm14,ymm8
  9039f6:	vpsrad ymm0,ymm0,0x1f
  9039fb:	vpor   ymm0,ymm14,ymm0
  9039ff:	vmovdqa ymm4,YMMWORD PTR [rsp+0x1e0]
  903a08:	vpsubd ymm14,ymm4,ymm15
  903a0d:	vpmulld ymm15,ymm14,ymm1
  903a12:	vmovdqa ymm6,YMMWORD PTR [rsp+0x1a0]
  903a1b:	vpaddd ymm15,ymm15,ymm6
  903a1f:	vpsrad ymm14,ymm14,0x1f
  903a25:	vpor   ymm14,ymm15,ymm14
  903a2a:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2800],ymm0
  903a34:	vmovdqu YMMWORD PTR [rbx+r14*4-0x27e0],ymm14
  903a3e:	vmovdqa ymm14,YMMWORD PTR [rsp+0x780]
  903a47:	vpand  ymm0,ymm10,ymm14
  903a4c:	vmovdqa ymm1,YMMWORD PTR [rsp+0x720]
  903a55:	vpaddd ymm10,ymm7,ymm1
  903a59:	vpsubd ymm0,ymm10,ymm0
  903a5d:	vpand  ymm10,ymm12,ymm14
  903a62:	vmovdqa ymm15,YMMWORD PTR [rsp+0x180]
  903a6b:	vpaddd ymm12,ymm15,ymm1
  903a6f:	vpsubd ymm10,ymm12,ymm10
  903a74:	vpand  ymm9,ymm9,ymm14
  903a79:	vmovdqa ymm2,YMMWORD PTR [rsp+0x600]
  903a82:	vpcmpeqd ymm9,ymm9,ymm2
  903a86:	vmovdqa ymm1,YMMWORD PTR [rsp+0x700]
  903a8f:	vpminud ymm0,ymm1,ymm0
  903a94:	vpcmpeqd ymm0,ymm1,ymm0
  903a98:	vpandn ymm0,ymm0,ymm9
  903a9d:	vpandn ymm12,ymm5,ymm0
  903aa1:	vmovdqa YMMWORD PTR [rsp+0x420],ymm12
  903aaa:	vpand  ymm0,ymm14,ymm3
  903aae:	vpcmpeqd ymm0,ymm0,ymm2
  903ab2:	vpminud ymm5,ymm1,ymm10
  903ab7:	vpcmpeqd ymm5,ymm1,ymm5
  903abb:	vpandn ymm0,ymm5,ymm0
  903abf:	vpandn ymm10,ymm11,ymm0
  903ac3:	vmovdqa YMMWORD PTR [rsp+0x200],ymm10
  903acc:	vmovdqa ymm1,YMMWORD PTR [rsp+0x6a0]
  903ad5:	vpsubd ymm0,ymm13,ymm1
  903ad9:	vpsubd ymm2,ymm4,ymm1
  903add:	vmovdqa ymm9,YMMWORD PTR [rsp+0x640]
  903ae6:	vpmulld ymm3,ymm0,ymm9
  903aeb:	vpaddd ymm3,ymm8,ymm3
  903aef:	vpmulld ymm5,ymm2,ymm9
  903af4:	vpaddd ymm5,ymm5,ymm6
  903af8:	vpsrad ymm0,ymm0,0x1f
  903afd:	vpor   ymm0,ymm3,ymm0
  903b01:	vpbroadcastd ymm3,DWORD PTR [rip+0xffffffffff715146]        # 18c50 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  903b0a:	vpsrad ymm2,ymm2,0x1f
  903b0f:	vpor   ymm2,ymm5,ymm2
  903b13:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2700],ymm0
  903b1d:	vmovdqu YMMWORD PTR [rbx+r14*4-0x26e0],ymm2
  903b27:	vmovdqa ymm6,YMMWORD PTR [rsp+0x2a0]
  903b30:	vpsubd ymm0,ymm6,ymm1
  903b34:	vmovdqa ymm4,YMMWORD PTR [rsp+0x2c0]
  903b3d:	vpsubd ymm2,ymm4,ymm1
  903b41:	vpmulld ymm5,ymm0,ymm9
  903b46:	vpaddd ymm5,ymm5,YMMWORD PTR [rsp+0x2e0]
  903b4f:	vpsrad ymm0,ymm0,0x1f
  903b54:	vpor   ymm0,ymm5,ymm0
  903b58:	vpmulld ymm5,ymm2,ymm9
  903b5d:	vpaddd ymm5,ymm5,YMMWORD PTR [rsp+0xe0]
  903b66:	vpsrad ymm2,ymm2,0x1f
  903b6b:	vpor   ymm2,ymm5,ymm2
  903b6f:	vpand  ymm1,ymm12,ymm3
  903b73:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm1
  903b7c:	vpand  ymm1,ymm10,ymm3
  903b80:	vmovdqa YMMWORD PTR [rsp+0x1e0],ymm1
  903b89:	vmovdqa ymm5,YMMWORD PTR [rsp+0x6c0]
  903b92:	vpminud ymm1,ymm5,ymm7
  903b97:	vpcmpeqd ymm1,ymm5,ymm1
  903b9b:	vpminud ymm3,ymm5,ymm15
  903ba0:	vpcmpeqd ymm3,ymm5,ymm3
  903ba4:	vmovdqa ymm5,YMMWORD PTR [rsp+0x4a0]
  903bad:	vpandn ymm1,ymm1,ymm5
  903bb1:	vmovdqa YMMWORD PTR [rsp+0x180],ymm1
  903bba:	vpandn ymm1,ymm3,ymm5
  903bbe:	vmovdqa YMMWORD PTR [rsp+0x1a0],ymm1
  903bc7:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2600],ymm0
  903bd1:	vmovdqu YMMWORD PTR [rbx+r14*4-0x25e0],ymm2
  903bdb:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4e0]
  903be4:	vpminud ymm0,ymm1,ymm0
  903be9:	vpcmpeqd ymm0,ymm1,ymm0
  903bed:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0x220]
  903bf6:	vmovdqa YMMWORD PTR [rsp+0x220],ymm0
  903bff:	vpminud ymm0,ymm1,ymm2
  903c04:	vpcmpeqd ymm0,ymm1,ymm0
  903c08:	vpor   ymm0,ymm0,YMMWORD PTR [rsp+0x240]
  903c11:	vmovdqa YMMWORD PTR [rsp+0x400],ymm0
  903c1a:	mov    edx,DWORD PTR [rsp+0x6c]
  903c1e:	mov    eax,edx
  903c20:	not    eax
  903c22:	vmovd  xmm0,eax
  903c26:	vpbroadcastd ymm0,xmm0
  903c2b:	vpand  ymm1,ymm6,ymm0
  903c2f:	vpand  ymm0,ymm4,ymm0
  903c33:	vmovdqa ymm2,YMMWORD PTR [rsp+0x5e0]
  903c3c:	vpcmpeqd ymm1,ymm2,ymm1
  903c40:	vmovdqa YMMWORD PTR [rsp+0x3e0],ymm1
  903c49:	vpcmpeqd ymm0,ymm2,ymm0
  903c4d:	vmovdqa YMMWORD PTR [rsp+0x260],ymm0
  903c56:	mov    QWORD PTR [rsp+0x240],rdi
  903c5e:	lea    rdi,[rsp+0x300]
  903c66:	lea    rsi,[rsp+0x800]
  903c6e:	mov    rbx,r11
  903c71:	vzeroupper
  903c74:	call   4be3c0 <_RINvMsm_NtCs8uuN1nrGffB_4core5arrayAINtNtNtCscIM9z48VHAb_13fearless_simd9generated10simd_types6i32x16NtNtBD_4avx24Avx2Ej2_7try_mapINtNtNtB8_3ops9try_trait17NeverShortCircuitBy_ENCINvMB27_B24_10wrap_mut_1By_NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesB1B_Kb1_Es4_0E0EB3x_>
  903c79:	vmovdqa xmm14,XMMWORD PTR [rsp+0x440]
  903c82:	mov    r11,rbx
  903c85:	mov    rdi,QWORD PTR [rsp+0x240]
  903c8d:	mov    rbx,QWORD PTR [rsp+0x170]
  903c95:	mov    rdx,QWORD PTR [rsp+0x178]
  903c9d:	vmovdqa xmm13,XMMWORD PTR [rsp+0x110]
  903ca6:	vmovdqa ymm0,YMMWORD PTR [rsp+0x2a0]
  903caf:	vpsubd ymm0,ymm0,YMMWORD PTR [rsp+0x300]
  903cb8:	vmovdqa ymm2,YMMWORD PTR [rsp+0x660]
  903cc1:	vpaddd ymm1,ymm2,YMMWORD PTR [rsp+0x2e0]
  903cca:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x340]
  903cd3:	vmovdqa ymm3,YMMWORD PTR [rsp+0x680]
  903cdc:	vpminud ymm0,ymm3,ymm0
  903ce1:	vpcmpeqd ymm0,ymm3,ymm0
  903ce5:	vmovdqa ymm4,YMMWORD PTR [rsp+0x620]
  903cee:	vpminud ymm1,ymm4,ymm1
  903cf3:	vpcmpeqd ymm1,ymm4,ymm1
  903cf7:	vpor   ymm0,ymm0,ymm1
  903cfb:	vmovdqa ymm1,YMMWORD PTR [rsp+0x2c0]
  903d04:	vpsubd ymm1,ymm1,YMMWORD PTR [rsp+0x320]
  903d0d:	vpaddd ymm2,ymm2,YMMWORD PTR [rsp+0xe0]
  903d16:	vpsubd ymm2,ymm2,YMMWORD PTR [rsp+0x360]
  903d1f:	vpminud ymm1,ymm3,ymm1
  903d24:	vpcmpeqd ymm1,ymm3,ymm1
  903d28:	vpminud ymm2,ymm4,ymm2
  903d2d:	vpcmpeqd ymm2,ymm4,ymm2
  903d31:	vpor   ymm1,ymm1,ymm2
  903d35:	vmovdqa ymm4,YMMWORD PTR [rsp+0x220]
  903d3e:	vpandn ymm2,ymm4,YMMWORD PTR [rsp+0x3e0]
  903d47:	vmovdqa ymm5,YMMWORD PTR [rsp+0x400]
  903d50:	vpandn ymm3,ymm5,YMMWORD PTR [rsp+0x260]
  903d59:	vpsrld ymm2,ymm2,0x1f
  903d5e:	vpor   ymm0,ymm0,ymm4
  903d62:	vpor   ymm1,ymm1,ymm5
  903d66:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff7150f9]        # 18e68 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1449>
  903d6f:	vpandn ymm0,ymm0,ymm4
  903d73:	vpandn ymm1,ymm1,ymm4
  903d77:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff7152c0]        # 19040 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  903d80:	vmovdqa ymm7,YMMWORD PTR [rsp+0x180]
  903d89:	vpand  ymm5,ymm7,ymm4
  903d8d:	vpor   ymm2,ymm2,ymm5
  903d91:	vpor   ymm2,ymm2,YMMWORD PTR [rsp+0x1c0]
  903d9a:	vpsrld ymm3,ymm3,0x1f
  903d9f:	vmovdqa ymm6,YMMWORD PTR [rsp+0x1a0]
  903da8:	vpand  ymm4,ymm6,ymm4
  903dac:	vpor   ymm3,ymm3,ymm4
  903db0:	vpor   ymm3,ymm3,YMMWORD PTR [rsp+0x1e0]
  903db9:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffff7150ce]        # 18e90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  903dc2:	vpand  ymm5,ymm7,ymm4
  903dc6:	vpand  ymm5,ymm5,YMMWORD PTR [rsp+0x420]
  903dcf:	vpor   ymm0,ymm5,ymm0
  903dd3:	vpor   ymm0,ymm2,ymm0
  903dd7:	vpand  ymm2,ymm6,ymm4
  903ddb:	vpand  ymm2,ymm2,YMMWORD PTR [rsp+0x200]
  903de4:	vpor   ymm1,ymm2,ymm1
  903de8:	vpor   ymm1,ymm3,ymm1
  903dec:	lea    rax,[r14-0xc40]
  903df3:	vpor   xmm2,xmm14,XMMWORD PTR [rip+0xffffffffff7113f5]        # 151f0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0xeb0>
  903dfb:	vextracti128 xmm3,ymm1,0x1
  903e01:	vpackssdw xmm1,xmm1,xmm3
  903e05:	vextracti128 xmm3,ymm0,0x1
  903e0b:	vpackssdw xmm0,xmm0,xmm3
  903e0f:	vpacksswb xmm0,xmm0,xmm1
  903e13:	vpand  xmm0,xmm2,xmm0
  903e17:	vmovdqu XMMWORD PTR [rbx+r14*1],xmm0
  903e1d:	vpand  xmm0,xmm13,xmm0
  903e21:	vpxor  xmm1,xmm1,xmm1
  903e25:	vpcmpeqb xmm0,xmm0,xmm1
  903e29:	vpmovmskb ecx,xmm0
  903e2d:	xor    ecx,0xffff
  903e33:	shlx   rax,rcx,rax
  903e38:	or     r12,rax
  903e3b:	inc    r11
  903e3e:	add    r14,0x10
  903e42:	add    r15,0x30
  903e46:	add    r13d,DWORD PTR [rsp+0x130]
  903e4e:	cmp    r11,rdx
  903e51:	jae    904440 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x13f0>
  903e57:	add    rdi,QWORD PTR [rsp+0x3c0]
  903e5f:	cmp    rdi,0x7fffffff
  903e66:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  903e6c:	cmp    QWORD PTR [rsp+0x280],0x1
  903e75:	jne    903f30 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xee0>
  903e7b:	vmovdqu xmm0,XMMWORD PTR [rbx+r15*2-0x56]
  903e82:	vmovdqu xmm1,XMMWORD PTR [rbx+r15*2-0x50]
  903e89:	vmovdqu xmm2,XMMWORD PTR [rbx+r15*2-0x26]
  903e90:	vmovdqu xmm3,XMMWORD PTR [rbx+r15*2-0x20]
  903e97:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r15*2-0x46],0x4
  903e9f:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r15*2-0x36],0x2
  903ea7:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r15*2-0x16],0x4
  903eaf:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r15*2-0x6],0x2
  903eb7:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r15*2-0x40],0x4
  903ebf:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r15*2-0x30],0x2
  903ec7:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r15*2-0x10],0x4
  903ecf:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r15*2],0x2
  903ed6:	vmovq  xmm6,QWORD PTR [rip+0xffffffffff712882]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  903ede:	vpshufb xmm4,xmm1,xmm6
  903ee3:	vpshufb xmm5,xmm0,xmm6
  903ee8:	vpunpcklbw xmm4,xmm5,xmm4
  903eec:	vpshufb xmm5,xmm3,xmm6
  903ef1:	vpshufb xmm6,xmm2,xmm6
  903ef6:	vpunpcklbw xmm5,xmm6,xmm5
  903efa:	vmovd  xmm6,DWORD PTR [rip+0xffffffffff7109ce]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x590>
  903f02:	vpshufb xmm1,xmm1,xmm6
  903f07:	vpshufb xmm0,xmm0,xmm6
  903f0c:	vpunpcklbw xmm0,xmm0,xmm1
  903f10:	vpshufb xmm1,xmm3,xmm6
  903f15:	vpshufb xmm2,xmm2,xmm6
  903f1a:	vpunpcklbw xmm1,xmm2,xmm1
  903f1e:	jmp    903fe9 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xf99>
  903f23:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  903f30:	vmovdqu xmm0,XMMWORD PTR [rbx+r15*4-0xac]
  903f3a:	vmovdqu xmm1,XMMWORD PTR [rbx+r15*4-0x8c]
  903f44:	vmovdqu xmm2,XMMWORD PTR [rbx+r15*4-0x7c]
  903f4b:	vmovdqu xmm3,XMMWORD PTR [rbx+r15*4-0x5c]
  903f52:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r15*4-0x9c],0x4
  903f5d:	vmovdqa xmm5,XMMWORD PTR [rip+0xffffffffff7121ab]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  903f65:	vpshufb xmm1,xmm1,xmm5
  903f6a:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff7133ae]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  903f72:	vpshufb xmm0,xmm0,xmm6
  903f77:	vpor   xmm0,xmm0,xmm1
  903f7b:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+r15*4-0x6c],0x4
  903f83:	vpshufb xmm2,xmm3,xmm5
  903f88:	vpshufb xmm1,xmm1,xmm6
  903f8d:	vpor   xmm1,xmm1,xmm2
  903f91:	vmovdqu xmm2,XMMWORD PTR [rbx+r15*4-0x2c]
  903f98:	vmovdqu xmm3,XMMWORD PTR [rbx+r15*4-0x4c]
  903f9f:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r15*4-0x3c],0x4
  903fa7:	vpshufb xmm2,xmm2,xmm5
  903fac:	vpshufb xmm3,xmm3,xmm6
  903fb1:	vpor   xmm2,xmm3,xmm2
  903fb5:	vmovdqu xmm3,XMMWORD PTR [rbx+r15*4+0x4]
  903fbc:	vmovdqu xmm4,XMMWORD PTR [rbx+r15*4-0x1c]
  903fc3:	vpblendd xmm4,xmm4,XMMWORD PTR [rbx+r15*4-0xc],0x4
  903fcb:	vpshufb xmm3,xmm3,xmm5
  903fd0:	vpshufb xmm4,xmm4,xmm6
  903fd5:	vpor   xmm3,xmm4,xmm3
  903fd9:	vpunpckldq xmm4,xmm0,xmm1
  903fdd:	vpunpckldq xmm5,xmm2,xmm3
  903fe1:	vpunpckhdq xmm0,xmm0,xmm1
  903fe5:	vpunpckhdq xmm1,xmm2,xmm3
  903fe9:	vpunpcklqdq xmm0,xmm0,xmm1
  903fed:	vpunpcklqdq xmm1,xmm4,xmm5
  903ff1:	vpunpckhqdq xmm3,xmm4,xmm5
  903ff5:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70ffb3]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  903ffd:	vmovdqa xmm4,XMMWORD PTR [rsp+0x120]
  904006:	vpshufb xmm14,xmm4,xmm2
  90400b:	vptest xmm14,xmm13
  904010:	je     903e3b <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xdeb>
  904016:	vmovdqu XMMWORD PTR [rbx+r14*1-0x40],xmm1
  90401d:	vmovdqa xmm1,XMMWORD PTR [rsp+0x490]
  904026:	vpshufb xmm4,xmm1,xmm2
  90402b:	vmovdqa xmm1,XMMWORD PTR [rsp+0x480]
  904034:	vpshufb xmm2,xmm1,xmm2
  904039:	vpunpcklbw xmm1,xmm4,xmm2
  90403d:	vpunpckhbw xmm2,xmm4,xmm2
  904041:	vpmovsxbw ymm3,xmm3
  904046:	vpmovsxwd ymm4,xmm3
  90404b:	vextracti128 xmm3,ymm3,0x1
  904051:	vpmovsxwd ymm3,xmm3
  904056:	vpabsd ymm5,ymm4
  90405b:	vpabsd ymm6,ymm3
  904060:	vpsrld ymm7,ymm5,0x4
  904065:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff714f02]        # 18f70 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  90406e:	vpsrld ymm8,ymm6,0x4
  904073:	vpmaxud ymm7,ymm7,ymm9
  904078:	vpcmpeqd ymm11,ymm11,ymm11
  90407d:	vpaddd ymm7,ymm11,ymm7
  904081:	vpmaxud ymm8,ymm8,ymm9
  904086:	vpaddd ymm8,ymm8,ymm11
  90408b:	vpslld ymm10,ymm7,0x4
  904090:	vpsubd ymm5,ymm5,ymm10
  904095:	vpslld ymm10,ymm8,0x4
  90409b:	vpsubd ymm6,ymm6,ymm10
  9040a0:	vpsllvd ymm5,ymm5,ymm7
  9040a5:	vpsllvd ymm6,ymm6,ymm8
  9040aa:	vpsrad ymm4,ymm4,0x1f
  9040af:	vpsrad ymm3,ymm3,0x1f
  9040b4:	vpxor  ymm5,ymm5,ymm4
  9040b8:	vpxor  ymm6,ymm6,ymm3
  9040bc:	vpsubd ymm8,ymm5,ymm4
  9040c0:	vpsubd ymm7,ymm6,ymm3
  9040c4:	vpmovsxbw ymm0,xmm0
  9040c9:	vpmovsxwd ymm3,xmm0
  9040ce:	vextracti128 xmm0,ymm0,0x1
  9040d4:	vpmovsxwd ymm0,xmm0
  9040d9:	vpabsd ymm4,ymm3
  9040de:	vpabsd ymm5,ymm0
  9040e3:	vpsrld ymm6,ymm4,0x4
  9040e8:	vpsrld ymm10,ymm5,0x4
  9040ed:	vpmaxud ymm6,ymm6,ymm9
  9040f2:	vpaddd ymm6,ymm11,ymm6
  9040f6:	vpmaxud ymm9,ymm10,ymm9
  9040fb:	vpaddd ymm9,ymm9,ymm11
  904100:	vpslld ymm10,ymm6,0x4
  904105:	vpsubd ymm4,ymm4,ymm10
  90410a:	vpslld ymm10,ymm9,0x4
  904110:	vpsubd ymm5,ymm5,ymm10
  904115:	vpmovsxwd ymm1,xmm1
  90411a:	vpmovsxwd ymm2,xmm2
  90411f:	vmovdqa ymm10,YMMWORD PTR [rsp+0x7a0]
  904128:	vpmulld ymm1,ymm10,ymm1
  90412d:	vpmulld ymm2,ymm10,ymm2
  904132:	vpsllvd ymm4,ymm4,ymm6
  904137:	vpsllvd ymm5,ymm5,ymm9
  90413c:	vpsrad ymm3,ymm3,0x1f
  904141:	vpsrad ymm0,ymm0,0x1f
  904146:	vpxor  ymm4,ymm4,ymm3
  90414a:	vpxor  ymm5,ymm5,ymm0
  90414e:	vpsubd ymm4,ymm4,ymm3
  904152:	vpsubd ymm6,ymm5,ymm0
  904156:	vpmulld ymm0,ymm1,ymm8
  90415b:	vpmulld ymm3,ymm2,ymm7
  904160:	vpsrad ymm5,ymm0,0x1f
  904165:	vpbroadcastd ymm9,DWORD PTR [rip+0xffffffffff714e3a]        # 18fa8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  90416e:	vpaddd ymm0,ymm9,ymm0
  904172:	vpaddd ymm5,ymm0,ymm5
  904176:	vpsrad ymm0,ymm3,0x1f
  90417b:	vpaddd ymm3,ymm9,ymm3
  90417f:	vpaddd ymm10,ymm3,ymm0
  904183:	vpmulld ymm0,ymm1,ymm4
  904188:	vpsrad ymm1,ymm0,0x1f
  90418d:	vpaddd ymm0,ymm9,ymm0
  904191:	vpaddd ymm11,ymm0,ymm1
  904195:	vmovd  xmm0,r13d
  90419a:	vpbroadcastd ymm0,xmm0
  90419f:	vpmulld ymm1,ymm2,ymm6
  9041a4:	vpaddd ymm2,ymm9,ymm1
  9041a8:	vpsrad ymm1,ymm1,0x1f
  9041ad:	vpaddd ymm9,ymm2,ymm1
  9041b1:	vpaddd ymm1,ymm0,YMMWORD PTR [rsp+0x7c0]
  9041ba:	vpaddd ymm15,ymm0,YMMWORD PTR [rsp+0x7e0]
  9041c3:	vpsrad ymm3,ymm5,0xe
  9041c8:	vpsrad ymm2,ymm10,0xe
  9041ce:	vpsrad ymm10,ymm11,0xe
  9041d4:	vpsrad ymm12,ymm9,0xe
  9041da:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2e00],ymm8
  9041e4:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2de0],ymm7
  9041ee:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2c00],ymm3
  9041f8:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2be0],ymm2
  904202:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2d00],ymm4
  90420c:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2ce0],ymm6
  904216:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2b00],ymm10
  904220:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2ae0],ymm12
  90422a:	mov    rax,QWORD PTR [rsp+0xc8]
  904232:	test   QWORD PTR [rsp+0x58],rax
  904237:	jne    9037a0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x750>
  90423d:	vpabsd ymm5,ymm6
  904242:	vpabsd ymm9,ymm4
  904247:	vpabsd ymm11,ymm7
  90424c:	vpor   ymm5,ymm11,ymm5
  904250:	vpabsd ymm11,ymm8
  904255:	vpor   ymm9,ymm9,ymm11
  90425a:	vpabsd ymm11,ymm3
  90425f:	vpor   ymm9,ymm9,ymm11
  904264:	vpabsd ymm11,ymm2
  904269:	vpor   ymm5,ymm11,ymm5
  90426d:	vpabsd ymm11,ymm12
  904272:	vpor   ymm5,ymm11,ymm5
  904276:	vpabsd ymm11,ymm10
  90427b:	vpor   ymm9,ymm9,ymm11
  904280:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff714b6f]        # 18df8 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x13d9>
  904289:	vpcmpgtd ymm5,ymm5,ymm11
  90428e:	vpcmpgtd ymm9,ymm9,ymm11
  904293:	vpackssdw ymm5,ymm9,ymm5
  904297:	vpmovmskb eax,ymm5
  90429b:	test   eax,eax
  90429d:	jne    9037a0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x750>
  9042a3:	vmovaps ymm0,YMMWORD PTR [rsp+0x4c0]
  9042ac:	vmovups YMMWORD PTR [rbx+r14*4-0x2a00],ymm0
  9042b6:	vmovups YMMWORD PTR [rbx+r14*4-0x29e0],ymm0
  9042c0:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2900],ymm1
  9042ca:	vmovdqu YMMWORD PTR [rbx+r14*4-0x28e0],ymm15
  9042d4:	vmovdqa ymm0,YMMWORD PTR [rsp+0x580]
  9042dd:	vpaddd ymm2,ymm1,ymm0
  9042e1:	vpaddd ymm3,ymm15,ymm0
  9042e5:	vmovdqa ymm0,YMMWORD PTR [rsp+0x560]
  9042ee:	vpor   ymm2,ymm2,ymm0
  9042f2:	vpor   ymm3,ymm3,ymm0
  9042f6:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2800],ymm2
  904300:	vmovdqu YMMWORD PTR [rbx+r14*4-0x27e0],ymm3
  90430a:	vmovdqa ymm0,YMMWORD PTR [rsp+0x500]
  904313:	vpminud ymm2,ymm0,ymm1
  904318:	vpcmpeqd ymm2,ymm0,ymm2
  90431c:	vpminud ymm3,ymm0,ymm15
  904321:	vpcmpeqd ymm4,ymm0,ymm3
  904325:	vmovdqa ymm0,YMMWORD PTR [rsp+0x5a0]
  90432e:	vpandn ymm3,ymm2,ymm0
  904332:	vpandn ymm2,ymm4,ymm0
  904336:	vmovdqa ymm0,YMMWORD PTR [rsp+0x5c0]
  90433f:	vpminud ymm4,ymm0,ymm1
  904344:	vpcmpeqd ymm4,ymm0,ymm4
  904348:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffff7148ff]        # 18c50 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  904351:	vmovdqa ymm9,ymm1
  904355:	vmovdqa ymm1,YMMWORD PTR [rsp+0x4a0]
  90435e:	vpandn ymm4,ymm4,ymm1
  904362:	vpand  ymm6,ymm3,ymm5
  904366:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffff714cd1]        # 19040 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x1a0>
  90436f:	vpand  ymm8,ymm4,ymm7
  904373:	vpor   ymm6,ymm8,ymm6
  904377:	vpminud ymm8,ymm0,ymm15
  90437c:	vpcmpeqd ymm8,ymm8,ymm0
  904380:	vpandn ymm8,ymm8,ymm1
  904384:	vpand  ymm5,ymm2,ymm5
  904388:	vpand  ymm7,ymm8,ymm7
  90438c:	vpor   ymm5,ymm7,ymm5
  904390:	vmovdqa ymm0,YMMWORD PTR [rsp+0x540]
  904399:	vpaddd ymm1,ymm9,ymm0
  90439d:	vpaddd ymm0,ymm15,ymm0
  9043a1:	vmovdqa ymm7,YMMWORD PTR [rsp+0x520]
  9043aa:	vpor   ymm1,ymm1,ymm7
  9043ae:	vpor   ymm0,ymm0,ymm7
  9043b2:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2700],ymm1
  9043bc:	vmovdqu YMMWORD PTR [rbx+r14*4-0x26e0],ymm0
  9043c6:	vmovdqu YMMWORD PTR [rbx+r14*4-0x2600],ymm1
  9043d0:	vmovdqa ymm7,YMMWORD PTR [rsp+0x4e0]
  9043d9:	vpminud ymm1,ymm7,ymm1
  9043de:	vpcmpeqd ymm1,ymm7,ymm1
  9043e2:	vpandn ymm1,ymm1,ymm3
  9043e6:	vpand  ymm3,ymm4,ymm3
  9043ea:	vmovdqu YMMWORD PTR [rbx+r14*4-0x25e0],ymm0
  9043f4:	vpminud ymm0,ymm7,ymm0
  9043f9:	vpcmpeqd ymm0,ymm7,ymm0
  9043fd:	vpandn ymm4,ymm0,ymm2
  904401:	vpand  ymm0,ymm8,ymm2
  904405:	vpbroadcastd ymm2,DWORD PTR [rip+0xffffffffff714a82]        # 18e90 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1471>
  90440e:	vpand  ymm3,ymm3,ymm2
  904412:	vpor   ymm3,ymm6,ymm3
  904416:	vpand  ymm0,ymm0,ymm2
  90441a:	vpor   ymm2,ymm5,ymm0
  90441e:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffff714a49]        # 18e70 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1451>
  904427:	vpand  ymm0,ymm1,ymm5
  90442b:	vpor   ymm0,ymm3,ymm0
  90442f:	vpand  ymm1,ymm4,ymm5
  904433:	vpor   ymm1,ymm2,ymm1
  904437:	jmp    903dec <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0xd9c>
  90443c:	nop    DWORD PTR [rax+0x0]
  904440:	mov    rax,QWORD PTR [rsp+0x148]
  904448:	cmp    rax,0x1
  90444c:	adc    rax,0x0
  904450:	bzhi   rax,r12,rax
  904455:	mov    QWORD PTR [rsp+0x300],rbx
  90445d:	mov    QWORD PTR [rsp+0x308],rax
  904465:	mov    r14,QWORD PTR [rsp+0x18]
  90446a:	mov    QWORD PTR [rsp+0x310],r14
  904472:	mov    rax,QWORD PTR [rsp+0x108]
  90447a:	mov    QWORD PTR [rsp+0x318],rax
  904482:	mov    r13,QWORD PTR [rsp+0x280]
  90448a:	mov    QWORD PTR [rsp+0x320],r13
  904492:	test   BYTE PTR [rsp+0xb8],0x1
  90449a:	je     9044d0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1480>
  90449c:	lea    rdi,[rsp+0x300]
  9044a4:	mov    rsi,QWORD PTR [rsp+0xb0]
  9044ac:	mov    rdx,QWORD PTR [rsp+0xc0]
  9044b4:	mov    rcx,QWORD PTR [rsp+0xa8]
  9044bc:	vzeroupper
  9044bf:	call   QWORD PTR [rip+0x6de8b3]        # fe2d78 <_DYNAMIC+0x1850>
  9044c5:	jmp    9044f9 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x14a9>
  9044c7:	nop    WORD PTR [rax+rax*1+0x0]
  9044d0:	lea    rdi,[rsp+0x300]
  9044d8:	mov    rsi,QWORD PTR [rsp+0xb0]
  9044e0:	mov    rdx,QWORD PTR [rsp+0xc0]
  9044e8:	mov    rcx,QWORD PTR [rsp+0xa8]
  9044f0:	vzeroupper
  9044f3:	call   QWORD PTR [rip+0x6de877]        # fe2d70 <_DYNAMIC+0x1848>
  9044f9:	mov    r12d,DWORD PTR [rsp+0x64]
  9044fe:	mov    rcx,QWORD PTR [rsp+0x150]
  904506:	lea    rax,[rcx+rcx*2]
  90450a:	mov    rsi,QWORD PTR [rsp+0x168]
  904512:	lea    rsi,[rsi+rax*2]
  904516:	mov    rdx,QWORD PTR [rsp+0x158]
  90451e:	sub    rdx,rcx
  904521:	mov    rdi,QWORD PTR [rsp+0x160]
  904529:	inc    rdi
  90452c:	mov    rax,QWORD PTR [rsp+0xa0]
  904534:	add    eax,DWORD PTR [rsp+0xdc]
  90453b:	mov    QWORD PTR [rsp+0xa0],rax
  904543:	mov    rax,QWORD PTR [rsp+0x98]
  90454b:	add    rax,QWORD PTR [rsp+0x50]
  904550:	mov    QWORD PTR [rsp+0x98],rax
  904558:	test   rdx,rdx
  90455b:	jne    903667 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x617>
  904561:	jmp    903470 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x420>
  904566:	vmovd  xmm0,r13d
  90456b:	vpbroadcastd ymm0,xmm0
  904570:	vpmulld ymm4,ymm0,YMMWORD PTR [rip+0xffffffffff715e67]        # 1a3e0 <anon.db13f839740d960fd97bc530122b4c99.104.llvm.5594421697515501092+0x4c8>
  904579:	vmovdqa YMMWORD PTR [rsp+0x3c0],ymm4
  904582:	vpmulld xmm1,xmm0,XMMWORD PTR [rip+0xffffffffff70fa15]        # 13fa0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6ee>
  90458b:	vpmulld xmm2,xmm0,XMMWORD PTR [rip+0xffffffffff71281c]        # 16db0 <anon.43d21acec09d19046152b53125a552af.1615.llvm.7158842796534594082+0x3e0>
  904594:	not    r8d
  904597:	vmovd  xmm5,r8d
  90459c:	mov    rax,QWORD PTR [rsp+0xb8]
  9045a4:	shl    al,0x3
  9045a7:	or     al,0x4
  9045a9:	vmovd  xmm3,eax
  9045ad:	vpbroadcastb xmm3,xmm3
  9045b2:	vmovdqa XMMWORD PTR [rsp+0x130],xmm3
  9045bb:	vpxor  xmm3,xmm3,xmm3
  9045bf:	vpblendd xmm0,xmm3,xmm0,0x2
  9045c5:	vpermq ymm2,ymm2,0xd0
  9045cb:	vpblendd ymm0,ymm2,ymm0,0x3
  9045d1:	vpbroadcastq ymm1,xmm1
  9045d6:	vpblendd ymm1,ymm0,ymm1,0xc0
  9045dc:	lea    r15,[rbx+0x300]
  9045e3:	mov    rax,QWORD PTR [rsp+0x58]
  9045e8:	not    eax
  9045ea:	vmovd  xmm0,eax
  9045ee:	vmovdqa XMMWORD PTR [rsp+0x110],xmm5
  9045f7:	vmovdqa XMMWORD PTR [rsp+0x2c0],xmm0
  904600:	vpand  xmm0,xmm5,xmm0
  904604:	vpbroadcastd ymm0,xmm0
  904609:	vmovdqa YMMWORD PTR [rsp+0x2a0],ymm0
  904612:	vmovss xmm0,DWORD PTR [rsp+0x30]
  904618:	vbroadcastss ymm0,xmm0
  90461d:	vmovaps YMMWORD PTR [rsp+0x280],ymm0
  904626:	vmovd  xmm0,r12d
  90462b:	vpbroadcastd ymm0,xmm0
  904630:	vmovdqa YMMWORD PTR [rsp+0x240],ymm0
  904639:	vmovd  xmm0,edi
  90463d:	vpbroadcastd ymm0,xmm0
  904642:	vmovdqa YMMWORD PTR [rsp+0x2e0],ymm1
  90464b:	vpaddd ymm1,ymm1,ymm0
  90464f:	vmovdqa YMMWORD PTR [rsp+0x440],ymm1
  904658:	vpaddd ymm0,ymm4,ymm0
  90465c:	vmovdqa YMMWORD PTR [rsp+0x220],ymm0
  904665:	vmovd  xmm0,esi
  904669:	vpbroadcastd ymm0,xmm0
  90466e:	vmovdqa YMMWORD PTR [rsp+0x200],ymm0
  904677:	vmovss xmm0,DWORD PTR [rsp+0x34]
  90467d:	vbroadcastss ymm0,xmm0
  904682:	vmovaps YMMWORD PTR [rsp+0x1e0],ymm0
  90468b:	vmovd  xmm0,ecx
  90468f:	vpbroadcastd ymm0,xmm0
  904694:	vmovdqa YMMWORD PTR [rsp+0x1c0],ymm0
  90469d:	vmovaps xmm0,XMMWORD PTR [rsp+0x380]
  9046a6:	vmovaps XMMWORD PTR [rsp+0x420],xmm0
  9046af:	vmovaps xmm0,XMMWORD PTR [rsp+0x390]
  9046b8:	vmovaps XMMWORD PTR [rsp+0x1a0],xmm0
  9046c1:	vmovaps xmm0,XMMWORD PTR [rsp+0x3a0]
  9046ca:	vmovaps XMMWORD PTR [rsp+0xe0],xmm0
  9046d3:	vpbroadcastd ymm0,DWORD PTR [rsp+0x3b0]
  9046dd:	vmovdqa YMMWORD PTR [rsp+0x180],ymm0
  9046e6:	jmp    904706 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16b6>
  9046e8:	nop    DWORD PTR [rax+rax*1+0x0]
  9046f0:	add    r14,r13
  9046f3:	mov    QWORD PTR [rsp+0x18],r14
  9046f8:	dec    QWORD PTR [rsp+0x88]
  904700:	je     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  904706:	mov    r14,QWORD PTR [rsp+0x18]
  90470b:	mov    rax,r14
  90470e:	sub    rax,QWORD PTR [rsp+0x40]
  904713:	jb     9046f0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16a0>
  904715:	mul    QWORD PTR [rsp+0x20]
  90471a:	jo     9046f0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16a0>
  90471c:	mov    rcx,rax
  90471f:	add    rcx,QWORD PTR [rsp+0x20]
  904724:	jb     9046f0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16a0>
  904726:	mov    rdx,QWORD PTR [rsp+0x80]
  90472e:	test   rdx,rdx
  904731:	je     90474c <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16fc>
  904733:	cmp    edx,0x1
  904736:	jne    90475d <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x170d>
  904738:	mov    rsi,QWORD PTR [rsp+0x38]
  90473d:	mov    rdx,QWORD PTR [rsi+0x18]
  904741:	mov    rsi,QWORD PTR [rsi+0x20]
  904745:	cmp    rcx,rsi
  904748:	ja     9046f0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16a0>
  90474a:	jmp    9047ba <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x176a>
  90474c:	mov    rsi,QWORD PTR [rsp+0x28]
  904751:	mov    rdx,QWORD PTR [rsp+0x48]
  904756:	cmp    rcx,rsi
  904759:	ja     9046f0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16a0>
  90475b:	jmp    9047ba <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x176a>
  90475d:	mov    rdx,QWORD PTR [rsp+0x28]
  904762:	cmp    BYTE PTR [rdx+0x10],0x0
  904766:	je     904771 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1721>
  904768:	mov    edx,0x1
  90476d:	xor    esi,esi
  90476f:	jmp    90477c <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x172c>
  904771:	mov    rsi,rdx
  904774:	mov    rdx,QWORD PTR [rdx+0x20]
  904778:	mov    rsi,QWORD PTR [rsi+0x28]
  90477c:	cmp    QWORD PTR [rsp+0x48],rsi
  904781:	seta   sil
  904785:	or     sil,BYTE PTR [rsp+0x17]
  90478a:	mov    rsi,QWORD PTR [rsp+0x38]
  90478f:	lea    rsi,[rsi+rsi*2]
  904793:	lea    rdx,[rdx+rsi*2]
  904797:	mov    rsi,QWORD PTR [rsp+0x90]
  90479f:	mov    edi,0x0
  9047a4:	cmovne rsi,rdi
  9047a8:	mov    edi,0x1
  9047ad:	cmovne rdx,rdi
  9047b1:	cmp    rcx,rsi
  9047b4:	ja     9046f0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16a0>
  9047ba:	lea    rax,[rax+rax*2]
  9047be:	lea    rsi,[rdx+rax*2]
  9047c2:	cmp    r14,0x7fffffff
  9047c9:	ja     905730 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x26e0>
  9047cf:	vmovd  xmm0,r14d
  9047d4:	vpbroadcastd ymm0,xmm0
  9047d9:	vmovdqa YMMWORD PTR [rsp+0x400],ymm0
  9047e2:	vpand  xmm0,xmm0,XMMWORD PTR [rsp+0x110]
  9047eb:	vpbroadcastd ymm0,xmm0
  9047f0:	vmovdqa YMMWORD PTR [rsp+0x3e0],ymm0
  9047f9:	mov    QWORD PTR [rsp+0x260],0x0
  904805:	mov    rdx,QWORD PTR [rsp+0x20]
  90480a:	mov    rcx,QWORD PTR [rsp+0x50]
  90480f:	cmp    rdx,rcx
  904812:	mov    rdi,rcx
  904815:	cmovb  rdi,rdx
  904819:	mov    rax,rdi
  90481c:	or     rax,r13
  90481f:	shr    rax,0x20
  904823:	mov    QWORD PTR [rsp+0x58],rdx
  904828:	je     904837 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17e7>
  90482a:	mov    rax,rdi
  90482d:	xor    edx,edx
  90482f:	div    r13
  904832:	mov    r14,rax
  904835:	jmp    904841 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17f1>
  904837:	mov    eax,edi
  904839:	xor    edx,edx
  90483b:	div    r13d
  90483e:	mov    r14d,eax
  904841:	mov    r12,QWORD PTR [rsp+0x260]
  904849:	imul   r12,rcx
  90484d:	cmp    rdx,0x1
  904851:	sbb    r14,0xffffffffffffffff
  904855:	cmp    r14,0x40
  904859:	mov    eax,0x40
  90485e:	cmovae r14,rax
  904862:	mov    QWORD PTR [rsp+0xc8],rdi
  90486a:	lea    rax,[rdi+rdi*1]
  90486e:	lea    rax,[rax+rax*2]
  904872:	mov    rcx,QWORD PTR [rsp+0x70]
  904877:	sub    rax,rcx
  90487a:	mov    edx,0x0
  90487f:	cmovb  rax,rdx
  904883:	mov    rdx,r14
  904886:	imul   rdx,QWORD PTR [rsp+0x78]
  90488c:	cmp    rax,rdx
  90488f:	cmovb  rdx,rax
  904893:	mov    QWORD PTR [rsp+0x120],rsi
  90489b:	add    rsi,rcx
  90489e:	cmp    rdx,0x300
  9048a5:	mov    eax,0x300
  9048aa:	cmovae rdx,rax
  9048ae:	mov    rdi,rbx
  9048b1:	vzeroupper
  9048b4:	call   QWORD PTR [rip+0x6dcea6]        # fe1760 <memcpy@GLIBC_2.14>
  9048ba:	lea    ecx,[r14+0xf]
  9048be:	shr    ecx,0x4
  9048c1:	xor    eax,eax
  9048c3:	xor    r8d,r8d
  9048c6:	vmovdqa ymm14,YMMWORD PTR [rsp+0x3c0]
  9048cf:	vmovdqa xmm15,XMMWORD PTR [rsp+0x130]
  9048d8:	jmp    904cc8 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1c78>
  9048dd:	nop    DWORD PTR [rax]
  9048e0:	mov    r9,rdi
  9048e3:	mov    rdi,r8
  9048e6:	vpunpckhqdq xmm7,xmm7,xmm8
  9048eb:	vpunpckhdq xmm5,xmm5,xmm6
  9048ef:	vpunpckhdq xmm3,xmm3,xmm4
  9048f3:	vpunpcklqdq xmm4,xmm3,xmm5
  9048f7:	vmovd  xmm3,esi
  9048fb:	vpbroadcastd ymm3,xmm3
  904900:	mov    rsi,rdi
  904903:	shl    rsi,0x4
  904907:	lea    r8,[rbx+0xc00]
  90490e:	vmovdqu XMMWORD PTR [r8+rsi*1],xmm1
  904914:	vmovdqa xmm1,XMMWORD PTR [rsp+0x420]
  90491d:	vpshufb xmm1,xmm1,xmm2
  904922:	vmovdqa xmm5,XMMWORD PTR [rsp+0x1a0]
  90492b:	vpshufb xmm2,xmm5,xmm2
  904930:	vpunpcklbw xmm6,xmm1,xmm2
  904934:	vpunpckhbw xmm8,xmm1,xmm2
  904938:	vpmovsxbw ymm1,xmm7
  90493d:	vpmovsxwd ymm2,xmm1
  904942:	vextracti128 xmm1,ymm1,0x1
  904948:	vpmovsxwd ymm1,xmm1
  90494d:	vpabsd ymm5,ymm2
  904952:	vpabsd ymm7,ymm1
  904957:	vpsrld ymm9,ymm5,0x4
  90495c:	vpbroadcastd ymm10,DWORD PTR [rip+0xffffffffff71460b]        # 18f70 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0xd0>
  904965:	vpsrld ymm11,ymm7,0x4
  90496a:	vpmaxud ymm9,ymm9,ymm10
  90496f:	vpcmpeqd ymm13,ymm13,ymm13
  904974:	vpaddd ymm9,ymm9,ymm13
  904979:	vpmaxud ymm11,ymm11,ymm10
  90497e:	vpaddd ymm11,ymm11,ymm13
  904983:	vpslld ymm12,ymm9,0x4
  904989:	vpsubd ymm5,ymm5,ymm12
  90498e:	vpslld ymm12,ymm11,0x4
  904994:	vpsubd ymm7,ymm7,ymm12
  904999:	vpsllvd ymm5,ymm5,ymm9
  90499e:	vpsllvd ymm7,ymm7,ymm11
  9049a3:	vpsrad ymm2,ymm2,0x1f
  9049a8:	vpsrad ymm1,ymm1,0x1f
  9049ad:	vpxor  ymm5,ymm2,ymm5
  9049b1:	vpxor  ymm7,ymm1,ymm7
  9049b5:	vpsubd ymm5,ymm5,ymm2
  9049b9:	vpsubd ymm2,ymm7,ymm1
  9049bd:	vpmovsxbw ymm1,xmm4
  9049c2:	vpmovsxwd ymm4,xmm1
  9049c7:	vextracti128 xmm1,ymm1,0x1
  9049cd:	vpmovsxwd ymm7,xmm1
  9049d2:	vpabsd ymm1,ymm4
  9049d7:	vpabsd ymm9,ymm7
  9049dc:	vpsrld ymm11,ymm1,0x4
  9049e1:	vpsrld ymm12,ymm9,0x4
  9049e7:	vpmaxud ymm11,ymm11,ymm10
  9049ec:	vpaddd ymm11,ymm11,ymm13
  9049f1:	vpmaxud ymm10,ymm12,ymm10
  9049f6:	vpaddd ymm10,ymm10,ymm13
  9049fb:	vpslld ymm12,ymm11,0x4
  904a01:	vpsubd ymm12,ymm1,ymm12
  904a06:	vpslld ymm1,ymm10,0x4
  904a0c:	vpsubd ymm9,ymm9,ymm1
  904a10:	vpaddd ymm1,ymm3,YMMWORD PTR [rsp+0x2e0]
  904a19:	vpmovsxwd ymm6,xmm6
  904a1e:	vpmovsxwd ymm8,xmm8
  904a23:	vmovdqa ymm13,YMMWORD PTR [rsp+0x180]
  904a2c:	vpmulld ymm6,ymm13,ymm6
  904a31:	vpmulld ymm13,ymm13,ymm8
  904a36:	vpsllvd ymm8,ymm12,ymm11
  904a3b:	vpsllvd ymm9,ymm9,ymm10
  904a40:	vpsrad ymm4,ymm4,0x1f
  904a45:	vpsrad ymm7,ymm7,0x1f
  904a4a:	vpxor  ymm8,ymm8,ymm4
  904a4e:	vpxor  ymm9,ymm9,ymm7
  904a52:	vpsubd ymm10,ymm8,ymm4
  904a56:	vpsubd ymm8,ymm9,ymm7
  904a5a:	vpmulld ymm4,ymm6,ymm5
  904a5f:	vpmulld ymm7,ymm13,ymm2
  904a64:	vpsrad ymm9,ymm4,0x1f
  904a69:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffff714536]        # 18fa8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x108>
  904a72:	vpaddd ymm4,ymm11,ymm4
  904a76:	vpaddd ymm4,ymm9,ymm4
  904a7a:	vpsrad ymm9,ymm7,0x1f
  904a7f:	vpaddd ymm7,ymm11,ymm7
  904a83:	vpaddd ymm12,ymm9,ymm7
  904a87:	vpmulld ymm6,ymm6,ymm10
  904a8c:	vpsrad ymm7,ymm6,0x1f
  904a91:	vpaddd ymm6,ymm11,ymm6
  904a95:	vpaddd ymm6,ymm6,ymm7
  904a99:	vpaddd ymm7,ymm14,ymm3
  904a9d:	vpmulld ymm9,ymm13,ymm8
  904aa2:	vpaddd ymm11,ymm9,ymm11
  904aa7:	vpsrad ymm9,ymm9,0x1f
  904aad:	vpaddd ymm11,ymm11,ymm9
  904ab2:	vpsrad ymm13,ymm4,0xe
  904ab7:	shl    rdi,0x6
  904abb:	vmovdqu YMMWORD PTR [r15+rdi*1],ymm5
  904ac1:	vpsrad ymm5,ymm12,0xe
  904ac7:	vmovdqu YMMWORD PTR [r15+rdi*1+0x20],ymm2
  904ace:	vpsrad ymm9,ymm6,0xe
  904ad3:	vmovdqu YMMWORD PTR [r15+rdi*1+0x100],ymm10
  904add:	vpsrad ymm10,ymm11,0xe
  904ae3:	vmovdqu YMMWORD PTR [r15+rdi*1+0x120],ymm8
  904aed:	vpsrad ymm2,ymm12,0x1f
  904af3:	vpsrld ymm2,ymm2,0x1a
  904af8:	vpaddd ymm2,ymm2,ymm5
  904afc:	vpsrad ymm2,ymm2,0x6
  904b01:	vmovdqa ymm12,YMMWORD PTR [rsp+0x400]
  904b0a:	vpaddd ymm2,ymm12,ymm2
  904b0e:	vpbroadcastd ymm8,DWORD PTR [rsp+0x2c0]
  904b18:	vpand  ymm5,ymm8,ymm2
  904b1c:	vpsrad ymm4,ymm4,0x1f
  904b21:	vpsrld ymm4,ymm4,0x1a
  904b26:	vpaddd ymm4,ymm13,ymm4
  904b2a:	vpsrad ymm4,ymm4,0x6
  904b2f:	vpaddd ymm4,ymm12,ymm4
  904b33:	vpand  ymm12,ymm8,ymm4
  904b37:	vpsrad ymm11,ymm11,0x1f
  904b3d:	vpsrld ymm11,ymm11,0x1a
  904b43:	vpaddd ymm10,ymm11,ymm10
  904b48:	vmovdqa ymm13,YMMWORD PTR [rsp+0x1e0]
  904b51:	vpminud ymm11,ymm13,ymm2
  904b56:	vpcmpeqd ymm11,ymm13,ymm11
  904b5b:	vpsrad ymm10,ymm10,0x6
  904b61:	vpaddd ymm7,ymm10,ymm7
  904b65:	vpminud ymm10,ymm13,ymm4
  904b6a:	vpcmpeqd ymm10,ymm13,ymm10
  904b6f:	vpsrad ymm6,ymm6,0x1f
  904b74:	vpsrld ymm6,ymm6,0x1a
  904b79:	vpaddd ymm6,ymm9,ymm6
  904b7d:	vpand  ymm9,ymm8,ymm7
  904b81:	vpsrad ymm6,ymm6,0x6
  904b86:	vpaddd ymm6,ymm1,ymm6
  904b8a:	vpand  ymm8,ymm8,ymm6
  904b8e:	vmovdqa ymm13,YMMWORD PTR [rsp+0x1c0]
  904b97:	vpminud ymm1,ymm13,ymm7
  904b9c:	vpcmpeqd ymm1,ymm13,ymm1
  904ba0:	vpor   ymm1,ymm11,ymm1
  904ba4:	vpminud ymm11,ymm13,ymm6
  904ba9:	vpcmpeqd ymm11,ymm13,ymm11
  904bae:	vpor   ymm10,ymm10,ymm11
  904bb3:	vmovdqa ymm13,YMMWORD PTR [rsp+0x280]
  904bbc:	vpsubd ymm11,ymm12,ymm13
  904bc1:	vpsubd ymm5,ymm5,ymm13
  904bc6:	vmovdqa ymm13,YMMWORD PTR [rsp+0x240]
  904bcf:	vpmulld ymm12,ymm11,ymm13
  904bd4:	vpaddd ymm8,ymm12,ymm8
  904bd9:	vpmulld ymm12,ymm5,ymm13
  904bde:	vpaddd ymm9,ymm12,ymm9
  904be3:	vpsrad ymm11,ymm11,0x1f
  904be9:	vpor   ymm8,ymm8,ymm11
  904bee:	vpsrad ymm5,ymm5,0x1f
  904bf3:	vpor   ymm5,ymm9,ymm5
  904bf7:	lea    rsi,[rbx+0x900]
  904bfe:	vmovdqu YMMWORD PTR [rsi+rdi*1],ymm8
  904c03:	vmovdqa ymm8,YMMWORD PTR [rsp+0x2a0]
  904c0c:	vpand  ymm6,ymm8,ymm6
  904c10:	vmovdqu YMMWORD PTR [rsi+rdi*1+0x20],ymm5
  904c16:	vpaddd ymm5,ymm3,YMMWORD PTR [rsp+0x440]
  904c1f:	vpsubd ymm5,ymm5,ymm6
  904c23:	vpand  ymm6,ymm8,ymm7
  904c27:	vpaddd ymm3,ymm3,YMMWORD PTR [rsp+0x220]
  904c30:	vpsubd ymm3,ymm3,ymm6
  904c34:	vpand  ymm4,ymm8,ymm4
  904c38:	vmovdqa ymm7,YMMWORD PTR [rsp+0x3e0]
  904c41:	vpcmpeqd ymm4,ymm4,ymm7
  904c45:	vmovdqa ymm6,YMMWORD PTR [rsp+0x200]
  904c4e:	vpminud ymm5,ymm6,ymm5
  904c53:	vpcmpeqd ymm5,ymm6,ymm5
  904c57:	vpandn ymm4,ymm5,ymm4
  904c5b:	vpandn ymm4,ymm10,ymm4
  904c5f:	vpand  ymm2,ymm8,ymm2
  904c63:	vpcmpeqd ymm2,ymm2,ymm7
  904c67:	vpminud ymm3,ymm6,ymm3
  904c6c:	vpcmpeqd ymm3,ymm6,ymm3
  904c70:	vpandn ymm2,ymm3,ymm2
  904c74:	vpbroadcastd ymm3,DWORD PTR [rip+0xffffffffff713fd3]        # 18c50 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x1231>
  904c7d:	vpandn ymm1,ymm1,ymm2
  904c81:	vpand  ymm2,ymm4,ymm3
  904c85:	vpand  ymm1,ymm1,ymm3
  904c89:	vextracti128 xmm3,ymm1,0x1
  904c8f:	vpackusdw xmm1,xmm1,xmm3
  904c94:	vextracti128 xmm3,ymm2,0x1
  904c9a:	vpackusdw xmm2,xmm2,xmm3
  904c9f:	vpackuswb xmm1,xmm2,xmm1
  904ca3:	vpand  xmm0,xmm15,xmm0
  904ca7:	vpand  xmm0,xmm0,xmm1
  904cab:	vpxor  xmm1,xmm1,xmm1
  904caf:	vpcmpeqb xmm0,xmm0,xmm1
  904cb3:	vpmovmskb esi,xmm0
  904cb7:	xor    esi,0xffff
  904cbd:	shlx   rdx,rsi,rdx
  904cc2:	or     rax,rdx
  904cc5:	mov    r8,r9
  904cc8:	cmp    r13,0x1
  904ccc:	jne    904db0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1d60>
  904cd2:	cmp    r8,rcx
  904cd5:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  904cdb:	mov    rdx,r8
  904cde:	shl    rdx,0x4
  904ce2:	lea    rsi,[rdx+r12*1]
  904ce6:	cmp    rsi,0x7fffffff
  904ced:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  904cf3:	lea    rdi,[r8+r8*2]
  904cf7:	shl    rdi,0x5
  904cfb:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  904d00:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x6]
  904d06:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  904d0c:	vmovdqu xmm6,XMMWORD PTR [rbx+rdi*1+0x36]
  904d12:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  904d1a:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+rdi*1+0x20],0x2
  904d22:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  904d2a:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+rdi*1+0x50],0x2
  904d32:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+rdi*1+0x16],0x4
  904d3a:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+rdi*1+0x26],0x2
  904d42:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+rdi*1+0x46],0x4
  904d4a:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+rdi*1+0x56],0x2
  904d52:	lea    rdi,[r8+0x1]
  904d56:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff711a02]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  904d5e:	vpshufb xmm0,xmm5,xmm2
  904d63:	vpshufb xmm1,xmm3,xmm2
  904d68:	vpunpcklbw xmm7,xmm1,xmm0
  904d6c:	vpshufb xmm0,xmm6,xmm2
  904d71:	vpshufb xmm1,xmm4,xmm2
  904d76:	vpunpcklbw xmm8,xmm1,xmm0
  904d7a:	vpunpcklqdq xmm1,xmm7,xmm8
  904d7f:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70f229]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  904d87:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  904d90:	vpshufb xmm0,xmm0,xmm2
  904d95:	vptest xmm0,xmm15
  904d9a:	je     904fd0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1f80>
  904da0:	mov    r9,rdi
  904da3:	mov    rdi,r8
  904da6:	jmp    905670 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2620>
  904dab:	nop    DWORD PTR [rax+rax*1+0x0]
  904db0:	cmp    r8,rcx
  904db3:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  904db9:	mov    rdx,r8
  904dbc:	shl    rdx,0x4
  904dc0:	mov    rsi,rdx
  904dc3:	imul   rsi,r13
  904dc7:	add    rsi,r12
  904dca:	cmp    rsi,0x7fffffff
  904dd1:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  904dd7:	lea    rdi,[r8+0x1]
  904ddb:	lea    r9,[r8+r8*2]
  904ddf:	shl    r9,0x6
  904de3:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  904de9:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  904df0:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  904df7:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  904dfe:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  904e06:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff711302]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  904e0e:	vpshufb xmm1,xmm1,xmm6
  904e13:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff712505]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  904e1b:	vpshufb xmm0,xmm0,xmm7
  904e20:	vpor   xmm3,xmm0,xmm1
  904e24:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  904e2c:	vpshufb xmm1,xmm4,xmm6
  904e31:	vpshufb xmm0,xmm0,xmm7
  904e36:	vpor   xmm4,xmm0,xmm1
  904e3a:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  904e44:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  904e4b:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  904e53:	vpshufb xmm0,xmm0,xmm6
  904e58:	vpshufb xmm1,xmm1,xmm7
  904e5d:	vpor   xmm5,xmm1,xmm0
  904e61:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  904e6b:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  904e75:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  904e80:	vpshufb xmm0,xmm0,xmm6
  904e85:	vpshufb xmm1,xmm1,xmm7
  904e8a:	vpor   xmm6,xmm1,xmm0
  904e8e:	vpunpckldq xmm7,xmm3,xmm4
  904e92:	vpunpckldq xmm8,xmm5,xmm6
  904e96:	vpunpcklqdq xmm1,xmm7,xmm8
  904e9b:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70f10d]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  904ea3:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  904eac:	vpshufb xmm0,xmm0,xmm2
  904eb1:	vptest xmm0,xmm15
  904eb6:	jne    9048e0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1890>
  904ebc:	cmp    rdi,rcx
  904ebf:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  904ec5:	mov    rdx,rdi
  904ec8:	shl    rdx,0x4
  904ecc:	mov    rsi,rdx
  904ecf:	imul   rsi,r13
  904ed3:	add    rsi,r12
  904ed6:	cmp    rsi,0x7fffffff
  904edd:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  904ee3:	lea    r10,[r8+0x2]
  904ee7:	lea    r9,[rdi+rdi*2]
  904eeb:	shl    r9,0x6
  904eef:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  904ef5:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  904efc:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  904f03:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  904f0a:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  904f12:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff7111f6]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  904f1a:	vpshufb xmm1,xmm1,xmm6
  904f1f:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff7123f9]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  904f27:	vpshufb xmm0,xmm0,xmm7
  904f2c:	vpor   xmm3,xmm0,xmm1
  904f30:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  904f38:	vpshufb xmm1,xmm4,xmm6
  904f3d:	vpshufb xmm0,xmm0,xmm7
  904f42:	vpor   xmm4,xmm0,xmm1
  904f46:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  904f50:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  904f57:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  904f5f:	vpshufb xmm0,xmm0,xmm6
  904f64:	vpshufb xmm1,xmm1,xmm7
  904f69:	vpor   xmm5,xmm1,xmm0
  904f6d:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  904f77:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  904f81:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  904f8c:	vpshufb xmm0,xmm0,xmm6
  904f91:	vpshufb xmm1,xmm1,xmm7
  904f96:	vpor   xmm6,xmm1,xmm0
  904f9a:	vpunpckldq xmm7,xmm3,xmm4
  904f9e:	vpunpckldq xmm8,xmm5,xmm6
  904fa2:	vpunpcklqdq xmm1,xmm7,xmm8
  904fa7:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70f001]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  904faf:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  904fb8:	vpshufb xmm0,xmm0,xmm2
  904fbd:	vptest xmm0,xmm15
  904fc2:	je     9050aa <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x205a>
  904fc8:	mov    r9,r10
  904fcb:	jmp    9048e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1896>
  904fd0:	cmp    rdi,rcx
  904fd3:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  904fd9:	mov    rdx,rdi
  904fdc:	shl    rdx,0x4
  904fe0:	lea    rsi,[rdx+r12*1]
  904fe4:	cmp    rsi,0x7fffffff
  904feb:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  904ff1:	lea    r9,[rdi+rdi*2]
  904ff5:	shl    r9,0x5
  904ff9:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  904fff:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x6]
  905006:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  90500d:	vmovdqu xmm6,XMMWORD PTR [rbx+r9*1+0x36]
  905014:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  90501c:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+r9*1+0x20],0x2
  905024:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  90502c:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+r9*1+0x50],0x2
  905034:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+r9*1+0x16],0x4
  90503c:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+r9*1+0x26],0x2
  905044:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+r9*1+0x46],0x4
  90504c:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+r9*1+0x56],0x2
  905054:	lea    r10,[r8+0x2]
  905058:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff711700]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  905060:	vpshufb xmm0,xmm5,xmm2
  905065:	vpshufb xmm1,xmm3,xmm2
  90506a:	vpunpcklbw xmm7,xmm1,xmm0
  90506e:	vpshufb xmm0,xmm6,xmm2
  905073:	vpshufb xmm1,xmm4,xmm2
  905078:	vpunpcklbw xmm8,xmm1,xmm0
  90507c:	vpunpcklqdq xmm1,xmm7,xmm8
  905081:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70ef27]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  905089:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  905092:	vpshufb xmm0,xmm0,xmm2
  905097:	vptest xmm0,xmm15
  90509c:	je     9051b9 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2169>
  9050a2:	mov    r9,r10
  9050a5:	jmp    905670 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2620>
  9050aa:	cmp    r10,rcx
  9050ad:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  9050b3:	mov    rdx,r10
  9050b6:	shl    rdx,0x4
  9050ba:	mov    rsi,rdx
  9050bd:	imul   rsi,r13
  9050c1:	add    rsi,r12
  9050c4:	cmp    rsi,0x7fffffff
  9050cb:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  9050d1:	lea    r11,[r8+0x3]
  9050d5:	lea    rdi,[r10+r10*2]
  9050d9:	shl    rdi,0x6
  9050dd:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  9050e2:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x20]
  9050e8:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  9050ee:	vmovdqu xmm4,XMMWORD PTR [rbx+rdi*1+0x50]
  9050f4:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  9050fc:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff71100c]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  905104:	vpshufb xmm1,xmm1,xmm6
  905109:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff71220f]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  905111:	vpshufb xmm0,xmm0,xmm7
  905116:	vpor   xmm3,xmm0,xmm1
  90511a:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  905122:	vpshufb xmm1,xmm4,xmm6
  905127:	vpshufb xmm0,xmm0,xmm7
  90512c:	vpor   xmm4,xmm0,xmm1
  905130:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1+0x80]
  905139:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x60]
  90513f:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdi*1+0x70],0x4
  905147:	vpshufb xmm0,xmm0,xmm6
  90514c:	vpshufb xmm1,xmm1,xmm7
  905151:	vpor   xmm5,xmm1,xmm0
  905155:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1+0xb0]
  90515e:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x90]
  905167:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdi*1+0xa0],0x4
  905172:	vpshufb xmm0,xmm0,xmm6
  905177:	vpshufb xmm1,xmm1,xmm7
  90517c:	vpor   xmm6,xmm1,xmm0
  905180:	vpunpckldq xmm7,xmm3,xmm4
  905184:	vpunpckldq xmm8,xmm5,xmm6
  905188:	vpunpcklqdq xmm1,xmm7,xmm8
  90518d:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70ee1b]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  905195:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  90519e:	vpshufb xmm0,xmm0,xmm2
  9051a3:	vptest xmm0,xmm15
  9051a8:	je     905292 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2242>
  9051ae:	mov    r9,r11
  9051b1:	mov    rdi,r10
  9051b4:	jmp    9048e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1896>
  9051b9:	cmp    r10,rcx
  9051bc:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  9051c2:	mov    rdx,r10
  9051c5:	shl    rdx,0x4
  9051c9:	lea    rsi,[rdx+r12*1]
  9051cd:	cmp    rsi,0x7fffffff
  9051d4:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  9051da:	lea    rdi,[r10+r10*2]
  9051de:	shl    rdi,0x5
  9051e2:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  9051e7:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x6]
  9051ed:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  9051f3:	vmovdqu xmm6,XMMWORD PTR [rbx+rdi*1+0x36]
  9051f9:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  905201:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+rdi*1+0x20],0x2
  905209:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  905211:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+rdi*1+0x50],0x2
  905219:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+rdi*1+0x16],0x4
  905221:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+rdi*1+0x26],0x2
  905229:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+rdi*1+0x46],0x4
  905231:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+rdi*1+0x56],0x2
  905239:	lea    r11,[r8+0x3]
  90523d:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71151b]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  905245:	vpshufb xmm0,xmm5,xmm2
  90524a:	vpshufb xmm1,xmm3,xmm2
  90524f:	vpunpcklbw xmm7,xmm1,xmm0
  905253:	vpshufb xmm0,xmm6,xmm2
  905258:	vpshufb xmm1,xmm4,xmm2
  90525d:	vpunpcklbw xmm8,xmm1,xmm0
  905261:	vpunpcklqdq xmm1,xmm7,xmm8
  905266:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70ed42]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  90526e:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  905277:	vpshufb xmm0,xmm0,xmm2
  90527c:	vptest xmm0,xmm15
  905281:	je     9053a9 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2359>
  905287:	mov    r9,r11
  90528a:	mov    rdi,r10
  90528d:	jmp    905670 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2620>
  905292:	cmp    r11,rcx
  905295:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  90529b:	mov    rdx,r11
  90529e:	shl    rdx,0x4
  9052a2:	mov    rsi,rdx
  9052a5:	imul   rsi,r13
  9052a9:	add    rsi,r12
  9052ac:	cmp    rsi,0x7fffffff
  9052b3:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  9052b9:	lea    rdi,[r8+0x4]
  9052bd:	lea    r9,[r11+r11*2]
  9052c1:	shl    r9,0x6
  9052c5:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  9052cb:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  9052d2:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  9052d9:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  9052e0:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  9052e8:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff710e20]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  9052f0:	vpshufb xmm1,xmm1,xmm6
  9052f5:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff712023]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  9052fd:	vpshufb xmm0,xmm0,xmm7
  905302:	vpor   xmm3,xmm0,xmm1
  905306:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  90530e:	vpshufb xmm1,xmm4,xmm6
  905313:	vpshufb xmm0,xmm0,xmm7
  905318:	vpor   xmm4,xmm0,xmm1
  90531c:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  905326:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  90532d:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  905335:	vpshufb xmm0,xmm0,xmm6
  90533a:	vpshufb xmm1,xmm1,xmm7
  90533f:	vpor   xmm5,xmm1,xmm0
  905343:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  90534d:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  905357:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  905362:	vpshufb xmm0,xmm0,xmm6
  905367:	vpshufb xmm1,xmm1,xmm7
  90536c:	vpor   xmm6,xmm1,xmm0
  905370:	vpunpckldq xmm7,xmm3,xmm4
  905374:	vpunpckldq xmm8,xmm5,xmm6
  905378:	vpunpcklqdq xmm1,xmm7,xmm8
  90537d:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70ec2b]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  905385:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  90538e:	vpshufb xmm0,xmm0,xmm2
  905393:	vptest xmm0,xmm15
  905398:	je     905482 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2432>
  90539e:	mov    r9,rdi
  9053a1:	mov    rdi,r11
  9053a4:	jmp    9048e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1896>
  9053a9:	cmp    r11,rcx
  9053ac:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  9053b2:	mov    rdx,r11
  9053b5:	shl    rdx,0x4
  9053b9:	lea    rsi,[rdx+r12*1]
  9053bd:	cmp    rsi,0x7fffffff
  9053c4:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  9053ca:	lea    rdi,[r11+r11*2]
  9053ce:	shl    rdi,0x5
  9053d2:	vmovdqu xmm0,XMMWORD PTR [rbx+rdi*1]
  9053d7:	vmovdqu xmm1,XMMWORD PTR [rbx+rdi*1+0x6]
  9053dd:	vmovdqu xmm2,XMMWORD PTR [rbx+rdi*1+0x30]
  9053e3:	vmovdqu xmm6,XMMWORD PTR [rbx+rdi*1+0x36]
  9053e9:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdi*1+0x10],0x4
  9053f1:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+rdi*1+0x20],0x2
  9053f9:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+rdi*1+0x40],0x4
  905401:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+rdi*1+0x50],0x2
  905409:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+rdi*1+0x16],0x4
  905411:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+rdi*1+0x26],0x2
  905419:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+rdi*1+0x46],0x4
  905421:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+rdi*1+0x56],0x2
  905429:	lea    rdi,[r8+0x4]
  90542d:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71132b]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  905435:	vpshufb xmm0,xmm5,xmm2
  90543a:	vpshufb xmm1,xmm3,xmm2
  90543f:	vpunpcklbw xmm7,xmm1,xmm0
  905443:	vpshufb xmm0,xmm6,xmm2
  905448:	vpshufb xmm1,xmm4,xmm2
  90544d:	vpunpcklbw xmm8,xmm1,xmm0
  905451:	vpunpcklqdq xmm1,xmm7,xmm8
  905456:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70eb52]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  90545e:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  905467:	vpshufb xmm0,xmm0,xmm2
  90546c:	vptest xmm0,xmm15
  905471:	je     905596 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2546>
  905477:	mov    r9,rdi
  90547a:	mov    rdi,r11
  90547d:	jmp    905670 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2620>
  905482:	cmp    rdi,rcx
  905485:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  90548b:	mov    rdx,rdi
  90548e:	shl    rdx,0x4
  905492:	mov    rsi,rdx
  905495:	imul   rsi,r13
  905499:	add    rsi,r12
  90549c:	cmp    rsi,0x7fffffff
  9054a3:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  9054a9:	lea    r9,[rdi+rdi*2]
  9054ad:	shl    r9,0x6
  9054b1:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  9054b7:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x20]
  9054be:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  9054c5:	vmovdqu xmm4,XMMWORD PTR [rbx+r9*1+0x50]
  9054cc:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  9054d4:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff710c34]        # 16110 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1dd0>
  9054dc:	vpshufb xmm1,xmm1,xmm6
  9054e1:	vmovdqa xmm7,XMMWORD PTR [rip+0xffffffffff711e37]        # 17320 <anon.aba984e1f6198cdf523864d2e78509ba.113.llvm.6483746121354671294+0x210>
  9054e9:	vpshufb xmm0,xmm0,xmm7
  9054ee:	vpor   xmm3,xmm0,xmm1
  9054f2:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  9054fa:	vpshufb xmm1,xmm4,xmm6
  9054ff:	vpshufb xmm0,xmm0,xmm7
  905504:	vpor   xmm4,xmm0,xmm1
  905508:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0x80]
  905512:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x60]
  905519:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0x70],0x4
  905521:	vpshufb xmm0,xmm0,xmm6
  905526:	vpshufb xmm1,xmm1,xmm7
  90552b:	vpor   xmm5,xmm1,xmm0
  90552f:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1+0xb0]
  905539:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x90]
  905543:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r9*1+0xa0],0x4
  90554e:	vpshufb xmm0,xmm0,xmm6
  905553:	vpshufb xmm1,xmm1,xmm7
  905558:	vpor   xmm6,xmm1,xmm0
  90555c:	vpunpckldq xmm7,xmm3,xmm4
  905560:	vpunpckldq xmm8,xmm5,xmm6
  905564:	vpunpcklqdq xmm1,xmm7,xmm8
  905569:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70ea3f]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  905571:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  90557a:	vpshufb xmm0,xmm0,xmm2
  90557f:	vptest xmm0,xmm15
  905584:	je     9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  90558a:	add    r8,0x5
  90558e:	mov    r9,r8
  905591:	jmp    9048e6 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x1896>
  905596:	cmp    rdi,rcx
  905599:	jae    9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  90559f:	mov    rdx,rdi
  9055a2:	shl    rdx,0x4
  9055a6:	lea    rsi,[rdx+r12*1]
  9055aa:	cmp    rsi,0x7fffffff
  9055b1:	ja     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  9055b7:	lea    r9,[rdi+rdi*2]
  9055bb:	shl    r9,0x5
  9055bf:	vmovdqu xmm0,XMMWORD PTR [rbx+r9*1]
  9055c5:	vmovdqu xmm1,XMMWORD PTR [rbx+r9*1+0x6]
  9055cc:	vmovdqu xmm2,XMMWORD PTR [rbx+r9*1+0x30]
  9055d3:	vmovdqu xmm6,XMMWORD PTR [rbx+r9*1+0x36]
  9055da:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r9*1+0x10],0x4
  9055e2:	vpblendd xmm3,xmm0,XMMWORD PTR [rbx+r9*1+0x20],0x2
  9055ea:	vpblendd xmm0,xmm2,XMMWORD PTR [rbx+r9*1+0x40],0x4
  9055f2:	vpblendd xmm4,xmm0,XMMWORD PTR [rbx+r9*1+0x50],0x2
  9055fa:	vpblendd xmm0,xmm1,XMMWORD PTR [rbx+r9*1+0x16],0x4
  905602:	vpblendd xmm5,xmm0,XMMWORD PTR [rbx+r9*1+0x26],0x2
  90560a:	vpblendd xmm0,xmm6,XMMWORD PTR [rbx+r9*1+0x46],0x4
  905612:	vpblendd xmm6,xmm0,XMMWORD PTR [rbx+r9*1+0x56],0x2
  90561a:	vmovq  xmm2,QWORD PTR [rip+0xffffffffff71113e]        # 16760 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x2420>
  905622:	vpshufb xmm0,xmm5,xmm2
  905627:	vpshufb xmm1,xmm3,xmm2
  90562c:	vpunpcklbw xmm7,xmm1,xmm0
  905630:	vpshufb xmm0,xmm6,xmm2
  905635:	vpshufb xmm1,xmm4,xmm2
  90563a:	vpunpcklbw xmm8,xmm1,xmm0
  90563e:	vpunpcklqdq xmm1,xmm7,xmm8
  905643:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff70e965]        # 13fb0 <anon.5158a44e4446e4e86c12a6838a7d57e4.0.llvm.6651927231164529940+0x6fe>
  90564b:	vmovdqa xmm0,XMMWORD PTR [rsp+0xe0]
  905654:	vpshufb xmm0,xmm0,xmm2
  905659:	vptest xmm0,xmm15
  90565e:	je     9056a2 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2652>
  905660:	add    r8,0x5
  905664:	mov    r9,r8
  905667:	nop    WORD PTR [rax+rax*1+0x0]
  905670:	vpunpckhqdq xmm7,xmm7,xmm8
  905675:	vmovd  xmm8,DWORD PTR [rip+0xffffffffff70f253]        # 148d0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x590>
  90567d:	vpshufb xmm5,xmm5,xmm8
  905682:	vpshufb xmm3,xmm3,xmm8
  905687:	vpunpcklbw xmm3,xmm3,xmm5
  90568b:	vpshufb xmm5,xmm6,xmm8
  905690:	vpshufb xmm4,xmm4,xmm8
  905695:	vpunpcklbw xmm4,xmm4,xmm5
  905699:	vpunpcklqdq xmm4,xmm3,xmm4
  90569d:	jmp    9048f7 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x18a7>
  9056a2:	cmp    r14,0x1
  9056a6:	adc    r14,0x0
  9056aa:	bzhi   rax,rax,r14
  9056af:	inc    QWORD PTR [rsp+0x260]
  9056b7:	mov    QWORD PTR [rsp+0x300],rbx
  9056bf:	mov    QWORD PTR [rsp+0x308],rax
  9056c7:	mov    r14,QWORD PTR [rsp+0x18]
  9056cc:	mov    QWORD PTR [rsp+0x310],r14
  9056d4:	mov    QWORD PTR [rsp+0x318],r12
  9056dc:	mov    QWORD PTR [rsp+0x320],r13
  9056e4:	lea    rdi,[rsp+0x300]
  9056ec:	mov    rsi,QWORD PTR [rsp+0xb0]
  9056f4:	mov    rdx,QWORD PTR [rsp+0xa8]
  9056fc:	vzeroupper
  9056ff:	call   QWORD PTR [rip+0x6dd843]        # fe2f48 <_DYNAMIC+0x1a20>
  905705:	mov    rcx,QWORD PTR [rsp+0xc8]
  90570d:	lea    rax,[rcx+rcx*2]
  905711:	mov    rsi,QWORD PTR [rsp+0x120]
  905719:	lea    rsi,[rsi+rax*2]
  90571d:	mov    rdx,QWORD PTR [rsp+0x58]
  905722:	sub    rdx,rcx
  905725:	jne    90480a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x17ba>
  90572b:	jmp    9046f0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x16a0>
  905730:	mov    rax,QWORD PTR [rsp+0x20]
  905735:	mov    rdi,QWORD PTR [rsp+0x50]
  90573a:	cmp    rax,rdi
  90573d:	cmovb  rdi,rax
  905741:	mov    rax,rdi
  905744:	or     rax,r13
  905747:	shr    rax,0x20
  90574b:	je     905757 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2707>
  90574d:	mov    rax,rdi
  905750:	xor    edx,edx
  905752:	div    r13
  905755:	jmp    90575e <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x270e>
  905757:	mov    eax,edi
  905759:	xor    edx,edx
  90575b:	div    r13d
  90575e:	cmp    rdx,0x1
  905762:	sbb    rax,0xffffffffffffffff
  905766:	cmp    rax,0x40
  90576a:	mov    ecx,0x40
  90576f:	cmovb  rcx,rax
  905773:	add    rdi,rdi
  905776:	lea    rax,[rdi+rdi*2]
  90577a:	mov    rdi,QWORD PTR [rsp+0x70]
  90577f:	add    rsi,rdi
  905782:	xor    edx,edx
  905784:	sub    rax,rdi
  905787:	cmovae rdx,rax
  90578b:	imul   rcx,QWORD PTR [rsp+0x78]
  905791:	cmp    rdx,rcx
  905794:	cmovb  rcx,rdx
  905798:	cmp    rcx,0x300
  90579f:	mov    edx,0x300
  9057a4:	cmovb  rdx,rcx
  9057a8:	mov    rdi,rbx
  9057ab:	vzeroupper
  9057ae:	call   QWORD PTR [rip+0x6dbfac]        # fe1760 <memcpy@GLIBC_2.14>
  9057b4:	lea    rsp,[rbp-0x28]
  9057b8:	pop    rbx
  9057b9:	pop    r12
  9057bb:	pop    r13
  9057bd:	pop    r14
  9057bf:	pop    r15
  9057c1:	pop    rbp
  9057c2:	vzeroupper
  9057c5:	ret
  9057c6:	lea    rdi,[rip+0xffffffffff7508d2]        # 5609f <anon.43d21acec09d19046152b53125a552af.1081.llvm.7158842796534594082+0x158a>
  9057cd:	lea    rdx,[rip+0x6cc0a4]        # fd1878 <anon.43d21acec09d19046152b53125a552af.1039.llvm.7158842796534594082+0x5c0>
  9057d4:	mov    esi,0x1b
  9057d9:	call   QWORD PTR [rip+0x6dc0f1]        # fe18d0 <_DYNAMIC+0x3a8>
  9057df:	mov    r8,rax
  9057e2:	cmp    BYTE PTR [rsp+0x17],0x0
  9057e7:	je     90584e <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27fe>
  9057e9:	mov    rcx,QWORD PTR [rsp+0x40]
  9057ee:	neg    rcx
  9057f1:	jmp    905813 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27c3>
  9057f3:	mov    rdx,QWORD PTR [rsp+0x28]
  9057f8:	cmp    rax,rdx
  9057fb:	jbe    9058d7 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2887>
  905801:	add    rsi,r13
  905804:	mov    QWORD PTR [rsp+0x18],rsi
  905809:	dec    QWORD PTR [rsp+0x88]
  905811:	je     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  905813:	mov    rsi,QWORD PTR [rsp+0x18]
  905818:	cmp    rsi,QWORD PTR [rsp+0x40]
  90581d:	jb     905801 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27b1>
  90581f:	lea    rax,[rcx+rsi*1]
  905823:	mul    r8
  905826:	jo     905801 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27b1>
  905828:	add    rax,r8
  90582b:	jb     905801 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27b1>
  90582d:	mov    rdx,QWORD PTR [rsp+0x80]
  905835:	test   rdx,rdx
  905838:	je     9057f3 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27a3>
  90583a:	cmp    edx,0x1
  90583d:	jne    90584a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27fa>
  90583f:	mov    rdx,QWORD PTR [rsp+0x38]
  905844:	mov    rdx,QWORD PTR [rdx+0x20]
  905848:	jmp    9057f8 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27a8>
  90584a:	xor    edx,edx
  90584c:	jmp    9057f8 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x27a8>
  90584e:	mov    rcx,QWORD PTR [rsp+0x40]
  905853:	neg    rcx
  905856:	xor    esi,esi
  905858:	jmp    90587a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x282a>
  90585a:	mov    rdx,QWORD PTR [rsp+0x28]
  90585f:	cmp    rax,rdx
  905862:	jbe    9058d7 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2887>
  905864:	add    rdi,r13
  905867:	mov    QWORD PTR [rsp+0x18],rdi
  90586c:	dec    QWORD PTR [rsp+0x88]
  905874:	je     9057b4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2764>
  90587a:	mov    rdi,QWORD PTR [rsp+0x18]
  90587f:	cmp    rdi,QWORD PTR [rsp+0x40]
  905884:	jb     905864 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2814>
  905886:	lea    rax,[rcx+rdi*1]
  90588a:	mul    r8
  90588d:	jo     905864 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2814>
  90588f:	add    rax,r8
  905892:	jb     905864 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2814>
  905894:	mov    rdx,QWORD PTR [rsp+0x80]
  90589c:	test   rdx,rdx
  90589f:	je     90585a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x280a>
  9058a1:	cmp    edx,0x1
  9058a4:	jne    9058b1 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2861>
  9058a6:	mov    rdx,QWORD PTR [rsp+0x38]
  9058ab:	mov    rdx,QWORD PTR [rdx+0x20]
  9058af:	jmp    90585f <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x280f>
  9058b1:	mov    rdx,QWORD PTR [rsp+0x28]
  9058b6:	cmp    BYTE PTR [rdx+0x10],0x0
  9058ba:	je     9058c0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2870>
  9058bc:	xor    edx,edx
  9058be:	jmp    9058c4 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x2874>
  9058c0:	mov    rdx,QWORD PTR [rdx+0x28]
  9058c4:	cmp    QWORD PTR [rsp+0x48],rdx
  9058c9:	mov    rdx,QWORD PTR [rsp+0x90]
  9058d1:	cmova  rdx,rsi
  9058d5:	jmp    90585f <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCINvNtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scan29project_temporal_motion_fieldNtNtCseYV3ZbSFDJ4_10splot_core4simd11Avx2BackendNtNtB1Z_4band18TemporalMotionBandEs0_0uEB27_+0x280f>
  9058d7:	lea    rdi,[rip+0xffffffffff744b7b]        # 4a459 <_RNvNtNtNtCsiiWGwn0QfU0_12splot_decode9bitstream12tile_payload11coeff_state15ZERO_QUANT_SIGN+0x521>
  9058de:	lea    rdx,[rip+0x6ca79b]        # fd0080 <anon.43d21acec09d19046152b53125a552af.157.llvm.7158842796534594082+0x2288>
  9058e5:	mov    esi,0x37
  9058ea:	vzeroupper
  9058ed:	call   QWORD PTR [rip+0x6dbeed]        # fe17e0 <_DYNAMIC+0x2b8>
