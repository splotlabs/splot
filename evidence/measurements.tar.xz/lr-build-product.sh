set -euo pipefail
root=$(pwd)
variant=$1
repo="$root/../splot-1934-lr-module"
out="$root/lr-product-$variant"
mkdir -p "$out"
opts=(env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u RUSTC_WRAPPER CARGO_TARGET_DIR="$out/target" CARGO_PROFILE_RELEASE_STRIP=none)
if [[ $variant == unit ]]; then opts+=(RUSTC_WRAPPER="$repo/scripts/rustc-lr-prototype.py" SPLOT_LR_COMPILE_LOG="$out/flags.tsv"); fi
(cd "$repo" && systemd-run --user --scope --quiet -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p CPUQuota=180% flock "$root/build.lock" taskset -c 6-11,14-19 "${opts[@]}" cargo build --locked --offline --release -j1 -p splot-cli -p splot-capi) > "$out/build.log" 2>&1
cli="$out/target/release/splot"
for artifact in splot libsplot_capi.so; do strip -o "$out/$artifact.stripped" "$out/target/release/$artifact"; done
sha256sum "$cli" "$out/target/release/libsplot_capi.so" > "$out/binaries.sha256"
nm -S -n --demangle=rust "$cli" | rg '(splot_lr_avx2::filter_luma_run|splot_lr_avx2::word_row)' > "$out/symbols.txt"
ritual="$root/ci-data/RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf"
taskset -c 2 valgrind --tool=callgrind --callgrind-out-file="$out/ritual16.cg" --log-file="$out/ritual16.log" "$cli" decode "$ritual" --threads 1 --frame-delay 1 --limit 16 --output-format null
sed "s|splot-1934-cdef-module|splot-1934-lr-module|g;s|out=\"\$root/cdef-module\"|out=\"\$root/lr-product-$variant\"|g" module-raw-check.sh > "$out/checks.sh"
bash "$out/checks.sh" > "$out/sse2.txt" 2>&1
