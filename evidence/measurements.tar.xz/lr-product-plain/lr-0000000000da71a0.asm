
<WORKTREES>/qualification-1882/lr-product-plain/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000da71a0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_>:
  da71a0:	push   %rbp
  da71a1:	push   %r15
  da71a3:	push   %r14
  da71a5:	push   %r13
  da71a7:	push   %r12
  da71a9:	push   %rbx
  da71aa:	sub    $0x7b8,%rsp
  da71b1:	mov    (%rdi),%rsi
  da71b4:	mov    0x8(%rdi),%r10
  da71b8:	mov    0x10(%rdi),%rax
  da71bc:	mov    (%rax),%r13
  da71bf:	mov    0x18(%rdi),%rax
  da71c3:	mov    (%rax),%r8
  da71c6:	mov    0x8(%rax),%rax
  da71ca:	mov    0x20(%rdi),%rcx
  da71ce:	vmovdqu (%rcx),%ymm0
  da71d2:	xor    %ebp,%ebp
  da71d4:	sub    %r8,%rax
  da71d7:	cmovae %rax,%rbp
  da71db:	vmovdqu %ymm0,0x2b0(%rsp)
  da71e4:	mov    %rbp,%rcx
  da71e7:	and    $0xfffffffffffffff0,%rcx
  da71eb:	sete   %dl
  da71ee:	test   %r13,%r13
  da71f1:	sete   %al
  da71f4:	or     %dl,%al
  da71f6:	cmp    $0x8,%r13
  da71fa:	ja     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da71fc:	test   %al,%al
  da71fe:	jne    da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7200:	mov    %rcx,%r9
  da7203:	xor    %eax,%eax
  da7205:	add    %r8,%r9
  da7208:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da720a:	test   %r10,%r10
  da720d:	je     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da720f:	cmp    $0xfffffffffffffff7,%r9
  da7213:	ja     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7215:	add    $0x8,%r9
  da7219:	mov    %r9,%r14
  da721c:	sub    %r8,%r14
  da721f:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7221:	cmp    0x8(%rsi),%r9
  da7225:	ja     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7227:	lea    0x8(%r13),%r12
  da722b:	cmp    %r12,%r10
  da722e:	jae    da7247 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0xa7>
  da7230:	xor    %eax,%eax
  da7232:	add    $0x7b8,%rsp
  da7239:	pop    %rbx
  da723a:	pop    %r12
  da723c:	pop    %r13
  da723e:	pop    %r14
  da7240:	pop    %r15
  da7242:	pop    %rbp
  da7243:	vzeroupper
  da7246:	ret
  da7247:	mov    0x28(%rdi),%rax
  da724b:	mov    0x30(%rdi),%r11
  da724f:	mov    0x38(%rdi),%rdx
  da7253:	mov    0x48(%rdi),%rdi
  da7257:	mov    %rdi,0x128(%rsp)
  da725f:	mov    (%rsi),%rdi
  da7262:	lea    (%rdi,%r8,2),%rdi
  da7266:	mov    %rdi,0x10(%rsp)
  da726b:	mov    %r14,0x18(%rsp)
  da7270:	mov    %rdi,0x20(%rsp)
  da7275:	mov    %r14,0x28(%rsp)
  da727a:	mov    %rdi,0x30(%rsp)
  da727f:	mov    %r14,0x38(%rsp)
  da7284:	mov    %rdi,0x40(%rsp)
  da7289:	mov    %r14,0x48(%rsp)
  da728e:	mov    %rdi,0x50(%rsp)
  da7293:	mov    %r14,0x58(%rsp)
  da7298:	mov    %rdi,0x60(%rsp)
  da729d:	mov    %r14,0x68(%rsp)
  da72a2:	mov    %rdi,0x70(%rsp)
  da72a7:	mov    %r14,0x78(%rsp)
  da72ac:	mov    %rdi,0x80(%rsp)
  da72b4:	mov    %r14,0x88(%rsp)
  da72bc:	mov    %rdi,0x90(%rsp)
  da72c4:	mov    %r14,0x98(%rsp)
  da72cc:	mov    %rdi,0xa0(%rsp)
  da72d4:	mov    %r14,0xa8(%rsp)
  da72dc:	mov    %rdi,0xb0(%rsp)
  da72e4:	mov    %r14,0xb8(%rsp)
  da72ec:	mov    %rdi,0xc0(%rsp)
  da72f4:	mov    %r14,0xc8(%rsp)
  da72fc:	mov    %rdi,0xd0(%rsp)
  da7304:	mov    %r14,0xd8(%rsp)
  da730c:	mov    %rdi,0xe0(%rsp)
  da7314:	mov    %r14,0xe8(%rsp)
  da731c:	mov    %rdi,0xf0(%rsp)
  da7324:	mov    %r14,0xf8(%rsp)
  da732c:	mov    %rdi,0x120(%rsp)
  da7334:	mov    %rdi,0x100(%rsp)
  da733c:	cmp    $0x10,%r10
  da7340:	mov    $0x10,%edi
  da7345:	cmovb  %r10,%rdi
  da7349:	mov    %r14,0x108(%rsp)
  da7351:	shl    $0x4,%edi
  da7354:	xor    %r10d,%r10d
  da7357:	lea    (%r8,%r8,1),%r15
  da735b:	nopl   0x0(%rax,%rax,1)
  da7360:	cmp    %r10,%rdi
  da7363:	je     da738d <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x1ed>
  da7365:	cmp    0x8(%rsi,%r10,1),%r9
  da736a:	ja     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7370:	dec    %r12
  da7373:	mov    (%rsi,%r10,1),%rbx
  da7377:	add    %r15,%rbx
  da737a:	mov    %rbx,0x10(%rsp,%r10,1)
  da737f:	mov    %r14,0x18(%rsp,%r10,1)
  da7384:	add    $0x10,%r10
  da7388:	test   %r12,%r12
  da738b:	jne    da7360 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x1c0>
  da738d:	vbroadcasti128 -0xd92326(%rip),%ymm0        # 15070 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1230>
  da7396:	vmovdqu %ymm0,0x1b0(%rsp)
  da739f:	vmovdqu %ymm0,0x1d0(%rsp)
  da73a8:	vmovdqu %ymm0,0x1f0(%rsp)
  da73b1:	vmovdqu %ymm0,0x210(%rsp)
  da73ba:	vmovdqu %ymm0,0x230(%rsp)
  da73c3:	vmovdqu %ymm0,0x250(%rsp)
  da73cc:	vmovdqu %ymm0,0x270(%rsp)
  da73d5:	vmovdqu %ymm0,0x290(%rsp)
  da73de:	mov    %r11,%rsi
  da73e1:	sub    %r8,%rsi
  da73e4:	cmp    %rcx,%rdx
  da73e7:	jae    da741f <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x27f>
  da73e9:	cmp    %r8,%r11
  da73ec:	setb   %dl
  da73ef:	cmp    %rcx,%rsi
  da73f2:	setb   %sil
  da73f6:	or     %dl,%sil
  da73f9:	jne    da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da73ff:	lea    (%rax,%r8,2),%rax
  da7403:	mov    %rax,0x1b0(%rsp)
  da740b:	mov    %rcx,0x1b8(%rsp)
  da7413:	cmp    $0x1,%r13
  da7417:	jne    da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da741d:	jmp    da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da741f:	cmp    %r8,%r11
  da7422:	setb   %dil
  da7426:	cmp    %rcx,%rsi
  da7429:	setb   %r9b
  da742d:	or     %dil,%r9b
  da7430:	jne    da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7436:	lea    (%rax,%r8,2),%rdi
  da743a:	mov    %rdi,0x1b0(%rsp)
  da7442:	mov    %rcx,0x1b8(%rsp)
  da744a:	cmp    $0x1,%r13
  da744e:	jne    da7b4a <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x9aa>
  da7454:	mov    0x2b0(%rsp),%rbx
  da745c:	test   %rbx,%rbx
  da745f:	jne    da748c <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2ec>
  da7461:	vpbroadcastq 0x2b8(%rsp),%ymm0
  da746b:	vmovdqu %ymm0,0x330(%rsp)
  da7474:	lea    0x578(%rsp),%rdi
  da747c:	lea    0x330(%rsp),%rsi
  da7484:	vzeroupper
  da7487:	call   da8030 <_RNvNvNvNtCsilixuIrojZt_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  da748c:	shr    $0x4,%rbp
  da7490:	mov    $0x1,%al
  da7492:	je     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7498:	lea    0x578(%rsp),%rax
  da74a0:	xor    %r15d,%r15d
  da74a3:	movq   $0x0,(%rsp)
  da74ab:	mov    %rbx,0x118(%rsp)
  da74b3:	mov    %rax,0x8(%rsp)
  da74b8:	test   %rbx,%rbx
  da74bb:	je     da7505 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x365>
  da74bd:	lea    0x2d0(%rsp),%rdi
  da74c5:	lea    0x2b0(%rsp),%rsi
  da74cd:	mov    (%rsp),%rdx
  da74d1:	vzeroupper
  da74d4:	call   da7f30 <_RNvMCsilixuIrojZt_15splot_lr_kernelNtB2_7Classes5group>
  da74d9:	cmpq   $0x0,0x2d0(%rsp)
  da74e2:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da74e8:	lea    0x330(%rsp),%r12
  da74f0:	mov    %r12,%rdi
  da74f3:	lea    0x2d0(%rsp),%rsi
  da74fb:	call   da8030 <_RNvNvNvNtCsilixuIrojZt_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  da7500:	mov    %r12,0x8(%rsp)
  da7505:	mov    %r14,%rcx
  da7508:	sub    %r15,%rcx
  da750b:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7511:	cmp    $0x18,%rcx
  da7515:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da751b:	mov    0x120(%rsp),%rcx
  da7523:	lea    (%rcx,%r15,2),%rcx
  da7527:	vmovq  %rcx,%xmm0
  da752c:	vpbroadcastq %xmm0,%ymm0
  da7531:	vmovdqu %ymm0,0x178(%rsp)
  da753a:	mov    %rcx,0x198(%rsp)
  da7542:	mov    %rcx,0x1a0(%rsp)
  da754a:	mov    %rcx,0x1a8(%rsp)
  da7552:	mov    0x18(%rsp),%rcx
  da7557:	sub    %r15,%rcx
  da755a:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7560:	cmp    $0x18,%rcx
  da7564:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da756a:	lea    (%r15,%r15,1),%rcx
  da756e:	mov    0x10(%rsp),%rdx
  da7573:	add    %rcx,%rdx
  da7576:	mov    %rdx,0x130(%rsp)
  da757e:	mov    0x28(%rsp),%rdx
  da7583:	sub    %r15,%rdx
  da7586:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da758c:	cmp    $0x18,%rdx
  da7590:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7596:	mov    0x20(%rsp),%rdx
  da759b:	add    %rcx,%rdx
  da759e:	mov    %rdx,0x138(%rsp)
  da75a6:	mov    0x38(%rsp),%rdx
  da75ab:	sub    %r15,%rdx
  da75ae:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da75b4:	cmp    $0x18,%rdx
  da75b8:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da75be:	mov    0x30(%rsp),%rdx
  da75c3:	add    %rcx,%rdx
  da75c6:	mov    %rdx,0x140(%rsp)
  da75ce:	mov    0x48(%rsp),%rdx
  da75d3:	sub    %r15,%rdx
  da75d6:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da75dc:	cmp    $0x18,%rdx
  da75e0:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da75e6:	mov    0x40(%rsp),%rdx
  da75eb:	add    %rcx,%rdx
  da75ee:	mov    %rdx,0x148(%rsp)
  da75f6:	mov    0x58(%rsp),%rdx
  da75fb:	sub    %r15,%rdx
  da75fe:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7604:	cmp    $0x18,%rdx
  da7608:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da760e:	mov    0x50(%rsp),%rdx
  da7613:	add    %rcx,%rdx
  da7616:	mov    %rdx,0x150(%rsp)
  da761e:	mov    0x68(%rsp),%rdx
  da7623:	sub    %r15,%rdx
  da7626:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da762c:	cmp    $0x18,%rdx
  da7630:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7636:	mov    0x60(%rsp),%rdx
  da763b:	add    %rcx,%rdx
  da763e:	mov    %rdx,0x158(%rsp)
  da7646:	mov    0x78(%rsp),%rdx
  da764b:	sub    %r15,%rdx
  da764e:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7654:	cmp    $0x18,%rdx
  da7658:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da765e:	mov    0x70(%rsp),%rdx
  da7663:	add    %rcx,%rdx
  da7666:	mov    %rdx,0x160(%rsp)
  da766e:	mov    0x88(%rsp),%rdx
  da7676:	sub    %r15,%rdx
  da7679:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da767f:	cmp    $0x18,%rdx
  da7683:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7689:	mov    0x80(%rsp),%rdx
  da7691:	add    %rcx,%rdx
  da7694:	mov    %rdx,0x168(%rsp)
  da769c:	mov    0x98(%rsp),%rdx
  da76a4:	sub    %r15,%rdx
  da76a7:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da76ad:	cmp    $0x18,%rdx
  da76b1:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da76b7:	mov    0x90(%rsp),%rdx
  da76bf:	add    %rcx,%rdx
  da76c2:	mov    %rdx,0x170(%rsp)
  da76ca:	cmp    $0x1,%r13
  da76ce:	je     da7847 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  da76d4:	mov    0xa8(%rsp),%rdx
  da76dc:	sub    %r15,%rdx
  da76df:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da76e5:	cmp    $0x18,%rdx
  da76e9:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da76ef:	mov    0xa0(%rsp),%rdx
  da76f7:	add    %rcx,%rdx
  da76fa:	mov    %rdx,0x178(%rsp)
  da7702:	cmp    $0x2,%r13
  da7706:	je     da7847 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  da770c:	mov    0xb8(%rsp),%rdx
  da7714:	sub    %r15,%rdx
  da7717:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da771d:	cmp    $0x18,%rdx
  da7721:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7727:	mov    0xb0(%rsp),%rdx
  da772f:	add    %rcx,%rdx
  da7732:	mov    %rdx,0x180(%rsp)
  da773a:	cmp    $0x3,%r13
  da773e:	je     da7847 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  da7744:	mov    0xc8(%rsp),%rdx
  da774c:	sub    %r15,%rdx
  da774f:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7755:	cmp    $0x18,%rdx
  da7759:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da775f:	mov    0xc0(%rsp),%rdx
  da7767:	add    %rcx,%rdx
  da776a:	mov    %rdx,0x188(%rsp)
  da7772:	cmp    $0x4,%r13
  da7776:	je     da7847 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  da777c:	mov    0xd8(%rsp),%rdx
  da7784:	sub    %r15,%rdx
  da7787:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da778d:	cmp    $0x18,%rdx
  da7791:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7797:	mov    0xd0(%rsp),%rdx
  da779f:	add    %rcx,%rdx
  da77a2:	mov    %rdx,0x190(%rsp)
  da77aa:	cmp    $0x5,%r13
  da77ae:	je     da7847 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  da77b4:	mov    0xe8(%rsp),%rdx
  da77bc:	sub    %r15,%rdx
  da77bf:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da77c5:	cmp    $0x18,%rdx
  da77c9:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da77cf:	mov    0xe0(%rsp),%rdx
  da77d7:	add    %rcx,%rdx
  da77da:	mov    %rdx,0x198(%rsp)
  da77e2:	cmp    $0x6,%r13
  da77e6:	je     da7847 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  da77e8:	mov    0xf8(%rsp),%rdx
  da77f0:	sub    %r15,%rdx
  da77f3:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da77f9:	cmp    $0x18,%rdx
  da77fd:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7803:	mov    0xf0(%rsp),%rdx
  da780b:	add    %rcx,%rdx
  da780e:	mov    %rdx,0x1a0(%rsp)
  da7816:	cmp    $0x7,%r13
  da781a:	je     da7847 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  da781c:	mov    0x108(%rsp),%rdx
  da7824:	sub    %r15,%rdx
  da7827:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da782d:	cmp    $0x18,%rdx
  da7831:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7837:	add    0x100(%rsp),%rcx
  da783f:	mov    %rcx,0x1a8(%rsp)
  da7847:	lea    0x10(%r15),%rax
  da784b:	mov    %rax,0x110(%rsp)
  da7853:	dec    %rbp
  da7856:	incq   (%rsp)
  da785a:	lea    0x1b8(%rsp),%rdx
  da7862:	xor    %esi,%esi
  da7864:	mov    (%rdx),%rdi
  da7867:	sub    %r15,%rdi
  da786a:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7870:	cmp    $0x10,%rdi
  da7874:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da787a:	cmp    $0x7,%rsi
  da787e:	ja     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7884:	mov    0x158(%rsp,%rsi,8),%r8
  da788c:	mov    0x148(%rsp,%rsi,8),%r9
  da7894:	mov    0x150(%rsp,%rsi,8),%rdi
  da789c:	vmovdqu (%rdi),%ymm4
  da78a0:	vmovdqu 0x2(%rdi),%ymm7
  da78a5:	mov    0x160(%rsp,%rsi,8),%r10
  da78ad:	mov    0x140(%rsp,%rsi,8),%r11
  da78b5:	vmovups 0x6(%r8),%ymm0
  da78bb:	vmovups %ymm0,0x310(%rsp)
  da78c4:	vmovdqu 0x6(%r11),%ymm8
  da78ca:	vmovdqu 0xa(%r11),%ymm9
  da78d0:	vmovdqu 0x4(%r9),%ymm10
  da78d6:	vmovdqu 0x6(%r9),%ymm6
  da78dc:	mov    %r15,%rax
  da78df:	mov    0x168(%rsp,%rsi,8),%r15
  da78e7:	mov    0x130(%rsp,%rsi,8),%rcx
  da78ef:	mov    0x138(%rsp,%rsi,8),%r12
  da78f7:	mov    0x170(%rsp,%rsi,8),%rbx
  da78ff:	vmovdqu 0x2(%r12),%ymm1
  da7906:	vmovdqu 0xe(%r12),%ymm2
  da790d:	vpaddw 0xe(%r15),%ymm1,%ymm0
  da7913:	vmovdqu %ymm0,0x2f0(%rsp)
  da791c:	vpaddw 0x2(%r15),%ymm2,%ymm2
  da7922:	vmovdqu 0x8(%rcx),%ymm3
  da7927:	vpunpckhwd %ymm2,%ymm0,%ymm5
  da792b:	mov    0x8(%rsp),%rcx
  da7930:	vpmaddwd 0x1e0(%rcx),%ymm5,%ymm12
  da7938:	vpaddw 0x8(%rbx),%ymm3,%ymm3
  da793d:	vpaddw 0x10(%rdi),%ymm4,%ymm4
  da7942:	vmovdqu 0x8(%r12),%ymm5
  da7949:	vpunpckhwd %ymm4,%ymm3,%ymm11
  da794d:	vpmaddwd 0x1a0(%rcx),%ymm11,%ymm13
  da7955:	vpaddw 0x8(%r15),%ymm5,%ymm5
  da795b:	mov    %rax,%r15
  da795e:	vpaddw 0xe(%rdi),%ymm7,%ymm7
  da7963:	vmovdqu 0xc(%r9),%ymm11
  da7969:	vpunpckhwd %ymm7,%ymm5,%ymm14
  da796d:	vpmaddwd 0x160(%rcx),%ymm14,%ymm14
  da7975:	vpaddw 0xc(%r8),%ymm10,%ymm10
  da797b:	vpaddw 0x4(%r8),%ymm11,%ymm11
  da7981:	vpaddd %ymm12,%ymm13,%ymm15
  da7986:	vpunpckhwd %ymm11,%ymm10,%ymm12
  da798b:	vpmaddwd 0x120(%rcx),%ymm12,%ymm12
  da7993:	vpaddw 0xa(%r10),%ymm8,%ymm8
  da7999:	vpaddw 0x6(%r10),%ymm9,%ymm9
  da799f:	vpaddd %ymm12,%ymm14,%ymm14
  da79a4:	vpunpckhwd %ymm9,%ymm8,%ymm12
  da79a9:	vpmaddwd 0xe0(%rcx),%ymm12,%ymm0
  da79b1:	vpaddw 0xa(%r8),%ymm6,%ymm12
  da79b7:	vmovdqu 0x310(%rsp),%ymm1
  da79c0:	vpaddw 0xa(%r9),%ymm1,%ymm13
  da79c6:	vpaddd %ymm14,%ymm15,%ymm15
  da79cb:	vpunpckhwd %ymm13,%ymm12,%ymm6
  da79d0:	vpmaddwd 0xa0(%rcx),%ymm6,%ymm6
  da79d8:	vmovdqu 0x8(%r11),%ymm14
  da79de:	vpaddd %ymm6,%ymm0,%ymm0
  da79e2:	vpaddw 0x8(%r10),%ymm14,%ymm6
  da79e8:	vmovdqu 0x4(%rdi),%ymm14
  da79ed:	vpaddw 0xc(%rdi),%ymm14,%ymm14
  da79f2:	vpunpckhwd %ymm14,%ymm6,%ymm1
  da79f7:	vpmaddwd 0x60(%rcx),%ymm1,%ymm1
  da79fc:	vpaddd %ymm1,%ymm0,%ymm0
  da7a00:	vpaddd %ymm0,%ymm15,%ymm0
  da7a04:	vmovdqu 0x2f0(%rsp),%ymm1
  da7a0d:	vpunpcklwd %ymm2,%ymm1,%ymm1
  da7a11:	vpunpcklwd %ymm4,%ymm3,%ymm2
  da7a15:	vpunpcklwd %ymm7,%ymm5,%ymm3
  da7a19:	vpunpcklwd %ymm11,%ymm10,%ymm4
  da7a1e:	vpmaddwd 0x1c0(%rcx),%ymm1,%ymm1
  da7a26:	vpmaddwd 0x180(%rcx),%ymm2,%ymm2
  da7a2e:	vpmaddwd 0x140(%rcx),%ymm3,%ymm3
  da7a36:	vpmaddwd 0x100(%rcx),%ymm4,%ymm4
  da7a3e:	vpaddd %ymm1,%ymm2,%ymm1
  da7a42:	vpaddd %ymm4,%ymm3,%ymm2
  da7a46:	vpaddd %ymm2,%ymm1,%ymm1
  da7a4a:	vpunpcklwd %ymm9,%ymm8,%ymm2
  da7a4f:	vpunpcklwd %ymm13,%ymm12,%ymm3
  da7a54:	vmovdqu 0x6(%rdi),%ymm4
  da7a59:	vpmaddwd 0xc0(%rcx),%ymm2,%ymm2
  da7a61:	vpmaddwd 0x80(%rcx),%ymm3,%ymm3
  da7a69:	vpaddd %ymm3,%ymm2,%ymm2
  da7a6d:	vmovdqu 0x8(%r9),%ymm3
  da7a73:	vpaddw 0x8(%r8),%ymm3,%ymm3
  da7a79:	vpaddw 0xa(%rdi),%ymm4,%ymm4
  da7a7e:	vpunpcklwd %ymm14,%ymm6,%ymm5
  da7a83:	vpmaddwd 0x40(%rcx),%ymm5,%ymm5
  da7a88:	vpaddd %ymm5,%ymm2,%ymm2
  da7a8c:	vpunpckhwd %ymm4,%ymm3,%ymm5
  da7a90:	vpunpcklwd %ymm4,%ymm3,%ymm3
  da7a94:	vpmaddwd (%rcx),%ymm3,%ymm3
  da7a98:	vpaddd %ymm2,%ymm1,%ymm1
  da7a9c:	vmovdqu 0x8(%rdi),%ymm2
  da7aa1:	vpunpcklwd -0xd8d189(%rip),%ymm2,%ymm4        # 1a920 <anon.d0b4188290527594ec9c3077380d8c05.2236.llvm.18078306828565754329+0x260>
  da7aa9:	vpshufb -0xd8c2b2(%rip),%ymm4,%ymm4        # 1b800 <anon.46faa55fc0c0e7039c2263dc0e03ad74.181.llvm.15643780285783194673+0x540>
  da7ab2:	vpmaddwd 0x200(%rcx),%ymm4,%ymm4
  da7aba:	vpaddd %ymm4,%ymm3,%ymm3
  da7abe:	vpaddd %ymm3,%ymm1,%ymm1
  da7ac2:	vpmaddwd 0x20(%rcx),%ymm5,%ymm3
  da7ac7:	vpunpckhwd -0xd8bd6f(%rip),%ymm2,%ymm2        # 1bd60 <anon.dfffc8809c62f00655f8db48cb5f601e.1518.llvm.287868192297488560+0x1c0>
  da7acf:	vpshufb -0xd8d718(%rip),%ymm2,%ymm2        # 1a3c0 <anon.46faa55fc0c0e7039c2263dc0e03ad74.183.llvm.15643780285783194673+0x1a0>
  da7ad8:	vpmaddwd 0x220(%rcx),%ymm2,%ymm2
  da7ae0:	vpaddd %ymm2,%ymm3,%ymm2
  da7ae4:	vpaddd %ymm2,%ymm0,%ymm0
  da7ae8:	vpsrad $0x7,%ymm1,%ymm1
  da7aed:	vpsrad $0x7,%ymm0,%ymm0
  da7af2:	mov    0x128(%rsp),%rcx
  da7afa:	vpbroadcastw (%rcx),%ymm2
  da7aff:	vpackusdw %ymm0,%ymm1,%ymm0
  da7b04:	vpminuw %ymm2,%ymm0,%ymm0
  da7b09:	mov    -0x8(%rdx),%rcx
  da7b0d:	vmovdqu %ymm0,(%rcx,%rax,2)
  da7b12:	inc    %rsi
  da7b15:	add    $0x10,%rdx
  da7b19:	cmp    %rsi,%r13
  da7b1c:	jne    da7864 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x6c4>
  da7b22:	mov    0x110(%rsp),%r15
  da7b2a:	test   %rbp,%rbp
  da7b2d:	mov    0x118(%rsp),%rbx
  da7b35:	lea    0x578(%rsp),%rax
  da7b3d:	jne    da74b3 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x313>
  da7b43:	mov    $0x1,%al
  da7b45:	jmp    da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7b4a:	xor    %eax,%eax
  da7b4c:	sub    %rdx,%rsi
  da7b4f:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7b55:	cmp    %rcx,%rsi
  da7b58:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7b5e:	lea    (%rdi,%rdx,2),%rdi
  da7b62:	mov    %rdi,0x1c0(%rsp)
  da7b6a:	mov    %rcx,0x1c8(%rsp)
  da7b72:	cmp    $0x2,%r13
  da7b76:	je     da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da7b7c:	xor    %eax,%eax
  da7b7e:	sub    %rdx,%rsi
  da7b81:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7b87:	cmp    %rcx,%rsi
  da7b8a:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7b90:	lea    (%rdi,%rdx,2),%rdi
  da7b94:	mov    %rdi,0x1d0(%rsp)
  da7b9c:	mov    %rcx,0x1d8(%rsp)
  da7ba4:	cmp    $0x3,%r13
  da7ba8:	je     da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da7bae:	xor    %eax,%eax
  da7bb0:	sub    %rdx,%rsi
  da7bb3:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7bb9:	cmp    %rcx,%rsi
  da7bbc:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7bc2:	lea    (%rdi,%rdx,2),%rdi
  da7bc6:	mov    %rdi,0x1e0(%rsp)
  da7bce:	mov    %rcx,0x1e8(%rsp)
  da7bd6:	cmp    $0x4,%r13
  da7bda:	je     da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da7be0:	sub    %rdx,%rsi
  da7be3:	jb     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7be9:	cmp    %rcx,%rsi
  da7bec:	mov    $0x0,%eax
  da7bf1:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7bf7:	lea    (%rdi,%rdx,2),%rax
  da7bfb:	mov    %rax,0x1f0(%rsp)
  da7c03:	mov    %rcx,0x1f8(%rsp)
  da7c0b:	cmp    $0x5,%r13
  da7c0f:	je     da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da7c15:	sub    %rdx,%rsi
  da7c18:	lea    (%rax,%rdx,2),%rdi
  da7c1c:	mov    $0x0,%r8d
  da7c22:	cmovae %rdi,%r8
  da7c26:	test   %r8,%r8
  da7c29:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7c2f:	cmp    %rcx,%rsi
  da7c32:	mov    $0x0,%eax
  da7c37:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7c3d:	mov    %r8,0x200(%rsp)
  da7c45:	mov    %rcx,0x208(%rsp)
  da7c4d:	cmp    $0x6,%r13
  da7c51:	je     da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da7c57:	sub    %rdx,%rsi
  da7c5a:	lea    (%rdi,%rdx,2),%rdi
  da7c5e:	mov    $0x0,%r8d
  da7c64:	cmovae %rdi,%r8
  da7c68:	test   %r8,%r8
  da7c6b:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7c71:	cmp    %rcx,%rsi
  da7c74:	mov    $0x0,%eax
  da7c79:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7c7f:	mov    %r8,0x210(%rsp)
  da7c87:	mov    %rcx,0x218(%rsp)
  da7c8f:	cmp    $0x7,%r13
  da7c93:	je     da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da7c99:	sub    %rdx,%rsi
  da7c9c:	lea    (%rdi,%rdx,2),%rdi
  da7ca0:	mov    $0x0,%r8d
  da7ca6:	cmovae %rdi,%r8
  da7caa:	test   %r8,%r8
  da7cad:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7cb3:	cmp    %rcx,%rsi
  da7cb6:	mov    $0x0,%eax
  da7cbb:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7cc1:	mov    %r8,0x220(%rsp)
  da7cc9:	mov    %rcx,0x228(%rsp)
  da7cd1:	cmp    $0x8,%r13
  da7cd5:	je     da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  da7cdb:	sub    %rdx,%rsi
  da7cde:	lea    (%rdi,%rdx,2),%rdi
  da7ce2:	mov    $0x0,%r8d
  da7ce8:	cmovae %rdi,%r8
  da7cec:	test   %r8,%r8
  da7cef:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7cf5:	cmp    %rcx,%rsi
  da7cf8:	mov    $0x0,%eax
  da7cfd:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7d03:	mov    %r8,0x230(%rsp)
  da7d0b:	mov    %rcx,0x238(%rsp)
  da7d13:	sub    %rdx,%rsi
  da7d16:	lea    (%rdi,%rdx,2),%rdi
  da7d1a:	mov    $0x0,%r8d
  da7d20:	cmovae %rdi,%r8
  da7d24:	test   %r8,%r8
  da7d27:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7d2d:	cmp    %rcx,%rsi
  da7d30:	mov    $0x0,%eax
  da7d35:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7d3b:	mov    %r8,0x240(%rsp)
  da7d43:	mov    %rcx,0x248(%rsp)
  da7d4b:	sub    %rdx,%rsi
  da7d4e:	lea    (%rdi,%rdx,2),%rdi
  da7d52:	mov    $0x0,%r8d
  da7d58:	cmovae %rdi,%r8
  da7d5c:	test   %r8,%r8
  da7d5f:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7d65:	cmp    %rcx,%rsi
  da7d68:	mov    $0x0,%eax
  da7d6d:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7d73:	mov    %r8,0x250(%rsp)
  da7d7b:	mov    %rcx,0x258(%rsp)
  da7d83:	sub    %rdx,%rsi
  da7d86:	lea    (%rdi,%rdx,2),%rdi
  da7d8a:	mov    $0x0,%r8d
  da7d90:	cmovae %rdi,%r8
  da7d94:	test   %r8,%r8
  da7d97:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7d9d:	cmp    %rcx,%rsi
  da7da0:	mov    $0x0,%eax
  da7da5:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7dab:	mov    %r8,0x260(%rsp)
  da7db3:	mov    %rcx,0x268(%rsp)
  da7dbb:	sub    %rdx,%rsi
  da7dbe:	lea    (%rdi,%rdx,2),%rdi
  da7dc2:	mov    $0x0,%r8d
  da7dc8:	cmovae %rdi,%r8
  da7dcc:	test   %r8,%r8
  da7dcf:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7dd5:	cmp    %rcx,%rsi
  da7dd8:	mov    $0x0,%eax
  da7ddd:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7de3:	mov    %r8,0x270(%rsp)
  da7deb:	mov    %rcx,0x278(%rsp)
  da7df3:	sub    %rdx,%rsi
  da7df6:	lea    (%rdi,%rdx,2),%rdi
  da7dfa:	mov    $0x0,%r8d
  da7e00:	cmovae %rdi,%r8
  da7e04:	test   %r8,%r8
  da7e07:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7e0d:	cmp    %rcx,%rsi
  da7e10:	mov    $0x0,%eax
  da7e15:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7e1b:	mov    %r8,0x280(%rsp)
  da7e23:	mov    %rcx,0x288(%rsp)
  da7e2b:	sub    %rdx,%rsi
  da7e2e:	lea    (%rdi,%rdx,2),%rdi
  da7e32:	mov    $0x0,%r8d
  da7e38:	cmovae %rdi,%r8
  da7e3c:	test   %r8,%r8
  da7e3f:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7e45:	cmp    %rcx,%rsi
  da7e48:	mov    $0x0,%eax
  da7e4d:	jb     da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7e53:	mov    %r8,0x290(%rsp)
  da7e5b:	mov    %rcx,0x298(%rsp)
  da7e63:	xor    %eax,%eax
  da7e65:	sub    %rdx,%rsi
  da7e68:	lea    (%rdi,%rdx,2),%rdx
  da7e6c:	cmovb  %rax,%rdx
  da7e70:	setae  %al
  da7e73:	cmp    %rcx,%rsi
  da7e76:	setb   %sil
  da7e7a:	test   %rdx,%rdx
  da7e7d:	je     da7230 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  da7e83:	and    %sil,%al
  da7e86:	mov    $0x0,%eax
  da7e8b:	jne    da7232 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  da7e91:	mov    %rdx,0x2a0(%rsp)
  da7e99:	mov    %rcx,0x2a8(%rsp)
  da7ea1:	jmp    da7454 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
