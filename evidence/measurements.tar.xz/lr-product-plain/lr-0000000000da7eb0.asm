
<WORKTREES>/qualification-1882/lr-product-plain/target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000da7eb0 <_RNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run>:
  da7eb0:	sub    $0x78,%rsp
  da7eb4:	mov    0x80(%rsp),%rax
  da7ebc:	mov    %rdx,0x10(%rsp)
  da7ec1:	mov    %rcx,0x18(%rsp)
  da7ec6:	mov    %r8,0x20(%rsp)
  da7ecb:	mov    %rdi,0x28(%rsp)
  da7ed0:	mov    %rsi,0x30(%rsp)
  da7ed5:	lea    0x10(%rsp),%rcx
  da7eda:	mov    %rcx,0x38(%rsp)
  da7edf:	lea    0x18(%rsp),%rcx
  da7ee4:	mov    %rcx,0x40(%rsp)
  da7ee9:	mov    %r9,0x48(%rsp)
  da7eee:	movups (%rax),%xmm0
  da7ef1:	movups %xmm0,0x50(%rsp)
  da7ef6:	mov    0x10(%rax),%rax
  da7efa:	mov    %rax,0x60(%rsp)
  da7eff:	lea    0xf(%rsp),%rax
  da7f04:	mov    %rax,0x68(%rsp)
  da7f09:	lea    0x88(%rsp),%rax
  da7f11:	mov    %rax,0x70(%rsp)
  da7f16:	lea    0x28(%rsp),%rdi
  da7f1b:	call   da71a0 <_RINvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs5XUajaoBfLn_13splot_lr_avx215filter_luma_run0bEB1W_>
  da7f20:	add    $0x78,%rsp
  da7f24:	ret
