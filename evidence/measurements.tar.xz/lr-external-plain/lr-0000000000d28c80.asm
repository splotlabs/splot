
<WORKTREES>/qualification-1882/lr-external-plain/target/release/lr-consumer:     file format elf64-x86-64


Disassembly of section .text:

0000000000d28c80 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run>:
  d28c80:	sub    $0x78,%rsp
  d28c84:	mov    0x80(%rsp),%rax
  d28c8c:	mov    %rdx,0x10(%rsp)
  d28c91:	mov    %rcx,0x18(%rsp)
  d28c96:	mov    %r8,0x20(%rsp)
  d28c9b:	mov    %rdi,0x28(%rsp)
  d28ca0:	mov    %rsi,0x30(%rsp)
  d28ca5:	lea    0x10(%rsp),%rcx
  d28caa:	mov    %rcx,0x38(%rsp)
  d28caf:	lea    0x18(%rsp),%rcx
  d28cb4:	mov    %rcx,0x40(%rsp)
  d28cb9:	mov    %r9,0x48(%rsp)
  d28cbe:	movups (%rax),%xmm0
  d28cc1:	movups %xmm0,0x50(%rsp)
  d28cc6:	mov    0x10(%rax),%rax
  d28cca:	mov    %rax,0x60(%rsp)
  d28ccf:	lea    0xf(%rsp),%rax
  d28cd4:	mov    %rax,0x68(%rsp)
  d28cd9:	lea    0x88(%rsp),%rax
  d28ce1:	mov    %rax,0x70(%rsp)
  d28ce6:	lea    0x28(%rsp),%rdi
  d28ceb:	call   d27f70 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_>
  d28cf0:	add    $0x78,%rsp
  d28cf4:	ret
