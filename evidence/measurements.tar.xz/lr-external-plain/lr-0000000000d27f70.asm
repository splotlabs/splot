
<WORKTREES>/qualification-1882/lr-external-plain/target/release/lr-consumer:     file format elf64-x86-64


Disassembly of section .text:

0000000000d27f70 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_>:
  d27f70:	push   %rbp
  d27f71:	push   %r15
  d27f73:	push   %r14
  d27f75:	push   %r13
  d27f77:	push   %r12
  d27f79:	push   %rbx
  d27f7a:	sub    $0x7b8,%rsp
  d27f81:	mov    (%rdi),%rsi
  d27f84:	mov    0x8(%rdi),%r10
  d27f88:	mov    0x10(%rdi),%rax
  d27f8c:	mov    (%rax),%r13
  d27f8f:	mov    0x18(%rdi),%rax
  d27f93:	mov    (%rax),%r8
  d27f96:	mov    0x8(%rax),%rax
  d27f9a:	mov    0x20(%rdi),%rcx
  d27f9e:	vmovdqu (%rcx),%ymm0
  d27fa2:	xor    %ebp,%ebp
  d27fa4:	sub    %r8,%rax
  d27fa7:	cmovae %rax,%rbp
  d27fab:	vmovdqu %ymm0,0x2b0(%rsp)
  d27fb4:	mov    %rbp,%rcx
  d27fb7:	and    $0xfffffffffffffff0,%rcx
  d27fbb:	sete   %dl
  d27fbe:	test   %r13,%r13
  d27fc1:	sete   %al
  d27fc4:	or     %dl,%al
  d27fc6:	cmp    $0x8,%r13
  d27fca:	ja     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d27fcc:	test   %al,%al
  d27fce:	jne    d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d27fd0:	mov    %rcx,%r9
  d27fd3:	xor    %eax,%eax
  d27fd5:	add    %r8,%r9
  d27fd8:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d27fda:	test   %r10,%r10
  d27fdd:	je     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d27fdf:	cmp    $0xfffffffffffffff7,%r9
  d27fe3:	ja     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d27fe5:	add    $0x8,%r9
  d27fe9:	mov    %r9,%r14
  d27fec:	sub    %r8,%r14
  d27fef:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d27ff1:	cmp    0x8(%rsi),%r9
  d27ff5:	ja     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d27ff7:	lea    0x8(%r13),%r12
  d27ffb:	cmp    %r12,%r10
  d27ffe:	jae    d28017 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0xa7>
  d28000:	xor    %eax,%eax
  d28002:	add    $0x7b8,%rsp
  d28009:	pop    %rbx
  d2800a:	pop    %r12
  d2800c:	pop    %r13
  d2800e:	pop    %r14
  d28010:	pop    %r15
  d28012:	pop    %rbp
  d28013:	vzeroupper
  d28016:	ret
  d28017:	mov    0x28(%rdi),%rax
  d2801b:	mov    0x30(%rdi),%r11
  d2801f:	mov    0x38(%rdi),%rdx
  d28023:	mov    0x48(%rdi),%rdi
  d28027:	mov    %rdi,0x128(%rsp)
  d2802f:	mov    (%rsi),%rdi
  d28032:	lea    (%rdi,%r8,2),%rdi
  d28036:	mov    %rdi,0x10(%rsp)
  d2803b:	mov    %r14,0x18(%rsp)
  d28040:	mov    %rdi,0x20(%rsp)
  d28045:	mov    %r14,0x28(%rsp)
  d2804a:	mov    %rdi,0x30(%rsp)
  d2804f:	mov    %r14,0x38(%rsp)
  d28054:	mov    %rdi,0x40(%rsp)
  d28059:	mov    %r14,0x48(%rsp)
  d2805e:	mov    %rdi,0x50(%rsp)
  d28063:	mov    %r14,0x58(%rsp)
  d28068:	mov    %rdi,0x60(%rsp)
  d2806d:	mov    %r14,0x68(%rsp)
  d28072:	mov    %rdi,0x70(%rsp)
  d28077:	mov    %r14,0x78(%rsp)
  d2807c:	mov    %rdi,0x80(%rsp)
  d28084:	mov    %r14,0x88(%rsp)
  d2808c:	mov    %rdi,0x90(%rsp)
  d28094:	mov    %r14,0x98(%rsp)
  d2809c:	mov    %rdi,0xa0(%rsp)
  d280a4:	mov    %r14,0xa8(%rsp)
  d280ac:	mov    %rdi,0xb0(%rsp)
  d280b4:	mov    %r14,0xb8(%rsp)
  d280bc:	mov    %rdi,0xc0(%rsp)
  d280c4:	mov    %r14,0xc8(%rsp)
  d280cc:	mov    %rdi,0xd0(%rsp)
  d280d4:	mov    %r14,0xd8(%rsp)
  d280dc:	mov    %rdi,0xe0(%rsp)
  d280e4:	mov    %r14,0xe8(%rsp)
  d280ec:	mov    %rdi,0xf0(%rsp)
  d280f4:	mov    %r14,0xf8(%rsp)
  d280fc:	mov    %rdi,0x120(%rsp)
  d28104:	mov    %rdi,0x100(%rsp)
  d2810c:	cmp    $0x10,%r10
  d28110:	mov    $0x10,%edi
  d28115:	cmovb  %r10,%rdi
  d28119:	mov    %r14,0x108(%rsp)
  d28121:	shl    $0x4,%edi
  d28124:	xor    %r10d,%r10d
  d28127:	lea    (%r8,%r8,1),%r15
  d2812b:	nopl   0x0(%rax,%rax,1)
  d28130:	cmp    %r10,%rdi
  d28133:	je     d2815d <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x1ed>
  d28135:	cmp    0x8(%rsi,%r10,1),%r9
  d2813a:	ja     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28140:	dec    %r12
  d28143:	mov    (%rsi,%r10,1),%rbx
  d28147:	add    %r15,%rbx
  d2814a:	mov    %rbx,0x10(%rsp,%r10,1)
  d2814f:	mov    %r14,0x18(%rsp,%r10,1)
  d28154:	add    $0x10,%r10
  d28158:	test   %r12,%r12
  d2815b:	jne    d28130 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x1c0>
  d2815d:	vbroadcasti128 -0xce5036(%rip),%ymm0        # 43130 <anon.936c60de95d7a09f3acdd5b08a91176d.199.llvm.6645579717452751935+0xeb0>
  d28166:	vmovdqu %ymm0,0x1b0(%rsp)
  d2816f:	vmovdqu %ymm0,0x1d0(%rsp)
  d28178:	vmovdqu %ymm0,0x1f0(%rsp)
  d28181:	vmovdqu %ymm0,0x210(%rsp)
  d2818a:	vmovdqu %ymm0,0x230(%rsp)
  d28193:	vmovdqu %ymm0,0x250(%rsp)
  d2819c:	vmovdqu %ymm0,0x270(%rsp)
  d281a5:	vmovdqu %ymm0,0x290(%rsp)
  d281ae:	mov    %r11,%rsi
  d281b1:	sub    %r8,%rsi
  d281b4:	cmp    %rcx,%rdx
  d281b7:	jae    d281ef <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x27f>
  d281b9:	cmp    %r8,%r11
  d281bc:	setb   %dl
  d281bf:	cmp    %rcx,%rsi
  d281c2:	setb   %sil
  d281c6:	or     %dl,%sil
  d281c9:	jne    d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d281cf:	lea    (%rax,%r8,2),%rax
  d281d3:	mov    %rax,0x1b0(%rsp)
  d281db:	mov    %rcx,0x1b8(%rsp)
  d281e3:	cmp    $0x1,%r13
  d281e7:	jne    d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d281ed:	jmp    d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d281ef:	cmp    %r8,%r11
  d281f2:	setb   %dil
  d281f6:	cmp    %rcx,%rsi
  d281f9:	setb   %r9b
  d281fd:	or     %dil,%r9b
  d28200:	jne    d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28206:	lea    (%rax,%r8,2),%rdi
  d2820a:	mov    %rdi,0x1b0(%rsp)
  d28212:	mov    %rcx,0x1b8(%rsp)
  d2821a:	cmp    $0x1,%r13
  d2821e:	jne    d2891a <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x9aa>
  d28224:	mov    0x2b0(%rsp),%rbx
  d2822c:	test   %rbx,%rbx
  d2822f:	jne    d2825c <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2ec>
  d28231:	vpbroadcastq 0x2b8(%rsp),%ymm0
  d2823b:	vmovdqu %ymm0,0x330(%rsp)
  d28244:	lea    0x578(%rsp),%rdi
  d2824c:	lea    0x330(%rsp),%rsi
  d28254:	vzeroupper
  d28257:	call   d28e00 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  d2825c:	shr    $0x4,%rbp
  d28260:	mov    $0x1,%al
  d28262:	je     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28268:	lea    0x578(%rsp),%rax
  d28270:	xor    %r15d,%r15d
  d28273:	movq   $0x0,(%rsp)
  d2827b:	mov    %rbx,0x118(%rsp)
  d28283:	mov    %rax,0x8(%rsp)
  d28288:	test   %rbx,%rbx
  d2828b:	je     d282d5 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x365>
  d2828d:	lea    0x2d0(%rsp),%rdi
  d28295:	lea    0x2b0(%rsp),%rsi
  d2829d:	mov    (%rsp),%rdx
  d282a1:	vzeroupper
  d282a4:	call   d28d00 <_RNvMCs3HZP85FyIZE_15splot_lr_kernelNtB2_7Classes5group>
  d282a9:	cmpq   $0x0,0x2d0(%rsp)
  d282b2:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d282b8:	lea    0x330(%rsp),%r12
  d282c0:	mov    %r12,%rdi
  d282c3:	lea    0x2d0(%rsp),%rsi
  d282cb:	call   d28e00 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
  d282d0:	mov    %r12,0x8(%rsp)
  d282d5:	mov    %r14,%rcx
  d282d8:	sub    %r15,%rcx
  d282db:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d282e1:	cmp    $0x18,%rcx
  d282e5:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d282eb:	mov    0x120(%rsp),%rcx
  d282f3:	lea    (%rcx,%r15,2),%rcx
  d282f7:	vmovq  %rcx,%xmm0
  d282fc:	vpbroadcastq %xmm0,%ymm0
  d28301:	vmovdqu %ymm0,0x178(%rsp)
  d2830a:	mov    %rcx,0x198(%rsp)
  d28312:	mov    %rcx,0x1a0(%rsp)
  d2831a:	mov    %rcx,0x1a8(%rsp)
  d28322:	mov    0x18(%rsp),%rcx
  d28327:	sub    %r15,%rcx
  d2832a:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28330:	cmp    $0x18,%rcx
  d28334:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2833a:	lea    (%r15,%r15,1),%rcx
  d2833e:	mov    0x10(%rsp),%rdx
  d28343:	add    %rcx,%rdx
  d28346:	mov    %rdx,0x130(%rsp)
  d2834e:	mov    0x28(%rsp),%rdx
  d28353:	sub    %r15,%rdx
  d28356:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2835c:	cmp    $0x18,%rdx
  d28360:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28366:	mov    0x20(%rsp),%rdx
  d2836b:	add    %rcx,%rdx
  d2836e:	mov    %rdx,0x138(%rsp)
  d28376:	mov    0x38(%rsp),%rdx
  d2837b:	sub    %r15,%rdx
  d2837e:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28384:	cmp    $0x18,%rdx
  d28388:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2838e:	mov    0x30(%rsp),%rdx
  d28393:	add    %rcx,%rdx
  d28396:	mov    %rdx,0x140(%rsp)
  d2839e:	mov    0x48(%rsp),%rdx
  d283a3:	sub    %r15,%rdx
  d283a6:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d283ac:	cmp    $0x18,%rdx
  d283b0:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d283b6:	mov    0x40(%rsp),%rdx
  d283bb:	add    %rcx,%rdx
  d283be:	mov    %rdx,0x148(%rsp)
  d283c6:	mov    0x58(%rsp),%rdx
  d283cb:	sub    %r15,%rdx
  d283ce:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d283d4:	cmp    $0x18,%rdx
  d283d8:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d283de:	mov    0x50(%rsp),%rdx
  d283e3:	add    %rcx,%rdx
  d283e6:	mov    %rdx,0x150(%rsp)
  d283ee:	mov    0x68(%rsp),%rdx
  d283f3:	sub    %r15,%rdx
  d283f6:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d283fc:	cmp    $0x18,%rdx
  d28400:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28406:	mov    0x60(%rsp),%rdx
  d2840b:	add    %rcx,%rdx
  d2840e:	mov    %rdx,0x158(%rsp)
  d28416:	mov    0x78(%rsp),%rdx
  d2841b:	sub    %r15,%rdx
  d2841e:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28424:	cmp    $0x18,%rdx
  d28428:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2842e:	mov    0x70(%rsp),%rdx
  d28433:	add    %rcx,%rdx
  d28436:	mov    %rdx,0x160(%rsp)
  d2843e:	mov    0x88(%rsp),%rdx
  d28446:	sub    %r15,%rdx
  d28449:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2844f:	cmp    $0x18,%rdx
  d28453:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28459:	mov    0x80(%rsp),%rdx
  d28461:	add    %rcx,%rdx
  d28464:	mov    %rdx,0x168(%rsp)
  d2846c:	mov    0x98(%rsp),%rdx
  d28474:	sub    %r15,%rdx
  d28477:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2847d:	cmp    $0x18,%rdx
  d28481:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28487:	mov    0x90(%rsp),%rdx
  d2848f:	add    %rcx,%rdx
  d28492:	mov    %rdx,0x170(%rsp)
  d2849a:	cmp    $0x1,%r13
  d2849e:	je     d28617 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  d284a4:	mov    0xa8(%rsp),%rdx
  d284ac:	sub    %r15,%rdx
  d284af:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d284b5:	cmp    $0x18,%rdx
  d284b9:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d284bf:	mov    0xa0(%rsp),%rdx
  d284c7:	add    %rcx,%rdx
  d284ca:	mov    %rdx,0x178(%rsp)
  d284d2:	cmp    $0x2,%r13
  d284d6:	je     d28617 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  d284dc:	mov    0xb8(%rsp),%rdx
  d284e4:	sub    %r15,%rdx
  d284e7:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d284ed:	cmp    $0x18,%rdx
  d284f1:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d284f7:	mov    0xb0(%rsp),%rdx
  d284ff:	add    %rcx,%rdx
  d28502:	mov    %rdx,0x180(%rsp)
  d2850a:	cmp    $0x3,%r13
  d2850e:	je     d28617 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  d28514:	mov    0xc8(%rsp),%rdx
  d2851c:	sub    %r15,%rdx
  d2851f:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28525:	cmp    $0x18,%rdx
  d28529:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2852f:	mov    0xc0(%rsp),%rdx
  d28537:	add    %rcx,%rdx
  d2853a:	mov    %rdx,0x188(%rsp)
  d28542:	cmp    $0x4,%r13
  d28546:	je     d28617 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  d2854c:	mov    0xd8(%rsp),%rdx
  d28554:	sub    %r15,%rdx
  d28557:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2855d:	cmp    $0x18,%rdx
  d28561:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28567:	mov    0xd0(%rsp),%rdx
  d2856f:	add    %rcx,%rdx
  d28572:	mov    %rdx,0x190(%rsp)
  d2857a:	cmp    $0x5,%r13
  d2857e:	je     d28617 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  d28584:	mov    0xe8(%rsp),%rdx
  d2858c:	sub    %r15,%rdx
  d2858f:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28595:	cmp    $0x18,%rdx
  d28599:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2859f:	mov    0xe0(%rsp),%rdx
  d285a7:	add    %rcx,%rdx
  d285aa:	mov    %rdx,0x198(%rsp)
  d285b2:	cmp    $0x6,%r13
  d285b6:	je     d28617 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  d285b8:	mov    0xf8(%rsp),%rdx
  d285c0:	sub    %r15,%rdx
  d285c3:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d285c9:	cmp    $0x18,%rdx
  d285cd:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d285d3:	mov    0xf0(%rsp),%rdx
  d285db:	add    %rcx,%rdx
  d285de:	mov    %rdx,0x1a0(%rsp)
  d285e6:	cmp    $0x7,%r13
  d285ea:	je     d28617 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6a7>
  d285ec:	mov    0x108(%rsp),%rdx
  d285f4:	sub    %r15,%rdx
  d285f7:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d285fd:	cmp    $0x18,%rdx
  d28601:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28607:	add    0x100(%rsp),%rcx
  d2860f:	mov    %rcx,0x1a8(%rsp)
  d28617:	lea    0x10(%r15),%rax
  d2861b:	mov    %rax,0x110(%rsp)
  d28623:	dec    %rbp
  d28626:	incq   (%rsp)
  d2862a:	lea    0x1b8(%rsp),%rdx
  d28632:	xor    %esi,%esi
  d28634:	mov    (%rdx),%rdi
  d28637:	sub    %r15,%rdi
  d2863a:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28640:	cmp    $0x10,%rdi
  d28644:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d2864a:	cmp    $0x7,%rsi
  d2864e:	ja     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28654:	mov    0x158(%rsp,%rsi,8),%r8
  d2865c:	mov    0x148(%rsp,%rsi,8),%r9
  d28664:	mov    0x150(%rsp,%rsi,8),%rdi
  d2866c:	vmovdqu (%rdi),%ymm4
  d28670:	vmovdqu 0x2(%rdi),%ymm7
  d28675:	mov    0x160(%rsp,%rsi,8),%r10
  d2867d:	mov    0x140(%rsp,%rsi,8),%r11
  d28685:	vmovups 0x6(%r8),%ymm0
  d2868b:	vmovups %ymm0,0x310(%rsp)
  d28694:	vmovdqu 0x6(%r11),%ymm8
  d2869a:	vmovdqu 0xa(%r11),%ymm9
  d286a0:	vmovdqu 0x4(%r9),%ymm10
  d286a6:	vmovdqu 0x6(%r9),%ymm6
  d286ac:	mov    %r15,%rax
  d286af:	mov    0x168(%rsp,%rsi,8),%r15
  d286b7:	mov    0x130(%rsp,%rsi,8),%rcx
  d286bf:	mov    0x138(%rsp,%rsi,8),%r12
  d286c7:	mov    0x170(%rsp,%rsi,8),%rbx
  d286cf:	vmovdqu 0x2(%r12),%ymm1
  d286d6:	vmovdqu 0xe(%r12),%ymm2
  d286dd:	vpaddw 0xe(%r15),%ymm1,%ymm0
  d286e3:	vmovdqu %ymm0,0x2f0(%rsp)
  d286ec:	vpaddw 0x2(%r15),%ymm2,%ymm2
  d286f2:	vmovdqu 0x8(%rcx),%ymm3
  d286f7:	vpunpckhwd %ymm2,%ymm0,%ymm5
  d286fb:	mov    0x8(%rsp),%rcx
  d28700:	vpmaddwd 0x1e0(%rcx),%ymm5,%ymm12
  d28708:	vpaddw 0x8(%rbx),%ymm3,%ymm3
  d2870d:	vpaddw 0x10(%rdi),%ymm4,%ymm4
  d28712:	vmovdqu 0x8(%r12),%ymm5
  d28719:	vpunpckhwd %ymm4,%ymm3,%ymm11
  d2871d:	vpmaddwd 0x1a0(%rcx),%ymm11,%ymm13
  d28725:	vpaddw 0x8(%r15),%ymm5,%ymm5
  d2872b:	mov    %rax,%r15
  d2872e:	vpaddw 0xe(%rdi),%ymm7,%ymm7
  d28733:	vmovdqu 0xc(%r9),%ymm11
  d28739:	vpunpckhwd %ymm7,%ymm5,%ymm14
  d2873d:	vpmaddwd 0x160(%rcx),%ymm14,%ymm14
  d28745:	vpaddw 0xc(%r8),%ymm10,%ymm10
  d2874b:	vpaddw 0x4(%r8),%ymm11,%ymm11
  d28751:	vpaddd %ymm12,%ymm13,%ymm15
  d28756:	vpunpckhwd %ymm11,%ymm10,%ymm12
  d2875b:	vpmaddwd 0x120(%rcx),%ymm12,%ymm12
  d28763:	vpaddw 0xa(%r10),%ymm8,%ymm8
  d28769:	vpaddw 0x6(%r10),%ymm9,%ymm9
  d2876f:	vpaddd %ymm12,%ymm14,%ymm14
  d28774:	vpunpckhwd %ymm9,%ymm8,%ymm12
  d28779:	vpmaddwd 0xe0(%rcx),%ymm12,%ymm0
  d28781:	vpaddw 0xa(%r8),%ymm6,%ymm12
  d28787:	vmovdqu 0x310(%rsp),%ymm1
  d28790:	vpaddw 0xa(%r9),%ymm1,%ymm13
  d28796:	vpaddd %ymm14,%ymm15,%ymm15
  d2879b:	vpunpckhwd %ymm13,%ymm12,%ymm6
  d287a0:	vpmaddwd 0xa0(%rcx),%ymm6,%ymm6
  d287a8:	vmovdqu 0x8(%r11),%ymm14
  d287ae:	vpaddd %ymm6,%ymm0,%ymm0
  d287b2:	vpaddw 0x8(%r10),%ymm14,%ymm6
  d287b8:	vmovdqu 0x4(%rdi),%ymm14
  d287bd:	vpaddw 0xc(%rdi),%ymm14,%ymm14
  d287c2:	vpunpckhwd %ymm14,%ymm6,%ymm1
  d287c7:	vpmaddwd 0x60(%rcx),%ymm1,%ymm1
  d287cc:	vpaddd %ymm1,%ymm0,%ymm0
  d287d0:	vpaddd %ymm0,%ymm15,%ymm0
  d287d4:	vmovdqu 0x2f0(%rsp),%ymm1
  d287dd:	vpunpcklwd %ymm2,%ymm1,%ymm1
  d287e1:	vpunpcklwd %ymm4,%ymm3,%ymm2
  d287e5:	vpunpcklwd %ymm7,%ymm5,%ymm3
  d287e9:	vpunpcklwd %ymm11,%ymm10,%ymm4
  d287ee:	vpmaddwd 0x1c0(%rcx),%ymm1,%ymm1
  d287f6:	vpmaddwd 0x180(%rcx),%ymm2,%ymm2
  d287fe:	vpmaddwd 0x140(%rcx),%ymm3,%ymm3
  d28806:	vpmaddwd 0x100(%rcx),%ymm4,%ymm4
  d2880e:	vpaddd %ymm1,%ymm2,%ymm1
  d28812:	vpaddd %ymm4,%ymm3,%ymm2
  d28816:	vpaddd %ymm2,%ymm1,%ymm1
  d2881a:	vpunpcklwd %ymm9,%ymm8,%ymm2
  d2881f:	vpunpcklwd %ymm13,%ymm12,%ymm3
  d28824:	vmovdqu 0x6(%rdi),%ymm4
  d28829:	vpmaddwd 0xc0(%rcx),%ymm2,%ymm2
  d28831:	vpmaddwd 0x80(%rcx),%ymm3,%ymm3
  d28839:	vpaddd %ymm3,%ymm2,%ymm2
  d2883d:	vmovdqu 0x8(%r9),%ymm3
  d28843:	vpaddw 0x8(%r8),%ymm3,%ymm3
  d28849:	vpaddw 0xa(%rdi),%ymm4,%ymm4
  d2884e:	vpunpcklwd %ymm14,%ymm6,%ymm5
  d28853:	vpmaddwd 0x40(%rcx),%ymm5,%ymm5
  d28858:	vpaddd %ymm5,%ymm2,%ymm2
  d2885c:	vpunpckhwd %ymm4,%ymm3,%ymm5
  d28860:	vpunpcklwd %ymm4,%ymm3,%ymm3
  d28864:	vpmaddwd (%rcx),%ymm3,%ymm3
  d28868:	vpaddd %ymm2,%ymm1,%ymm1
  d2886c:	vmovdqu 0x8(%rdi),%ymm2
  d28871:	vpunpcklwd -0xce36b9(%rip),%ymm2,%ymm4        # 451c0 <anon.641001004215a5507dd026cf93eadf7f.0.llvm.16322531315505051856+0x2e0>
  d28879:	vpshufb -0xce29e2(%rip),%ymm4,%ymm4        # 45ea0 <anon.641001004215a5507dd026cf93eadf7f.0.llvm.16322531315505051856+0xfc0>
  d28882:	vpmaddwd 0x200(%rcx),%ymm4,%ymm4
  d2888a:	vpaddd %ymm4,%ymm3,%ymm3
  d2888e:	vpaddd %ymm3,%ymm1,%ymm1
  d28892:	vpmaddwd 0x20(%rcx),%ymm5,%ymm3
  d28897:	vpunpckhwd -0xce259f(%rip),%ymm2,%ymm2        # 46300 <anon.641001004215a5507dd026cf93eadf7f.0.llvm.16322531315505051856+0x1420>
  d2889f:	vpshufb -0xce3b28(%rip),%ymm2,%ymm2        # 44d80 <anon.b06d5af9046adfc4f8b836ea1c075b06.152.llvm.16901765343427469375+0x20>
  d288a8:	vpmaddwd 0x220(%rcx),%ymm2,%ymm2
  d288b0:	vpaddd %ymm2,%ymm3,%ymm2
  d288b4:	vpaddd %ymm2,%ymm0,%ymm0
  d288b8:	vpsrad $0x7,%ymm1,%ymm1
  d288bd:	vpsrad $0x7,%ymm0,%ymm0
  d288c2:	mov    0x128(%rsp),%rcx
  d288ca:	vpbroadcastw (%rcx),%ymm2
  d288cf:	vpackusdw %ymm0,%ymm1,%ymm0
  d288d4:	vpminuw %ymm2,%ymm0,%ymm0
  d288d9:	mov    -0x8(%rdx),%rcx
  d288dd:	vmovdqu %ymm0,(%rcx,%rax,2)
  d288e2:	inc    %rsi
  d288e5:	add    $0x10,%rdx
  d288e9:	cmp    %rsi,%r13
  d288ec:	jne    d28634 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x6c4>
  d288f2:	mov    0x110(%rsp),%r15
  d288fa:	test   %rbp,%rbp
  d288fd:	mov    0x118(%rsp),%rbx
  d28905:	lea    0x578(%rsp),%rax
  d2890d:	jne    d28283 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x313>
  d28913:	mov    $0x1,%al
  d28915:	jmp    d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d2891a:	xor    %eax,%eax
  d2891c:	sub    %rdx,%rsi
  d2891f:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28925:	cmp    %rcx,%rsi
  d28928:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d2892e:	lea    (%rdi,%rdx,2),%rdi
  d28932:	mov    %rdi,0x1c0(%rsp)
  d2893a:	mov    %rcx,0x1c8(%rsp)
  d28942:	cmp    $0x2,%r13
  d28946:	je     d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d2894c:	xor    %eax,%eax
  d2894e:	sub    %rdx,%rsi
  d28951:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28957:	cmp    %rcx,%rsi
  d2895a:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28960:	lea    (%rdi,%rdx,2),%rdi
  d28964:	mov    %rdi,0x1d0(%rsp)
  d2896c:	mov    %rcx,0x1d8(%rsp)
  d28974:	cmp    $0x3,%r13
  d28978:	je     d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d2897e:	xor    %eax,%eax
  d28980:	sub    %rdx,%rsi
  d28983:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28989:	cmp    %rcx,%rsi
  d2898c:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28992:	lea    (%rdi,%rdx,2),%rdi
  d28996:	mov    %rdi,0x1e0(%rsp)
  d2899e:	mov    %rcx,0x1e8(%rsp)
  d289a6:	cmp    $0x4,%r13
  d289aa:	je     d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d289b0:	sub    %rdx,%rsi
  d289b3:	jb     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d289b9:	cmp    %rcx,%rsi
  d289bc:	mov    $0x0,%eax
  d289c1:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d289c7:	lea    (%rdi,%rdx,2),%rax
  d289cb:	mov    %rax,0x1f0(%rsp)
  d289d3:	mov    %rcx,0x1f8(%rsp)
  d289db:	cmp    $0x5,%r13
  d289df:	je     d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d289e5:	sub    %rdx,%rsi
  d289e8:	lea    (%rax,%rdx,2),%rdi
  d289ec:	mov    $0x0,%r8d
  d289f2:	cmovae %rdi,%r8
  d289f6:	test   %r8,%r8
  d289f9:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d289ff:	cmp    %rcx,%rsi
  d28a02:	mov    $0x0,%eax
  d28a07:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28a0d:	mov    %r8,0x200(%rsp)
  d28a15:	mov    %rcx,0x208(%rsp)
  d28a1d:	cmp    $0x6,%r13
  d28a21:	je     d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d28a27:	sub    %rdx,%rsi
  d28a2a:	lea    (%rdi,%rdx,2),%rdi
  d28a2e:	mov    $0x0,%r8d
  d28a34:	cmovae %rdi,%r8
  d28a38:	test   %r8,%r8
  d28a3b:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28a41:	cmp    %rcx,%rsi
  d28a44:	mov    $0x0,%eax
  d28a49:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28a4f:	mov    %r8,0x210(%rsp)
  d28a57:	mov    %rcx,0x218(%rsp)
  d28a5f:	cmp    $0x7,%r13
  d28a63:	je     d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d28a69:	sub    %rdx,%rsi
  d28a6c:	lea    (%rdi,%rdx,2),%rdi
  d28a70:	mov    $0x0,%r8d
  d28a76:	cmovae %rdi,%r8
  d28a7a:	test   %r8,%r8
  d28a7d:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28a83:	cmp    %rcx,%rsi
  d28a86:	mov    $0x0,%eax
  d28a8b:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28a91:	mov    %r8,0x220(%rsp)
  d28a99:	mov    %rcx,0x228(%rsp)
  d28aa1:	cmp    $0x8,%r13
  d28aa5:	je     d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
  d28aab:	sub    %rdx,%rsi
  d28aae:	lea    (%rdi,%rdx,2),%rdi
  d28ab2:	mov    $0x0,%r8d
  d28ab8:	cmovae %rdi,%r8
  d28abc:	test   %r8,%r8
  d28abf:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28ac5:	cmp    %rcx,%rsi
  d28ac8:	mov    $0x0,%eax
  d28acd:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28ad3:	mov    %r8,0x230(%rsp)
  d28adb:	mov    %rcx,0x238(%rsp)
  d28ae3:	sub    %rdx,%rsi
  d28ae6:	lea    (%rdi,%rdx,2),%rdi
  d28aea:	mov    $0x0,%r8d
  d28af0:	cmovae %rdi,%r8
  d28af4:	test   %r8,%r8
  d28af7:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28afd:	cmp    %rcx,%rsi
  d28b00:	mov    $0x0,%eax
  d28b05:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28b0b:	mov    %r8,0x240(%rsp)
  d28b13:	mov    %rcx,0x248(%rsp)
  d28b1b:	sub    %rdx,%rsi
  d28b1e:	lea    (%rdi,%rdx,2),%rdi
  d28b22:	mov    $0x0,%r8d
  d28b28:	cmovae %rdi,%r8
  d28b2c:	test   %r8,%r8
  d28b2f:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28b35:	cmp    %rcx,%rsi
  d28b38:	mov    $0x0,%eax
  d28b3d:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28b43:	mov    %r8,0x250(%rsp)
  d28b4b:	mov    %rcx,0x258(%rsp)
  d28b53:	sub    %rdx,%rsi
  d28b56:	lea    (%rdi,%rdx,2),%rdi
  d28b5a:	mov    $0x0,%r8d
  d28b60:	cmovae %rdi,%r8
  d28b64:	test   %r8,%r8
  d28b67:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28b6d:	cmp    %rcx,%rsi
  d28b70:	mov    $0x0,%eax
  d28b75:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28b7b:	mov    %r8,0x260(%rsp)
  d28b83:	mov    %rcx,0x268(%rsp)
  d28b8b:	sub    %rdx,%rsi
  d28b8e:	lea    (%rdi,%rdx,2),%rdi
  d28b92:	mov    $0x0,%r8d
  d28b98:	cmovae %rdi,%r8
  d28b9c:	test   %r8,%r8
  d28b9f:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28ba5:	cmp    %rcx,%rsi
  d28ba8:	mov    $0x0,%eax
  d28bad:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28bb3:	mov    %r8,0x270(%rsp)
  d28bbb:	mov    %rcx,0x278(%rsp)
  d28bc3:	sub    %rdx,%rsi
  d28bc6:	lea    (%rdi,%rdx,2),%rdi
  d28bca:	mov    $0x0,%r8d
  d28bd0:	cmovae %rdi,%r8
  d28bd4:	test   %r8,%r8
  d28bd7:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28bdd:	cmp    %rcx,%rsi
  d28be0:	mov    $0x0,%eax
  d28be5:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28beb:	mov    %r8,0x280(%rsp)
  d28bf3:	mov    %rcx,0x288(%rsp)
  d28bfb:	sub    %rdx,%rsi
  d28bfe:	lea    (%rdi,%rdx,2),%rdi
  d28c02:	mov    $0x0,%r8d
  d28c08:	cmovae %rdi,%r8
  d28c0c:	test   %r8,%r8
  d28c0f:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28c15:	cmp    %rcx,%rsi
  d28c18:	mov    $0x0,%eax
  d28c1d:	jb     d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28c23:	mov    %r8,0x290(%rsp)
  d28c2b:	mov    %rcx,0x298(%rsp)
  d28c33:	xor    %eax,%eax
  d28c35:	sub    %rdx,%rsi
  d28c38:	lea    (%rdi,%rdx,2),%rdx
  d28c3c:	cmovb  %rax,%rdx
  d28c40:	setae  %al
  d28c43:	cmp    %rcx,%rsi
  d28c46:	setb   %sil
  d28c4a:	test   %rdx,%rdx
  d28c4d:	je     d28000 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x90>
  d28c53:	and    %sil,%al
  d28c56:	mov    $0x0,%eax
  d28c5b:	jne    d28002 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x92>
  d28c61:	mov    %rdx,0x2a0(%rsp)
  d28c69:	mov    %rcx,0x2a8(%rsp)
  d28c71:	jmp    d28224 <_RINvNvXs2_NtNtCsj9XtZgyEy2O_13fearless_simd9generated4avx2NtB8_4Avx2NtNtBa_10simd_trait4Simd9vectorize14vectorize_avx2NCNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run0bEB1W_+0x2b4>
