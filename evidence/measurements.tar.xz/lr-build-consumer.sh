set -euo pipefail
root=$(pwd)
variant=$1
cd "$root/lr-external-$variant"
cargo +1.100.0 generate-lockfile --offline > lock.log 2>&1
build=(env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u CARGO_BUILD_RUSTFLAGS -u RUSTC_WRAPPER)
if [[ $variant == unit ]]; then build+=(RUSTC_WRAPPER="$root/../splot-1934-lr-module/scripts/rustc-lr-prototype.py" SPLOT_LR_COMPILE_LOG="$root/lr-external-unit/flags.tsv"); fi
systemd-run --user --scope --quiet -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p CPUQuota=180% flock "$root/build.lock" taskset -c 6-11,14-19 "${build[@]}" cargo +1.100.0 build --release --locked --offline -j1 > build.log 2>&1
exe="$PWD/target/release/lr-consumer"
sha256sum "$exe" > binary.sha256
for stream in syn-3frame-multiref-64x64 syn-3frame-deblock-subpu-chroma-64x32-10bit-q90; do
 input="$root/../splot-1934-blend-callback/tests/conformance/vectors/valid/$stream.ivf"
 "$exe" avx2 "$input" raw 99999 | sha256sum > "$stream.avx2.sha"
 "$root/qemu/usr/bin/qemu-x86_64" -cpu qemu64,-pni,-sse4a,-ssse3,-sse4.1,-sse4.2 "$exe" sse2 "$input" raw 99999 | sha256sum > "$stream.sse2.sha"
 cmp "$stream.avx2.sha" "$stream.sse2.sha"
 old=$(awk -v name="$stream" '$1 == "avx2" && $2 == name {print $3}' "$root/standalone-decoder/parity.txt")
 read -r actual rest < "$stream.avx2.sha"
 [[ $old == "$actual" ]]
done
ritual="$root/ci-data/RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf"
taskset -c 2 valgrind --tool=callgrind --callgrind-out-file=ritual16.cg --log-file=ritual16.log "$exe" avx2 "$ritual" null 16
