set -euo pipefail
while [[ ! -f compound/avm.txt ]] || [[ $(wc -l < compound/avm.txt) -lt 21 ]]; do sleep 5; done
flock build.lock python3 -u bench.py compound-four-way.csv compound module function shipped > compound-four-way.txt
