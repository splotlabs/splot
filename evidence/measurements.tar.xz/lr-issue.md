## Shared luma Wiener restoration experiment

**Rollout decision: keep the standalone restoration crates and compiler wrapper on the experiment branch.** Ordinary Cargo successfully reaches the concrete kernel in a downstream application. Its 600-frame RitualDance elapsed median improved by 0.49% against control, with a 95% paired interval spanning −1.13% to +10.32%. The extra compiler flags saved another 0.084% of whole-application instructions and the full-stream unit-vs-plain interval also includes zero. The ordinary release CLI was faster in the short RitualDance prefix (−8.89%, interval −17.72% to −0.17%), but remained slower than shipped on that prefix and the downstream full stream did not establish a repeatable improvement. That evidence does not justify two extra crates or a wrapper in the release. [Measured source](https://github.com/splotlabs/splot/commit/9b8a8b639dae69a3fd6a4ea04b3b5acddbf0a969) · [Signed lint-only follow-up](https://github.com/splotlabs/splot/commit/deba2c412167159ad56a767bbe463ad37c50b5ef).

The measured control is `07cdddce`. The experiment uses `9b8a8b63` on `experiment/simd-1934-lr-module`. The decoder hands the startup-selected AVX2 token, borrowed 10-bit rows, class weights, and output slice to one concrete luma Wiener run. PC-Wiener and luma retain their respective taps. The traversal and the AVX2 tap arithmetic are shared with existing code. SSE2 and NEON retain their own entries. The tested restoration scope is the 10-bit luma Wiener run, previously called 46,794 times in the 16-frame RitualDance control.

**Control** is the previous in-tree implementation. **Ordinary Cargo** builds the extracted code through normal path dependencies. **AVX2 unit flags** builds the same source with the optional experiment wrapper applying the Fearless SIMD 1.2.0 feature contract only to `splot_lr_avx2`. The main decoder and other crates build at baseline. The external program has no checkout Cargo configuration or custom release profile. Its release settings differ from the workspace CLI, so comparisons are paired within each program.

### External decoder playback

Twelve paired rounds per input, one pinned worker, frame delay one, null output, after warmup. Each of the six three-build launch orders appears twice. Changes are paired median elapsed time with 95% paired bootstrap intervals. Negative elapsed changes are faster.

```text
RitualDance 16 plain/control: -1.64% [-3.88, +0.62]
RitualDance 16 unit/plain: +0.82% [-1.39, +1.74]
RitualDance 16 unit/control: -1.08% [-3.89, +0.75]
RitualDance 600 plain/control: -0.49% [-1.13, +10.32]
RitualDance 600 unit/plain: -0.39% [-2.67, +0.60]
RitualDance 600 unit/control: -1.09% [-2.49, +5.58]
TunnelFlag 40 plain/control: +0.06% [-1.11, +4.72]
TunnelFlag 40 unit/plain: -1.49% [-4.93, -0.24]
TunnelFlag 40 unit/control: -0.26% [-1.92, +2.02]
```

### Linked release CLI playback

Four builds, 12 balanced rounds, one worker and null output. WITCHER3 and TunnelFlag use 40 frames. RitualDance and Noise_Ocean use 16. Shipped v3 is `10279846`.

| Input | Ordinary vs separately compiled unit | Ordinary vs control | Ordinary vs shipped v3 |
|---|---:|---:|---:|
| WITCHER3 | +3.44% [-2.80, +15.86] | +5.63% [-5.41, +11.51] | +13.48% [+2.63, +16.09] |
| TunnelFlag | +2.62% [-28.99, +16.62] | -5.37% [-24.63, +3.61] | +10.69% [-15.07, +16.60] |
| RitualDance | -6.15% [-8.69, +2.10] | -8.89% [-17.72, -0.17] | +9.90% [+3.40, +19.38] |
| Noise_Ocean | +1.15% [-3.78, +11.37] | +2.35% [-4.10, +12.93] | +29.04% [+24.90, +44.70] |

### Kernel and instruction measurements

The separate plain-Cargo kernel driver measured the same 64 input cases under both compiler settings. Median timings were plain 374.15 ns/run, unit 382.10 ns/run.

```text
luma runs unit/plain: -3.01% [-5.60, +6.70]
```

Callgrind guest instructions on the same 16 displayed RitualDance frames.

| Program | Control | Ordinary Cargo | AVX2 unit flags | Ordinary vs control | Unit vs ordinary |
|---|---:|---:|---:|---:|---:|
| External consumer | 5,941,939,319 | 5,927,148,604 | 5,922,192,122 | -0.249% | -0.084% |
| Release CLI | 5,331,986,361 | 5,312,934,008 | 5,307,982,422 | -0.357% | -0.093% |

| Stripped release artifact | Control | Ordinary Cargo | AVX2 unit flags |
|---|---:|---:|---:|
| splot | 16,869,232 | 16,865,088 | 16,864,560 |
| libsplot_capi.so | 13,159,816 | 13,156,024 | 13,155,992 |

The external application called the concrete luma run 46,794 times in the 16-frame trace. The in-tree control spent 191,465,491 guest instructions inside that call edge. The plain Cargo prototype spent 175,852,024 (8.15% fewer). Both ran the same 46,794 calls. The linked ordinary-Cargo AVX2 body in the external application contained 644 instructions, including 116 vector mnemonics and no CPUID. The explicitly compiled unit reduced the linked body to 573 instructions and 2,933 bytes and used 170,900,392 guest instructions across the same 46,794 calls. These instruction counts describe that function and do not measure application wall time.

### Hardware and source revisions

The native Intel Xeon 6975P-C passed all 63 full-stream comparisons on the measured prototype (21 Auto selecting AVX2, 21 forced AVX2 and 21 forced AVX-512) and four backend lifecycle tests. The first hosted VM lacked the required AVX-512 features and the hardware precondition rejected it. [Native run, attempt 2](https://github.com/splotlabs/splot/actions/runs/45634575719/attempts/2). Apple ARM64 cross-compilation passed for the reconstruction crate and its test targets. Native M2 Max first-picture timing remains tracked in [#1993](https://github.com/splotlabs/splot/issues/1993). The follow-up `deba2c41` removes an unused Clippy expectation while retaining the inlining attribute. Native all-target checks, Apple ARM64 cross-checks, and Clippy with `-D warnings` passed for the checked crates. The two prototype builds use identical kernel arithmetic.

### Correctness and reproducibility

Both variants matched the independent 64-case scalar oracle for signed tap weights, rounding, clipping, uniform and mixed classes, padded strides, partial multiples of 16, 1–8 rows and untouched output guards. Each external decoder matched the AVM raw hashes for all seven complete streams on native AVX2, and all four 8/10-bit Wiener and PC-Wiener fixtures on native AVX2 and strict emulated SSE2. Each release CLI matched 21/21 full AVM hashes across 1, 7 and 12 workers. Each CLI and C shared library matched 40/40 strict SSE2 comparisons.

Build a standalone Rust consumer with path dependencies on `splot-core` and `splot-decode` using `cargo build --release`. The standalone kernel driver is in `tests/downstream/restoration-module.rs`. The alternate comparison uses `RUSTC_WRAPPER=/absolute/path/to/scripts/rustc-lr-prototype.py` and a fresh target directory. Build the release CLI and C library with `CARGO_PROFILE_RELEASE_STRIP=none cargo build --release --locked -p splot-cli -p splot-capi`; strip the linked artifacts for size comparison. CPU 4 on i7-12700H, Linux x86-64, Rust 1.100.0, LLVM 23.1.5. Compilers and timed processes were serialized.

<details><summary>Reproduce the external Rust consumer</summary>

With the prototype checkout and consumer directory as siblings, adjust the dependency paths in this manifest. The control used the same program with its two paths pointing at its own checkout.

```toml
[package]
name = "lr-consumer"
version = "0.0.0"
edition = "2024"
publish = false

[dependencies]
splot-core = { path = "../../splot-1934-lr-module/crates/splot-core" }
splot-decode = { path = "../../splot-1934-lr-module/crates/splot-decode" }
```

```rust
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// SPDX-FileCopyrightText: 2026 Bartosz Tomczyk <bartekplus@gmail.com>

use std::io::Write;

use splot_core::stream_reader::{StreamUnit, TemporalUnitReader};
use splot_decode::{
    DataProps, DecodeError, Decoder, DecoderSettings, FrameDelay, PictureSamples, PlaneId,
    SendStatus, SimdPolicy, ThreadCount,
};

fn assert_unsupported(settings: DecoderSettings, policy: SimdPolicy) {
    let error = Decoder::new(settings.with_simd_policy(policy)).unwrap_err();
    assert!(
        matches!(error, DecodeError::UnsupportedBackend { source } if source.requested() == policy),
        "{policy}: {error}"
    );
}

fn write_ready_pictures(
    decoder: &mut Decoder,
    output: &mut impl Write,
    raw: bool,
    pictures: &mut usize,
    limit: usize,
) {
    while let Some(picture) = decoder.get_picture().unwrap() {
        *pictures += 1;
        if *pictures > limit {
            return;
        }
        if !raw {
            std::hint::black_box(&picture);
            continue;
        }
        for plane in [PlaneId::Y, PlaneId::U, PlaneId::V] {
            match picture.plane(plane).unwrap() {
                PictureSamples::Eight(plane) => {
                    for row in plane.visible_rows() {
                        output.write_all(row).unwrap();
                    }
                }
                PictureSamples::Ten(plane) => {
                    for sample in plane.visible_rows().flatten() {
                        output.write_all(&sample.to_le_bytes()).unwrap();
                    }
                }
            }
        }
    }
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let [_, expected_backend, filename, mode, limit] = args.as_slice() else {
        panic!("expected backend, IVF filename, output mode and picture limit");
    };
    assert!(
        !cfg!(target_feature = "avx2"),
        "consumer requires default compiler flags"
    );
    assert_eq!(
        std::arch::is_x86_feature_detected!("avx2"),
        expected_backend == "avx2",
        "unexpected emulated CPU"
    );
    if expected_backend == "sse2" {
        assert!(!std::arch::is_x86_feature_detected!("sse3"));
    }

    let settings = DecoderSettings::default()
        .with_threads(ThreadCount::from(1))
        .with_frame_delay(FrameDelay::from(1usize));
    let raw = match mode.as_str() {
        "raw" => true,
        "null" => false,
        _ => panic!("unknown output mode"),
    };
    let limit: usize = limit.parse().unwrap();
    let mut pictures = 0;
    let mut decoder = Decoder::new(settings).unwrap();
    assert_eq!(decoder.selected_backend().as_str(), expected_backend);
    assert_unsupported(settings, SimdPolicy::Neon);
    assert_unsupported(settings, SimdPolicy::Avx512);
    if expected_backend == "sse2" {
        assert_unsupported(settings, SimdPolicy::Avx2);
    }

    let input = std::fs::read(filename).unwrap();
    let mut reader = TemporalUnitReader::new(input.as_slice());
    let mut output = std::io::BufWriter::new(std::io::stdout().lock());
    while let Some(unit) = reader.next_unit().unwrap() {
        let StreamUnit::IvfFrame { payload, .. } = unit else {
            panic!("expected IVF frame");
        };
        while decoder.send_data(payload, DataProps::default()).unwrap() == SendStatus::Full {
            write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);
            if pictures >= limit {
                break;
            }
        }
        write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);
        if pictures >= limit {
            break;
        }
    }
    if pictures < limit {
        decoder.drain();
        write_ready_pictures(&mut decoder, &mut output, raw, &mut pictures, limit);
    }
    eprintln!("{} displayed pictures", pictures.min(limit));
    output.flush().unwrap();
}
```

The command line is `lr-consumer avx2 INPUT.ivf null FRAME_LIMIT`. The executable asserts the startup choice before it reads the input. For raw parity pass `raw 99999`.
</details>

<details><summary>Raw kernel timings</summary>

```csv
case,round,position,build,ns_per_run,checksum_or_frames
luma runs,1,1,plain,280.307,42343295
luma runs,1,2,unit,300.539,42343295
luma runs,2,1,unit,309.804,42343295
luma runs,2,2,plain,306.031,42343295
luma runs,3,1,plain,315.395,42343295
luma runs,3,2,unit,304.621,42343295
luma runs,4,1,unit,304.7,42343295
luma runs,4,2,plain,322.28,42343295
luma runs,5,1,plain,324.881,42343295
luma runs,5,2,unit,421.29,42343295
luma runs,6,1,unit,457.18,42343295
luma runs,6,2,plain,412.908,42343295
luma runs,7,1,plain,438.045,42343295
luma runs,7,2,unit,379.834,42343295
luma runs,8,1,unit,401.649,42343295
luma runs,8,2,plain,378.27,42343295
luma runs,9,1,plain,398.871,42343295
luma runs,9,2,unit,388.458,42343295
luma runs,10,1,unit,425.146,42343295
luma runs,10,2,plain,440.542,42343295
luma runs,11,1,plain,407.759,42343295
luma runs,11,2,unit,384.358,42343295
luma runs,12,1,unit,336.921,42343295
luma runs,12,2,plain,370.028,42343295
```
</details>

<details><summary>Raw external timings</summary>

```csv
case,round,position,build,elapsed_s,checksum_or_frames
RitualDance 16,1,1,control,0.9182840650009894,16
RitualDance 16,1,2,plain,0.891739847998906,16
RitualDance 16,1,3,unit,1.1062990270002047,16
RitualDance 600,1,1,plain,23.944949004999216,600
RitualDance 600,1,2,control,24.068470538000838,600
RitualDance 600,1,3,unit,22.322661390000576,600
TunnelFlag 40,1,1,unit,1.9300404000005074,40
TunnelFlag 40,1,2,control,1.9403793399997085,40
TunnelFlag 40,1,3,plain,1.9714974670005176,40
TunnelFlag 40,2,1,unit,1.953939134000393,40
TunnelFlag 40,2,2,plain,2.0295615720006026,40
TunnelFlag 40,2,3,control,1.940176751000763,40
RitualDance 600,2,1,plain,26.817103059000146,600
RitualDance 600,2,2,unit,24.171585752999817,600
RitualDance 600,2,3,control,21.778188609998324,600
RitualDance 16,2,1,control,0.5369020250000176,16
RitualDance 16,2,2,unit,0.5190807010003482,16
RitualDance 16,2,3,plain,0.5115852460003225,16
RitualDance 16,3,1,plain,0.639326042999528,16
RitualDance 16,3,2,control,0.49891299800037814,16
RitualDance 16,3,3,unit,0.49960613999974157,16
RitualDance 600,3,1,unit,19.769405024999287,600
RitualDance 600,3,2,control,20.475087883000015,600
RitualDance 600,3,3,plain,20.204742918000193,600
TunnelFlag 40,3,1,control,1.9620062800004234,40
TunnelFlag 40,3,2,plain,1.8377284630005306,40
TunnelFlag 40,3,3,unit,1.6304861869994056,40
TunnelFlag 40,4,1,control,1.8680299980005657,40
TunnelFlag 40,4,2,unit,2.025257760000386,40
TunnelFlag 40,4,3,plain,2.1577338710012555,40
RitualDance 600,4,1,unit,20.73587691300054,600
RitualDance 600,4,2,plain,19.55535052400046,600
RitualDance 600,4,3,control,16.189716955999756,600
RitualDance 16,4,1,plain,0.4559737799991126,16
RitualDance 16,4,2,unit,0.45308921600008034,16
RitualDance 16,4,3,control,0.45883411899922066,16
RitualDance 16,5,1,unit,0.45001795400094124,16
RitualDance 16,5,2,control,0.4567916670002887,16
RitualDance 16,5,3,plain,0.47356397500152525,16
RitualDance 600,5,1,control,15.66830245500023,600
RitualDance 600,5,2,plain,15.600009440000576,600
RitualDance 600,5,3,unit,15.478437816000223,600
TunnelFlag 40,5,1,plain,1.415731388000495,40
TunnelFlag 40,5,2,control,1.4113461460001417,40
TunnelFlag 40,5,3,unit,1.391283523000311,40
TunnelFlag 40,6,1,plain,1.4024351560001378,40
TunnelFlag 40,6,2,unit,1.3921631060002255,40
TunnelFlag 40,6,3,control,1.4777525310000783,40
RitualDance 600,6,1,control,16.65065183599836,600
RitualDance 600,6,2,unit,15.667739091999465,600
RitualDance 600,6,3,plain,15.617384958000912,600
RitualDance 16,6,1,unit,0.4619833029992151,16
RitualDance 16,6,2,plain,0.45432784799959336,16
RitualDance 16,6,3,control,0.4555391569992935,16
RitualDance 16,7,1,control,0.45806503700077883,16
RitualDance 16,7,2,plain,0.46154004900017753,16
RitualDance 16,7,3,unit,0.46236432700061414,16
RitualDance 600,7,1,plain,15.452137500999015,600
RitualDance 600,7,2,control,15.578194018000431,600
RitualDance 600,7,3,unit,15.587076801000876,600
TunnelFlag 40,7,1,unit,1.4377289770000061,40
TunnelFlag 40,7,2,control,1.427319307000289,40
TunnelFlag 40,7,3,plain,1.4181123609996575,40
TunnelFlag 40,8,1,unit,1.4044263619998674,40
TunnelFlag 40,8,2,plain,1.4164912600008392,40
TunnelFlag 40,8,3,control,1.43903881299957,40
RitualDance 600,8,1,plain,15.465924449999875,600
RitualDance 600,8,2,unit,15.388166767001167,600
RitualDance 600,8,3,control,15.537993475998519,600
RitualDance 16,8,1,control,0.47113996599910024,16
RitualDance 16,8,2,unit,0.44704651499887404,16
RitualDance 16,8,3,plain,0.4568360240009497,16
RitualDance 16,9,1,plain,0.4558957030003512,16
RitualDance 16,9,2,control,0.45370259400078794,16
RitualDance 16,9,3,unit,0.45627561600122135,16
RitualDance 600,9,1,unit,15.38240277300065,600
RitualDance 600,9,2,control,15.62171794599999,600
RitualDance 600,9,3,plain,15.388518534999093,600
TunnelFlag 40,9,1,control,1.406008825999379,40
TunnelFlag 40,9,2,plain,1.403341401999569,40
TunnelFlag 40,9,3,unit,1.3857141509997746,40
TunnelFlag 40,10,1,control,1.4036218530000042,40
TunnelFlag 40,10,2,unit,1.4036988230000134,40
TunnelFlag 40,10,3,plain,1.400193545001457,40
RitualDance 600,10,1,unit,15.363754649999464,600
RitualDance 600,10,2,plain,15.407049776000349,600
RitualDance 600,10,3,control,15.551656019000802,600
RitualDance 16,10,1,plain,0.4565845690012793,16
RitualDance 16,10,2,unit,0.4815224570011196,16
RitualDance 16,10,3,control,0.5339269300002343,16
RitualDance 16,11,1,unit,0.474283096000363,16
RitualDance 16,11,2,control,0.4964591739990283,16
RitualDance 16,11,3,plain,0.46746095699927537,16
RitualDance 600,11,1,control,16.1183102899995,600
RitualDance 600,11,2,plain,18.886244334000367,600
RitualDance 600,11,3,unit,19.253937035999115,600
TunnelFlag 40,11,1,plain,1.722009867999077,40
TunnelFlag 40,11,2,control,1.6425295690005441,40
TunnelFlag 40,11,3,unit,1.748771818998648,40
TunnelFlag 40,12,1,plain,1.8196186570003192,40
TunnelFlag 40,12,2,unit,1.6605950789999042,40
TunnelFlag 40,12,3,control,1.6072728279996227,40
RitualDance 600,12,1,control,18.26049187300123,600
RitualDance 600,12,2,unit,18.291305957000077,600
RitualDance 600,12,3,plain,18.893618769998284,600
RitualDance 16,12,1,unit,0.5030897549986548,16
RitualDance 16,12,2,plain,0.49422463299924857,16
RitualDance 16,12,3,control,0.5076676709995809,16
```
</details>

<details><summary>Raw product timings</summary>

```csv
stream,round,position,build,elapsed,CPU
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,1,plain,0.9126673610007856,0.9122639999999986
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,2,unit,0.7362934299999324,0.7359810000000024
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,3,shipped,0.7133789140007138,0.7130759999999992
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,1,4,callback,0.8364928959999816,0.836079999999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,1,callback,1.557657293000375,1.5570699999999995
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,2,shipped,1.2629809669997485,1.262557000000001
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,3,unit,1.515765387999636,1.5151949999999985
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,4,plain,1.4654350529999647,1.4648660000000042
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,1,plain,0.44836418100021547,0.4481269999999995
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,2,unit,0.4779538450002292,0.47767499999999785
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,3,shipped,0.4488528990004852,0.44861299999999815
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,1,4,callback,0.4891004299988708,0.4886739999999996
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,1,callback,0.1375845719994686,0.13729700000000378
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,2,shipped,0.10664330200052063,0.10646699999999498
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,3,unit,0.14072350899914454,0.14053100000000285
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,1,4,plain,0.14100321700061613,0.14080000000000226
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,1,shipped,0.10865803299930121,0.10845799999999883
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,2,plain,0.13770516799922916,0.1374379999999995
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,3,callback,0.14086593199863273,0.14062799999999953
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,2,4,unit,0.1396967599994241,0.13952900000000312
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,1,unit,0.4467760019997513,0.4465339999999962
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,2,callback,0.47488588099986373,0.4745550000000023
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,3,plain,0.4617699150003318,0.4615269999999967
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,4,shipped,0.4257415990014124,0.42540200000000183
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,1,shipped,1.3199908819988195,1.3194909999999993
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,2,plain,1.4157664029989974,1.4152910000000034
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,3,callback,2.4504270010002074,2.2830539999999964
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,2,4,unit,3.1377209549991676,2.3976289999999985
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,1,unit,1.2326703859998815,1.2315240000000074
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,2,callback,1.613654882999981,1.2135309999999961
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,3,plain,1.8381736890005413,1.2134529999999941
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,2,4,shipped,1.6774841680016834,1.0691270000000017
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,1,callback,1.2170566709992272,1.2040679999999995
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,2,shipped,1.101894061999701,1.0380030000000033
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,3,unit,1.8011542710009962,1.200454999999998
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,3,4,plain,1.2554226739994192,1.2546110000000041
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,1,plain,2.0960400969997863,2.095151999999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,2,unit,3.461553241000729,2.4570189999999954
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,3,shipped,2.6734547920004843,2.0804450000000045
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,4,callback,3.0706684440010577,2.540894999999999
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,1,callback,0.8971021259985719,0.8299230000000009
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,2,shipped,1.0238700560003053,0.7203919999999968
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,3,unit,1.169612812998821,0.7602170000000044
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,3,4,plain,0.669487956998637,0.6689519999999973
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,1,plain,0.21837390499968024,0.21797300000000064
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,2,unit,0.19125659400015138,0.190889999999996
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,3,shipped,0.13304430000061984,0.13280300000000267
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,3,4,callback,0.18476839899994957,0.18436200000000724
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,1,unit,0.40883028999996895,0.4081909999999951
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,2,callback,0.2869931470013398,0.2864839999999944
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,3,plain,0.3090181300012773,0.30835400000000845
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,4,4,shipped,0.23150012800033437,0.23101599999999678
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,1,shipped,0.7180328940012259,0.7173640000000034
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,2,plain,0.6880856019997736,0.6876499999999979
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,3,callback,0.8769680770001287,0.8763749999999959
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,4,unit,0.7681211159997474,0.7675350000000094
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,1,unit,2.4325833060011064,2.4287199999999913
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,2,callback,2.20161698100128,2.200535000000002
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,3,plain,2.8161323399999674,2.4035029999999935
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,4,4,shipped,2.249288142000296,1.9518040000000099
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,1,shipped,1.1324819419987762,1.0331170000000043
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,2,plain,1.188353121999171,1.1874490000000009
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,3,callback,2.2264611649989092,1.2109129999999908
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,4,4,unit,1.5728670950011292,1.2277350000000098
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,1,plain,1.1665830010006175,1.16590699999999
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,2,unit,1.191898291999678,1.1909459999999967
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,3,shipped,1.3733609950013488,1.0256260000000026
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,5,4,callback,1.4161353780000354,1.2403280000000052
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,1,callback,2.4912301980002667,2.3660050000000012
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,2,shipped,2.2157319620000635,2.025884999999988
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,3,unit,2.554779576999863,2.260991000000004
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,4,plain,1.7287854649985093,1.7277320000000032
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,1,plain,0.5458036010004435,0.5453449999999975
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,2,unit,0.5392500220004877,0.5388549999999981
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,3,shipped,0.46550083700094547,0.46510700000000327
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,5,4,callback,0.6247305630004121,0.6241720000000015
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,1,callback,0.21147367699995812,0.21111099999998828
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,2,shipped,0.17849794500034477,0.1779200000000145
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,3,unit,0.22948639599962917,0.22907699999998954
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,5,4,plain,0.2783172889994603,0.27775700000000825
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,1,shipped,0.1920243330005178,0.1913849999999968
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,2,plain,0.22644274899903394,0.22583099999999945
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,3,callback,0.2648323530011112,0.2154910000000001
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,6,4,unit,0.43731067499902565,0.21805599999999004
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,1,unit,1.4952739529999235,0.7455120000000051
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,2,callback,1.0599850269991293,0.7495390000000128
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,3,plain,0.7342216239994741,0.7332259999999877
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,4,shipped,0.6624944680006593,0.6611290000000167
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,1,shipped,2.010494617999939,2.008306999999988
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,2,plain,2.548918144999334,2.2634530000000126
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,3,callback,3.133161153000401,2.205539999999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,6,4,unit,2.169756466000763,2.1687889999999896
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,1,unit,1.1859904039993125,1.185331000000005
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,2,callback,1.1729733370011672,1.1723029999999994
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,3,plain,1.2498438589991565,1.2490920000000045
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,6,4,shipped,1.1023849939992942,1.101167999999987
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,1,callback,1.4052018379989022,1.2173760000000158
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,2,shipped,1.398092663999705,1.0638609999999886
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,3,unit,1.2589360440015298,1.1759490000000028
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,7,4,plain,1.27766291899934,1.202723000000006
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,1,plain,2.81041955100045,2.2175219999999882
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,2,unit,2.2759503060005954,2.1471750000000043
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,3,shipped,2.8164490509989264,1.9332959999999986
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,4,callback,2.972025668999777,2.2589609999999993
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,1,callback,1.0991049549993477,0.7136789999999991
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,2,shipped,1.0990458959986427,0.6326490000000149
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,3,unit,1.4731240829987655,0.7365419999999858
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,7,4,plain,1.3787362210005085,0.7407560000000046
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,1,plain,0.47415017899948,0.23658899999999505
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,2,unit,0.46438908299933246,0.23272099999999796
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,3,shipped,0.21582822500022303,0.19984699999999123
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,7,4,callback,0.22276313600013964,0.22234900000000835
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,1,unit,0.22440682699925674,0.22395099999999957
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,2,callback,0.2572894860004453,0.2568339999999978
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,3,plain,0.27192436199948133,0.2714210000000037
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,8,4,shipped,0.209346353998626,0.20891699999999958
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,1,shipped,0.6954022379995877,0.6256120000000038
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,2,plain,0.8210092829995119,0.7302269999999993
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,3,callback,0.9535926529988501,0.7249189999999999
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,4,unit,0.7625947150008869,0.7619609999999994
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,1,unit,2.9228790940014733,2.3610220000000197
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,2,callback,2.294782656999814,2.1733899999999835
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,3,plain,2.1732268409996323,2.1721769999999765
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,8,4,shipped,2.522572986999876,2.016997000000032
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,1,shipped,1.1701353799999197,1.081532999999979
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,2,plain,1.1739101620005385,1.1504680000000178
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,3,callback,1.0958098249993782,1.0952120000000036
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,8,4,unit,1.0918845590003912,1.0911499999999705
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,1,plain,0.9893355749991315,0.9886510000000044
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,2,unit,0.9180471030012995,0.9176580000000172
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,3,shipped,0.8496954630008986,0.8493529999999794
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,9,4,callback,0.8670288369994523,0.8666369999999972
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,1,callback,1.6481296820002171,1.6474910000000023
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,2,shipped,1.458789558000717,1.458248000000026
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,3,unit,1.586770208001326,1.5861749999999972
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,4,plain,1.7071719209998264,1.706528999999989
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,1,plain,0.5545571090005978,0.5540809999999965
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,2,unit,0.5384464009985095,0.538123000000013
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,3,shipped,0.4322832199995901,0.4319319999999891
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,9,4,callback,0.5184092319996125,0.5180829999999901
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,1,callback,0.18779988099959155,0.18754800000002092
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,2,shipped,0.13537061599890876,0.1351489999999842
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,3,unit,0.18089184000018577,0.18061600000001476
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,9,4,plain,0.17093559199929587,0.1706790000000069
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,1,shipped,0.1284330279995629,0.12820899999999824
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,2,plain,0.15764018099980603,0.15742599999998674
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,3,callback,0.16377305100104422,0.16354599999999664
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,10,4,unit,0.16095934999975725,0.16068200000000843
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,1,unit,0.5584637789997942,0.5581029999999885
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,2,callback,0.5732883660002699,0.5729580000000283
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,3,plain,0.5243942919987603,0.5240469999999959
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,4,shipped,0.4904712429997744,0.49011099999998464
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,1,shipped,1.465072216000408,1.464573999999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,2,plain,1.7021331480009394,1.701582000000002
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,3,callback,1.7422068810010387,1.7416859999999872
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,10,4,unit,1.67958450200058,1.6790279999999882
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,1,unit,0.9458572040002764,0.9453710000000228
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,2,callback,0.871837446000427,0.8713950000000068
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,3,plain,0.912895675000982,0.9125370000000146
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,10,4,shipped,0.8037662389997422,0.8033680000000061
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,1,callback,0.9186964479995368,0.9183379999999772
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,2,shipped,0.7798469250010385,0.7793819999999982
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,3,unit,0.9163072650007962,0.9159099999999967
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,11,4,plain,0.9026623829995515,0.9022380000000112
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,1,plain,1.7815548609996767,1.780937999999992
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,2,unit,1.7147078380003222,1.71396900000002
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,3,shipped,1.5611480900006427,1.5604399999999714
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,4,callback,1.7190365360002033,1.7181740000000048
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,1,callback,0.5330306449995987,0.5327040000000238
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,2,shipped,0.4523029800002405,0.451943
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,3,unit,0.5594707649997872,0.5591079999999806
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,11,4,plain,0.5459063950002019,0.5454859999999826
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,1,plain,0.16505798100115499,0.16486100000003034
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,2,unit,0.15823860199998308,0.1580499999999745
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,3,shipped,0.12875704699945345,0.12853699999999435
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,11,4,callback,0.17276586499974655,0.17252500000000737
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,1,unit,0.16225531700001738,0.1620150000000251
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,2,callback,0.172335547998955,0.17203499999996552
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,3,plain,0.17615890399974887,0.17592600000003245
Noise_Ocean_1920x1080_60fps_qp135_130f.ivf,12,4,shipped,0.14260977799858665,0.1423639999999864
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,1,shipped,0.4795913500001916,0.47925299999999993
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,2,plain,0.522593349998715,0.522262000000012
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,3,callback,0.5759308089982369,0.5755849999999896
RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,4,unit,0.5616708420002396,0.5612770000000182
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,1,unit,1.6867280649985332,1.686126999999999
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,2,callback,1.7428546470000583,1.7422709999999881
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,3,plain,2.1828600499993627,1.9460550000000012
TunnelFlag_1920x1080_60fps_10bit_420_qp135_600f.ivf,12,4,shipped,2.6075105909985723,2.137952999999982
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,1,shipped,1.9066478579989052,1.1166160000000218
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,2,plain,2.577759662999597,1.2894589999999937
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,3,callback,2.22003210100047,1.2629560000000026
WITCHER3_1920x1080_60_8bit_420_qp135_130f.ivf,12,4,unit,1.1756799720005802,1.1749499999999955
```
</details>
