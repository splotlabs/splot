from pathlib import Path
import collections
import re
import subprocess
root=Path(__file__).parent
for version in ("function","module"):
    home=root/("cdef-"+version)
    binary=home/"target/release/splot"
    syms=subprocess.check_output(["nm","-n","-S","--demangle=rust",binary],text=True)
    summaries=[]
    for line in syms.splitlines():
        parts=line.split(None,3)
        if len(parts)!=4 or "gather_packed" not in parts[3] or not any(n in parts[3] for n in ("splot_cdef_base","splot_cdef_avx2")):
            continue
        addr,size,kind,name=parts
        if kind.lower()!="t":
            continue
        a,n=int(addr,16),int(size,16)
        asm=subprocess.check_output(["objdump","-d","--no-show-raw-insn",f"--start-address={a}",f"--stop-address={a+n}",str(binary)],text=True)
        (home/f"gather-{addr}.asm").write_text(asm)
        mnems=[m[1] for row in asm.splitlines() if (m:=re.match(r"^\s*[a-f0-9]+:\s+(\S+)",row))]
        summaries.append((addr,n,sum(x.startswith("v") for x in mnems),mnems.count('call'),mnems.count('cpuid'),name))
    with (home/"linked-audit.tsv").open("w") as f:
        print('address','bytes','VEX/EVEX mnemonics','calls','cpuid','symbol',sep='\t',file=f)
        for row in summaries: print(*row,sep='\t',file=f)
