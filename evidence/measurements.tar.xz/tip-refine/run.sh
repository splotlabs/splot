set -euo pipefail
out=$(pwd -P)
q=$(dirname "$out")
repo=$q/../splot-1934-tip-refine
(
    flock -x 9
    mkdir -p "$out/target"
    rsync -a --exclude='*splot*' --exclude='*xtask*' --exclude='.cargo-*lock' "$q/final-integration/target/" "$out/target/"
    cd "$repo"
    taskset -c 6-11,14-19 env -u RUSTFLAGS -u CARGO_ENCODED_RUSTFLAGS -u CARGO_BUILD_RUSTFLAGS CARGO_TARGET_DIR="$out/target" CARGO_PROFILE_RELEASE_STRIP=none cargo build --locked --offline --release -j1 -p splot-cli
) 9>"$q/build.lock" > "$out/build.log" 2>&1
bin=$out/target/release/splot
for stream in RitualDance_1920x1080_60fps_10bit_420_qp135_600f Noise_Ocean_1920x1080_60fps_qp135_130f; do
    name=${stream%%_1920*}
    taskset -c 2 valgrind --tool=callgrind --callgrind-out-file="$out/$name.cg" --log-file="$out/$name.log" "$bin" decode "$q/ci-data/$stream.ivf" --threads 1 --frame-delay 1 --limit 16 --output-format null
    taskset -c 3 "$bin" decode "$q/ci-data/$stream.ivf" --threads 1 --frame-delay 1 --output-format raw -o - | sha256sum > "$out/$name.sha256"
    hash=$(cut -d ' ' -f1 "$out/$name.sha256")
    awk -F '\t' -v n="$stream.ivf" -v h="$hash" '$1==n && $2==h {ok=1} END{exit !ok}' "$q/ci-data/simd-cases.tsv"
done
strip -o "$out/splot.stripped" "$bin"
wc -c "$out/splot.stripped"
