"""Count one inclusive edge around all TIP refinement work, including its callees."""
from pathlib import Path
import runpy

out = Path(__file__).resolve().parent
q = out.parent
read = runpy.run_path(str(q / 'noise-stage-breakdown.py'))['read']
for name,reference in [('RitualDance',q/'compiler-attribution/ritual-shipped-symbols.cg'),('Noise_Ocean',q/'current-native/shipped-symbols-16.cg')]:
    for label,path in [('shipped',reference),('draft',q/f'cdef-boundary-ab/direct/{name}-base.cg'),('candidate',out/f'{name}.cg')]:
        if not path.exists(): continue
        own, edges, calls = read(path)
        incoming = [key for key in edges if '::tip::predict_block' in key[0] and '::tip_units::refine_tip_units' in key[1]]
        print(name, label, 'whole', own.total(), 'TIP refinement calls', sum(calls[key] for key in incoming), 'inclusive Ir', sum(edges[key] for key in incoming))
