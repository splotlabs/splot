from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
cases = ('Noise_Ocean_1920x1080_60fps_qp135_130f.ivf', 'RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf')
for case in cases:
    results = {}
    for label in ('main', 'draft', 'autowide', 'base'):
        src = root.parent/'ci-data'/case
        binary = root/f'playback-{label}'/'splot'
        binary.chmod(0o755)
        trace = root/f'{label}-{case[:case.index("_1920")]}.cg'
        subprocess.run(['valgrind', '--tool=callgrind', f'--log-file={trace}.log',f'--callgrind-out-file={trace}',binary,'decode',src,'--threads','1','--frame-delay','1','--limit','16','--output-format','null'],check=True)
        results[label] = int(next(x.split()[1] for x in trace.read_text().splitlines() if x.startswith('summary:')))
        print(case,label,results[label],flush=True)
    for label in ('draft','autowide'):
        print(case,label,'vs main Ir',f'{results[label]/results["main"]-1:+.3%}',flush=True)
