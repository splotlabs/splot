from hashlib import sha256
from pathlib import Path
import subprocess

out = Path(__file__).resolve().parent
q = out.parent
manifest = [row.split('\t') for row in (q/'ci-data/simd-cases.tsv').read_text().splitlines()]
builds = {'main':'d171d824','base':'d49defcf','draft':'29e00167','autowide':'29e00167'}
for name, revision in builds.items():
    root = out/f'playback-{name}'
    assert (root/'revision.txt').read_text().strip().startswith(revision)
    assert (root/'toolchain.txt').read_text() == (out/'playback-main/toolchain.txt').read_text()
    flags = (root/'flags.txt').read_text().split()
    assert 'target-cpu=x86-64-v3' in flags and ('disable_dispatch_avx512' in flags) == (name!='autowide')
    subprocess.run(['sha256sum','--quiet','-c','SHA256SUMS'],cwd=root,check=True)
    bin = root/'splot'
    bin.chmod(0o755)
    print(name,revision,' '.join(flags),flush=True)
    for stem in ('Noise_Ocean_1920x1080_60fps_qp135_','RitualDance'):
        [item] = [row for row in manifest if row[0].startswith(stem)]
        fname,sha,frames,expected_size = item
        args=[bin,'decode',q/'ci-data'/fname,'--threads','1','--frame-delay','1']
        with subprocess.Popen([*args,'--output-format','raw','-o','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE) as proc:
            digest = sha256()
            size=0
            for chunk in iter(lambda:proc.stdout.read(2**20),b''):
                digest.update(chunk)
                size+=len(chunk)
            assert proc.wait()==0 and size==int(expected_size) and digest.hexdigest()==sha
        print(f'PASS {name} {fname} {frames} {size} {sha}',flush=True)
