# Noise_Ocean AVX2 instruction attribution

The paired playback median for `f03b06e2` was 23.98% slower than shipped `10279846`, with a 95% paired interval of +4.91% to +34.77%. The matched Callgrind traces count guest instructions for the same 16 official 8-bit frames, one worker, frame delay one, and null output. They measure an instruction increase of 18.95%. The traces cannot assign the difference between these two percentages to native cycles or hardware events.

Both release binaries were stripped. The stage column uses the closest available fully symbolized profile, `07cdddce`, which is 0.227% below the exact `f03b06e2` total. These revisions differ in source as well as code generation. Selected rows below verify identical or near-identical costs for the major CDEF and TIP call paths and quantify the difference on coefficient parsing directly. There is no text-identical unstripped shipped binary in the available artifacts.

The attribution method and trace filenames are included below. The script matches stripped stage roots to the symbolized call graph using caller structure and matching call counts. It then walks the graph and assigns each function's exclusive instructions once. Semantic transform roots and known library memory/allocator functions receive separate labels. Functions with conflicting reachable stages or insufficient evidence remain uncategorized. Inline memory work stays in the stage containing it. Both stage-column totals are asserted against their respective trace summaries.

## Exclusive stage and matched edge counts

| Stage | Shipped 10279846 | Symbolized 07cdddce | Excess Ir |
|---|---:|---:|---:|
| Entropy/parser | 156,594,950 | 170,691,212 | +14,096,262 |
| Motion/prediction | 440,954,627 | 546,814,608 | +105,859,981 |
| Transforms/residual math | 35,189,724 | 39,157,279 | +3,967,555 |
| Filters | 554,765,410 | 652,282,209 | +97,516,799 |
| Memory/allocator functions | 101,076,809 | 102,095,436 | +1,018,627 |
| Output/scheduling/frame setup | 7,281,943 | 7,447,688 | +165,745 |
| Uncategorized/shared | 10,296,180 | 31,670,245 | +21,374,065 |
| Total | 1,306,159,643 | 1,550,158,677 | +243,999,034 |

Exact stripped f03 total: 1,553,670,804 (+247,511,161, +18.95% versus shipped; +3,512,127, +0.227% versus symbolized 07cdddce).

These are inclusive call edges in separate branches of the profile. The costs are already represented in the exclusive stage totals above.

| Selected call edge | Calls in each trace | Shipped | Symbolized 07cdddce | Exact f03 | f03 excess Ir |
|---|---:|---:|---:|---:|---:|
| TIP motion-field units | 14 | 25,127,545 | 91,474,414 | 91,474,414 | +66,346,869 |
| CDEF segment filter | 88,876 | 173,025,432 | 187,305,879 | 187,305,879 | +14,280,447 |
| CDEF packed chroma gather | 88,876 | 31,017,724 | 48,792,924 | 48,792,924 | +17,775,200 |
| Luma Wiener filter | 1,151 | 126,600,630 | 142,593,483 | 142,593,077 | +15,992,447 |
| Coefficient high-frequency pass | 7,651 | 48,694,513 | 55,285,219 | 61,474,026 | +12,779,513 |

## Where the instructions go

- Motion/prediction and filters account for 83.3% of the symbolized gap. The 14 TIP field entries alone account for 66.35M of the exact f03 excess. The symbolized candidate calls the cross-stencil closure 170,100 times for 33.85M inclusive instructions and the scaling array helper 113,400 times for 26.65M. Both callees call narrow AVX2 primitives out of line. Their counts and costs persist at corresponding stripped addresses in f03. The shipped TIP leaf spends 24.98M instructions in its own body. The ordinary-build TIP field experiment in `tip-field/noise16.cg` later recovers 64.15M overall instructions from f03, down to 1,489,522,483.
- The candidate CDEF segment filter's `cdef_filter_rows_wide8` variant for clamped, primary-only filtering grew from 14.54M to 20.32M at 94,692 calls. The candidate splits each call between a shim and vectorized body. The packed chroma gather still calls the `pair_ranges` callback 177,752 times for 8.89M inclusive instructions. These cases contribute to the measured filter gap alongside luma restoration.
- The coefficient high-frequency pass accounts for 12.78M extra instructions at the same 7,651 calls in f03. The symbolized proxy attributes 6.59M to this edge. Use the exact edge to interpret this branch instead of equating the proxy's entropy total with f03's.
- Recognized memory and allocator functions and identified output/scheduling/setup account for 1.18M extra instructions combined in the stage table. Known shared vector helpers remain in the uncategorized bucket. This comparison alone does not measure cache behavior or native stall cycles and excludes output-formatting work because the invocation uses null output.

The measured TIP improvement demonstrates that the ordinary portable build can remove a high-cost repeated boundary. The data supports retaining startup dispatch while fixing named kernels with matched evidence. A wider architecture change would need its own paired native-time and instruction evidence across multiple kernels and streams.

## Testing the largest matched loss

The 14 TIP motion-field calls cost 91.47M instructions in the portable draft and 25.13M in the shipped build. At `942dd6e9` the same 14 calls cost 27.33M. Keeping motion scaling and neighborhood averaging in the active vector loop reduced the entire 16-frame Noise_Ocean decode from 1,553,670,804 to 1,489,522,483 instructions (**−4.13% of the entire decode**). RitualDance fell from 5,302,707,985 to 5,246,658,721 (**−1.06%**). All 21 complete AVM output checks and all 40 strict SSE2 CLI/C comparisons passed. A separate intra-prediction fix reduced the RitualDance smooth edge from 41.31M to 6.73M instructions over the same 8,035 calls. That change alone saved 0.72% of the full prefix and matched the 600-frame raw reference.

The two fixes are combined at `183e04ea` in [draft #1987](https://github.com/splotlabs/splot/pull/1987). Per-stage results above are attribution of guest instructions. Native playback at the combined head is being measured separately.

<details><summary>Attribution script</summary>

```python
#!/usr/bin/env python3
"""Count each recorded self instruction once in the matched Noise_Ocean traces."""

import argparse
from collections import Counter, defaultdict, deque
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
SHIPPED = HERE / "shipped-Noise_Ocean_qp135.cg"
SYMBOLIZED = HERE / "callback/Noise_Ocean.cg"
F03 = HERE / "draft-f03/noise16.cg"
STAGES = (
    "Entropy/parser",
    "Motion/prediction",
    "Transforms/residual math",
    "Filters",
    "Memory/allocator functions",
    "Output/scheduling/frame setup",
    "Uncategorized/shared",
)
FUNCTION = re.compile(r"^(c?fn)=\((\d+)\)(?: (.*))?$")
COST = re.compile(r"^[-+*0-9]+\s+(\d+)\s*$")
MEMORY = re.compile(
    r"(^(__)?(memcpy|memset|memmove|memcmp|malloc|realloc|calloc|free)(_|$)|"
    r"^(_int_|__libc_(malloc|realloc|calloc|free|memalign)|tcache_|sysmalloc|malloc_consolidate|"
    r"_?(mmap|munmap|mremap|madvise|brk)|__mmap)|"
    r"^((__rustc::)?__rust_(alloc|realloc|dealloc)|alloc::raw_vec::))"
)


def read(path):
    names = {}
    self_ir = Counter()
    calls = Counter()
    edges = Counter()
    current = callee = None
    pending = False
    summary = None
    for raw in path.read_text().splitlines():
        if raw.startswith("summary: "):
            summary = int(raw.split()[1])
        elif match := FUNCTION.fullmatch(raw):
            kind, number, name = match.groups()
            if name:
                names[number] = name
            if kind == "fn":
                current = number
            else:
                callee = number
        elif raw.startswith("calls="):
            pending = True
            calls[current, callee] += int(raw[6:].split()[0])
        elif match := COST.fullmatch(raw):
            if pending:
                edges[current, callee] += int(match[1])
            else:
                self_ir[current] += int(match[1])
            pending = False

    def name(number):
        return names.get(number, f"unresolved Callgrind function {number}")

    own, named_edges, named_calls = Counter(), Counter(), Counter()
    for number, cost in self_ir.items():
        own[name(number)] += cost
    for (caller, callee), cost in edges.items():
        named_edges[name(caller), name(callee)] += cost
        named_calls[name(caller), name(callee)] += calls[caller, callee]
    assert own.total() == summary, (path, own.total(), summary)
    return own, named_edges, named_calls


# Each address is a stripped shipped function. The symbol fragment describes
# its equivalent in the symbolized trace, matched by callers, counts and, for
# major leaves, disassembly. A trailing * marks a caller whose descendants
# contain different stages, so only its own instructions receive that label.
ANCHORS = [
    ("Entropy/parser", "6f9c30", "::TileParser>::next_unit::<"),
    ("Entropy/parser", "3c2da0", "::TileResolveState>::resolve_unit::<"),
    ("Entropy/parser", "749620", "::TileFilterRecords>::publish_into"),
    ("Entropy/parser", "7751c0", "::parse_inter_core_with_effects"),
    ("Motion/prediction", "38c100", "::TemporalPrelude>::run::<"),
    ("Motion/prediction", "397400", "::InterReconScratch<u8>>::reconstruct::<"),
    ("Motion/prediction", "3112f0", "::ResidualPlanePlan>::reconstruct::<"),
    ("Motion/prediction", "5be140", "::plane_execution::reconstruct_chroma_pair::<"),
    ("Motion/prediction", "41f0f0", "::frame_tasks::RowPools>::push_tip::<"),
    ("Motion/prediction*", "3a2830", "::ParsedResidualPlane>::reconstruct::<"),
    ("Transforms/residual math", "615ab0", "::add_general_intra_coeff_block_residual_in_place_with::<"),
    ("Transforms/residual math", "5053e0", "::add_inter_residual_to_workspace::<"),
    ("Transforms/residual math", "3bfde0", "::add_residual_rect_block_with_runner::<"),
    ("Transforms/residual math", "3c0040", "::add_adjusted_residual_rect_block_with_runner::<"),
    ("Transforms/residual math", "6557f0", "::ResidualRunner>::add_u8::{closure#0}"),
    ("Transforms/residual math", "aa4180", "::inverse_transform_2d_8bit::avx2::transform::__fearless_simd_kernel"),
    ("Filters", "38e230", "::OwnedFilterJob<u8>>::run::<"),
    ("Filters", "3f34c0", "::OwnedFilterFrontier<u8>>::advance::<"),
    ("Output/scheduling/frame setup", "6bc6c0", "::WalkedFrame<u8>>::into_frontier"),
    ("Output/scheduling/frame setup", "51e950", "::frame_tasks::reserve_tip_output::<"),
    ("Output/scheduling/frame setup*", "763310", "::decode_frames_in_order::<"),
    ("Output/scheduling/frame setup*", "773940", "::decode_key_frame_with_effects::<"),
    ("Output/scheduling/frame setup*", "527fe0", "::settle_walk_stage::<"),
    ("Output/scheduling/frame setup*", "51f2f0", "::frame_engine::walk_frame::<"),
    ("Output/scheduling/frame setup*", "55fca0", "::decode_inter_blocks::<"),
    ("Output/scheduling/frame setup*", "31c6c0", "::TileCommit<u8>>::replay::<"),
    ("Output/scheduling/frame setup*", "6b1290", "::DecodedLeafPublication>::publish_block_decoded"),
]


FOCUSED_EDGES = [
    ("TIP motion-field units", ("5e8c00", "61cfb0"),
     ("::tip_field::prepare_tip_field<", "::tip_field::prepare_tip_units::<"), ("8f9840", "8257e0"), 14),
    ("CDEF segment filter", ("515130", "487480"),
     ("::cdef::cdef_segment::<", "::cdef_filter_segment_with<"), ("595850", "88cd80"), 88_876),
    ("CDEF packed chroma gather", ("515130", "387790"),
     ("::cdef::cdef_segment::<", "::CdefPairSegment>::gather_with_mode::<"), ("595850", "3f9640"), 88_876),
    ("Luma Wiener filter", ("3bacb0", "4477b0"),
     ("::compute_luma_lr_block::<", "::wiener_ns_filter_luma_block_padded_layout_into::<"), ("44a800", "534890"), 1_151),
    ("Coefficient high-frequency pass", ("5f07b0", "316130"),
     ("::hf_pass::<", "::hf_pass<0, true, true, false>"), ("7ede10", "31d580"), 7_651),
]


def edge(profile, fragments, calls, stripped):
    _, costs, counts = profile
    if stripped:
        key = tuple("0x" + address.zfill(16) for address in fragments)
    else:
        matches = [key for key, count in counts.items() if count == calls and
                   all(fragment in name for fragment, name in zip(fragments, key))]
        assert len(matches) == 1, (fragments, calls, matches)
        key = matches[0]
    assert counts[key] == calls, (key, counts[key], calls)
    return costs[key]


def label_stages(profile, shipped):
    own, edges, _ = profile
    nodes = set(own) | {n for edge in edges for n in edge}
    roots, local = {}, {}
    for stage, address, fragment in ANCHORS:
        if shipped:
            names = ["0x" + address.zfill(16)]
        else:
            names = [name for name in nodes if fragment in name]
        assert len(names) == 1 and names[0] in nodes, (address, fragment, names)
        if stage.endswith("*"):
            local[names[0]] = stage[:-1]
        else:
            roots[names[0]] = stage

    children = defaultdict(list)
    for caller, callee in edges:
        children[caller].append(callee)
    labels = defaultdict(set)
    work = deque(roots.items())
    while work:
        node, stage = work.popleft()
        if stage in labels[node] or (node in roots and roots[node] != stage):
            continue
        labels[node].add(stage)
        work.extend((child, stage) for child in children[node])

    groups = Counter()
    members = defaultdict(Counter)
    for node, count in own.items():
        if MEMORY.search(node):
            stage = "Memory/allocator functions"
        elif node in local:
            stage = local[node]
        elif len(labels[node]) == 1:
            stage = next(iter(labels[node]))
        else:
            stage = "Uncategorized/shared"
        groups[stage] += count
        members[stage][node] += count
    assert groups.total() == own.total()
    return groups, members


def output(details):
    shipped = read(SHIPPED)
    proxy = read(SYMBOLIZED)
    results = label_stages(shipped, True), label_stages(proxy, False)
    profiles = [groups for groups, _ in results]
    print("| Stage | Shipped 10279846 | Symbolized 07cdddce | Excess Ir |")
    print("|---|---:|---:|---:|")
    for key in STAGES:
        a, b = (profile[key] for profile in profiles)
        print(f"| {key} | {a:,} | {b:,} | {b-a:+,} |")
    a, b = (profile.total() for profile in profiles)
    print(f"| Total | {a:,} | {b:,} | {b-a:+,} |")
    if F03.exists() and F03.stat().st_size:
        f03 = read(F03)
        n = f03[0].total()
        print(f"\nExact stripped f03 total: {n:,} ({n-a:+,}, {(n/a-1):+.2%} versus shipped; {n-b:+,}, {(n/b-1):+.3%} versus symbolized 07cdddce).")
        print("\nThese are inclusive call edges in separate branches of the profile. The costs are already represented in the exclusive stage totals above.\n")
        print("| Selected call edge | Calls in each trace | Shipped | Symbolized 07cdddce | Exact f03 | f03 excess Ir |")
        print("|---|---:|---:|---:|---:|---:|")
        for label, old, named, new, calls in FOCUSED_EDGES:
            x = edge(shipped, old, calls, stripped=True)
            y = edge(proxy, named, calls, stripped=False)
            z = edge(f03, new, calls, stripped=True)
            print(f"| {label} | {calls:,} | {x:,} | {y:,} | {z:,} | {z-x:+,} |")
    if details:
        for name, (_, members) in zip(("Shipped", "Symbolized"), results):
            for category in STAGES:
                print(f"\n{name} {category}")
                for function, cost in members[category].most_common(6):
                    print(f"{cost:12,}  {function}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--details", action="store_true", help="print the busiest functions in each stage")
    output(parser.parse_args().details)

```
</details>
