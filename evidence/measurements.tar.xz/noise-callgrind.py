"""Report self costs and direct caller edges from an Ir-only Callgrind trace."""
import collections
import re
import sys

names = {}
self_costs = collections.Counter()
edges = collections.defaultdict(lambda: [0, 0])
caller = callee = None
calls = None

def symbol(encoded):
    match = re.fullmatch(r"\((\d+)\)(?: (.*))?", encoded)
    if match is None:
        return encoded
    index, definition = match.groups()
    if definition is not None:
        names[index] = definition
    return index

with open(sys.argv[1]) as trace:
    for line in trace:
        line = line.strip()
        if line.startswith("fn="):
            caller = symbol(line[3:])
        elif line.startswith("cfn="):
            callee = symbol(line[4:])
        elif line.startswith("calls="):
            calls = int(line[6:].split()[0])
        elif line and line[0] in "*+-0123456789" and caller is not None:
            instructions = int(line.split()[1])
            if calls is None:
                self_costs[caller] += instructions
            else:
                edge = edges[caller, callee]
                edge[0] += instructions
                edge[1] += calls
                calls = None

def name(index):
    return names.get(index, index)

pattern = re.compile(sys.argv[2], re.IGNORECASE) if len(sys.argv) > 2 else re.compile(".")
print("Total self Ir", sum(self_costs.values()))
print("\nSelf Ir")
for fn, instructions in self_costs.most_common():
    if pattern.search(name(fn)):
        print(f"{instructions:>14,} {name(fn)}")
print("\nInclusive edge Ir | calls | direct caller -> callee (nested edges overlap)")
for (parent, child), (instructions, count) in sorted(edges.items(), key=lambda pair: pair[1][0], reverse=True):
    if pattern.search(name(child)):
        print(f"{instructions:>14,} {count:>12,} {name(parent)} -> {name(child)}")
