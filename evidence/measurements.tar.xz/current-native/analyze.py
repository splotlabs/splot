"""Pair the current captures with the same attribution used in native-stacks."""

from collections import Counter
from pathlib import Path
import re
from runpy import run_path
from statistics import mean, median

HERE = Path(__file__).resolve().parent
TOOLS = run_path(str(HERE.parent / "native-stacks/analyze.py"))
# v3 keeps lane preparation as a separate function. The merged scan inlines it.
for i, (name, pattern) in enumerate(TOOLS["FOCUSES"]):
    if name == "Temporal motion-field projection":
        matched = re.compile(
            r"::(?:project_tracked|project_temporal_motion_field|chunk_lanes|TargetTables)(?:::)?<"
            r"|ChunkWalk>::project$"
        )
        TOOLS["FOCUSES"][i] = name, matched
LABELS = ("shipped-symbols", "portable")
PAIRS = tuple(
    int(p.stem.rsplit("-", 1)[1])
    for p in sorted(HERE.glob("shipped-symbols-*.overview"))
    if (HERE / p.name.replace("shipped-symbols-", "portable-")).exists()
)
RANGES, _, _ = TOOLS["resolve_libc"]()

def read(label, pair, suffix):
    return (HERE / f"{label}-{pair}.{suffix}").read_text()

profiles = {}
checks = {}
for label in LABELS:
    for pair in PAIRS:
        pcs = read(label, pair, "pcs")
        checks[label, pair] = {}
        profiles[label, pair] = TOOLS["summarize"](read(label, pair, "tree"),
                                                  read(label, pair, "functions"), pcs, RANGES)
        overview = read(label, pair, "overview")
        duration = float(re.search(r"\bDuration\s*:\s*([0-9.]+) Seconds", overview)[1])
        cpu = profiles[label, pair][0].total()
        match = re.search(r"\btotalcpu \(Seconds\):\s*\[\*([0-9.]+)\]", overview)
        assert match and round(float(match[1]) * 1000) == cpu, (label, pair, cpu)
        costs = sorted(
            ((TOOLS["milliseconds"](match[1]), line)
             for line in pcs.splitlines() if (match := TOOLS["PC_LINE"].fullmatch(line))),
            reverse=True,
        )
        two_pc = sum(cost for cost, _ in costs[:2])
        peak_cost, peak_line = costs[0]
        scheduling_entry = (
            peak_cost >= 0.2 * cpu
            and "::output_schedule::charge_emitted_outputs + 0x00000000" in peak_line
            and all(peak_line.split(" + ")[0].split(" ", maxsplit=3)[-1] not in
                    read(label, other, "pcs") for other in PAIRS if other != pair)
        )
        checks[label, pair] = duration, cpu, two_pc / cpu, scheduling_entry

assert len(PAIRS) >= 3
accepted = []
print("# Noise_Ocean after the TIP fix\n")
print("One-millisecond native gprofng CPU samples, 130 frames, CPU 3, one worker, "
      "frame delay one, null output. Pair order alternates. All three binaries matched "
      "the full 130-frame hash output.\n")
print("The merged binary is the exact symbolized 7c50c1b4 build. Shipped is the same-SHA "
      "symbolized 10279846 rebuild. Its .text is 272 bytes larger than the distributed binary; "
      "the earlier study verified five hotspot instruction shapes and decoded frame hashes. "
      "The merged revision also includes upstream changes.\n")
print("A gross outlier has more than three times its variant median wall or sampled CPU time, "
      "or at least 35% of sampled CPU on two PCs. We also excluded one transient "
      "scheduling capture after inspecting its PC data. Exclusion applies to the whole pair. "
      "Pair 4 replaced pair 3.\n")
print("| Pair | Shipped wall s | Merged wall s | Shipped CPU ms | Merged CPU ms | "
      "Top-two PC share, shipped/merged | Status |")
print("|---:|---:|---:|---:|---:|---:|---|")
for pair in PAIRS:
    old, new = (checks[label, pair] for label in LABELS)
    reasons = []
    for label, data in zip(LABELS, (old, new)):
        for index, metric in enumerate(("wall", "CPU")):
            if data[index] > 3 * median(checks[label, r][index] for r in PAIRS):
                reasons.append(f"{label} {metric}")
        if data[2] >= 0.35:
            reasons.append(f"{label} PC concentration")
        if data[3]:
            reasons.append(f"{label} scheduling entry concentration")
    status = ", ".join(reasons) if reasons else "Accepted"
    if not reasons:
        accepted.append(pair)
    print(f"| {pair} | {old[0]:.3f} | {new[0]:.3f} | {old[1]} | {new[1]} | "
          f"{old[2]:.1%} / {new[2]:.1%} | {status} |")

assert accepted
print("\nThe shipped capture in pair 3 assigned 259 ms to the entry instruction of "
      "`charge_emitted_outputs`. This instruction has no samples in the other shipped "
      "captures. The temporal row below includes both shipped's separate lane-preparation "
      "symbols and the merged scan's inlined preparation.")
cpu = [profiles["portable", pair][0].total() - profiles["shipped-symbols", pair][0].total()
       for pair in accepted]
paired = [100 * (checks["portable", pair][1] / checks["shipped-symbols", pair][1] - 1)
          for pair in accepted]
print(f"\nMean sampled gap {mean(cpu):+.1f} ms, median paired CPU change {median(paired):+.2f}%.")

for index, title, keys in (
    (0, "Exclusive CPU stages", TOOLS["STAGES"]),
    (4, "Filter subgroups", [x[0] for x in TOOLS["FILTERS"]] + ["Filter staging/shared"]),
    (1, "Matched stack-attributed kernels", [x[0] for x in TOOLS["FOCUSES"]]),
):
    print(f"\n## {title}\n")
    print("| Group | Shipped mean ms | Merged mean ms | Mean delta ms | Paired deltas ms |")
    print("|---|---:|---:|---:|---|")
    rows = []
    for key in keys:
        old, new = ([profiles[label, pair][index][key] for pair in accepted] for label in LABELS)
        deltas = [b - a for a, b in zip(old, new)]
        rows.append((mean(deltas), key, mean(old), mean(new), deltas))
    for delta, key, old, new, deltas in sorted(rows, reverse=True):
        paired_text = ", ".join(f"{n:+d}" for n in deltas)
        print(f"| {key} | {old:.1f} | {new:.1f} | {delta:+.1f} | {paired_text} |")

for label in LABELS:
    totals = Counter()
    for pair in accepted:
        totals.update(profiles[label, pair][2])
    print(f"\n## {'Merged' if label == 'portable' else 'Shipped'} top exclusive symbols\n")
    for name, samples in totals.most_common(15):
        print(f"{samples / len(accepted):7.1f} ms  {name}")

print("\nEach sample is counted once per attribution table. Stage and kernel tables overlap. "
      "Three pairs describe sample variability but do not establish a stable confidence interval. "
      "Raw experiments, PC samples, and per-capture duration remain available.")
