# Temporal motion-field projection on Noise_Ocean

The exact merged `7c50c1b4` binary and the symbolized shipped `10279846` rebuild decoded the same 130 frame hashes. The one-millisecond native profiles use three accepted pairs on CPU 3. Pair 3 remains in the raw results and was replaced after its shipped capture attributed 259 ms to one scheduling-function entry PC.

The adjusted native match includes shipped's separately symbolized `chunk_lanes` and `TargetTables::new` as well as both tracked walks and the untracked walk. The merged scoped function already includes lane preparation. Temporal projection averaged **99.3 to 120.7 ms**, an excess of **21.3 ms** and paired excesses of **22, 24 and 18 ms**. The matched CDEF segment filter also rose by 21.3 ms. The broader CDEF group rose by 71.3 ms.

| Part | Shipped mean ms | Merged mean ms | Excess ms |
|---|---:|---:|---:|
| Tracked with trajectory extension | 61.3 | 74.3 | +13.0 |
| Tracked without trajectory extension | 12.3 | 15.3 | +3.0 |
| Untracked walk | 0.3 | 1.0 | +0.7 |
| Lane preparation and scan overhead | 25.3 | 30.0 | +4.7 |

## Retired instructions, first 16 frames

Exact merged capture is `../cdef-boundary-ab/direct/Noise_Ocean-base.cg`. The local symbolized shipped capture is `shipped-symbols-16.cg`. Its whole-decode Ir differs by 2,483 of 1.306 billion from the preserved distributed shipped capture.

| Walk | Calls per build | Shipped Ir | Merged Ir | Excess Ir |
|---|---:|---:|---:|---:|
| Tracked with trajectory extension | 19,980 | 156,761,198 | 160,143,181 | +3,381,983 |
| Tracked without trajectory extension | 7,020 | 34,729,000 | 39,764,760 | +5,035,760 |
| Untracked | 4,320 | 3,504,692 | 3,504,692 | 0 |

The merged scan edge costs 239,508,095 Ir. Shipped's matched walks, lane preparation, table construction and row fetches total 230,320,145 Ir. The resulting 9,187,950 Ir difference is an upper estimate because shipped inlines some scan orchestration into its caller. The tracked walks alone account for 8,417,743 excess Ir, with equal direct call counts and no callees in either build.

The respective 16-frame lane staging copies have the same call counts. The 27,000 tracked copies cost 1,751,600 Ir in both builds, and the 4,320 untracked copies cost about 280,000 Ir in both. The merged scan also calls one outlined `try_map` 17,712 times for 3,347,568 inclusive Ir. This belongs to the lane-preparation part of the operation, where the total matched increase is much smaller than in the tracked walks.

## Source and machine code

The tracked walk stays outside the existing feature scope because of its `#[inline(never)]`. Shipped's v3 build still has BMI and AVX2 features there. Both shipped tracked leaves use `blsr` and `shrx`, and contain 27 and 23 VEX instructions respectively. The merged tracked leaves use separate mask-clear instructions, shifts through `cl`, and scalar arithmetic for paired motion-component work such as the projected multiply, rounding and clipping. The merged retained walk has some SSE2 moves, but neither tracked leaf has any VEX instructions or outlined SIMD calls. Shipped's untracked walk also uses `blsr`, but both untracked leaves retire the same number of instructions on this prefix.

The retained walk bodies and trajectory storage logic agree in source between the two revisions. Local experiment `03ff8b7a` and its branch equivalent `528fbedc` applied scope and inlining to lane preparation and TIP holes. That work left the ordered tracked and untracked walks outside the SIMD entry.

## Proposed whole-scan change

Keep the existing narrow-backend feature entry around the entire row scan. Inline the shared row scan and its ordered tracked and untracked walks into that entry, and remove the nested per-chunk vectorize closures. Keep chunk order, least-set-bit iteration, and trajectory reads, updates and scatter writes in the same order. This lets the existing AVX2/BMI target context compile the entire accepted-token operation, including scalar bit iteration and per-motion-vector paired arithmetic. Benchmark the entire scan and check code size because the full-field and band callers currently produce distinct instantiations.

Restoring shipped tracked-walk code generation could recover up to the observed **16.0 ms** of native tracked-walk excess over 130 frames and **8.42 million Ir** on the 16-frame prefix. Restoring the whole matched operation to shipped parity would remove up to roughly **21.3 ms** and **9.19 million Ir**, about **2.3%** of the merged sampled CPU and **0.62%** of its prefix instructions respectively. These figures bound the measured gaps. The proposed scope has no measured speedup yet.
