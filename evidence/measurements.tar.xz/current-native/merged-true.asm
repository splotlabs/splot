
../final-integration/splot.full:     file format elf64-x86-64


Disassembly of section .text:

000000000042ff50 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_>:
  42ff50:	push   rbp
  42ff51:	push   r15
  42ff53:	push   r14
  42ff55:	push   r13
  42ff57:	push   r12
  42ff59:	push   rbx
  42ff5a:	sub    rsp,0x98
  42ff61:	mov    rax,rcx
  42ff64:	movabs r15,0x7fffffffffffffff
  42ff6e:	mov    rcx,QWORD PTR [rsi+0x130]
  42ff75:	mov    QWORD PTR [rsp-0x30],rcx
  42ff7a:	mov    rcx,QWORD PTR [rdi+0x10]
  42ff7e:	mov    r9,QWORD PTR [rdi+0x18]
  42ff82:	mov    r8,QWORD PTR [rdx+0x30]
  42ff86:	mov    QWORD PTR [rsp-0x18],r8
  42ff8b:	sub    rcx,r8
  42ff8e:	jb     42ffad <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5d>
  42ff90:	imul   rcx,QWORD PTR [rdx+0x58]
  42ff95:	mov    r8,QWORD PTR [rdx+0x28]
  42ff99:	cmp    rcx,r8
  42ff9c:	jae    42ffad <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5d>
  42ff9e:	add    rcx,r9
  42ffa1:	imul   r8,QWORD PTR [rsp-0x30]
  42ffa7:	add    r8,rcx
  42ffaa:	mov    r15,r8
  42ffad:	mov    QWORD PTR [rsp+0x88],r9
  42ffb5:	mov    r14,QWORD PTR [rdi+0x8]
  42ffb9:	test   r14,r14
  42ffbc:	je     430aef <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xb9f>
  42ffc2:	mov    rbp,QWORD PTR [rdi]
  42ffc5:	mov    r10,QWORD PTR [rdi+0x20]
  42ffc9:	mov    r9,QWORD PTR [rdx+0x28]
  42ffcd:	mov    r13,QWORD PTR [rdx+0x18]
  42ffd1:	mov    rcx,QWORD PTR [rdx+0x10]
  42ffd5:	mov    QWORD PTR [rsp-0x70],rcx
  42ffda:	cmp    QWORD PTR [rdx+0x38],0x1
  42ffdf:	movzx  ecx,BYTE PTR [rdx+0x6c]
  42ffe3:	mov    BYTE PTR [rsp-0x7b],cl
  42ffe7:	sete   cl
  42ffea:	mov    rdi,QWORD PTR [rdx+0x48]
  42ffee:	mov    r8,rdi
  42fff1:	shr    r8,cl
  42fff4:	mov    rcx,QWORD PTR [rdx+0x50]
  42fff8:	not    rcx
  42fffb:	mov    QWORD PTR [rsp-0x20],rcx
  430000:	mov    rcx,QWORD PTR [rdx+0x58]
  430004:	mov    QWORD PTR [rsp-0x48],rcx
  430009:	mov    rcx,QWORD PTR [rdx+0x40]
  43000d:	not    rcx
  430010:	mov    QWORD PTR [rsp],rcx
  430014:	mov    rcx,r9
  430017:	imul   rcx,QWORD PTR [rsp-0x30]
  43001d:	mov    QWORD PTR [rsp+0x48],rcx
  430022:	mov    rcx,QWORD PTR [rax]
  430025:	mov    QWORD PTR [rsp+0x20],rcx
  43002a:	mov    rax,QWORD PTR [rax+0x8]
  43002e:	mov    QWORD PTR [rsp+0x90],rax
  430036:	mov    rax,QWORD PTR [rdx]
  430039:	mov    QWORD PTR [rsp-0x68],rax
  43003e:	mov    rax,QWORD PTR [rdx+0x8]
  430042:	mov    QWORD PTR [rsp-0x58],rax
  430047:	mov    rax,QWORD PTR [rdx+0x20]
  43004b:	mov    QWORD PTR [rsp+0x28],rax
  430050:	mov    rax,QWORD PTR [rdx+0x60]
  430054:	mov    QWORD PTR [rsp+0x58],rax
  430059:	mov    eax,DWORD PTR [rdx+0x68]
  43005c:	and    eax,0x3f
  43005f:	mov    QWORD PTR [rsp+0x80],rax
  430067:	mov    QWORD PTR [rsp+0x50],rdi
  43006c:	mov    QWORD PTR [rsp+0x78],r8
  430071:	lea    rax,[r8+rdi*1]
  430075:	mov    QWORD PTR [rsp+0x60],rax
  43007a:	mov    QWORD PTR [rsp-0x28],rsi
  43007f:	mov    QWORD PTR [rsp+0x10],r15
  430084:	mov    QWORD PTR [rsp+0x18],r10
  430089:	mov    QWORD PTR [rsp-0x38],r9
  43008e:	mov    QWORD PTR [rsp-0x60],r13
  430093:	mov    QWORD PTR [rsp+0x8],rbp
  430098:	jmp    4300cd <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x17d>
  43009a:	mov    BYTE PTR [rax+0xd],dl
  43009d:	xor    edx,edx
  43009f:	mov    dil,0x1
  4300a2:	mov    ecx,r8d
  4300a5:	shl    dil,cl
  4300a8:	shr    r9,0x10
  4300ac:	mov    DWORD PTR [rax+r8*4],r9d
  4300b0:	or     dil,dl
  4300b3:	mov    BYTE PTR [rax+0xc],dil
  4300b7:	nop    WORD PTR [rax+rax*1+0x0]
  4300c0:	lea    rax,[r14-0x1]
  4300c4:	and    r14,rax
  4300c7:	je     430aef <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xb9f>
  4300cd:	tzcnt  rax,r14
  4300d2:	movzx  r12d,BYTE PTR [rbp+rax*1+0xc00]
  4300db:	cmp    r12d,0x8
  4300df:	ja     4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  4300e1:	shl    r12d,0x5
  4300e5:	add    r12,rsi
  4300e8:	movzx  r11d,BYTE PTR [rbp+rax*1+0xc40]
  4300f1:	mov    rdx,rax
  4300f4:	imul   rdx,r10
  4300f8:	lea    rbx,[rdx+r15*1]
  4300fc:	mov    ecx,DWORD PTR [rbp+rax*4+0x300]
  430103:	mov    QWORD PTR [rsp-0x8],rcx
  430108:	mov    ecx,DWORD PTR [rbp+rax*4+0x400]
  43010f:	mov    QWORD PTR [rsp-0x10],rcx
  430114:	movzx  r9d,BYTE PTR [r12]
  430119:	xor    edi,edi
  43011b:	test   r11b,0x8
  43011f:	je     43081a <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8ca>
  430125:	test   r9b,r9b
  430128:	je     43081a <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8ca>
  43012e:	mov    QWORD PTR [rsp-0x78],rdx
  430133:	mov    r8,QWORD PTR [r12+0x8]
  430138:	mov    edx,DWORD PTR [rbp+rax*4+0xb00]
  43013f:	mov    QWORD PTR [rsp+0x70],r8
  430144:	imul   r8,QWORD PTR [rsp-0x38]
  43014a:	cmp    rbx,r13
  43014d:	jae    4301e0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x290>
  430153:	mov    rcx,rbx
  430156:	shl    rcx,0x4
  43015a:	mov    QWORD PTR [rsp+0x68],rdx
  43015f:	mov    rdx,QWORD PTR [rsp-0x70]
  430164:	movzx  edi,BYTE PTR [rsp-0x7b]
  430169:	cmp    BYTE PTR [rdx+rcx*1+0xd],dil
  43016e:	mov    rdx,QWORD PTR [rsp+0x68]
  430173:	jne    4301e0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x290>
  430175:	add    rcx,QWORD PTR [rsp-0x70]
  43017a:	cmp    BYTE PTR [rcx+0xc],0x0
  43017e:	je     4301e0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x290>
  430180:	mov    BYTE PTR [rsp-0x79],r11b
  430185:	mov    QWORD PTR [rsp-0x50],rbx
  43018a:	mov    BYTE PTR [rsp-0x7a],r9b
  43018f:	mov    QWORD PTR [rsp-0x40],r8
  430194:	movaps xmm0,XMMWORD PTR [rcx]
  430197:	movaps XMMWORD PTR [rsp+0x30],xmm0
  43019c:	movzx  edi,BYTE PTR [rsp+0x3c]
  4301a1:	test   dil,dil
  4301a4:	jne    43028e <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x33e>
  4301aa:	mov    rsi,QWORD PTR [rsp-0x28]
  4301af:	mov    r15,QWORD PTR [rsp+0x10]
  4301b4:	mov    rbp,QWORD PTR [rsp+0x8]
  4301b9:	mov    r10,QWORD PTR [rsp+0x18]
  4301be:	mov    r13,QWORD PTR [rsp-0x60]
  4301c3:	mov    r8,QWORD PTR [rsp-0x40]
  4301c8:	movzx  r9d,BYTE PTR [rsp-0x7a]
  4301ce:	mov    rbx,QWORD PTR [rsp-0x50]
  4301d3:	movzx  r11d,BYTE PTR [rsp-0x79]
  4301d9:	mov    rdx,QWORD PTR [rsp+0x68]
  4301de:	xchg   ax,ax
  4301e0:	add    r8,rdx
  4301e3:	test   r11b,0x1
  4301e7:	mov    QWORD PTR [rsp-0x40],r8
  4301ec:	je     430810 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8c0>
  4301f2:	cmp    r8,r13
  4301f5:	jae    430810 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8c0>
  4301fb:	mov    rcx,r8
  4301fe:	shl    rcx,0x4
  430202:	mov    rdx,QWORD PTR [rsp-0x70]
  430207:	movzx  edi,BYTE PTR [rsp-0x7b]
  43020c:	cmp    BYTE PTR [rdx+rcx*1+0xd],dil
  430211:	jne    430810 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8c0>
  430217:	add    rcx,QWORD PTR [rsp-0x70]
  43021c:	cmp    BYTE PTR [rcx+0xc],0x0
  430220:	je     430810 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8c0>
  430226:	mov    BYTE PTR [rsp-0x79],r11b
  43022b:	mov    QWORD PTR [rsp-0x50],rbx
  430230:	mov    BYTE PTR [rsp-0x7a],r9b
  430235:	movaps xmm0,XMMWORD PTR [rcx]
  430238:	movaps XMMWORD PTR [rsp+0x30],xmm0
  43023d:	movzx  r9d,BYTE PTR [rsp+0x3c]
  430243:	test   r9b,r9b
  430246:	mov    r8,QWORD PTR [rsp-0x78]
  43024b:	je     4307e5 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x895>
  430251:	add    r8,QWORD PTR [rsp+0x88]
  430259:	mov    QWORD PTR [rsp-0x78],r8
  43025e:	jmp    430550 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  430263:	mov    BYTE PTR [rsi+0xc],0x0
  430267:	mov    dl,0x1
  430269:	shl    dl,cl
  43026b:	mov    DWORD PTR [rsi+rcx*4],ebp
  43026e:	or     BYTE PTR [rsi+0xc],dl
  430271:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  430280:	lea    ecx,[rdi-0x1]
  430283:	and    cl,dil
  430286:	mov    edi,ecx
  430288:	je     4301aa <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x25a>
  43028e:	movzx  ecx,dil
  430292:	tzcnt  ecx,ecx
  430296:	cmp    cl,0x3
  430299:	jae    4301aa <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x25a>
  43029f:	mov    ebp,DWORD PTR [rsp+rcx*4+0x30]
  4302a3:	mov    r11d,ebp
  4302a6:	shr    r11d,0x10
  4302aa:	movzx  r9d,bp
  4302ae:	mov    esi,r11d
  4302b1:	and    esi,DWORD PTR [rsp-0x20]
  4302b5:	mov    rbx,rsi
  4302b8:	sub    rbx,QWORD PTR [rsp+0x78]
  4302bd:	mov    edx,0x0
  4302c2:	cmovb  rbx,rdx
  4302c6:	mov    r13,r9
  4302c9:	sub    r13,QWORD PTR [rsp-0x18]
  4302ce:	jb     430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  4302d0:	imul   r13,QWORD PTR [rsp-0x48]
  4302d6:	add    r13,r11
  4302d9:	mov    rdx,r13
  4302dc:	imul   rdx,QWORD PTR [rsp+0x28]
  4302e2:	mov    r8,QWORD PTR [rsp+0x70]
  4302e7:	lea    r15,[rdx+r8*1]
  4302eb:	cmp    r15,QWORD PTR [rsp-0x58]
  4302f0:	jae    430305 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x3b5>
  4302f2:	mov    r8,QWORD PTR [rsp-0x68]
  4302f7:	xor    r10d,r10d
  4302fa:	cmp    r10w,WORD PTR [r8+r15*4]
  4302ff:	jno    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  430305:	add    rdx,QWORD PTR [rsp-0x30]
  43030a:	cmp    rdx,QWORD PTR [rsp-0x58]
  43030f:	jae    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  430315:	mov    r8,QWORD PTR [rsp-0x68]
  43031a:	movsx  r10d,WORD PTR [r8+rdx*4]
  43031f:	cmp    r10d,0xffff8000
  430326:	je     430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  43032c:	add    r10d,DWORD PTR [rsp-0x8]
  430331:	cmp    r10d,0xfffff802
  430338:	jge    430340 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x3f0>
  43033a:	mov    r10d,0xfffff801
  430340:	cmp    r10d,0x7ff
  430347:	jl     43034f <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x3ff>
  430349:	mov    r10d,0x7ff
  43034f:	mov    r8,QWORD PTR [rsp-0x68]
  430354:	movsx  edx,WORD PTR [r8+rdx*4+0x2]
  43035a:	add    edx,DWORD PTR [rsp-0x10]
  43035e:	cmp    edx,0xfffff802
  430364:	jl     4303f0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x4a0>
  43036a:	cmp    edx,0x7ff
  430370:	jge    430401 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x4b1>
  430376:	cmp    r15,QWORD PTR [rsp-0x58]
  43037b:	jae    43038d <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x43d>
  43037d:	mov    r8,QWORD PTR [rsp-0x68]
  430382:	mov    WORD PTR [r8+r15*4],r10w
  430387:	mov    WORD PTR [r8+r15*4+0x2],dx
  43038d:	mov    r15d,r10d
  430390:	neg    r15d
  430393:	cmovs  r15d,r10d
  430397:	mov    r8d,edx
  43039a:	neg    r8d
  43039d:	cmovs  r8d,edx
  4303a1:	cmp    r15d,r8d
  4303a4:	cmova  r8d,r15d
  4303a8:	cmp    r8d,0x40
  4303ac:	jae    430416 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x4c6>
  4303ae:	cmp    r13,QWORD PTR [rsp-0x38]
  4303b3:	jae    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  4303b9:	add    r13,QWORD PTR [rsp-0x40]
  4303be:	cmp    r13,QWORD PTR [rsp-0x60]
  4303c3:	jae    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  4303c9:	shl    r13,0x4
  4303cd:	mov    rdx,QWORD PTR [rsp-0x70]
  4303d2:	lea    rsi,[rdx+r13*1]
  4303d6:	movzx  r8d,BYTE PTR [rsp-0x7b]
  4303dc:	cmp    BYTE PTR [rdx+r13*1+0xd],r8b
  4303e1:	je     430267 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x317>
  4303e7:	mov    BYTE PTR [rsi+0xd],r8b
  4303eb:	jmp    430263 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x313>
  4303f0:	mov    edx,0xfffff801
  4303f5:	cmp    edx,0x7ff
  4303fb:	jl     430376 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x426>
  430401:	mov    edx,0x7ff
  430406:	cmp    r15,QWORD PTR [rsp-0x58]
  43040b:	jb     43037d <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x42d>
  430411:	jmp    43038d <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x43d>
  430416:	lea    r8d,[r10+0x3f]
  43041a:	test   r10d,r10d
  43041d:	cmovns r8d,r10d
  430421:	movsx  r8d,r8w
  430425:	sar    r8d,0x6
  430429:	add    r8d,r9d
  43042c:	setns  r10b
  430430:	mov    r13d,r8d
  430433:	cmp    QWORD PTR [rsp+0x58],r13
  430438:	seta   r8b
  43043c:	and    r8b,r10b
  43043f:	cmp    r8b,0x1
  430443:	jne    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  430449:	lea    r8d,[rdx+0x3f]
  43044d:	test   edx,edx
  43044f:	cmovns r8d,edx
  430453:	movsx  edx,r8w
  430457:	sar    edx,0x6
  43045a:	add    r11d,edx
  43045d:	setns  r8b
  430461:	mov    edx,r11d
  430464:	cmp    QWORD PTR [rsp-0x48],rdx
  430469:	seta   r10b
  43046d:	and    r10b,r8b
  430470:	cmp    r10b,0x1
  430474:	jne    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  43047a:	and    r9d,DWORD PTR [rsp-0x20]
  43047f:	mov    r8,QWORD PTR [rsp+0x50]
  430484:	add    r8,r9
  430487:	add    rsi,QWORD PTR [rsp+0x60]
  43048c:	mov    r10,QWORD PTR [rsp]
  430490:	and    r13,r10
  430493:	and    rdx,r10
  430496:	cmp    r13,r9
  430499:	setb   r9b
  43049d:	cmp    r13,r8
  4304a0:	setae  r8b
  4304a4:	cmp    rdx,rbx
  4304a7:	setb   r10b
  4304ab:	or     r10b,r9b
  4304ae:	cmp    rdx,rsi
  4304b1:	setae  sil
  4304b5:	or     sil,r8b
  4304b8:	or     sil,r10b
  4304bb:	sub    r13,QWORD PTR [rsp-0x18]
  4304c0:	setb   r8b
  4304c4:	or     r8b,sil
  4304c7:	jne    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  4304cd:	imul   r13,QWORD PTR [rsp-0x48]
  4304d3:	add    rdx,r13
  4304d6:	cmp    rdx,QWORD PTR [rsp-0x38]
  4304db:	jae    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  4304e1:	add    rdx,QWORD PTR [rsp-0x40]
  4304e6:	cmp    rdx,QWORD PTR [rsp-0x60]
  4304eb:	jae    430280 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x330>
  4304f1:	shl    rdx,0x4
  4304f5:	mov    r8,QWORD PTR [rsp-0x70]
  4304fa:	lea    rsi,[r8+rdx*1]
  4304fe:	movzx  r9d,BYTE PTR [rsp-0x7b]
  430504:	cmp    BYTE PTR [r8+rdx*1+0xd],r9b
  430509:	je     430267 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x317>
  43050f:	mov    BYTE PTR [rsi+0xd],r9b
  430513:	jmp    430263 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x313>
  430518:	mov    BYTE PTR [r10+0xd],r8b
  43051c:	mov    BYTE PTR [r10+0xc],0x0
  430521:	mov    r8,QWORD PTR [rsp-0x78]
  430526:	mov    dl,0x1
  430528:	shl    dl,cl
  43052a:	mov    DWORD PTR [r10+rcx*4],edi
  43052e:	or     BYTE PTR [r10+0xc],dl
  430532:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  430540:	lea    ecx,[r9-0x1]
  430544:	and    cl,r9b
  430547:	mov    r9d,ecx
  43054a:	je     4307e5 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x895>
  430550:	movzx  ecx,r9b
  430554:	tzcnt  ecx,ecx
  430558:	cmp    cl,0x3
  43055b:	jae    4307e5 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x895>
  430561:	mov    edi,DWORD PTR [rsp+rcx*4+0x30]
  430565:	mov    r11d,edi
  430568:	shr    r11d,0x10
  43056c:	movzx  ebp,di
  43056f:	mov    r13d,r11d
  430572:	and    r13d,DWORD PTR [rsp-0x20]
  430577:	mov    rdx,r13
  43057a:	sub    rdx,QWORD PTR [rsp+0x78]
  43057f:	mov    ebx,0x0
  430584:	cmovae rbx,rdx
  430588:	mov    rsi,rbp
  43058b:	sub    rsi,QWORD PTR [rsp-0x18]
  430590:	jb     430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  430592:	cmp    r8,rbx
  430595:	jb     430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  430597:	add    r13,QWORD PTR [rsp+0x60]
  43059c:	cmp    r8,r13
  43059f:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  4305a1:	imul   rsi,QWORD PTR [rsp-0x48]
  4305a7:	add    rsi,r11
  4305aa:	mov    rdx,rsi
  4305ad:	imul   rdx,QWORD PTR [rsp+0x28]
  4305b3:	mov    r8,QWORD PTR [rsp-0x30]
  4305b8:	lea    r15,[rdx+r8*1]
  4305bc:	mov    r8,QWORD PTR [rsp-0x78]
  4305c1:	cmp    r15,QWORD PTR [rsp-0x58]
  4305c6:	jae    4305e0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x690>
  4305c8:	mov    r8,QWORD PTR [rsp-0x68]
  4305cd:	xor    r10d,r10d
  4305d0:	cmp    r10w,WORD PTR [r8+r15*4]
  4305d5:	mov    r8,QWORD PTR [rsp-0x78]
  4305da:	jno    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  4305e0:	add    rdx,QWORD PTR [rsp+0x70]
  4305e5:	cmp    rdx,QWORD PTR [rsp-0x58]
  4305ea:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  4305f0:	mov    r8,QWORD PTR [rsp-0x68]
  4305f5:	movsx  r10d,WORD PTR [r8+rdx*4]
  4305fa:	mov    r8,QWORD PTR [rsp-0x78]
  4305ff:	cmp    r10d,0xffff8000
  430606:	je     430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  43060c:	sub    r10d,DWORD PTR [rsp-0x8]
  430611:	cmp    r10d,0xfffff802
  430618:	jge    430620 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x6d0>
  43061a:	mov    r10d,0xfffff801
  430620:	cmp    r10d,0x7ff
  430627:	jl     43062f <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x6df>
  430629:	mov    r10d,0x7ff
  43062f:	mov    r8,QWORD PTR [rsp-0x68]
  430634:	movsx  edx,WORD PTR [r8+rdx*4+0x2]
  43063a:	sub    edx,DWORD PTR [rsp-0x10]
  43063e:	cmp    edx,0xfffff802
  430644:	jl     4306d1 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x781>
  43064a:	cmp    edx,0x7ff
  430650:	jge    4306e2 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x792>
  430656:	cmp    r15,QWORD PTR [rsp-0x58]
  43065b:	jae    43066d <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x71d>
  43065d:	mov    r8,QWORD PTR [rsp-0x68]
  430662:	mov    WORD PTR [r8+r15*4],r10w
  430667:	mov    WORD PTR [r8+r15*4+0x2],dx
  43066d:	mov    r8d,r10d
  430670:	neg    r8d
  430673:	cmovs  r8d,r10d
  430677:	mov    r15d,edx
  43067a:	neg    r15d
  43067d:	cmovs  r15d,edx
  430681:	cmp    r8d,r15d
  430684:	cmova  r15d,r8d
  430688:	cmp    r15d,0x40
  43068c:	jae    4306f7 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x7a7>
  43068e:	cmp    rsi,QWORD PTR [rsp-0x38]
  430693:	mov    r8,QWORD PTR [rsp-0x78]
  430698:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  43069e:	add    rsi,QWORD PTR [rsp+0x48]
  4306a3:	cmp    rsi,QWORD PTR [rsp-0x60]
  4306a8:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  4306ae:	shl    rsi,0x4
  4306b2:	mov    rdx,QWORD PTR [rsp-0x70]
  4306b7:	lea    r10,[rdx+rsi*1]
  4306bb:	movzx  r8d,BYTE PTR [rsp-0x7b]
  4306c1:	cmp    BYTE PTR [rdx+rsi*1+0xd],r8b
  4306c6:	jne    430518 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5c8>
  4306cc:	jmp    430521 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5d1>
  4306d1:	mov    edx,0xfffff801
  4306d6:	cmp    edx,0x7ff
  4306dc:	jl     430656 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x706>
  4306e2:	mov    edx,0x7ff
  4306e7:	cmp    r15,QWORD PTR [rsp-0x58]
  4306ec:	jb     43065d <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x70d>
  4306f2:	jmp    43066d <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x71d>
  4306f7:	lea    esi,[r10+0x3f]
  4306fb:	test   r10d,r10d
  4306fe:	cmovns esi,r10d
  430702:	movsx  esi,si
  430705:	sar    esi,0x6
  430708:	add    esi,ebp
  43070a:	setns  r8b
  43070e:	mov    esi,esi
  430710:	cmp    QWORD PTR [rsp+0x58],rsi
  430715:	seta   r10b
  430719:	and    r10b,r8b
  43071c:	cmp    r10b,0x1
  430720:	mov    r8,QWORD PTR [rsp-0x78]
  430725:	jne    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  43072b:	lea    r8d,[rdx+0x3f]
  43072f:	test   edx,edx
  430731:	cmovns r8d,edx
  430735:	movsx  edx,r8w
  430739:	sar    edx,0x6
  43073c:	add    r11d,edx
  43073f:	setns  r8b
  430743:	mov    edx,r11d
  430746:	cmp    QWORD PTR [rsp-0x48],rdx
  43074b:	seta   r10b
  43074f:	and    r10b,r8b
  430752:	mov    r8,QWORD PTR [rsp-0x78]
  430757:	cmp    r10b,0x1
  43075b:	jne    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  430761:	and    edx,DWORD PTR [rsp]
  430764:	cmp    rdx,r13
  430767:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  43076d:	and    ebp,DWORD PTR [rsp-0x20]
  430771:	and    esi,DWORD PTR [rsp]
  430774:	cmp    esi,ebp
  430776:	jb     430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  43077c:	add    rbp,QWORD PTR [rsp+0x50]
  430781:	cmp    rsi,rbp
  430784:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  43078a:	cmp    rdx,rbx
  43078d:	jb     430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  430793:	sub    rsi,QWORD PTR [rsp-0x18]
  430798:	jb     430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  43079e:	imul   rsi,QWORD PTR [rsp-0x48]
  4307a4:	add    rdx,rsi
  4307a7:	cmp    rdx,QWORD PTR [rsp-0x38]
  4307ac:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  4307b2:	add    rdx,QWORD PTR [rsp+0x48]
  4307b7:	cmp    rdx,QWORD PTR [rsp-0x60]
  4307bc:	jae    430540 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5f0>
  4307c2:	shl    rdx,0x4
  4307c6:	mov    rsi,QWORD PTR [rsp-0x70]
  4307cb:	lea    r10,[rsi+rdx*1]
  4307cf:	movzx  r8d,BYTE PTR [rsp-0x7b]
  4307d5:	cmp    BYTE PTR [rsi+rdx*1+0xd],r8b
  4307da:	jne    430518 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5c8>
  4307e0:	jmp    430521 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5d1>
  4307e5:	mov    rsi,QWORD PTR [rsp-0x28]
  4307ea:	mov    r15,QWORD PTR [rsp+0x10]
  4307ef:	mov    rbp,QWORD PTR [rsp+0x8]
  4307f4:	mov    r10,QWORD PTR [rsp+0x18]
  4307f9:	mov    r13,QWORD PTR [rsp-0x60]
  4307fe:	movzx  r9d,BYTE PTR [rsp-0x7a]
  430804:	mov    rbx,QWORD PTR [rsp-0x50]
  430809:	movzx  r11d,BYTE PTR [rsp-0x79]
  43080f:	nop
  430810:	mov    edi,r11d
  430813:	and    dil,0x2
  430817:	shr    dil,1
  43081a:	test   r11b,0x4
  43081e:	je     4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  430824:	mov    ecx,DWORD PTR [rbp+rax*4+0x900]
  43082b:	cmp    QWORD PTR [rsp+0x90],rcx
  430833:	jbe    4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  430839:	mov    rdx,QWORD PTR [rsp+0x20]
  43083e:	cmp    BYTE PTR [rdx+rcx*8+0x6],0x0
  430843:	je     43086b <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x91b>
  430845:	cmp    BYTE PTR [r12+0x1b],0x1
  43084b:	jne    4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  430851:	mov    rdx,QWORD PTR [rsp+0x20]
  430856:	movsx  r8d,WORD PTR [rdx+rcx*8]
  43085b:	mov    edx,DWORD PTR [r12+0x10]
  430860:	cmp    edx,r8d
  430863:	je     4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  430869:	jmp    430870 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x920>
  43086b:	mov    edx,DWORD PTR [r12+0x10]
  430870:	mov    rsi,r15
  430873:	mov    r15d,r11d
  430876:	mov    r11,QWORD PTR [rsp-0x8]
  43087b:	mov    BYTE PTR [rsp-0x7a],r9b
  430880:	mov    r9d,r11d
  430883:	neg    r9d
  430886:	mov    QWORD PTR [rsp-0x50],rbx
  43088b:	mov    rbx,QWORD PTR [rsp-0x10]
  430890:	mov    r8d,ebx
  430893:	neg    r8d
  430896:	cmp    BYTE PTR [r12+0x1a],0x0
  43089c:	cmove  r9d,r11d
  4308a0:	cmove  r8d,ebx
  4308a4:	shl    r8d,0x10
  4308a8:	movzx  r9d,r9w
  4308ac:	or     r9d,r8d
  4308af:	mov    r8,QWORD PTR [rsp+0x20]
  4308b4:	mov    WORD PTR [r8+rcx*8],dx
  4308b9:	mov    DWORD PTR [r8+rcx*8+0x2],r9d
  4308be:	mov    BYTE PTR [r8+rcx*8+0x6],0x1
  4308c4:	test   r15b,0x10
  4308c8:	mov    r15,rsi
  4308cb:	mov    rsi,QWORD PTR [rsp-0x28]
  4308d0:	je     4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  4308d6:	mov    r11d,DWORD PTR [rbp+rax*4+0xa00]
  4308de:	cmp    QWORD PTR [rsp-0x38],r11
  4308e3:	jbe    4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  4308e9:	mov    ebx,DWORD PTR [rbp+rax*4+0x500]
  4308f0:	mov    r13d,DWORD PTR [rbp+rax*4+0x600]
  4308f8:	movsxd r10,DWORD PTR [rbp+rax*4+0x800]
  430900:	mov    r9d,DWORD PTR [rbp+rax*4+0x700]
  430908:	mov    r8,r10
  43090b:	mov    rcx,QWORD PTR [rsp+0x80]
  430913:	shr    r8,cl
  430916:	mov    rax,r8
  430919:	movabs rcx,0xaaaaaaaaaaaaaaab
  430923:	mul    rcx
  430926:	shr    rdx,1
  430929:	lea    rax,[rdx+rdx*2]
  43092d:	sub    r8,rax
  430930:	mov    eax,r9d
  430933:	or     eax,r10d
  430936:	shl    r10,0x20
  43093a:	shl    r9,0x10
  43093e:	add    r9,r10
  430941:	cmp    eax,0xffff
  430946:	ja     4309ab <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa5b>
  430948:	mov    rcx,QWORD PTR [rsp-0x50]
  43094d:	cmp    rcx,QWORD PTR [rsp-0x60]
  430952:	jae    4309ab <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa5b>
  430954:	mov    r15,QWORD PTR [rsp-0x50]
  430959:	shl    r15,0x4
  43095d:	mov    rcx,QWORD PTR [rsp-0x70]
  430962:	lea    rdx,[rcx+r15*1]
  430966:	movzx  r10d,BYTE PTR [rsp-0x7b]
  43096c:	cmp    BYTE PTR [rcx+r15*1+0xd],r10b
  430971:	jne    43097a <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa2a>
  430973:	movzx  r10d,BYTE PTR [rdx+0xc]
  430978:	jmp    430981 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa31>
  43097a:	mov    BYTE PTR [rdx+0xd],r10b
  43097e:	xor    r10d,r10d
  430981:	mov    r15,r9
  430984:	mov    bpl,0x1
  430987:	mov    ecx,r8d
  43098a:	shl    bpl,cl
  43098d:	shr    r15,0x10
  430991:	mov    DWORD PTR [rdx+r8*4],r15d
  430995:	or     bpl,r10b
  430998:	mov    BYTE PTR [rdx+0xc],bpl
  43099c:	mov    r15,QWORD PTR [rsp+0x10]
  4309a1:	mov    rbp,QWORD PTR [rsp+0x8]
  4309a6:	mov    rsi,QWORD PTR [rsp-0x28]
  4309ab:	imul   r11,QWORD PTR [rsp+0x28]
  4309b1:	mov    rcx,QWORD PTR [rsp-0x30]
  4309b6:	add    rcx,r11
  4309b9:	cmp    rcx,QWORD PTR [rsp-0x58]
  4309be:	jae    430a08 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xab8>
  4309c0:	neg    r13d
  4309c3:	cmp    r13d,0xfffff802
  4309ca:	mov    edx,0xfffff801
  4309cf:	cmovl  r13d,edx
  4309d3:	cmp    r13d,0x7ff
  4309da:	mov    r10d,0x7ff
  4309e0:	cmovge r13d,r10d
  4309e4:	neg    ebx
  4309e6:	cmp    ebx,0xfffff802
  4309ec:	cmovl  ebx,edx
  4309ef:	cmp    ebx,0x7ff
  4309f5:	cmovge ebx,r10d
  4309f9:	mov    rdx,QWORD PTR [rsp-0x68]
  4309fe:	mov    WORD PTR [rdx+rcx*4],bx
  430a02:	mov    WORD PTR [rdx+rcx*4+0x2],r13w
  430a08:	cmp    BYTE PTR [rsp-0x7a],0x0
  430a0d:	mov    r10,QWORD PTR [rsp+0x18]
  430a12:	mov    r13,QWORD PTR [rsp-0x60]
  430a17:	je     4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  430a1d:	add    r11,QWORD PTR [r12+0x8]
  430a22:	cmp    r11,QWORD PTR [rsp-0x58]
  430a27:	jae    430aa5 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xb55>
  430a29:	mov    r12d,DWORD PTR [r12+0x14]
  430a2e:	mov    rcx,QWORD PTR [rsp-0x10]
  430a33:	imul   ecx,r12d
  430a37:	mov    edx,ecx
  430a39:	sar    ecx,0x1f
  430a3c:	add    edx,ecx
  430a3e:	add    edx,0x2000
  430a44:	sar    edx,0xe
  430a47:	cmp    edx,0xfffff802
  430a4d:	mov    ebx,0xfffff801
  430a52:	cmovl  edx,ebx
  430a55:	cmp    edx,0x7ff
  430a5b:	mov    ecx,0x7ff
  430a60:	cmovge edx,ecx
  430a63:	mov    rcx,QWORD PTR [rsp-0x8]
  430a68:	imul   ecx,r12d
  430a6c:	mov    r12d,ecx
  430a6f:	sar    ecx,0x1f
  430a72:	add    ecx,r12d
  430a75:	add    ecx,0x2000
  430a7b:	sar    ecx,0xe
  430a7e:	cmp    ecx,0xfffff802
  430a84:	cmovl  ecx,ebx
  430a87:	cmp    ecx,0x7ff
  430a8d:	mov    ebx,0x7ff
  430a92:	cmovge ecx,ebx
  430a95:	mov    r12,QWORD PTR [rsp-0x68]
  430a9a:	mov    WORD PTR [r12+r11*4],cx
  430a9f:	mov    WORD PTR [r12+r11*4+0x2],dx
  430aa5:	cmp    eax,0x10000
  430aaa:	setae  al
  430aad:	xor    dil,0x1
  430ab1:	or     dil,al
  430ab4:	jne    4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  430aba:	cmp    QWORD PTR [rsp-0x40],r13
  430abf:	jae    4300c0 <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x170>
  430ac5:	mov    rdi,QWORD PTR [rsp-0x40]
  430aca:	shl    rdi,0x4
  430ace:	mov    rcx,QWORD PTR [rsp-0x70]
  430ad3:	lea    rax,[rcx+rdi*1]
  430ad7:	movzx  edx,BYTE PTR [rsp-0x7b]
  430adc:	cmp    BYTE PTR [rcx+rdi*1+0xd],dl
  430ae0:	jne    43009a <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x14a>
  430ae6:	movzx  edx,BYTE PTR [rax+0xc]
  430aea:	jmp    43009f <_RINvMs3_NtNtNtNtNtCsiiWGwn0QfU0_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x14f>
  430aef:	add    rsp,0x98
  430af6:	pop    rbx
  430af7:	pop    r12
  430af9:	pop    r13
  430afb:	pop    r14
  430afd:	pop    r15
  430aff:	pop    rbp
  430b00:	ret
