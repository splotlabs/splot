"""Reuse prior collection settings with the exact merged binary."""

import hashlib
import os
from pathlib import Path
from runpy import run_path
import sys

OUT = Path(__file__).resolve().parent
REFERENCE = OUT.parent / "native-stacks"
TOOL = run_path(str(REFERENCE / "collect.py"))
TOOL_ENV = TOOL["collect_profiles"].__globals__
BINARIES = {
    **TOOL_ENV["BINARIES"],
    "portable": OUT.parent / "final-integration/splot.full",
}
EXPECTED_MERGED = "92162d341559bec4c618ec6e312bd2df2afb0068f3b838e7eb335922fd03b34e"
EXPECTED_REFERENCE_TEXT = (
    10366695, "931aeed30d481ae76db646d231e48432b227e7d22b7c5d82e09475c646cb3773",
)

assert os.sched_getaffinity(0) == {3}
assert TOOL["text_section"](BINARIES["shipped-symbols"]) == EXPECTED_REFERENCE_TEXT
with BINARIES["portable"].open("rb") as binary:
    assert hashlib.file_digest(binary, "sha256").hexdigest() == EXPECTED_MERGED
TOOL_ENV.update(HERE=OUT, BINARIES=BINARIES)
if len(sys.argv) == 1:
    with (OUT / "binaries.sha256").open("x") as manifest:
        for path in BINARIES.values():
            with path.open("rb") as binary:
                print(hashlib.file_digest(binary, "sha256").hexdigest(), path, file=manifest)
    TOOL["verify_binaries"]()
    TOOL["collect_profiles"](range(1, 4))
else:
    TOOL["collect_profiles"](int(pair) for pair in sys.argv[1:])
