
../native-stacks/ref-target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

00000000003a1df0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_>:
  3a1df0:	push   rbp
  3a1df1:	push   r15
  3a1df3:	push   r14
  3a1df5:	push   r13
  3a1df7:	push   r12
  3a1df9:	push   rbx
  3a1dfa:	sub    rsp,0x98
  3a1e01:	movabs rbx,0x7fffffffffffffff
  3a1e0b:	mov    rax,QWORD PTR [rsi+0x130]
  3a1e12:	mov    QWORD PTR [rsp-0x20],rax
  3a1e17:	mov    rax,QWORD PTR [rdi+0x10]
  3a1e1b:	mov    r9,QWORD PTR [rdi+0x18]
  3a1e1f:	mov    r8,QWORD PTR [rdx+0x30]
  3a1e23:	mov    QWORD PTR [rsp],r8
  3a1e27:	sub    rax,r8
  3a1e2a:	jb     3a1e49 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x59>
  3a1e2c:	imul   rax,QWORD PTR [rdx+0x58]
  3a1e31:	mov    r8,QWORD PTR [rdx+0x28]
  3a1e35:	cmp    rax,r8
  3a1e38:	jae    3a1e49 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x59>
  3a1e3a:	add    rax,r9
  3a1e3d:	imul   r8,QWORD PTR [rsp-0x20]
  3a1e43:	add    r8,rax
  3a1e46:	mov    rbx,r8
  3a1e49:	mov    QWORD PTR [rsp+0x80],r9
  3a1e51:	mov    r11,QWORD PTR [rdi+0x8]
  3a1e55:	test   r11,r11
  3a1e58:	je     3a292b <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xb3b>
  3a1e5e:	mov    r12,QWORD PTR [rdi]
  3a1e61:	mov    rax,QWORD PTR [rdi+0x20]
  3a1e65:	mov    QWORD PTR [rsp+0x90],rax
  3a1e6d:	mov    r10,QWORD PTR [rdx+0x28]
  3a1e71:	mov    r15,QWORD PTR [rdx+0x18]
  3a1e75:	mov    rax,QWORD PTR [rdx+0x10]
  3a1e79:	mov    QWORD PTR [rsp-0x70],rax
  3a1e7e:	movzx  eax,BYTE PTR [rdx+0x6c]
  3a1e82:	mov    BYTE PTR [rsp-0x7a],al
  3a1e86:	mov    rax,QWORD PTR [rdx+0x50]
  3a1e8a:	mov    QWORD PTR [rsp-0x8],rax
  3a1e8f:	cmp    QWORD PTR [rdx+0x38],0x1
  3a1e94:	sete   al
  3a1e97:	mov    rdi,QWORD PTR [rdx+0x48]
  3a1e9b:	shrx   rax,rdi,rax
  3a1ea0:	mov    r8,QWORD PTR [rdx+0x58]
  3a1ea4:	mov    QWORD PTR [rsp-0x38],r8
  3a1ea9:	mov    r8,QWORD PTR [rdx]
  3a1eac:	mov    QWORD PTR [rsp-0x68],r8
  3a1eb1:	mov    r8,r10
  3a1eb4:	imul   r8,QWORD PTR [rsp-0x20]
  3a1eba:	mov    QWORD PTR [rsp+0x48],r8
  3a1ebf:	mov    r8,QWORD PTR [rcx]
  3a1ec2:	mov    QWORD PTR [rsp+0x20],r8
  3a1ec7:	mov    rcx,QWORD PTR [rcx+0x8]
  3a1ecb:	mov    QWORD PTR [rsp+0x88],rcx
  3a1ed3:	mov    rcx,QWORD PTR [rdx+0x8]
  3a1ed7:	mov    QWORD PTR [rsp-0x50],rcx
  3a1edc:	mov    rcx,QWORD PTR [rdx+0x20]
  3a1ee0:	mov    QWORD PTR [rsp+0x28],rcx
  3a1ee5:	mov    rcx,QWORD PTR [rdx+0x60]
  3a1ee9:	mov    QWORD PTR [rsp+0x58],rcx
  3a1eee:	mov    rcx,QWORD PTR [rdx+0x40]
  3a1ef2:	mov    QWORD PTR [rsp+0x8],rcx
  3a1ef7:	mov    ecx,DWORD PTR [rdx+0x68]
  3a1efa:	and    ecx,0x3f
  3a1efd:	mov    QWORD PTR [rsp+0x78],rcx
  3a1f02:	vpxor  xmm0,xmm0,xmm0
  3a1f06:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffffc7af01]        # 1ce10 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xdd0>
  3a1f0f:	vpbroadcastd xmm2,DWORD PTR [rip+0xffffffffffc7ae78]        # 1cd90 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xd50>
  3a1f18:	vpbroadcastd xmm3,DWORD PTR [rip+0xffffffffffc7b2d7]        # 1d1f8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x198>
  3a1f21:	mov    QWORD PTR [rsp+0x50],rdi
  3a1f26:	mov    QWORD PTR [rsp+0x70],rax
  3a1f2b:	add    rax,rdi
  3a1f2e:	mov    QWORD PTR [rsp+0x68],rax
  3a1f33:	mov    QWORD PTR [rsp+0x18],rsi
  3a1f38:	mov    QWORD PTR [rsp+0x10],rbx
  3a1f3d:	mov    QWORD PTR [rsp+0x60],r12
  3a1f42:	mov    QWORD PTR [rsp-0x40],r10
  3a1f47:	mov    QWORD PTR [rsp-0x58],r15
  3a1f4c:	jmp    3a1f7b <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x18b>
  3a1f4e:	mov    BYTE PTR [rax+0xd],cl
  3a1f51:	xor    edi,edi
  3a1f53:	mov    r8b,0x1
  3a1f56:	mov    rcx,QWORD PTR [rsp-0x48]
  3a1f5b:	shl    r8b,cl
  3a1f5e:	shr    r9,0x10
  3a1f62:	mov    DWORD PTR [rax+rcx*4],r9d
  3a1f66:	or     r8b,dil
  3a1f69:	mov    BYTE PTR [rax+0xc],r8b
  3a1f6d:	nop    DWORD PTR [rax]
  3a1f70:	blsr   r11,r11
  3a1f75:	je     3a292b <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xb3b>
  3a1f7b:	xor    edx,edx
  3a1f7d:	tzcnt  rdx,r11
  3a1f82:	movzx  r14d,BYTE PTR [r12+rdx*1+0xc00]
  3a1f8b:	cmp    r14d,0x8
  3a1f8f:	ja     3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a1f91:	shl    r14d,0x5
  3a1f95:	add    r14,rsi
  3a1f98:	movzx  ebp,BYTE PTR [r12+rdx*1+0xc40]
  3a1fa1:	mov    rax,rdx
  3a1fa4:	imul   rax,QWORD PTR [rsp+0x90]
  3a1fad:	mov    QWORD PTR [rsp-0x48],rax
  3a1fb2:	lea    r13,[rax+rbx*1]
  3a1fb6:	mov    eax,DWORD PTR [r12+rdx*4+0x300]
  3a1fbe:	mov    DWORD PTR [rsp-0x5c],eax
  3a1fc2:	mov    r8d,DWORD PTR [r12+rdx*4+0x400]
  3a1fca:	movzx  edi,BYTE PTR [r14]
  3a1fce:	xor    eax,eax
  3a1fd0:	test   bpl,0x8
  3a1fd4:	mov    BYTE PTR [rsp-0x71],dil
  3a1fd9:	je     3a26a6 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8b6>
  3a1fdf:	test   dil,dil
  3a1fe2:	je     3a26a6 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8b6>
  3a1fe8:	mov    rdi,QWORD PTR [r14+0x8]
  3a1fec:	mov    ecx,DWORD PTR [r12+rdx*4+0xb00]
  3a1ff4:	mov    QWORD PTR [rsp-0x10],rdi
  3a1ff9:	imul   rdi,r10
  3a1ffd:	cmp    r13,r15
  3a2000:	jae    3a20a0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x2b0>
  3a2006:	mov    rax,r13
  3a2009:	shl    rax,0x4
  3a200d:	mov    QWORD PTR [rsp-0x18],rcx
  3a2012:	movzx  ecx,BYTE PTR [rsp-0x7a]
  3a2017:	mov    r9,QWORD PTR [rsp-0x70]
  3a201c:	cmp    BYTE PTR [r9+rax*1+0xd],cl
  3a2021:	mov    rcx,QWORD PTR [rsp-0x18]
  3a2026:	jne    3a20a0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x2b0>
  3a2028:	add    rax,QWORD PTR [rsp-0x70]
  3a202d:	cmp    BYTE PTR [rax+0xc],0x0
  3a2031:	je     3a20a0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x2b0>
  3a2033:	mov    BYTE PTR [rsp-0x79],bpl
  3a2038:	mov    QWORD PTR [rsp-0x28],r13
  3a203d:	mov    DWORD PTR [rsp-0x78],r8d
  3a2042:	mov    QWORD PTR [rsp-0x30],rdi
  3a2047:	vmovdqa xmm4,XMMWORD PTR [rax]
  3a204b:	vmovdqa XMMWORD PTR [rsp+0x30],xmm4
  3a2051:	movzx  r9d,BYTE PTR [rsp+0x3c]
  3a2057:	test   r9b,r9b
  3a205a:	jne    3a2150 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x360>
  3a2060:	mov    rsi,QWORD PTR [rsp+0x18]
  3a2065:	mov    rbx,QWORD PTR [rsp+0x10]
  3a206a:	mov    r12,QWORD PTR [rsp+0x60]
  3a206f:	mov    r10,QWORD PTR [rsp-0x40]
  3a2074:	mov    r15,QWORD PTR [rsp-0x58]
  3a2079:	mov    rdi,QWORD PTR [rsp-0x30]
  3a207e:	mov    r8d,DWORD PTR [rsp-0x78]
  3a2083:	mov    r13,QWORD PTR [rsp-0x28]
  3a2088:	movzx  ebp,BYTE PTR [rsp-0x79]
  3a208d:	mov    rcx,QWORD PTR [rsp-0x18]
  3a2092:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  3a20a0:	add    rdi,rcx
  3a20a3:	test   bpl,0x1
  3a20a7:	mov    QWORD PTR [rsp-0x30],rdi
  3a20ac:	je     3a26a0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8b0>
  3a20b2:	cmp    rdi,r15
  3a20b5:	jae    3a26a0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8b0>
  3a20bb:	mov    rax,rdi
  3a20be:	shl    rax,0x4
  3a20c2:	movzx  ecx,BYTE PTR [rsp-0x7a]
  3a20c7:	mov    rdi,QWORD PTR [rsp-0x70]
  3a20cc:	cmp    BYTE PTR [rdi+rax*1+0xd],cl
  3a20d0:	jne    3a26a0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8b0>
  3a20d6:	add    rax,QWORD PTR [rsp-0x70]
  3a20db:	cmp    BYTE PTR [rax+0xc],0x0
  3a20df:	je     3a26a0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x8b0>
  3a20e5:	mov    BYTE PTR [rsp-0x79],bpl
  3a20ea:	mov    QWORD PTR [rsp-0x28],r13
  3a20ef:	mov    DWORD PTR [rsp-0x78],r8d
  3a20f4:	vmovdqa xmm4,XMMWORD PTR [rax]
  3a20f8:	vmovdqa XMMWORD PTR [rsp+0x30],xmm4
  3a20fe:	movzx  r8d,BYTE PTR [rsp+0x3c]
  3a2104:	test   r8b,r8b
  3a2107:	je     3a2674 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x884>
  3a210d:	mov    rax,QWORD PTR [rsp-0x48]
  3a2112:	add    rax,QWORD PTR [rsp+0x80]
  3a211a:	mov    QWORD PTR [rsp-0x48],rax
  3a211f:	jmp    3a2400 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x610>
  3a2124:	mov    BYTE PTR [rdi+0xc],0x0
  3a2128:	mov    al,0x1
  3a212a:	shl    al,cl
  3a212c:	mov    DWORD PTR [rdi+rcx*4],r10d
  3a2130:	or     BYTE PTR [rdi+0xc],al
  3a2133:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  3a2140:	lea    eax,[r9-0x1]
  3a2144:	and    al,r9b
  3a2147:	mov    r9d,eax
  3a214a:	je     3a2060 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x270>
  3a2150:	movzx  eax,r9b
  3a2154:	xor    ecx,ecx
  3a2156:	tzcnt  ecx,eax
  3a215a:	cmp    cl,0x3
  3a215d:	jae    3a2060 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x270>
  3a2163:	mov    r10d,DWORD PTR [rsp+rcx*4+0x30]
  3a2168:	mov    eax,r10d
  3a216b:	shr    eax,0x10
  3a216e:	movzx  r8d,r10w
  3a2172:	mov    rdi,QWORD PTR [rsp-0x8]
  3a2177:	andn   r15d,edi,eax
  3a217c:	mov    rdi,r15
  3a217f:	sub    rdi,QWORD PTR [rsp+0x70]
  3a2184:	mov    ebx,0x0
  3a2189:	cmovb  rdi,rbx
  3a218d:	mov    r12,r8
  3a2190:	sub    r12,QWORD PTR [rsp]
  3a2194:	jb     3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a2196:	imul   r12,QWORD PTR [rsp-0x38]
  3a219c:	add    r12,rax
  3a219f:	mov    r13,r12
  3a21a2:	imul   r13,QWORD PTR [rsp+0x28]
  3a21a8:	mov    rsi,QWORD PTR [rsp-0x10]
  3a21ad:	lea    rbx,[rsi+r13*1]
  3a21b1:	cmp    rbx,QWORD PTR [rsp-0x50]
  3a21b6:	jae    3a21ca <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x3da>
  3a21b8:	mov    rbp,QWORD PTR [rsp-0x68]
  3a21bd:	xor    esi,esi
  3a21bf:	cmp    si,WORD PTR [rbp+rbx*4+0x0]
  3a21c4:	jno    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a21ca:	add    r13,QWORD PTR [rsp-0x20]
  3a21cf:	cmp    r13,QWORD PTR [rsp-0x50]
  3a21d4:	jae    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a21da:	mov    rbp,QWORD PTR [rsp-0x68]
  3a21df:	movsx  ebp,WORD PTR [rbp+r13*4+0x0]
  3a21e5:	cmp    ebp,0xffff8000
  3a21eb:	je     3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a21f1:	add    ebp,DWORD PTR [rsp-0x5c]
  3a21f5:	cmp    ebp,0xfffff802
  3a21fb:	jge    3a2202 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x412>
  3a21fd:	mov    ebp,0xfffff801
  3a2202:	cmp    ebp,0x7ff
  3a2208:	jl     3a220f <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x41f>
  3a220a:	mov    ebp,0x7ff
  3a220f:	mov    rsi,QWORD PTR [rsp-0x68]
  3a2214:	movsx  r13d,WORD PTR [rsi+r13*4+0x2]
  3a221a:	add    r13d,DWORD PTR [rsp-0x78]
  3a221f:	cmp    r13d,0xfffff802
  3a2226:	jl     3a22a7 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x4b7>
  3a2228:	cmp    r13d,0x7ff
  3a222f:	jge    3a22ba <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x4ca>
  3a2235:	cmp    rbx,QWORD PTR [rsp-0x50]
  3a223a:	jae    3a224b <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x45b>
  3a223c:	mov    rsi,QWORD PTR [rsp-0x68]
  3a2241:	mov    WORD PTR [rsi+rbx*4],bp
  3a2245:	mov    WORD PTR [rsi+rbx*4+0x2],r13w
  3a224b:	mov    ebx,ebp
  3a224d:	neg    ebx
  3a224f:	cmovs  ebx,ebp
  3a2252:	mov    esi,r13d
  3a2255:	neg    esi
  3a2257:	cmovs  esi,r13d
  3a225b:	cmp    ebx,esi
  3a225d:	cmova  esi,ebx
  3a2260:	cmp    esi,0x40
  3a2263:	jae    3a22d0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x4e0>
  3a2265:	cmp    r12,QWORD PTR [rsp-0x40]
  3a226a:	jae    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a2270:	add    r12,QWORD PTR [rsp-0x30]
  3a2275:	cmp    r12,QWORD PTR [rsp-0x58]
  3a227a:	jae    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a2280:	shl    r12,0x4
  3a2284:	mov    rax,QWORD PTR [rsp-0x70]
  3a2289:	lea    rdi,[rax+r12*1]
  3a228d:	movzx  r8d,BYTE PTR [rsp-0x7a]
  3a2293:	cmp    BYTE PTR [rax+r12*1+0xd],r8b
  3a2298:	je     3a2128 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x338>
  3a229e:	mov    BYTE PTR [rdi+0xd],r8b
  3a22a2:	jmp    3a2124 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x334>
  3a22a7:	mov    r13d,0xfffff801
  3a22ad:	cmp    r13d,0x7ff
  3a22b4:	jl     3a2235 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x445>
  3a22ba:	mov    r13d,0x7ff
  3a22c0:	cmp    rbx,QWORD PTR [rsp-0x50]
  3a22c5:	jb     3a223c <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x44c>
  3a22cb:	jmp    3a224b <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x45b>
  3a22d0:	lea    esi,[rbp+0x3f]
  3a22d3:	test   ebp,ebp
  3a22d5:	cmovns esi,ebp
  3a22d8:	movsx  esi,si
  3a22db:	sar    esi,0x6
  3a22de:	add    esi,r8d
  3a22e1:	setns  bpl
  3a22e5:	mov    ebx,esi
  3a22e7:	cmp    QWORD PTR [rsp+0x58],rbx
  3a22ec:	seta   sil
  3a22f0:	and    sil,bpl
  3a22f3:	cmp    sil,0x1
  3a22f7:	jne    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a22fd:	lea    esi,[r13+0x3f]
  3a2301:	test   r13d,r13d
  3a2304:	cmovns esi,r13d
  3a2308:	movsx  esi,si
  3a230b:	sar    esi,0x6
  3a230e:	add    eax,esi
  3a2310:	setns  sil
  3a2314:	mov    eax,eax
  3a2316:	cmp    QWORD PTR [rsp-0x38],rax
  3a231b:	seta   bpl
  3a231f:	and    bpl,sil
  3a2322:	cmp    bpl,0x1
  3a2326:	jne    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a232c:	mov    rsi,QWORD PTR [rsp-0x8]
  3a2331:	andn   esi,esi,r8d
  3a2336:	mov    r8,QWORD PTR [rsp+0x50]
  3a233b:	lea    r12,[rsi+r8*1]
  3a233f:	add    r15,QWORD PTR [rsp+0x68]
  3a2344:	mov    r13,QWORD PTR [rsp+0x8]
  3a2349:	andn   r8,r13,rbx
  3a234e:	andn   rax,r13,rax
  3a2353:	cmp    r8,rsi
  3a2356:	setb   sil
  3a235a:	cmp    r8,r12
  3a235d:	setae  bl
  3a2360:	cmp    rax,rdi
  3a2363:	setb   dil
  3a2367:	or     dil,sil
  3a236a:	cmp    rax,r15
  3a236d:	setae  sil
  3a2371:	or     sil,bl
  3a2374:	or     sil,dil
  3a2377:	sub    r8,QWORD PTR [rsp]
  3a237b:	setb   dil
  3a237f:	or     dil,sil
  3a2382:	jne    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a2388:	imul   r8,QWORD PTR [rsp-0x38]
  3a238e:	add    rax,r8
  3a2391:	cmp    rax,QWORD PTR [rsp-0x40]
  3a2396:	jae    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a239c:	add    rax,QWORD PTR [rsp-0x30]
  3a23a1:	cmp    rax,QWORD PTR [rsp-0x58]
  3a23a6:	jae    3a2140 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x350>
  3a23ac:	shl    rax,0x4
  3a23b0:	mov    r8,QWORD PTR [rsp-0x70]
  3a23b5:	lea    rdi,[r8+rax*1]
  3a23b9:	movzx  ebx,BYTE PTR [rsp-0x7a]
  3a23be:	cmp    BYTE PTR [r8+rax*1+0xd],bl
  3a23c3:	je     3a2128 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x338>
  3a23c9:	mov    BYTE PTR [rdi+0xd],bl
  3a23cc:	jmp    3a2124 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x334>
  3a23d1:	mov    BYTE PTR [rax+0xd],dil
  3a23d5:	mov    BYTE PTR [rax+0xc],0x0
  3a23d9:	mov    sil,0x1
  3a23dc:	shl    sil,cl
  3a23df:	mov    DWORD PTR [rax+rcx*4],r12d
  3a23e3:	or     BYTE PTR [rax+0xc],sil
  3a23e7:	nop    WORD PTR [rax+rax*1+0x0]
  3a23f0:	lea    eax,[r8-0x1]
  3a23f4:	and    al,r8b
  3a23f7:	mov    r8d,eax
  3a23fa:	je     3a2674 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x884>
  3a2400:	movzx  eax,r8b
  3a2404:	xor    ecx,ecx
  3a2406:	tzcnt  ecx,eax
  3a240a:	cmp    cl,0x3
  3a240d:	jae    3a2674 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x884>
  3a2413:	mov    r12d,DWORD PTR [rsp+rcx*4+0x30]
  3a2418:	mov    r9d,r12d
  3a241b:	shr    r9d,0x10
  3a241f:	movzx  r15d,r12w
  3a2423:	mov    rax,QWORD PTR [rsp-0x8]
  3a2428:	andn   edi,eax,r9d
  3a242d:	mov    rsi,rdi
  3a2430:	sub    rsi,QWORD PTR [rsp+0x70]
  3a2435:	mov    eax,0x0
  3a243a:	cmovae rax,rsi
  3a243e:	mov    r10,r15
  3a2441:	sub    r10,QWORD PTR [rsp]
  3a2445:	jb     3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a2447:	cmp    QWORD PTR [rsp-0x48],rax
  3a244c:	jb     3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a244e:	add    rdi,QWORD PTR [rsp+0x68]
  3a2453:	cmp    QWORD PTR [rsp-0x48],rdi
  3a2458:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a245a:	imul   r10,QWORD PTR [rsp-0x38]
  3a2460:	add    r10,r9
  3a2463:	mov    r13,r10
  3a2466:	imul   r13,QWORD PTR [rsp+0x28]
  3a246c:	mov    rsi,QWORD PTR [rsp-0x20]
  3a2471:	lea    rbx,[rsi+r13*1]
  3a2475:	cmp    rbx,QWORD PTR [rsp-0x50]
  3a247a:	jae    3a248d <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x69d>
  3a247c:	mov    rsi,QWORD PTR [rsp-0x68]
  3a2481:	xor    ebp,ebp
  3a2483:	cmp    bp,WORD PTR [rsi+rbx*4]
  3a2487:	jno    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a248d:	add    r13,QWORD PTR [rsp-0x10]
  3a2492:	cmp    r13,QWORD PTR [rsp-0x50]
  3a2497:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a249d:	mov    rsi,QWORD PTR [rsp-0x68]
  3a24a2:	movsx  ebp,WORD PTR [rsi+r13*4]
  3a24a7:	cmp    ebp,0xffff8000
  3a24ad:	je     3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a24b3:	sub    ebp,DWORD PTR [rsp-0x5c]
  3a24b7:	cmp    ebp,0xfffff802
  3a24bd:	jge    3a24c4 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x6d4>
  3a24bf:	mov    ebp,0xfffff801
  3a24c4:	cmp    ebp,0x7ff
  3a24ca:	jl     3a24d1 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x6e1>
  3a24cc:	mov    ebp,0x7ff
  3a24d1:	mov    rsi,QWORD PTR [rsp-0x68]
  3a24d6:	movsx  r13d,WORD PTR [rsi+r13*4+0x2]
  3a24dc:	sub    r13d,DWORD PTR [rsp-0x78]
  3a24e1:	cmp    r13d,0xfffff802
  3a24e8:	jl     3a2560 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x770>
  3a24ea:	cmp    r13d,0x7ff
  3a24f1:	jge    3a256f <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x77f>
  3a24f3:	cmp    rbx,QWORD PTR [rsp-0x50]
  3a24f8:	jae    3a2509 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x719>
  3a24fa:	mov    rsi,QWORD PTR [rsp-0x68]
  3a24ff:	mov    WORD PTR [rsi+rbx*4],bp
  3a2503:	mov    WORD PTR [rsi+rbx*4+0x2],r13w
  3a2509:	mov    esi,ebp
  3a250b:	neg    esi
  3a250d:	cmovs  esi,ebp
  3a2510:	mov    ebx,r13d
  3a2513:	neg    ebx
  3a2515:	cmovs  ebx,r13d
  3a2519:	cmp    esi,ebx
  3a251b:	cmova  ebx,esi
  3a251e:	cmp    ebx,0x40
  3a2521:	jae    3a2582 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x792>
  3a2523:	cmp    r10,QWORD PTR [rsp-0x40]
  3a2528:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a252e:	add    r10,QWORD PTR [rsp+0x48]
  3a2533:	cmp    r10,QWORD PTR [rsp-0x58]
  3a2538:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a253e:	shl    r10,0x4
  3a2542:	mov    rsi,QWORD PTR [rsp-0x70]
  3a2547:	lea    rax,[rsi+r10*1]
  3a254b:	movzx  edi,BYTE PTR [rsp-0x7a]
  3a2550:	cmp    BYTE PTR [rsi+r10*1+0xd],dil
  3a2555:	jne    3a23d1 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5e1>
  3a255b:	jmp    3a23d9 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5e9>
  3a2560:	mov    r13d,0xfffff801
  3a2566:	cmp    r13d,0x7ff
  3a256d:	jl     3a24f3 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x703>
  3a256f:	mov    r13d,0x7ff
  3a2575:	cmp    rbx,QWORD PTR [rsp-0x50]
  3a257a:	jb     3a24fa <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x70a>
  3a2580:	jmp    3a2509 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x719>
  3a2582:	lea    esi,[rbp+0x3f]
  3a2585:	test   ebp,ebp
  3a2587:	cmovns esi,ebp
  3a258a:	movsx  esi,si
  3a258d:	sar    esi,0x6
  3a2590:	add    esi,r15d
  3a2593:	setns  bl
  3a2596:	mov    r10d,esi
  3a2599:	cmp    QWORD PTR [rsp+0x58],r10
  3a259e:	seta   sil
  3a25a2:	and    sil,bl
  3a25a5:	cmp    sil,0x1
  3a25a9:	jne    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a25af:	lea    esi,[r13+0x3f]
  3a25b3:	test   r13d,r13d
  3a25b6:	cmovns esi,r13d
  3a25ba:	movsx  esi,si
  3a25bd:	sar    esi,0x6
  3a25c0:	add    r9d,esi
  3a25c3:	setns  sil
  3a25c7:	mov    r9d,r9d
  3a25ca:	cmp    QWORD PTR [rsp-0x38],r9
  3a25cf:	seta   bl
  3a25d2:	and    bl,sil
  3a25d5:	cmp    bl,0x1
  3a25d8:	jne    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a25de:	mov    rsi,QWORD PTR [rsp+0x8]
  3a25e3:	andn   r9d,esi,r9d
  3a25e8:	cmp    r9,rdi
  3a25eb:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a25f1:	mov    rsi,QWORD PTR [rsp-0x8]
  3a25f6:	andn   ebx,esi,r15d
  3a25fb:	mov    rsi,QWORD PTR [rsp+0x8]
  3a2600:	andn   edi,esi,r10d
  3a2605:	cmp    edi,ebx
  3a2607:	jb     3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a260d:	add    rbx,QWORD PTR [rsp+0x50]
  3a2612:	cmp    rdi,rbx
  3a2615:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a261b:	cmp    r9,rax
  3a261e:	jb     3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a2624:	sub    rdi,QWORD PTR [rsp]
  3a2628:	jb     3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a262e:	imul   rdi,QWORD PTR [rsp-0x38]
  3a2634:	add    r9,rdi
  3a2637:	cmp    r9,QWORD PTR [rsp-0x40]
  3a263c:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a2642:	add    r9,QWORD PTR [rsp+0x48]
  3a2647:	cmp    r9,QWORD PTR [rsp-0x58]
  3a264c:	jae    3a23f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x600>
  3a2652:	shl    r9,0x4
  3a2656:	mov    rsi,QWORD PTR [rsp-0x70]
  3a265b:	lea    rax,[rsi+r9*1]
  3a265f:	movzx  edi,BYTE PTR [rsp-0x7a]
  3a2664:	cmp    BYTE PTR [rsi+r9*1+0xd],dil
  3a2669:	jne    3a23d1 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5e1>
  3a266f:	jmp    3a23d9 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x5e9>
  3a2674:	mov    rsi,QWORD PTR [rsp+0x18]
  3a2679:	mov    rbx,QWORD PTR [rsp+0x10]
  3a267e:	mov    r12,QWORD PTR [rsp+0x60]
  3a2683:	mov    r10,QWORD PTR [rsp-0x40]
  3a2688:	mov    r15,QWORD PTR [rsp-0x58]
  3a268d:	mov    r8d,DWORD PTR [rsp-0x78]
  3a2692:	mov    r13,QWORD PTR [rsp-0x28]
  3a2697:	movzx  ebp,BYTE PTR [rsp-0x79]
  3a269c:	nop    DWORD PTR [rax+0x0]
  3a26a0:	mov    eax,ebp
  3a26a2:	and    al,0x2
  3a26a4:	shr    al,1
  3a26a6:	test   bpl,0x4
  3a26aa:	je     3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a26b0:	mov    ecx,DWORD PTR [r12+rdx*4+0x900]
  3a26b8:	cmp    QWORD PTR [rsp+0x88],rcx
  3a26c0:	jbe    3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a26c6:	mov    rdi,QWORD PTR [rsp+0x20]
  3a26cb:	cmp    BYTE PTR [rdi+rcx*8+0x6],0x0
  3a26d0:	je     3a26f5 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x905>
  3a26d2:	cmp    BYTE PTR [r14+0x1b],0x1
  3a26d7:	jne    3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a26dd:	mov    rdi,QWORD PTR [rsp+0x20]
  3a26e2:	movsx  edi,WORD PTR [rdi+rcx*8]
  3a26e6:	mov    r9d,DWORD PTR [r14+0x10]
  3a26ea:	cmp    r9d,edi
  3a26ed:	je     3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a26f3:	jmp    3a26f9 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x909>
  3a26f5:	mov    r9d,DWORD PTR [r14+0x10]
  3a26f9:	mov    DWORD PTR [rsp-0x78],r8d
  3a26fe:	mov    r15,r10
  3a2701:	mov    r10,rbx
  3a2704:	mov    ebx,ebp
  3a2706:	mov    ebp,DWORD PTR [rsp-0x5c]
  3a270a:	mov    edi,ebp
  3a270c:	neg    edi
  3a270e:	mov    r8d,DWORD PTR [rsp-0x78]
  3a2713:	neg    r8d
  3a2716:	cmp    BYTE PTR [r14+0x1a],0x0
  3a271b:	cmove  edi,ebp
  3a271e:	mov    ebp,DWORD PTR [rsp-0x78]
  3a2722:	cmove  r8d,ebp
  3a2726:	shl    r8d,0x10
  3a272a:	movzx  edi,di
  3a272d:	or     edi,r8d
  3a2730:	mov    r8,QWORD PTR [rsp+0x20]
  3a2735:	mov    WORD PTR [r8+rcx*8],r9w
  3a273a:	mov    DWORD PTR [r8+rcx*8+0x2],edi
  3a273f:	mov    BYTE PTR [r8+rcx*8+0x6],0x1
  3a2745:	test   bl,0x10
  3a2748:	mov    rbx,r10
  3a274b:	mov    r10,r15
  3a274e:	mov    r15,QWORD PTR [rsp-0x58]
  3a2753:	je     3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a2759:	mov    edi,DWORD PTR [r12+rdx*4+0xa00]
  3a2761:	cmp    r10,rdi
  3a2764:	jbe    3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a276a:	mov    ecx,DWORD PTR [r12+rdx*4+0x500]
  3a2772:	mov    DWORD PTR [rsp-0x18],ecx
  3a2776:	mov    ecx,DWORD PTR [r12+rdx*4+0x600]
  3a277e:	mov    DWORD PTR [rsp-0x28],ecx
  3a2782:	mov    rcx,QWORD PTR [r14+0x8]
  3a2786:	mov    QWORD PTR [rsp-0x10],rcx
  3a278b:	movsxd rcx,DWORD PTR [r12+rdx*4+0x800]
  3a2793:	mov    r9d,DWORD PTR [r12+rdx*4+0x700]
  3a279b:	mov    rdx,QWORD PTR [rsp+0x78]
  3a27a0:	shrx   rdx,rcx,rdx
  3a27a5:	movabs r8,0xaaaaaaaaaaaaaaab
  3a27af:	mulx   r8,r8,r8
  3a27b4:	shr    r8,1
  3a27b7:	lea    r8,[r8+r8*2]
  3a27bb:	sub    rdx,r8
  3a27be:	mov    QWORD PTR [rsp-0x48],rdx
  3a27c3:	mov    r8d,r9d
  3a27c6:	or     r8d,ecx
  3a27c9:	shl    rcx,0x20
  3a27cd:	shl    r9,0x10
  3a27d1:	add    r9,rcx
  3a27d4:	cmp    r8d,0xffff
  3a27db:	ja     3a2848 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa58>
  3a27dd:	cmp    r13,r15
  3a27e0:	jae    3a2848 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa58>
  3a27e2:	shl    r13,0x4
  3a27e6:	mov    rdx,QWORD PTR [rsp-0x70]
  3a27eb:	lea    rbx,[rdx+r13*1]
  3a27ef:	movzx  ecx,BYTE PTR [rsp-0x7a]
  3a27f4:	cmp    BYTE PTR [rdx+r13*1+0xd],cl
  3a27f9:	jne    3a2807 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa17>
  3a27fb:	mov    rdx,r10
  3a27fe:	mov    r10,r12
  3a2801:	movzx  ebp,BYTE PTR [rbx+0xc]
  3a2805:	jmp    3a2812 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa22>
  3a2807:	mov    rdx,r10
  3a280a:	mov    r10,r12
  3a280d:	mov    BYTE PTR [rbx+0xd],cl
  3a2810:	xor    ebp,ebp
  3a2812:	mov    r12,r9
  3a2815:	mov    r13b,0x1
  3a2818:	mov    rcx,QWORD PTR [rsp-0x48]
  3a281d:	shl    r13b,cl
  3a2820:	shr    r12,0x10
  3a2824:	mov    DWORD PTR [rbx+rcx*4],r12d
  3a2828:	or     r13b,bpl
  3a282b:	mov    BYTE PTR [rbx+0xc],r13b
  3a282f:	mov    rsi,QWORD PTR [rsp+0x18]
  3a2834:	mov    rbx,QWORD PTR [rsp+0x10]
  3a2839:	mov    r12,r10
  3a283c:	mov    r10,rdx
  3a283f:	mov    r15,QWORD PTR [rsp-0x58]
  3a2844:	mov    ebp,DWORD PTR [rsp-0x78]
  3a2848:	imul   rdi,QWORD PTR [rsp+0x28]
  3a284e:	mov    rcx,QWORD PTR [rsp-0x20]
  3a2853:	lea    rdx,[rdi+rcx*1]
  3a2857:	cmp    rdx,QWORD PTR [rsp-0x50]
  3a285c:	jae    3a2889 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xa99>
  3a285e:	vmovd  xmm4,DWORD PTR [rsp-0x18]
  3a2864:	vpinsrd xmm4,xmm4,DWORD PTR [rsp-0x28],0x1
  3a286c:	vpsubd xmm4,xmm0,xmm4
  3a2870:	vpmaxsd xmm4,xmm4,xmm1
  3a2875:	vpminsd xmm4,xmm4,xmm2
  3a287a:	vpshuflw xmm4,xmm4,0xe8
  3a287f:	mov    rcx,QWORD PTR [rsp-0x68]
  3a2884:	vmovd  DWORD PTR [rcx+rdx*4],xmm4
  3a2889:	cmp    BYTE PTR [rsp-0x71],0x0
  3a288e:	je     3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a2894:	add    rdi,QWORD PTR [rsp-0x10]
  3a2899:	cmp    rdi,QWORD PTR [rsp-0x50]
  3a289e:	jae    3a28e2 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0xaf2>
  3a28a0:	vmovd  xmm4,DWORD PTR [rsp-0x5c]
  3a28a6:	vpinsrd xmm4,xmm4,ebp,0x1
  3a28ac:	vpbroadcastd xmm5,DWORD PTR [r14+0x14]
  3a28b2:	vpmulld xmm4,xmm5,xmm4
  3a28b7:	vpsrad xmm5,xmm4,0x1f
  3a28bc:	vpaddd xmm4,xmm4,xmm3
  3a28c0:	vpaddd xmm4,xmm4,xmm5
  3a28c4:	vpsrad xmm4,xmm4,0xe
  3a28c9:	vpmaxsd xmm4,xmm4,xmm1
  3a28ce:	vpminsd xmm4,xmm4,xmm2
  3a28d3:	vpshuflw xmm4,xmm4,0xe8
  3a28d8:	mov    rcx,QWORD PTR [rsp-0x68]
  3a28dd:	vmovd  DWORD PTR [rcx+rdi*4],xmm4
  3a28e2:	cmp    r8d,0x10000
  3a28e9:	setae  cl
  3a28ec:	xor    al,0x1
  3a28ee:	or     al,cl
  3a28f0:	jne    3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a28f6:	cmp    QWORD PTR [rsp-0x30],r15
  3a28fb:	jae    3a1f70 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x180>
  3a2901:	mov    rdx,QWORD PTR [rsp-0x30]
  3a2906:	shl    rdx,0x4
  3a290a:	mov    rdi,QWORD PTR [rsp-0x70]
  3a290f:	lea    rax,[rdi+rdx*1]
  3a2913:	movzx  ecx,BYTE PTR [rsp-0x7a]
  3a2918:	cmp    BYTE PTR [rdi+rdx*1+0xd],cl
  3a291c:	jne    3a1f4e <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x15e>
  3a2922:	movzx  edi,BYTE PTR [rax+0xc]
  3a2926:	jmp    3a1f53 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb1_EBg_+0x163>
  3a292b:	add    rsp,0x98
  3a2932:	pop    rbx
  3a2933:	pop    r12
  3a2935:	pop    r13
  3a2937:	pop    r14
  3a2939:	pop    r15
  3a293b:	pop    rbp
  3a293c:	ret
