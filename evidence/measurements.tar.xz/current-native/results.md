# Noise_Ocean after the TIP fix

One-millisecond native gprofng CPU samples, 130 frames, CPU 3, one worker, frame delay one, null output. Pair order alternates. All three binaries matched the full 130-frame hash output.

The merged binary is the exact symbolized 7c50c1b4 build. Shipped is the same-SHA symbolized 10279846 rebuild. Its .text is 272 bytes larger than the distributed binary; the earlier study verified five hotspot instruction shapes and decoded frame hashes. The merged revision also includes upstream changes.

A gross outlier has more than three times its variant median wall or sampled CPU time, or at least 35% of sampled CPU on two PCs. We also excluded one transient scheduling capture after inspecting its PC data. Exclusion applies to the whole pair. Pair 4 replaced pair 3.

| Pair | Shipped wall s | Merged wall s | Shipped CPU ms | Merged CPU ms | Top-two PC share, shipped/merged | Status |
|---:|---:|---:|---:|---:|---:|---|
| 1 | 0.780 | 0.944 | 778 | 943 | 3.9% / 3.1% | Accepted |
| 2 | 0.775 | 0.948 | 774 | 946 | 4.5% / 3.5% | Accepted |
| 3 | 1.116 | 0.948 | 1036 | 945 | 26.5% / 3.2% | shipped-symbols scheduling entry concentration |
| 4 | 0.780 | 0.941 | 778 | 939 | 3.7% / 3.0% | Accepted |

The shipped capture in pair 3 assigned 259 ms to the entry instruction of `charge_emitted_outputs`. This instruction has no samples in the other shipped captures. The temporal row below includes both shipped's separate lane-preparation symbols and the merged scan's inlined preparation.

Mean sampled gap +166.0 ms, median paired CPU change +21.21%.

## Exclusive CPU stages

| Group | Shipped mean ms | Merged mean ms | Mean delta ms | Paired deltas ms |
|---|---:|---:|---:|---|
| Filters | 362.7 | 466.7 | +104.0 | +112, +106, +94 |
| Motion/prediction | 283.3 | 328.3 | +45.0 | +46, +52, +37 |
| Output/scheduling/frame setup | 10.3 | 18.0 | +7.7 | -3, +14, +12 |
| Transforms/residual math | 16.7 | 24.0 | +7.3 | +12, +3, +7 |
| Entropy/parser | 41.0 | 46.0 | +5.0 | +6, +10, -1 |
| Uncategorized/shared | 8.7 | 7.3 | -1.3 | -4, -5, +5 |
| Memory/allocator functions | 54.0 | 52.3 | -1.7 | -4, -8, +7 |

## Filter subgroups

| Group | Shipped mean ms | Merged mean ms | Mean delta ms | Paired deltas ms |
|---|---:|---:|---:|---|
| CDEF | 162.7 | 234.0 | +71.3 | +67, +62, +85 |
| GDF | 68.7 | 86.0 | +17.3 | +22, +15, +15 |
| Restoration/classification | 95.3 | 108.7 | +13.3 | +8, +28, +4 |
| Filter staging/shared | 14.3 | 15.7 | +1.3 | +5, -1, +0 |
| Deblock | 21.7 | 22.3 | +0.7 | +10, +2, -10 |
| CCSO | 0.0 | 0.0 | +0.0 | +0, +0, +0 |

## Matched stack-attributed kernels

| Group | Shipped mean ms | Merged mean ms | Mean delta ms | Paired deltas ms |
|---|---:|---:|---:|---|
| Temporal motion-field projection | 99.3 | 120.7 | +21.3 | +22, +24, +18 |
| CDEF segment filter | 93.7 | 115.0 | +21.3 | +5, +31, +28 |
| CDEF packed chroma gather | 11.0 | 22.3 | +11.3 | +15, +5, +14 |
| Coefficient high-frequency pass | 16.0 | 23.7 | +7.7 | +3, +9, +11 |
| Luma Wiener filter | 52.0 | 55.3 | +3.3 | -7, +11, +6 |
| TIP motion-field units | 19.3 | 12.7 | -6.7 | -5, -3, -12 |

## Shipped top exclusive symbols

   64.3 ms  splot_recon::cdef_filter::segment::cdef_filter_segment_with::<splot_core::simd::Avx2Backend, u8>
   61.3 ms  <splot_decode::prediction::inter::find_mv_stack::temporal::scan::ChunkWalk>::project_tracked::<true>
   52.7 ms  <static>@0x197030 (<libc.so.6>)
   48.3 ms  splot_recon::wienerns_filter::wiener_ns_filter_luma_block_padded_layout_into::<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8>
   22.3 ms  splot_decode::prediction::inter::find_mv_stack::temporal::scan::chunk_lanes::<fearless_simd::generated::avx2::Avx2, true>
   20.3 ms  splot_decode::filters::gdf::simd::inlane::row_index::<splot_decode::filters::gdf::simd::TiledWindow, 0, false, true>
   19.3 ms  splot_decode::prediction::inter::find_mv_stack::temporal::tip_field::prepare_tip_units::<fearless_simd::generated::avx2::Avx2, 1, 1>
   17.0 ms  splot_recon::pc_wiener::classify_grid_from_cache::<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, splot_recon::pc_wiener::classify_grid_padded_mapped_into<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, splot_recon::pc_wiener::classify_grid_padded_classes_with_backend<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, <splot_decode::filters::wienerns_lr::recon::StripeChain>::luma_lr_cell_subclasses<splot_core::simd::Avx2Backend, u8>::{closure#7}::{closure#0}>::{closure#1}, u8>::{closure#0}, splot_recon::pc_wiener::classify_grid_padded_classes_with_backend<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend>, u8, <splot_decode::filters::wienerns_lr::recon::StripeChain>::luma_lr_cell_subclasses<splot_core::simd::Avx2Backend, u8>::{closure#7}::{closure#0}>::{closure#1}, u8>::{closure#5}
   16.0 ms  <splot_decode::bitstream::tile_payload::coeff_loop::transform_block::LevelPass>::hf_pass::<0, true, true, false>
   15.3 ms  splot_decode::filters::cdef::cdef_segment::<splot_core::simd::Avx2Backend, u8>
   15.3 ms  splot_decode::filters::gdf::simd::inlane::row_index::<splot_decode::filters::gdf::simd::TiledWindow, 1, false, true>
   14.7 ms  <splot_recon::cdef_filter::segment::TypedSegment<splot_core::simd::Avx2Backend> as splot_recon::cdef_filter::segment::SegmentSimd>::gather::<[[u16; 2]; 4], splot_recon::cdef_filter::segment::luma_bytes::LumaBytesGather>
   13.0 ms  splot_decode::prediction::inter::mc::compound_mask::blend_plane::<splot_core::simd::Avx2Backend, u8>
   12.7 ms  splot_recon::subpel_mc::eight_bit::avx2::strip_block::<0, 0, splot_recon::subpel_mc::rows::Prep<i16>>
   12.7 ms  <splot_decode::filters::wienerns_lr::recon::StripeChain>::apply_lr_stripe::<splot_core::simd::Avx2Backend, u8>

## Merged top exclusive symbols

   74.3 ms  <splot_decode::prediction::inter::find_mv_stack::temporal::scan::ChunkWalk>::project_tracked::<true>
   56.0 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_recon::cdef_filter::segment::cdef_filter_segment_with<splot_core::simd::Avx2Backend, u8>::{closure#0}, bool>
   53.7 ms  <static>@0x197030 (<libc.so.6>)
   28.7 ms  splot_recon::wienerns_filter::eight_bit::avx2::filter_row::__fearless_simd_kernel
   23.7 ms  <splot_decode::bitstream::tile_payload::coeff_loop::transform_block::LevelPass>::hf_pass::<0, true, true, false>
   23.0 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::filters::gdf::simd::inlane::row_index<splot_decode::filters::gdf::simd::TiledWindow, 1, false, true>::{closure#0}, [u16; 16]>
   22.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::filters::gdf::simd::inlane::row_index<splot_decode::filters::gdf::simd::TiledWindow, 0, false, true>::{closure#0}, [u16; 16]>
   21.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::prediction::inter::find_mv_stack::temporal::scan::project_temporal_motion_field<splot_core::simd::Avx2Backend, splot_decode::prediction::inter::find_mv_stack::temporal::TemporalMotionField>::{closure#2}, ()>
   20.3 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<splot_decode::filters::gdf::simd::filter_run<splot_core::simd::Avx2Backend, u8>::{closure#0}, core::option::Option<()>>
   18.3 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<<splot_recon::lr_madd::TypedLr<splot_core::simd::Avx2Backend> as splot_recon::lr_madd::LrBackend>::run<(), splot_recon::pc_wiener::PooledLanesOp<u8, 34>>::{closure#0}, ()>
   18.3 ms  splot_recon::subpel_mc::eight_bit::copy
   16.7 ms  splot_decode::filters::cdef::cdef_segment::<splot_core::simd::Avx2Backend, u8>
   16.7 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx2::<<splot_recon::cdef_filter::segment::TypedSegment<splot_core::simd::Avx2Backend> as splot_recon::cdef_filter::segment::SegmentSimd>::gather<[u16; 4], splot_recon::cdef_filter::segment::PairGather<u8, true>>::{closure#0}, core::option::Option<[u16; 4]>>
   15.3 ms  <splot_decode::prediction::inter::find_mv_stack::temporal::scan::ChunkWalk>::project_tracked::<false>
   15.0 ms  <fearless_simd::generated::avx2::Avx2 as fearless_simd::generated::simd_trait::Simd>::split_i32x8::kernel::__fearless_simd_kernel

Each sample is counted once per attribution table. Stage and kernel tables overlap. Three pairs describe sample variability but do not establish a stable confidence interval. Raw experiments, PC samples, and per-capture duration remain available.
