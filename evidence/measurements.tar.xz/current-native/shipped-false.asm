
../native-stacks/ref-target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

00000000003a19f0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_>:
  3a19f0:	push   rbp
  3a19f1:	push   r15
  3a19f3:	push   r14
  3a19f5:	push   r13
  3a19f7:	push   r12
  3a19f9:	push   rbx
  3a19fa:	push   rax
  3a19fb:	movabs rax,0x7fffffffffffffff
  3a1a05:	mov    QWORD PTR [rsp-0x38],rax
  3a1a0a:	mov    rax,QWORD PTR [rsi+0x130]
  3a1a11:	mov    QWORD PTR [rsp-0x30],rax
  3a1a16:	mov    rax,QWORD PTR [rdi+0x10]
  3a1a1a:	sub    rax,QWORD PTR [rdx+0x30]
  3a1a1e:	jb     3a1a40 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x50>
  3a1a20:	imul   rax,QWORD PTR [rdx+0x58]
  3a1a25:	mov    r8,QWORD PTR [rdx+0x28]
  3a1a29:	cmp    rax,r8
  3a1a2c:	jae    3a1a40 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x50>
  3a1a2e:	add    rax,QWORD PTR [rdi+0x18]
  3a1a32:	imul   r8,QWORD PTR [rsp-0x30]
  3a1a38:	add    r8,rax
  3a1a3b:	mov    QWORD PTR [rsp-0x38],r8
  3a1a40:	mov    r9,QWORD PTR [rdi+0x8]
  3a1a44:	test   r9,r9
  3a1a47:	je     3a1ddb <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x3eb>
  3a1a4d:	mov    r10,QWORD PTR [rdi]
  3a1a50:	mov    rax,QWORD PTR [rdi+0x20]
  3a1a54:	mov    QWORD PTR [rsp-0x18],rax
  3a1a59:	mov    r11,QWORD PTR [rdx+0x28]
  3a1a5d:	mov    rax,QWORD PTR [rcx]
  3a1a60:	mov    QWORD PTR [rsp-0x70],rax
  3a1a65:	mov    rax,QWORD PTR [rcx+0x8]
  3a1a69:	mov    QWORD PTR [rsp],rax
  3a1a6d:	mov    eax,DWORD PTR [rdx+0x68]
  3a1a70:	and    eax,0x3f
  3a1a73:	mov    QWORD PTR [rsp-0x8],rax
  3a1a78:	movzx  eax,BYTE PTR [rdx+0x6c]
  3a1a7c:	mov    BYTE PTR [rsp-0x7d],al
  3a1a80:	mov    rax,QWORD PTR [rdx+0x18]
  3a1a84:	mov    QWORD PTR [rsp-0x48],rax
  3a1a89:	mov    rax,QWORD PTR [rdx+0x10]
  3a1a8d:	mov    QWORD PTR [rsp-0x50],rax
  3a1a92:	mov    rax,QWORD PTR [rdx]
  3a1a95:	mov    QWORD PTR [rsp-0x58],rax
  3a1a9a:	mov    rax,QWORD PTR [rdx+0x8]
  3a1a9e:	mov    QWORD PTR [rsp-0x40],rax
  3a1aa3:	mov    rax,QWORD PTR [rdx+0x20]
  3a1aa7:	mov    QWORD PTR [rsp-0x10],rax
  3a1aac:	vpxor  xmm0,xmm0,xmm0
  3a1ab0:	vpbroadcastd xmm1,DWORD PTR [rip+0xffffffffffc7b357]        # 1ce10 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xdd0>
  3a1ab9:	vpbroadcastd xmm2,DWORD PTR [rip+0xffffffffffc7b2ce]        # 1cd90 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xd50>
  3a1ac2:	vpbroadcastd xmm3,DWORD PTR [rip+0xffffffffffc7b72d]        # 1d1f8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x198>
  3a1acb:	mov    QWORD PTR [rsp-0x78],r11
  3a1ad0:	jmp    3a1b0b <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x11b>
  3a1ad2:	mov    BYTE PTR [rax+0xd],cl
  3a1ad5:	xor    edx,edx
  3a1ad7:	mov    dil,0x1
  3a1ada:	mov    rcx,r8
  3a1add:	shl    dil,cl
  3a1ae0:	mov    r8,QWORD PTR [rsp-0x60]
  3a1ae5:	shr    r8,0x10
  3a1ae9:	mov    DWORD PTR [rax+rcx*4],r8d
  3a1aed:	or     dil,dl
  3a1af0:	mov    BYTE PTR [rax+0xc],dil
  3a1af4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  3a1b00:	blsr   r9,r9
  3a1b05:	je     3a1ddb <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x3eb>
  3a1b0b:	xor    ecx,ecx
  3a1b0d:	tzcnt  rcx,r9
  3a1b12:	movzx  r12d,BYTE PTR [r10+rcx*1+0xc00]
  3a1b1b:	cmp    r12d,0x8
  3a1b1f:	ja     3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1b21:	shl    r12d,0x5
  3a1b25:	add    r12,rsi
  3a1b28:	movzx  edx,BYTE PTR [r10+rcx*1+0xc40]
  3a1b31:	movzx  edi,BYTE PTR [r12]
  3a1b36:	mov    r13d,edx
  3a1b39:	and    r13b,0xa
  3a1b3d:	cmp    r13b,0xa
  3a1b41:	jne    3a1b5c <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x16c>
  3a1b43:	test   dil,dil
  3a1b46:	je     3a1b5c <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x16c>
  3a1b48:	mov    rax,QWORD PTR [r12+0x8]
  3a1b4d:	imul   rax,r11
  3a1b51:	mov    ebp,DWORD PTR [r10+rcx*4+0xb00]
  3a1b59:	add    rbp,rax
  3a1b5c:	test   dl,0x4
  3a1b5f:	je     3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1b61:	mov    r15d,DWORD PTR [r10+rcx*4+0x900]
  3a1b69:	cmp    QWORD PTR [rsp],r15
  3a1b6d:	jbe    3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1b6f:	mov    eax,DWORD PTR [r10+rcx*4+0x300]
  3a1b77:	mov    DWORD PTR [rsp-0x7c],eax
  3a1b7b:	mov    ebx,DWORD PTR [r10+rcx*4+0x400]
  3a1b83:	mov    rax,QWORD PTR [rsp-0x70]
  3a1b88:	cmp    BYTE PTR [rax+r15*8+0x6],0x0
  3a1b8e:	je     3a1bbb <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x1cb>
  3a1b90:	cmp    BYTE PTR [r12+0x1b],0x1
  3a1b96:	jne    3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1b9c:	mov    rax,QWORD PTR [rsp-0x70]
  3a1ba1:	movsx  r11d,WORD PTR [rax+r15*8]
  3a1ba6:	mov    r14d,DWORD PTR [r12+0x10]
  3a1bab:	cmp    r14d,r11d
  3a1bae:	mov    r11,QWORD PTR [rsp-0x78]
  3a1bb3:	je     3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1bb9:	jmp    3a1bc0 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x1d0>
  3a1bbb:	mov    r14d,DWORD PTR [r12+0x10]
  3a1bc0:	mov    r8d,DWORD PTR [rsp-0x7c]
  3a1bc5:	mov    r11d,r8d
  3a1bc8:	neg    r11d
  3a1bcb:	mov    eax,ebx
  3a1bcd:	neg    eax
  3a1bcf:	cmp    BYTE PTR [r12+0x1a],0x0
  3a1bd5:	cmove  r11d,r8d
  3a1bd9:	cmove  eax,ebx
  3a1bdc:	shl    eax,0x10
  3a1bdf:	movzx  r11d,r11w
  3a1be3:	or     r11d,eax
  3a1be6:	mov    rax,QWORD PTR [rsp-0x70]
  3a1beb:	mov    WORD PTR [rax+r15*8],r14w
  3a1bf0:	mov    DWORD PTR [rax+r15*8+0x2],r11d
  3a1bf5:	mov    r11,QWORD PTR [rsp-0x78]
  3a1bfa:	mov    BYTE PTR [rax+r15*8+0x6],0x1
  3a1c00:	test   dl,0x10
  3a1c03:	je     3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1c09:	mov    eax,DWORD PTR [r10+rcx*4+0xa00]
  3a1c11:	cmp    r11,rax
  3a1c14:	jbe    3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1c1a:	mov    QWORD PTR [rsp-0x20],rax
  3a1c1f:	mov    eax,DWORD PTR [r10+rcx*4+0x500]
  3a1c27:	mov    DWORD PTR [rsp-0x64],eax
  3a1c2b:	mov    eax,DWORD PTR [r10+rcx*4+0x600]
  3a1c33:	mov    DWORD PTR [rsp-0x68],eax
  3a1c37:	mov    rax,QWORD PTR [r12+0x8]
  3a1c3c:	mov    QWORD PTR [rsp-0x28],rax
  3a1c41:	movsxd rax,DWORD PTR [r10+rcx*4+0x800]
  3a1c49:	mov    r15d,DWORD PTR [r10+rcx*4+0x700]
  3a1c51:	mov    rdx,QWORD PTR [rsp-0x8]
  3a1c56:	shrx   r8,rax,rdx
  3a1c5b:	mov    rdx,r8
  3a1c5e:	movabs r14,0xaaaaaaaaaaaaaaab
  3a1c68:	mulx   rdx,rdx,r14
  3a1c6d:	shr    rdx,1
  3a1c70:	lea    rdx,[rdx+rdx*2]
  3a1c74:	sub    r8,rdx
  3a1c77:	mov    r14d,r15d
  3a1c7a:	or     r14d,eax
  3a1c7d:	shl    rax,0x20
  3a1c81:	shl    r15,0x10
  3a1c85:	add    r15,rax
  3a1c88:	mov    QWORD PTR [rsp-0x60],r15
  3a1c8d:	cmp    r14d,0xffff
  3a1c94:	ja     3a1cf6 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x306>
  3a1c96:	imul   rcx,QWORD PTR [rsp-0x18]
  3a1c9c:	add    rcx,QWORD PTR [rsp-0x38]
  3a1ca1:	cmp    rcx,QWORD PTR [rsp-0x48]
  3a1ca6:	jae    3a1cf6 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x306>
  3a1ca8:	mov    r15d,r14d
  3a1cab:	shl    rcx,0x4
  3a1caf:	mov    r11,QWORD PTR [rsp-0x50]
  3a1cb4:	lea    rdx,[r11+rcx*1]
  3a1cb8:	movzx  eax,BYTE PTR [rsp-0x7d]
  3a1cbd:	cmp    BYTE PTR [r11+rcx*1+0xd],al
  3a1cc2:	jne    3a1ccb <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x2db>
  3a1cc4:	movzx  r14d,BYTE PTR [rdx+0xc]
  3a1cc9:	jmp    3a1cd1 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x2e1>
  3a1ccb:	mov    BYTE PTR [rdx+0xd],al
  3a1cce:	xor    r14d,r14d
  3a1cd1:	mov    rax,QWORD PTR [rsp-0x60]
  3a1cd6:	mov    r11b,0x1
  3a1cd9:	mov    rcx,r8
  3a1cdc:	shl    r11b,cl
  3a1cdf:	shr    rax,0x10
  3a1ce3:	mov    DWORD PTR [rdx+r8*4],eax
  3a1ce7:	or     r11b,r14b
  3a1cea:	mov    BYTE PTR [rdx+0xc],r11b
  3a1cee:	mov    r11,QWORD PTR [rsp-0x78]
  3a1cf3:	mov    r14d,r15d
  3a1cf6:	mov    rdx,QWORD PTR [rsp-0x20]
  3a1cfb:	imul   rdx,QWORD PTR [rsp-0x10]
  3a1d01:	mov    rax,QWORD PTR [rsp-0x30]
  3a1d06:	lea    rcx,[rdx+rax*1]
  3a1d0a:	cmp    rcx,QWORD PTR [rsp-0x40]
  3a1d0f:	jae    3a1d3c <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x34c>
  3a1d11:	vmovd  xmm4,DWORD PTR [rsp-0x64]
  3a1d17:	vpinsrd xmm4,xmm4,DWORD PTR [rsp-0x68],0x1
  3a1d1f:	vpsubd xmm4,xmm0,xmm4
  3a1d23:	vpmaxsd xmm4,xmm4,xmm1
  3a1d28:	vpminsd xmm4,xmm4,xmm2
  3a1d2d:	vpshuflw xmm4,xmm4,0xe8
  3a1d32:	mov    rax,QWORD PTR [rsp-0x58]
  3a1d37:	vmovd  DWORD PTR [rax+rcx*4],xmm4
  3a1d3c:	test   dil,dil
  3a1d3f:	je     3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1d45:	add    rdx,QWORD PTR [rsp-0x28]
  3a1d4a:	cmp    rdx,QWORD PTR [rsp-0x40]
  3a1d4f:	jae    3a1d94 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x3a4>
  3a1d51:	vmovd  xmm4,DWORD PTR [rsp-0x7c]
  3a1d57:	vpinsrd xmm4,xmm4,ebx,0x1
  3a1d5d:	vpbroadcastd xmm5,DWORD PTR [r12+0x14]
  3a1d64:	vpmulld xmm4,xmm5,xmm4
  3a1d69:	vpsrad xmm5,xmm4,0x1f
  3a1d6e:	vpaddd xmm4,xmm4,xmm3
  3a1d72:	vpaddd xmm4,xmm4,xmm5
  3a1d76:	vpsrad xmm4,xmm4,0xe
  3a1d7b:	vpmaxsd xmm4,xmm4,xmm1
  3a1d80:	vpminsd xmm4,xmm4,xmm2
  3a1d85:	vpshuflw xmm4,xmm4,0xe8
  3a1d8a:	mov    rax,QWORD PTR [rsp-0x58]
  3a1d8f:	vmovd  DWORD PTR [rax+rdx*4],xmm4
  3a1d94:	cmp    r13b,0xa
  3a1d98:	jne    3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1d9e:	cmp    r14d,0xffff
  3a1da5:	ja     3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1dab:	cmp    rbp,QWORD PTR [rsp-0x48]
  3a1db0:	jae    3a1b00 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0x110>
  3a1db6:	shl    rbp,0x4
  3a1dba:	mov    rdx,QWORD PTR [rsp-0x50]
  3a1dbf:	lea    rax,[rdx+rbp*1]
  3a1dc3:	movzx  ecx,BYTE PTR [rsp-0x7d]
  3a1dc8:	cmp    BYTE PTR [rdx+rbp*1+0xd],cl
  3a1dcc:	jne    3a1ad2 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0xe2>
  3a1dd2:	movzx  edx,BYTE PTR [rax+0xc]
  3a1dd6:	jmp    3a1ad7 <_RINvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB6_9ChunkWalk15project_trackedKb0_EBg_+0xe7>
  3a1ddb:	add    rsp,0x8
  3a1ddf:	pop    rbx
  3a1de0:	pop    r12
  3a1de2:	pop    r13
  3a1de4:	pop    r14
  3a1de6:	pop    r15
  3a1de8:	pop    rbp
  3a1de9:	ret
