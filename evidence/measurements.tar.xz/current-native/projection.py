"""Match temporal projection across v3's separate lane symbols and the merged scan."""

from collections import Counter
from pathlib import Path
import re
from runpy import run_path
from statistics import mean

OUT = Path(__file__).resolve().parent
tools = run_path(str(OUT.parent / "native-stacks/analyze.py"))
labels = ("shipped-symbols", "portable")
pairs = (1, 2, 4)
groups = [
    ("Tracked with trajectory extension", re.compile(r"ChunkWalk>::project_tracked(?:::)?<true>")),
    ("Tracked without trajectory extension", re.compile(r"ChunkWalk>::project_tracked(?:::)?<false>")),
    ("Untracked walk", re.compile(r"ChunkWalk>::project$")),
    ("Lane preparation and scoped scan overhead", re.compile(r"::scan::(?:project_temporal_motion_field|chunk_lanes|TargetTables)")),
]
counts = {}
for label in labels:
    for pair in pairs:
        nodes = tools["read_tree"]((OUT / f"{label}-{pair}.tree").read_text())
        counts[label, pair] = Counter()
        for node in nodes:
            if group := tools["nearest_matching_group"](node.path, groups):
                counts[label, pair][group] += node.exclusive

print("| Matched projection operation | Shipped mean ms | Merged mean ms | Mean excess ms | Paired excess ms |")
print("|---|---:|---:|---:|---|")
for group in [row[0] for row in groups] + ["Total"]:
    def count(label, pair):
        row = counts[label, pair]
        return row.total() if group == "Total" else row[group]
    old, new = ([count(label, pair) for pair in pairs] for label in labels)
    delta = [after - before for before, after in zip(old, new)]
    print(f"| {group} | {mean(old):.1f} | {mean(new):.1f} | {mean(delta):+.1f} | "
          f"{', '.join(f'{n:+d}' for n in delta)} |")
