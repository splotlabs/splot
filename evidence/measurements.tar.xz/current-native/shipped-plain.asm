
../native-stacks/ref-target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

00000000006fd940 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project>:
  6fd940:	mov    rax,QWORD PTR [rdi+0x8]
  6fd944:	test   rax,rax
  6fd947:	je     6fda07 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xc7>
  6fd94d:	push   rbp
  6fd94e:	push   rbx
  6fd94f:	mov    rcx,QWORD PTR [rdi]
  6fd952:	mov    rdi,QWORD PTR [rdx]
  6fd955:	mov    rdx,QWORD PTR [rdx+0x8]
  6fd959:	jmp    6fd987 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x47>
  6fd95b:	shl    r9d,0x10
  6fd95f:	movzx  r10d,r10w
  6fd963:	or     r10d,r9d
  6fd966:	mov    WORD PTR [rdi+r8*8],bx
  6fd96b:	mov    DWORD PTR [rdi+r8*8+0x2],r10d
  6fd970:	mov    BYTE PTR [rdi+r8*8+0x6],0x1
  6fd976:	cs nop WORD PTR [rax+rax*1+0x0]
  6fd980:	blsr   rax,rax
  6fd985:	je     6fda05 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xc5>
  6fd987:	xor    r9d,r9d
  6fd98a:	tzcnt  r9,rax
  6fd98f:	movzx  r11d,BYTE PTR [rcx+r9*1+0xc00]
  6fd998:	cmp    r11d,0x8
  6fd99c:	ja     6fd980 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  6fd99e:	mov    r8d,DWORD PTR [rcx+r9*4+0x900]
  6fd9a6:	cmp    rdx,r8
  6fd9a9:	jbe    6fd980 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  6fd9ab:	shl    r11d,0x5
  6fd9af:	add    r11,rsi
  6fd9b2:	mov    r10d,DWORD PTR [rcx+r9*4+0x300]
  6fd9ba:	mov    r9d,DWORD PTR [rcx+r9*4+0x400]
  6fd9c2:	cmp    BYTE PTR [rdi+r8*8+0x6],0x0
  6fd9c8:	je     6fd9eb <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xab>
  6fd9ca:	cmp    BYTE PTR [r11+0x1b],0x1
  6fd9cf:	jne    6fd980 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  6fd9d1:	movsx  ebp,WORD PTR [rdi+r8*8]
  6fd9d6:	mov    ebx,DWORD PTR [r11+0x10]
  6fd9da:	cmp    ebx,ebp
  6fd9dc:	je     6fd980 <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x40>
  6fd9de:	cmp    BYTE PTR [r11+0x1a],0x0
  6fd9e3:	je     6fd95b <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x1b>
  6fd9e9:	jmp    6fd9fa <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0xba>
  6fd9eb:	mov    ebx,DWORD PTR [r11+0x10]
  6fd9ef:	cmp    BYTE PTR [r11+0x1a],0x0
  6fd9f4:	je     6fd95b <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x1b>
  6fd9fa:	neg    r10d
  6fd9fd:	neg    r9d
  6fda00:	jmp    6fd95b <_RNvMs3_NtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scanNtB5_9ChunkWalk7project+0x1b>
  6fda05:	pop    rbx
  6fda06:	pop    rbp
  6fda07:	ret
