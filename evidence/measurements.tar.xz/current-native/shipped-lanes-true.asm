
../native-stacks/ref-target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

000000000061b360 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_>:
  61b360:	push   rbp
  61b361:	push   r15
  61b363:	push   r14
  61b365:	push   r13
  61b367:	push   r12
  61b369:	push   rbx
  61b36a:	sub    rsp,0x588
  61b371:	mov    rbp,QWORD PTR [rsp+0x5c8]
  61b379:	mov    r13,QWORD PTR [rbp+0x0]
  61b37d:	test   r13,r13
  61b380:	je     61c2e7 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xf87>
  61b386:	mov    r12,r9
  61b389:	mov    r9,rdx
  61b38c:	mov    rbx,rdi
  61b38f:	mov    rax,rdx
  61b392:	or     rax,r13
  61b395:	shr    rax,0x20
  61b399:	mov    QWORD PTR [rsp+0x10],r8
  61b39e:	je     61b3aa <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0x4a>
  61b3a0:	mov    rax,r9
  61b3a3:	xor    edx,edx
  61b3a5:	div    r13
  61b3a8:	jmp    61b3b2 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0x52>
  61b3aa:	mov    eax,r9d
  61b3ad:	xor    edx,edx
  61b3af:	div    r13d
  61b3b2:	cmp    rdx,0x1
  61b3b6:	sbb    rax,0xffffffffffffffff
  61b3ba:	cmp    rax,0x40
  61b3be:	mov    r15d,0x40
  61b3c4:	cmovb  r15,rax
  61b3c8:	add    r9,r9
  61b3cb:	lea    rdi,[r9+r9*2]
  61b3cf:	add    rcx,rcx
  61b3d2:	lea    rax,[rcx+rcx*2]
  61b3d6:	shr    rax,1
  61b3d9:	add    rsi,rax
  61b3dc:	xor    r14d,r14d
  61b3df:	sub    rdi,rax
  61b3e2:	cmovb  rdi,r14
  61b3e6:	mov    eax,0x1
  61b3eb:	cmovae rax,rsi
  61b3ef:	mov    rcx,r13
  61b3f2:	imul   rcx,r15
  61b3f6:	add    rcx,rcx
  61b3f9:	lea    rcx,[rcx+rcx*2]
  61b3fd:	cmp    rdi,rcx
  61b400:	cmovae rdi,rcx
  61b404:	cmp    rdi,0x300
  61b40b:	mov    edx,0x300
  61b410:	cmovb  rdx,rdi
  61b414:	mov    rdi,rbx
  61b417:	mov    rsi,rax
  61b41a:	call   QWORD PTR [rip+0x58c0e0]        # ba7500 <memcpy@GLIBC_2.14>
  61b420:	cmp    r12,0x7fffffff
  61b427:	ja     61c2cf <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xf6f>
  61b42d:	vmovdqu ymm0,YMMWORD PTR [rbp+0x30]
  61b432:	vpextrd eax,xmm0,0x1
  61b438:	mov    edi,DWORD PTR [rbp+0x24]
  61b43b:	cmp    r12d,edi
  61b43e:	mov    esi,0x0
  61b443:	sbb    esi,esi
  61b445:	cmp    r12d,eax
  61b448:	mov    r10d,0x0
  61b44e:	sbb    r10d,r10d
  61b451:	mov    rdx,r15
  61b454:	lea    rax,[r15+0xf]
  61b458:	shr    rax,0x4
  61b45c:	je     61c2b4 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xf54>
  61b462:	mov    rcx,QWORD PTR [rsp+0x5c0]
  61b46a:	vmovd  xmm4,r13d
  61b46f:	vpbroadcastd ymm1,xmm4
  61b474:	vpmulld xmm5,xmm1,XMMWORD PTR [rip+0xffffffffff9fad93]        # 16210 <anon.46ccc32afff085b8b120907cd1a28060.1517.llvm.2116171125858951624+0x2a0>
  61b47d:	mov    r8d,DWORD PTR [rbp+0x28]
  61b481:	vpmulld xmm3,xmm1,XMMWORD PTR [rip+0xffffffffff9f85c6]        # 13a50 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x730>
  61b48a:	mov    r9d,DWORD PTR [rbp+0x2c]
  61b48e:	vpmulld ymm1,ymm1,YMMWORD PTR [rip+0xffffffffff9fcc49]        # 180e0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12a1>
  61b497:	vmovdqu YMMWORD PTR [rsp+0x410],ymm1
  61b4a0:	vmovdqu xmm1,XMMWORD PTR [rbp+0x40]
  61b4a5:	vpalignr xmm2,xmm1,xmm0,0x8
  61b4ab:	vpextrd r15d,xmm0,0x3
  61b4b1:	mov    r11,QWORD PTR [rbp+0x48]
  61b4b5:	vmovd  xmm6,r12d
  61b4ba:	vpbroadcastd ymm8,xmm6
  61b4bf:	mov    r14d,DWORD PTR [rbp+0x14]
  61b4c3:	vmovd  xmm6,esi
  61b4c7:	vpbroadcastd ymm6,xmm6
  61b4cc:	vmovdqu YMMWORD PTR [rsp+0x1d0],ymm6
  61b4d5:	mov    rsi,r12
  61b4d8:	or     rsi,rcx
  61b4db:	not    r14d
  61b4de:	vmovd  xmm6,r14d
  61b4e3:	movsxd r14,DWORD PTR [rbp+0x10]
  61b4e7:	and    rsi,r14
  61b4ea:	vpand  xmm7,xmm8,xmm6
  61b4ee:	vpbroadcastd ymm7,xmm7
  61b4f3:	vmovdqu YMMWORD PTR [rsp+0x390],ymm7
  61b4fc:	vmovd  xmm7,r10d
  61b501:	vpbroadcastd ymm7,xmm7
  61b506:	vmovdqu YMMWORD PTR [rsp+0xf0],ymm7
  61b50f:	shr    r11,0x20
  61b513:	and    r11d,0x1
  61b517:	shl    r11b,0x3
  61b51b:	or     r11b,0x4
  61b51f:	mov    DWORD PTR [rsp+0xc],r15d
  61b524:	vmovd  xmm7,r15d
  61b529:	vpbroadcastd ymm7,xmm7
  61b52e:	vmovdqu YMMWORD PTR [rsp+0x110],ymm8
  61b537:	vpandn ymm7,ymm7,ymm8
  61b53c:	vmovdqu YMMWORD PTR [rsp+0x370],ymm7
  61b545:	mov    r10d,r12d
  61b548:	sub    r10d,r8d
  61b54b:	vmovd  xmm7,r11d
  61b550:	mov    r11d,DWORD PTR [rbp+0x8]
  61b554:	not    r14d
  61b557:	vmovd  xmm9,r14d
  61b55c:	mov    r14d,DWORD PTR [rbp+0xc]
  61b560:	sub    r12d,r11d
  61b563:	vmovd  xmm8,r11d
  61b568:	mov    r11d,r12d
  61b56b:	imul   r12d,r14d
  61b56f:	vpsllq xmm4,xmm4,0x20
  61b574:	vpermq ymm5,ymm5,0xd0
  61b57a:	vpblendd ymm4,ymm5,ymm4,0x3
  61b580:	vmovd  xmm5,r14d
  61b585:	mov    r14d,r10d
  61b588:	sar    r14d,0x1f
  61b58c:	imul   r10d,r9d
  61b590:	sar    r11d,0x1f
  61b594:	vpbroadcastq ymm3,xmm3
  61b599:	vpblendd ymm3,ymm4,ymm3,0xc0
  61b59f:	vmovdqu YMMWORD PTR [rsp+0x3f0],ymm3
  61b5a8:	vpbroadcastb xmm3,xmm7
  61b5ad:	vmovdqa XMMWORD PTR [rsp+0x20],xmm3
  61b5b3:	vmovdqa XMMWORD PTR [rsp+0x30],xmm9
  61b5b9:	vpand  xmm3,xmm9,xmm6
  61b5bd:	vpbroadcastd ymm3,xmm3
  61b5c2:	vmovdqu YMMWORD PTR [rsp+0x350],ymm3
  61b5cb:	vpbroadcastd ymm3,xmm8
  61b5d0:	vmovdqu YMMWORD PTR [rsp+0x330],ymm3
  61b5d9:	vpbroadcastd ymm3,xmm5
  61b5de:	vmovdqu YMMWORD PTR [rsp+0x310],ymm3
  61b5e7:	vpbroadcastd ymm0,xmm0
  61b5ec:	vmovdqu YMMWORD PTR [rsp+0x90],ymm0
  61b5f5:	vmovd  xmm0,r8d
  61b5fa:	vpbroadcastd ymm0,xmm0
  61b5ff:	vmovdqu YMMWORD PTR [rsp+0x2f0],ymm0
  61b608:	vmovd  xmm0,r9d
  61b60d:	vpbroadcastd ymm0,xmm0
  61b612:	vmovdqu YMMWORD PTR [rsp+0x2d0],ymm0
  61b61b:	vpbroadcastd ymm0,xmm2
  61b620:	vmovdqu YMMWORD PTR [rsp+0xd0],ymm0
  61b629:	vpbroadcastd ymm0,xmm1
  61b62e:	vmovdqu YMMWORD PTR [rsp+0x2b0],ymm0
  61b637:	vpbroadcastd ymm0,DWORD PTR [rip+0xffffffffffa01b80]        # 1d1c0 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x160>
  61b640:	vmovdqu YMMWORD PTR [rsp+0x3d0],ymm0
  61b649:	vpermd ymm0,ymm0,ymm1
  61b64e:	vmovdqu YMMWORD PTR [rsp+0x290],ymm0
  61b657:	vpbroadcastd ymm0,DWORD PTR [rip+0xffffffffffa01960]        # 1cfc0 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xf80>
  61b660:	vmovdqu YMMWORD PTR [rsp+0x270],ymm0
  61b669:	vpermd ymm0,ymm0,ymm1
  61b66e:	vmovdqu YMMWORD PTR [rsp+0x250],ymm0
  61b677:	vmovd  xmm0,r12d
  61b67c:	vpbroadcastd ymm0,xmm0
  61b681:	vmovdqu YMMWORD PTR [rsp+0x1b0],ymm0
  61b68a:	vmovd  xmm0,r11d
  61b68f:	vpbroadcastd ymm0,xmm0
  61b694:	vmovdqu YMMWORD PTR [rsp+0x190],ymm0
  61b69d:	vmovd  xmm0,r10d
  61b6a2:	vpbroadcastd ymm0,xmm0
  61b6a7:	vmovdqu YMMWORD PTR [rsp+0x170],ymm0
  61b6b0:	vmovd  xmm0,r14d
  61b6b5:	vpbroadcastd ymm0,xmm0
  61b6ba:	vmovdqu YMMWORD PTR [rsp+0x150],ymm0
  61b6c3:	vmovd  xmm0,edi
  61b6c7:	vpbroadcastd ymm0,xmm0
  61b6cc:	vmovdqu YMMWORD PTR [rsp+0x230],ymm0
  61b6d5:	mov    edi,r13d
  61b6d8:	shl    edi,0x4
  61b6db:	mov    r8,r13
  61b6de:	shl    r8,0x4
  61b6e2:	mov    r9,rcx
  61b6e5:	sub    r9,r8
  61b6e8:	mov    r10d,0xc40
  61b6ee:	mov    r11d,0x2b
  61b6f4:	xor    r12d,r12d
  61b6f7:	xor    r14d,r14d
  61b6fa:	mov    r15,QWORD PTR [rsp+0x10]
  61b6ff:	vmovaps xmm0,XMMWORD PTR [r15]
  61b704:	vmovaps XMMWORD PTR [rsp+0x50],xmm0
  61b70a:	vmovaps xmm0,XMMWORD PTR [r15+0x10]
  61b710:	vmovaps XMMWORD PTR [rsp+0x40],xmm0
  61b716:	vmovaps xmm0,XMMWORD PTR [r15+0x20]
  61b71c:	vmovaps XMMWORD PTR [rsp+0x60],xmm0
  61b722:	vbroadcastss ymm0,DWORD PTR [r15+0x30]
  61b728:	vmovups YMMWORD PTR [rsp+0x3b0],ymm0
  61b731:	vbroadcastss ymm0,DWORD PTR [rbp+0x18]
  61b737:	vmovups YMMWORD PTR [rsp+0x210],ymm0
  61b740:	vbroadcastss ymm0,DWORD PTR [rbp+0x1c]
  61b746:	vmovups YMMWORD PTR [rsp+0x1f0],ymm0
  61b74f:	vpbroadcastd ymm0,DWORD PTR [rbp+0x20]
  61b755:	vmovdqu YMMWORD PTR [rsp+0xb0],ymm0
  61b75e:	mov    r15,rdx
  61b761:	jmp    61bcd1 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0x971>
  61b766:	cs nop WORD PTR [rax+rax*1+0x0]
  61b770:	vpsrld ymm7,ymm6,0x1a
  61b775:	vpaddd ymm6,ymm7,ymm6
  61b779:	vpsrad ymm6,ymm6,0x6
  61b77e:	vmovdqu ymm7,YMMWORD PTR [rsp+0x110]
  61b787:	vpaddd ymm15,ymm6,ymm7
  61b78b:	vpsrld ymm6,ymm4,0x1a
  61b790:	vpaddd ymm4,ymm6,ymm4
  61b794:	vpsrad ymm4,ymm4,0x6
  61b799:	vpaddd ymm11,ymm4,ymm7
  61b79d:	vmovdqu YMMWORD PTR [rsp+0x550],ymm9
  61b7a6:	vmovdqu ymm9,YMMWORD PTR [rsp+0x230]
  61b7af:	vpminud ymm4,ymm9,ymm11
  61b7b4:	vmovdqu YMMWORD PTR [rsp+0x430],ymm11
  61b7bd:	vpcmpeqd ymm10,ymm9,ymm4
  61b7c1:	vpsrad ymm4,ymm14,0x1f
  61b7c7:	vpsrld ymm4,ymm4,0x1a
  61b7cc:	vpaddd ymm4,ymm14,ymm4
  61b7d0:	vpsrad ymm6,ymm0,0x1f
  61b7d5:	vpsrld ymm6,ymm6,0x1a
  61b7da:	vpaddd ymm0,ymm6,ymm0
  61b7de:	vpsrad ymm4,ymm4,0x6
  61b7e3:	vpsrad ymm6,ymm0,0x6
  61b7e8:	vpaddd ymm0,ymm4,ymm7
  61b7ec:	vmovdqu YMMWORD PTR [rsp+0x70],ymm0
  61b7f2:	vpaddd ymm8,ymm6,ymm7
  61b7f6:	vpminud ymm4,ymm9,ymm0
  61b7fb:	vpcmpeqd ymm6,ymm9,ymm4
  61b7ff:	vpminud ymm4,ymm9,ymm8
  61b804:	vpcmpeqd ymm7,ymm9,ymm4
  61b808:	vpsrld ymm4,ymm5,0x1a
  61b80d:	vpaddd ymm5,ymm4,ymm5
  61b811:	vpsrld ymm4,ymm3,0x1a
  61b816:	vpaddd ymm3,ymm4,ymm3
  61b81a:	vpsrad ymm3,ymm3,0x6
  61b81f:	vpaddd ymm4,ymm12,ymm3
  61b823:	vpsrad ymm3,ymm2,0x1f
  61b828:	vpsrld ymm3,ymm3,0x1a
  61b82d:	vpaddd ymm2,ymm3,ymm2
  61b831:	vpsrad ymm2,ymm2,0x6
  61b836:	vpaddd ymm2,ymm13,ymm2
  61b83a:	vpsrad ymm3,ymm1,0x1f
  61b83f:	vpsrld ymm3,ymm3,0x1a
  61b844:	vpaddd ymm1,ymm3,ymm1
  61b848:	vpsrad ymm1,ymm1,0x6
  61b84d:	vpaddd ymm3,ymm12,ymm1
  61b851:	vmovdqu ymm0,YMMWORD PTR [rsp+0xb0]
  61b85a:	vpminud ymm1,ymm0,ymm2
  61b85f:	vpcmpeqd ymm1,ymm0,ymm1
  61b863:	vpor   ymm1,ymm7,ymm1
  61b867:	vmovdqu YMMWORD PTR [rsp+0x530],ymm1
  61b870:	vpminud ymm1,ymm0,ymm3
  61b875:	vpcmpeqd ymm1,ymm0,ymm1
  61b879:	vpor   ymm1,ymm6,ymm1
  61b87d:	vmovdqu YMMWORD PTR [rsp+0x510],ymm1
  61b886:	vpminud ymm1,ymm0,ymm4
  61b88b:	vpcmpeqd ymm1,ymm0,ymm1
  61b88f:	vpor   ymm1,ymm10,ymm1
  61b893:	vmovdqu YMMWORD PTR [rsp+0x450],ymm1
  61b89c:	vmovdqu YMMWORD PTR [rsp+0x470],ymm15
  61b8a5:	vpminud ymm7,ymm9,ymm15
  61b8aa:	vpcmpeqd ymm10,ymm9,ymm7
  61b8ae:	vpsrad ymm5,ymm5,0x6
  61b8b3:	vpaddd ymm7,ymm13,ymm5
  61b8b7:	vpminud ymm5,ymm0,ymm7
  61b8bc:	vpcmpeqd ymm5,ymm0,ymm5
  61b8c0:	vpor   ymm0,ymm10,ymm5
  61b8c4:	vmovdqu YMMWORD PTR [rsp+0x4f0],ymm0
  61b8cd:	vpbroadcastd ymm10,DWORD PTR [rsp+0x30]
  61b8d4:	vpand  ymm6,ymm11,ymm10
  61b8d9:	vmovdqa ymm1,ymm13
  61b8dd:	vmovdqu ymm13,YMMWORD PTR [rsp+0x330]
  61b8e6:	vpsubd ymm11,ymm6,ymm13
  61b8eb:	vmovdqu ymm0,YMMWORD PTR [rsp+0x310]
  61b8f4:	vpmulld ymm9,ymm11,ymm0
  61b8f9:	vpand  ymm14,ymm10,ymm4
  61b8fd:	vpaddd ymm9,ymm9,ymm14
  61b902:	vpsrad ymm11,ymm11,0x1f
  61b908:	vpor   ymm9,ymm9,ymm11
  61b90d:	vpand  ymm11,ymm10,YMMWORD PTR [rsp+0x70]
  61b913:	vpand  ymm5,ymm8,ymm10
  61b918:	vmovdqu YMMWORD PTR [rsp+0x4b0],ymm5
  61b921:	vpand  ymm2,ymm10,ymm2
  61b925:	vmovdqu YMMWORD PTR [rsp+0x4d0],ymm2
  61b92e:	vpand  ymm2,ymm10,ymm3
  61b932:	vmovdqu YMMWORD PTR [rsp+0x490],ymm2
  61b93b:	vpand  ymm8,ymm15,ymm10
  61b940:	vpsubd ymm13,ymm8,ymm13
  61b945:	vpmulld ymm0,ymm13,ymm0
  61b94a:	vpand  ymm10,ymm10,ymm7
  61b94e:	vpaddd ymm0,ymm10,ymm0
  61b952:	vpsrad ymm13,ymm13,0x1f
  61b958:	vpor   ymm0,ymm13,ymm0
  61b95c:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2a00],ymm6
  61b966:	vmovdqu YMMWORD PTR [rbx+r10*4-0x29e0],ymm8
  61b970:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2900],ymm14
  61b97a:	vmovdqu YMMWORD PTR [rbx+r10*4-0x28e0],ymm10
  61b984:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2800],ymm9
  61b98e:	vmovdqu YMMWORD PTR [rbx+r10*4-0x27e0],ymm0
  61b998:	vmovdqu ymm5,YMMWORD PTR [rsp+0x350]
  61b9a1:	vpand  ymm0,ymm4,ymm5
  61b9a5:	vmovdqu ymm2,YMMWORD PTR [rsp+0x210]
  61b9ae:	vpaddd ymm4,ymm12,ymm2
  61b9b2:	vpsubd ymm0,ymm4,ymm0
  61b9b6:	vpand  ymm4,ymm7,ymm5
  61b9ba:	vpaddd ymm7,ymm1,ymm2
  61b9be:	vpsubd ymm15,ymm7,ymm4
  61b9c2:	vpand  ymm7,ymm5,YMMWORD PTR [rsp+0x430]
  61b9cb:	vmovdqu ymm13,YMMWORD PTR [rsp+0x390]
  61b9d4:	vpcmpeqd ymm7,ymm13,ymm7
  61b9d8:	vmovdqu ymm4,YMMWORD PTR [rsp+0x1f0]
  61b9e1:	vpminud ymm0,ymm4,ymm0
  61b9e6:	vpcmpeqd ymm0,ymm4,ymm0
  61b9ea:	vpandn ymm0,ymm0,ymm7
  61b9ee:	vmovdqu ymm1,YMMWORD PTR [rsp+0x450]
  61b9f7:	vpandn ymm0,ymm1,ymm0
  61b9fb:	vmovdqu YMMWORD PTR [rsp+0x70],ymm0
  61ba01:	vmovdqu ymm3,YMMWORD PTR [rsp+0x2f0]
  61ba0a:	vpsubd ymm0,ymm6,ymm3
  61ba0e:	vmovdqu ymm2,YMMWORD PTR [rsp+0x2d0]
  61ba17:	vpmulld ymm1,ymm0,ymm2
  61ba1c:	vpaddd ymm1,ymm14,ymm1
  61ba20:	vpsrad ymm0,ymm0,0x1f
  61ba25:	vpsubd ymm9,ymm8,ymm3
  61ba29:	vpmulld ymm12,ymm9,ymm2
  61ba2e:	vpor   ymm0,ymm1,ymm0
  61ba32:	vpaddd ymm1,ymm12,ymm10
  61ba37:	vpsrad ymm9,ymm9,0x1f
  61ba3d:	vpor   ymm1,ymm9,ymm1
  61ba41:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2700],ymm0
  61ba4b:	vmovdqu YMMWORD PTR [rbx+r10*4-0x26e0],ymm1
  61ba55:	vpand  ymm0,ymm5,YMMWORD PTR [rsp+0x470]
  61ba5e:	vpcmpeqd ymm0,ymm13,ymm0
  61ba62:	vmovdqu ymm13,YMMWORD PTR [rsp+0x90]
  61ba6b:	vpminud ymm1,ymm4,ymm15
  61ba70:	vpcmpeqd ymm1,ymm4,ymm1
  61ba74:	vpandn ymm0,ymm1,ymm0
  61ba78:	vpsubd ymm1,ymm11,ymm3
  61ba7c:	vpmulld ymm4,ymm1,ymm2
  61ba81:	vmovdqu ymm5,YMMWORD PTR [rsp+0x4f0]
  61ba8a:	vpandn ymm9,ymm5,ymm0
  61ba8e:	vmovdqu ymm7,YMMWORD PTR [rsp+0x490]
  61ba97:	vpaddd ymm0,ymm7,ymm4
  61ba9b:	vpsrad ymm1,ymm1,0x1f
  61baa0:	vpor   ymm0,ymm0,ymm1
  61baa4:	vmovdqu ymm5,YMMWORD PTR [rsp+0x4b0]
  61baad:	vpsubd ymm1,ymm5,ymm3
  61bab1:	vpmulld ymm4,ymm1,ymm2
  61bab6:	vmovdqu ymm15,YMMWORD PTR [rsp+0x4d0]
  61babf:	vpaddd ymm4,ymm15,ymm4
  61bac3:	vpsrad ymm1,ymm1,0x1f
  61bac8:	vpor   ymm1,ymm4,ymm1
  61bacc:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2600],ymm0
  61bad6:	vmovdqu YMMWORD PTR [rbx+r10*4-0x25e0],ymm1
  61bae0:	vmovdqu ymm2,YMMWORD PTR [rsp+0xd0]
  61bae9:	vpminud ymm0,ymm2,ymm0
  61baee:	vpcmpeqd ymm0,ymm2,ymm0
  61baf2:	vpor   ymm4,ymm0,YMMWORD PTR [rsp+0x510]
  61bafb:	vpminud ymm0,ymm2,ymm1
  61bb00:	vpcmpeqd ymm0,ymm2,ymm0
  61bb04:	vpor   ymm1,ymm0,YMMWORD PTR [rsp+0x530]
  61bb0d:	mov    ebp,DWORD PTR [rsp+0xc]
  61bb11:	not    ebp
  61bb13:	vmovd  xmm0,ebp
  61bb17:	vpbroadcastd ymm0,xmm0
  61bb1c:	vpand  ymm6,ymm6,ymm0
  61bb20:	vpsubd ymm6,ymm11,ymm6
  61bb24:	vpand  ymm11,ymm11,ymm0
  61bb28:	vpand  ymm8,ymm8,ymm0
  61bb2c:	vpand  ymm12,ymm14,ymm0
  61bb30:	vpand  ymm10,ymm10,ymm0
  61bb34:	vpand  ymm0,ymm5,ymm0
  61bb38:	vpsubd ymm5,ymm5,ymm8
  61bb3d:	vmovdqu ymm2,YMMWORD PTR [rsp+0x290]
  61bb46:	vpaddd ymm3,ymm7,ymm2
  61bb4a:	vpsubd ymm3,ymm3,ymm12
  61bb4f:	vpaddd ymm2,ymm15,ymm2
  61bb53:	vpsubd ymm2,ymm2,ymm10
  61bb58:	vmovdqu ymm8,YMMWORD PTR [rsp+0x2b0]
  61bb61:	vpminud ymm6,ymm8,ymm6
  61bb66:	vpcmpeqd ymm6,ymm8,ymm6
  61bb6a:	vmovdqu ymm10,YMMWORD PTR [rsp+0x250]
  61bb73:	vpminud ymm3,ymm10,ymm3
  61bb78:	vpcmpeqd ymm3,ymm10,ymm3
  61bb7c:	vpor   ymm3,ymm6,ymm3
  61bb80:	vpminud ymm5,ymm8,ymm5
  61bb85:	vpcmpeqd ymm5,ymm8,ymm5
  61bb89:	vpminud ymm2,ymm10,ymm2
  61bb8e:	vpcmpeqd ymm2,ymm10,ymm2
  61bb92:	vpor   ymm2,ymm5,ymm2
  61bb96:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffffa010c1]        # 1cc60 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xc20>
  61bb9f:	vpcmpeqd ymm6,ymm13,YMMWORD PTR [rsp+0x130]
  61bba8:	vmovdqu ymm10,YMMWORD PTR [rsp+0xf0]
  61bbb1:	vpandn ymm6,ymm6,ymm10
  61bbb6:	vmovdqu ymm12,YMMWORD PTR [rsp+0x370]
  61bbbf:	vpcmpeqd ymm8,ymm12,ymm11
  61bbc4:	vpcmpeqd ymm0,ymm12,ymm0
  61bbc8:	vpandn ymm8,ymm4,ymm8
  61bbcd:	vpandn ymm0,ymm1,ymm0
  61bbd1:	vpsrld ymm8,ymm8,0x1f
  61bbd7:	vpor   ymm3,ymm3,ymm4
  61bbdb:	vpor   ymm1,ymm2,ymm1
  61bbdf:	vpbroadcastd ymm2,DWORD PTR [rip+0xffffffffffa01710]        # 1d2f8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x298>
  61bbe8:	vpand  ymm4,ymm6,ymm2
  61bbec:	vpor   ymm4,ymm8,ymm4
  61bbf0:	vmovdqu ymm7,YMMWORD PTR [rsp+0x70]
  61bbf6:	vpand  ymm8,ymm7,ymm5
  61bbfa:	vpor   ymm4,ymm8,ymm4
  61bbfe:	vpcmpeqd ymm8,ymm13,YMMWORD PTR [rsp+0x550]
  61bc07:	vpandn ymm8,ymm8,ymm10
  61bc0c:	vpsrld ymm0,ymm0,0x1f
  61bc11:	vpand  ymm2,ymm8,ymm2
  61bc15:	vpor   ymm0,ymm0,ymm2
  61bc19:	vpand  ymm2,ymm9,ymm5
  61bc1d:	vpor   ymm2,ymm0,ymm2
  61bc21:	vpbroadcastd ymm5,DWORD PTR [rip+0xffffffffffa013ee]        # 1d018 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xfd8>
  61bc2a:	vpand  ymm0,ymm6,ymm5
  61bc2e:	vpand  ymm0,ymm7,ymm0
  61bc32:	vpor   ymm0,ymm4,ymm0
  61bc36:	vpcmpeqd ymm6,ymm6,ymm6
  61bc3a:	vpxor  ymm3,ymm3,ymm6
  61bc3e:	vmovdqu ymm4,YMMWORD PTR [rsp+0x270]
  61bc47:	vpand  ymm3,ymm3,ymm4
  61bc4b:	vpor   ymm0,ymm0,ymm3
  61bc4f:	vpand  ymm3,ymm8,ymm5
  61bc53:	vpand  ymm3,ymm9,ymm3
  61bc57:	vpor   ymm2,ymm2,ymm3
  61bc5b:	vpxor  ymm1,ymm1,ymm6
  61bc5f:	vpand  ymm1,ymm1,ymm4
  61bc63:	vpor   ymm1,ymm2,ymm1
  61bc67:	lea    r15,[r10-0xc40]
  61bc6e:	vmovdqa xmm2,XMMWORD PTR [rsp+0x10]
  61bc74:	vpor   xmm2,xmm2,XMMWORD PTR [rip+0xffffffffff9f8e14]        # 14a90 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0xc40>
  61bc7c:	vextracti128 xmm3,ymm1,0x1
  61bc82:	vpackssdw xmm1,xmm1,xmm3
  61bc86:	vextracti128 xmm3,ymm0,0x1
  61bc8c:	vpackssdw xmm0,xmm0,xmm3
  61bc90:	vpacksswb xmm0,xmm0,xmm1
  61bc94:	vpand  xmm0,xmm2,xmm0
  61bc98:	vmovdqu XMMWORD PTR [rbx+r10*1],xmm0
  61bc9e:	vpand  xmm0,xmm0,XMMWORD PTR [rsp+0x20]
  61bca4:	vpxor  xmm1,xmm1,xmm1
  61bca8:	vpcmpgtb xmm0,xmm0,xmm1
  61bcac:	vpmovmskb ebp,xmm0
  61bcb0:	shlx   r15,rbp,r15
  61bcb5:	or     r14,r15
  61bcb8:	mov    r15,rdx
  61bcbb:	inc    r12
  61bcbe:	add    r10,0x10
  61bcc2:	add    r11,0x30
  61bcc6:	add    ecx,edi
  61bcc8:	cmp    r12,rax
  61bccb:	jae    61c2b7 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xf57>
  61bcd1:	add    r9,r8
  61bcd4:	test   r9,0xffffffff80000000
  61bcdb:	jne    61c2cc <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xf6c>
  61bce1:	cmp    r13,0x1
  61bce5:	jne    61bda0 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xa40>
  61bceb:	vmovdqu xmm0,XMMWORD PTR [rbx+r11*2-0x56]
  61bcf2:	vmovdqu xmm1,XMMWORD PTR [rbx+r11*2-0x50]
  61bcf9:	vmovdqu xmm2,XMMWORD PTR [rbx+r11*2-0x26]
  61bd00:	vmovdqu xmm3,XMMWORD PTR [rbx+r11*2-0x20]
  61bd07:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r11*2-0x46],0x4
  61bd0f:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r11*2-0x36],0x2
  61bd17:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r11*2-0x16],0x4
  61bd1f:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r11*2-0x6],0x2
  61bd27:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r11*2-0x40],0x4
  61bd2f:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r11*2-0x30],0x2
  61bd37:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r11*2-0x10],0x4
  61bd3f:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r11*2],0x2
  61bd46:	vmovq  xmm6,QWORD PTR [rip+0xffffffffff9fa002]        # 15d50 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1f00>
  61bd4e:	vpshufb xmm4,xmm1,xmm6
  61bd53:	vpshufb xmm5,xmm0,xmm6
  61bd58:	vpunpcklbw xmm4,xmm5,xmm4
  61bd5c:	vpshufb xmm5,xmm3,xmm6
  61bd61:	vpshufb xmm6,xmm2,xmm6
  61bd66:	vpunpcklbw xmm5,xmm6,xmm5
  61bd6a:	vmovd  xmm6,DWORD PTR [rip+0xffffffffff9f84de]        # 14250 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x400>
  61bd72:	vpshufb xmm1,xmm1,xmm6
  61bd77:	vpshufb xmm0,xmm0,xmm6
  61bd7c:	vpunpcklbw xmm0,xmm0,xmm1
  61bd80:	vpshufb xmm1,xmm3,xmm6
  61bd85:	vpshufb xmm2,xmm2,xmm6
  61bd8a:	vpunpcklbw xmm1,xmm2,xmm1
  61bd8e:	jmp    61be59 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xaf9>
  61bd93:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  61bda0:	vmovdqu xmm0,XMMWORD PTR [rbx+r11*4-0xac]
  61bdaa:	vmovdqu xmm1,XMMWORD PTR [rbx+r11*4-0x8c]
  61bdb4:	vmovdqu xmm2,XMMWORD PTR [rbx+r11*4-0x7c]
  61bdbb:	vmovdqu xmm3,XMMWORD PTR [rbx+r11*4-0x5c]
  61bdc2:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r11*4-0x9c],0x4
  61bdcd:	vmovdqa xmm5,XMMWORD PTR [rip+0xffffffffff9f9a0b]        # 157e0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1990>
  61bdd5:	vpshufb xmm1,xmm1,xmm5
  61bdda:	vmovdqa xmm6,XMMWORD PTR [rip+0xffffffffff9fa97e]        # 16760 <anon.04501cfa98bd26ad8a51aa7d966155f9.109.llvm.3626723408307321437+0x290>
  61bde2:	vpshufb xmm0,xmm0,xmm6
  61bde7:	vpor   xmm0,xmm0,xmm1
  61bdeb:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+r11*4-0x6c],0x4
  61bdf3:	vpshufb xmm2,xmm3,xmm5
  61bdf8:	vpshufb xmm1,xmm1,xmm6
  61bdfd:	vpor   xmm1,xmm1,xmm2
  61be01:	vmovdqu xmm2,XMMWORD PTR [rbx+r11*4-0x2c]
  61be08:	vmovdqu xmm3,XMMWORD PTR [rbx+r11*4-0x4c]
  61be0f:	vpblendd xmm3,xmm3,XMMWORD PTR [rbx+r11*4-0x3c],0x4
  61be17:	vpshufb xmm2,xmm2,xmm5
  61be1c:	vpshufb xmm3,xmm3,xmm6
  61be21:	vpor   xmm2,xmm3,xmm2
  61be25:	vmovdqu xmm3,XMMWORD PTR [rbx+r11*4+0x4]
  61be2c:	vmovdqu xmm4,XMMWORD PTR [rbx+r11*4-0x1c]
  61be33:	vpblendd xmm4,xmm4,XMMWORD PTR [rbx+r11*4-0xc],0x4
  61be3b:	vpshufb xmm3,xmm3,xmm5
  61be40:	vpshufb xmm4,xmm4,xmm6
  61be45:	vpor   xmm3,xmm4,xmm3
  61be49:	vpunpckldq xmm4,xmm0,xmm1
  61be4d:	vpunpckldq xmm5,xmm2,xmm3
  61be51:	vpunpckhdq xmm0,xmm0,xmm1
  61be55:	vpunpckhdq xmm1,xmm2,xmm3
  61be59:	vpunpcklqdq xmm0,xmm0,xmm1
  61be5d:	vpunpcklqdq xmm1,xmm4,xmm5
  61be61:	vpunpckhqdq xmm3,xmm4,xmm5
  61be65:	vpaddusb xmm2,xmm1,XMMWORD PTR [rip+0xffffffffff9f7bf3]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61be6d:	vmovdqa xmm4,XMMWORD PTR [rsp+0x60]
  61be73:	vpshufb xmm4,xmm4,xmm2
  61be78:	vptest xmm4,XMMWORD PTR [rsp+0x20]
  61be7f:	je     61bcbb <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0x95b>
  61be85:	vmovdqa XMMWORD PTR [rsp+0x10],xmm4
  61be8b:	vmovdqu XMMWORD PTR [rbx+r10*1-0x40],xmm1
  61be92:	vmovdqa xmm1,XMMWORD PTR [rsp+0x50]
  61be98:	vpshufb xmm1,xmm1,xmm2
  61be9d:	vmovdqa xmm4,XMMWORD PTR [rsp+0x40]
  61bea3:	vpshufb xmm4,xmm4,xmm2
  61bea8:	vpunpcklbw xmm2,xmm1,xmm4
  61beac:	vpunpckhbw xmm1,xmm1,xmm4
  61beb0:	vpmovsxbw ymm3,xmm3
  61beb5:	vpmovsxwd ymm5,xmm3
  61beba:	vextracti128 xmm3,ymm3,0x1
  61bec0:	vpmovsxwd ymm3,xmm3
  61bec5:	vpabsd ymm4,ymm5
  61beca:	vpabsd ymm6,ymm3
  61becf:	vpsrld ymm7,ymm4,0x4
  61bed4:	vpsrld ymm8,ymm6,0x4
  61bed9:	vmovdqu ymm11,YMMWORD PTR [rsp+0x3d0]
  61bee2:	vpmaxud ymm7,ymm7,ymm11
  61bee7:	vpcmpeqd ymm12,ymm12,ymm12
  61beec:	vpaddd ymm7,ymm12,ymm7
  61bef0:	vpmaxud ymm8,ymm8,ymm11
  61bef5:	vpaddd ymm8,ymm8,ymm12
  61befa:	vpslld ymm9,ymm7,0x4
  61beff:	vpslld ymm10,ymm8,0x4
  61bf05:	vpsubd ymm4,ymm4,ymm9
  61bf0a:	vpsllvd ymm7,ymm4,ymm7
  61bf0f:	vpsubd ymm4,ymm6,ymm10
  61bf14:	vpsllvd ymm4,ymm4,ymm8
  61bf19:	vpsrad ymm5,ymm5,0x1f
  61bf1e:	vpxor  ymm6,ymm7,ymm5
  61bf22:	vpsubd ymm14,ymm6,ymm5
  61bf26:	vpmovsxbw ymm0,xmm0
  61bf2b:	vpmovsxwd ymm5,xmm0
  61bf30:	vextracti128 xmm0,ymm0,0x1
  61bf36:	vpmovsxwd ymm6,xmm0
  61bf3b:	vpabsd ymm0,ymm5
  61bf40:	vpabsd ymm7,ymm6
  61bf45:	vpsrld ymm8,ymm0,0x4
  61bf4a:	vpsrld ymm9,ymm7,0x4
  61bf4f:	vpmaxud ymm8,ymm8,ymm11
  61bf54:	vpaddd ymm10,ymm8,ymm12
  61bf59:	vpmaxud ymm8,ymm9,ymm11
  61bf5e:	vpaddd ymm9,ymm8,ymm12
  61bf63:	vpslld ymm8,ymm10,0x4
  61bf69:	vpsubd ymm0,ymm0,ymm8
  61bf6e:	vpslld ymm8,ymm9,0x4
  61bf74:	vpsubd ymm7,ymm7,ymm8
  61bf79:	vmovd  xmm8,ecx
  61bf7d:	vpbroadcastd ymm8,xmm8
  61bf82:	vpsllvd ymm10,ymm0,ymm10
  61bf87:	vpaddd ymm13,ymm8,YMMWORD PTR [rsp+0x3f0]
  61bf90:	vpmovsxwd ymm0,xmm2
  61bf95:	vmovdqu ymm2,YMMWORD PTR [rsp+0x3b0]
  61bf9e:	vpmulld ymm11,ymm2,ymm0
  61bfa3:	vpmovsxwd ymm0,xmm1
  61bfa8:	vpmulld ymm12,ymm2,ymm0
  61bfad:	vpsrad ymm0,ymm3,0x1f
  61bfb2:	vpxor  ymm1,ymm4,ymm0
  61bfb6:	vpsllvd ymm2,ymm7,ymm9
  61bfbb:	vpsubd ymm0,ymm1,ymm0
  61bfbf:	vpsrad ymm1,ymm5,0x1f
  61bfc4:	vpsrad ymm3,ymm6,0x1f
  61bfc9:	vpxor  ymm4,ymm10,ymm1
  61bfcd:	vpxor  ymm2,ymm2,ymm3
  61bfd1:	vpsubd ymm1,ymm4,ymm1
  61bfd5:	vpmulld ymm4,ymm11,ymm14
  61bfda:	vpsubd ymm2,ymm2,ymm3
  61bfde:	vpmulld ymm3,ymm12,ymm0
  61bfe3:	vpsrad ymm5,ymm4,0x1f
  61bfe8:	vpbroadcastd ymm7,DWORD PTR [rip+0xffffffffffa01207]        # 1d1f8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x198>
  61bff1:	vpaddd ymm4,ymm4,ymm7
  61bff5:	vpaddd ymm4,ymm4,ymm5
  61bff9:	vpsrad ymm5,ymm3,0x1f
  61bffe:	vpaddd ymm3,ymm3,ymm7
  61c002:	vpaddd ymm3,ymm3,ymm5
  61c006:	vpsrad ymm4,ymm4,0xe
  61c00b:	vpsrad ymm6,ymm3,0xe
  61c010:	vpmulld ymm3,ymm11,ymm1
  61c015:	vpmulld ymm5,ymm12,ymm2
  61c01a:	vmovdqa ymm12,ymm13
  61c01f:	vpsrad ymm9,ymm3,0x1f
  61c024:	vpaddd ymm3,ymm3,ymm7
  61c028:	vpaddd ymm3,ymm9,ymm3
  61c02c:	vpsrad ymm9,ymm5,0x1f
  61c031:	vpaddd ymm5,ymm5,ymm7
  61c035:	vpaddd ymm5,ymm9,ymm5
  61c039:	vpsrad ymm3,ymm3,0xe
  61c03e:	vpsrad ymm5,ymm5,0xe
  61c043:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2e00],ymm14
  61c04d:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2de0],ymm0
  61c057:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2c00],ymm4
  61c061:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2be0],ymm6
  61c06b:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2d00],ymm1
  61c075:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2ce0],ymm2
  61c07f:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2b00],ymm3
  61c089:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2ae0],ymm5
  61c093:	vpaddd ymm13,ymm8,YMMWORD PTR [rsp+0x410]
  61c09c:	vmovdqu ymm7,YMMWORD PTR [rsp+0x90]
  61c0a5:	vpminud ymm8,ymm7,ymm12
  61c0aa:	vmovdqu YMMWORD PTR [rsp+0x130],ymm8
  61c0b3:	vpminud ymm9,ymm7,ymm13
  61c0b8:	test   rsi,rsi
  61c0bb:	jne    61b770 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0x410>
  61c0c1:	vpabsd ymm7,ymm2
  61c0c6:	vpabsd ymm8,ymm1
  61c0cb:	vpabsd ymm10,ymm0
  61c0d0:	vpor   ymm7,ymm10,ymm7
  61c0d4:	vpabsd ymm10,ymm14
  61c0d9:	vpor   ymm8,ymm8,ymm10
  61c0de:	vpabsd ymm10,ymm4
  61c0e3:	vpor   ymm8,ymm8,ymm10
  61c0e8:	vpabsd ymm10,ymm6
  61c0ed:	vpor   ymm7,ymm10,ymm7
  61c0f1:	vpabsd ymm10,ymm5
  61c0f6:	vpor   ymm7,ymm10,ymm7
  61c0fa:	vpabsd ymm10,ymm3
  61c0ff:	vpor   ymm8,ymm8,ymm10
  61c104:	vpbroadcastd ymm10,DWORD PTR [rip+0xffffffffffa00e2b]        # 1cf38 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xef8>
  61c10d:	vpcmpgtd ymm7,ymm7,ymm10
  61c112:	vpcmpgtd ymm8,ymm8,ymm10
  61c117:	vpackssdw ymm7,ymm8,ymm7
  61c11b:	vpmovmskb ebp,ymm7
  61c11f:	test   ebp,ebp
  61c121:	jne    61b770 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0x410>
  61c127:	vmovups ymm0,YMMWORD PTR [rsp+0x110]
  61c130:	vmovups YMMWORD PTR [rbx+r10*4-0x2a00],ymm0
  61c13a:	vmovups YMMWORD PTR [rbx+r10*4-0x29e0],ymm0
  61c144:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2900],ymm12
  61c14e:	vmovdqu YMMWORD PTR [rbx+r10*4-0x28e0],ymm13
  61c158:	vmovdqu ymm1,YMMWORD PTR [rsp+0x1b0]
  61c161:	vpaddd ymm0,ymm12,ymm1
  61c165:	vpaddd ymm1,ymm13,ymm1
  61c169:	vmovdqu ymm2,YMMWORD PTR [rsp+0x190]
  61c172:	vpor   ymm0,ymm0,ymm2
  61c176:	vpor   ymm1,ymm1,ymm2
  61c17a:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2800],ymm0
  61c184:	vmovdqu YMMWORD PTR [rbx+r10*4-0x27e0],ymm1
  61c18e:	vmovdqu ymm8,YMMWORD PTR [rsp+0xb0]
  61c197:	vpminud ymm0,ymm8,ymm12
  61c19c:	vpcmpeqd ymm0,ymm8,ymm0
  61c1a0:	vmovdqu ymm6,YMMWORD PTR [rsp+0x1d0]
  61c1a9:	vpandn ymm0,ymm0,ymm6
  61c1ad:	vmovdqu ymm10,YMMWORD PTR [rsp+0x90]
  61c1b6:	vpcmpeqd ymm1,ymm10,YMMWORD PTR [rsp+0x130]
  61c1bf:	vmovdqu ymm7,YMMWORD PTR [rsp+0xf0]
  61c1c8:	vpandn ymm1,ymm1,ymm7
  61c1cc:	vpbroadcastd ymm2,DWORD PTR [rip+0xffffffffffa00a8b]        # 1cc60 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xc20>
  61c1d5:	vpand  ymm3,ymm0,ymm2
  61c1d9:	vpbroadcastd ymm4,DWORD PTR [rip+0xffffffffffa01116]        # 1d2f8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x298>
  61c1e2:	vpand  ymm5,ymm1,ymm4
  61c1e6:	vpor   ymm3,ymm3,ymm5
  61c1ea:	vpminud ymm5,ymm8,ymm13
  61c1ef:	vpcmpeqd ymm5,ymm8,ymm5
  61c1f3:	vpandn ymm5,ymm5,ymm6
  61c1f7:	vpcmpeqd ymm6,ymm10,ymm9
  61c1fc:	vpandn ymm6,ymm6,ymm7
  61c200:	vpand  ymm2,ymm5,ymm2
  61c204:	vpand  ymm4,ymm6,ymm4
  61c208:	vpor   ymm2,ymm2,ymm4
  61c20c:	vmovdqu ymm7,YMMWORD PTR [rsp+0x170]
  61c215:	vpaddd ymm4,ymm12,ymm7
  61c219:	vpaddd ymm7,ymm13,ymm7
  61c21d:	vmovdqu ymm8,YMMWORD PTR [rsp+0x150]
  61c226:	vpor   ymm4,ymm8,ymm4
  61c22a:	vpor   ymm7,ymm8,ymm7
  61c22e:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2700],ymm4
  61c238:	vmovdqu YMMWORD PTR [rbx+r10*4-0x26e0],ymm7
  61c242:	vmovdqu YMMWORD PTR [rbx+r10*4-0x2600],ymm4
  61c24c:	vmovdqu ymm8,YMMWORD PTR [rsp+0xd0]
  61c255:	vpminud ymm4,ymm8,ymm4
  61c25a:	vpcmpeqd ymm4,ymm8,ymm4
  61c25e:	vpandn ymm4,ymm4,ymm0
  61c262:	vpand  ymm0,ymm0,ymm1
  61c266:	vmovdqu YMMWORD PTR [rbx+r10*4-0x25e0],ymm7
  61c270:	vpminud ymm1,ymm8,ymm7
  61c275:	vpcmpeqd ymm1,ymm8,ymm1
  61c279:	vpandn ymm1,ymm1,ymm5
  61c27d:	vpand  ymm5,ymm5,ymm6
  61c281:	vpbroadcastd ymm6,DWORD PTR [rip+0xffffffffffa00d8e]        # 1d018 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xfd8>
  61c28a:	vpand  ymm0,ymm0,ymm6
  61c28e:	vpor   ymm0,ymm3,ymm0
  61c292:	vpand  ymm3,ymm5,ymm6
  61c296:	vpor   ymm2,ymm2,ymm3
  61c29a:	vpbroadcastd ymm3,DWORD PTR [rip+0xffffffffffa00d45]        # 1cfe8 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xfa8>
  61c2a3:	vpand  ymm4,ymm4,ymm3
  61c2a7:	vpor   ymm0,ymm0,ymm4
  61c2ab:	vpand  ymm1,ymm1,ymm3
  61c2af:	jmp    61bc63 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0x903>
  61c2b4:	mov    r15,rdx
  61c2b7:	cmp    r15,0x1
  61c2bb:	adc    r15,0x0
  61c2bf:	bzhi   rdx,r14,r15
  61c2c4:	mov    r14d,0x1
  61c2ca:	jmp    61c2cf <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb1_EBc_+0xf6f>
  61c2cc:	xor    r14d,r14d
  61c2cf:	mov    rax,r14
  61c2d2:	add    rsp,0x588
  61c2d9:	pop    rbx
  61c2da:	pop    r12
  61c2dc:	pop    r13
  61c2de:	pop    r14
  61c2e0:	pop    r15
  61c2e2:	pop    rbp
  61c2e3:	vzeroupper
  61c2e6:	ret
  61c2e7:	lea    rdi,[rip+0x57a182]        # b96470 <anon.46ccc32afff085b8b120907cd1a28060.160.llvm.2116171125858951624+0x1d98>
  61c2ee:	call   QWORD PTR [rip+0x58b704]        # ba79f8 <_DYNAMIC+0x748>
