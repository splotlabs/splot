
../native-stacks/ref-target/release/splot:     file format elf64-x86-64


Disassembly of section .text:

000000000061a350 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_>:
  61a350:	push   rbp
  61a351:	push   r15
  61a353:	push   r14
  61a355:	push   r13
  61a357:	push   r12
  61a359:	push   rbx
  61a35a:	sub    rsp,0x1f8
  61a361:	mov    r14,QWORD PTR [rsp+0x238]
  61a369:	mov    r13,QWORD PTR [r14]
  61a36c:	test   r13,r13
  61a36f:	je     61b349 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xff9>
  61a375:	mov    r12,r9
  61a378:	mov    r15,r8
  61a37b:	mov    r8,rdx
  61a37e:	mov    rbx,rdi
  61a381:	mov    rax,rdx
  61a384:	or     rax,r13
  61a387:	shr    rax,0x20
  61a38b:	je     61a397 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x47>
  61a38d:	mov    rax,r8
  61a390:	xor    edx,edx
  61a392:	div    r13
  61a395:	jmp    61a39f <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x4f>
  61a397:	mov    eax,r8d
  61a39a:	xor    edx,edx
  61a39c:	div    r13d
  61a39f:	cmp    rdx,0x1
  61a3a3:	sbb    rax,0xffffffffffffffff
  61a3a7:	cmp    rax,0x40
  61a3ab:	mov    ebp,0x40
  61a3b0:	cmovb  rbp,rax
  61a3b4:	add    r8,r8
  61a3b7:	lea    rdi,[r8+r8*2]
  61a3bb:	add    rcx,rcx
  61a3be:	lea    rax,[rcx+rcx*2]
  61a3c2:	shr    rax,1
  61a3c5:	add    rsi,rax
  61a3c8:	xor    ecx,ecx
  61a3ca:	sub    rdi,rax
  61a3cd:	cmovb  rdi,rcx
  61a3d1:	mov    eax,0x1
  61a3d6:	cmovae rax,rsi
  61a3da:	mov    rcx,r13
  61a3dd:	imul   rcx,rbp
  61a3e1:	add    rcx,rcx
  61a3e4:	lea    rcx,[rcx+rcx*2]
  61a3e8:	cmp    rdi,rcx
  61a3eb:	cmovae rdi,rcx
  61a3ef:	cmp    rdi,0x300
  61a3f6:	mov    edx,0x300
  61a3fb:	cmovb  rdx,rdi
  61a3ff:	mov    rdi,rbx
  61a402:	mov    rsi,rax
  61a405:	call   QWORD PTR [rip+0x58d0f5]        # ba7500 <memcpy@GLIBC_2.14>
  61a40b:	xor    eax,eax
  61a40d:	cmp    r12,0x7fffffff
  61a414:	ja     61b334 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe4>
  61a41a:	vmovd  xmm0,r13d
  61a41f:	vpbroadcastd ymm0,xmm0
  61a424:	vpmulld ymm5,ymm0,YMMWORD PTR [rip+0xffffffffff9fdcb3]        # 180e0 <anon.cf6f674292e2a017b5d72c6faa48e642.51.llvm.6184456788655724013+0x12a1>
  61a42d:	mov    rax,QWORD PTR [rsp+0x230]
  61a435:	vpmulld xmm1,xmm0,XMMWORD PTR [rip+0xffffffffff9f9612]        # 13a50 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x730>
  61a43e:	vpmulld xmm2,xmm0,XMMWORD PTR [rip+0xffffffffff9fbdc9]        # 16210 <anon.46ccc32afff085b8b120907cd1a28060.1517.llvm.2116171125858951624+0x2a0>
  61a447:	vmovd  xmm3,r12d
  61a44c:	vpbroadcastd ymm4,xmm3
  61a451:	mov    edx,DWORD PTR [r14+0x10]
  61a455:	mov    ecx,DWORD PTR [r14+0x14]
  61a459:	not    ecx
  61a45b:	vmovd  xmm3,ecx
  61a45f:	vmovdqu YMMWORD PTR [rsp+0x1b0],ymm4
  61a468:	vpand  xmm4,xmm3,xmm4
  61a46c:	vpbroadcastd ymm4,xmm4
  61a471:	vmovdqu YMMWORD PTR [rsp+0x190],ymm4
  61a47a:	movzx  esi,BYTE PTR [r14+0x4c]
  61a47f:	shl    sil,0x3
  61a483:	or     sil,0x4
  61a487:	lea    rcx,[rbp+0xf]
  61a48b:	shr    rcx,0x4
  61a48f:	vmovaps xmm4,XMMWORD PTR [r15]
  61a494:	vmovaps XMMWORD PTR [rsp+0x40],xmm4
  61a49a:	vmovaps xmm4,XMMWORD PTR [r15+0x10]
  61a4a0:	vmovaps XMMWORD PTR [rsp+0x30],xmm4
  61a4a6:	vmovaps xmm4,XMMWORD PTR [r15+0x20]
  61a4ac:	vmovaps XMMWORD PTR [rsp],xmm4
  61a4b1:	vmovd  xmm4,esi
  61a4b5:	vpbroadcastb xmm6,xmm4
  61a4ba:	vpsllq xmm0,xmm0,0x20
  61a4bf:	vpermq ymm2,ymm2,0xd0
  61a4c5:	vpblendd ymm0,ymm2,ymm0,0x3
  61a4cb:	vpbroadcastq ymm1,xmm1
  61a4d0:	vpblendd ymm1,ymm0,ymm1,0xc0
  61a4d6:	vbroadcastss ymm0,DWORD PTR [r15+0x30]
  61a4dc:	vmovups YMMWORD PTR [rsp+0x150],ymm0
  61a4e5:	lea    rsi,[rbx+0x300]
  61a4ec:	not    edx
  61a4ee:	vmovd  xmm0,edx
  61a4f2:	vmovdqa XMMWORD PTR [rsp+0x10],xmm0
  61a4f8:	vpand  xmm0,xmm3,xmm0
  61a4fc:	vpbroadcastd ymm0,xmm0
  61a501:	vmovdqu YMMWORD PTR [rsp+0x130],ymm0
  61a50a:	vbroadcastss ymm0,DWORD PTR [r14+0x8]
  61a510:	vmovups YMMWORD PTR [rsp+0x110],ymm0
  61a519:	vbroadcastss ymm0,DWORD PTR [r14+0xc]
  61a51f:	vmovups YMMWORD PTR [rsp+0xf0],ymm0
  61a528:	lea    rdi,[rbx+0x900]
  61a52f:	vpbroadcastd ymm0,DWORD PTR [r14+0x18]
  61a535:	vpbroadcastd ymm2,DWORD PTR [r14+0x1c]
  61a53b:	vmovdqu YMMWORD PTR [rsp+0xd0],ymm2
  61a544:	vmovdqu YMMWORD PTR [rsp+0x170],ymm1
  61a54d:	vpaddd ymm1,ymm1,ymm0
  61a551:	vmovdqu YMMWORD PTR [rsp+0xb0],ymm1
  61a55a:	vmovdqu YMMWORD PTR [rsp+0x1d0],ymm5
  61a563:	vpaddd ymm0,ymm5,ymm0
  61a567:	vmovdqu YMMWORD PTR [rsp+0x90],ymm0
  61a570:	xor    r8d,r8d
  61a573:	xor    r15d,r15d
  61a576:	vbroadcastss ymm0,DWORD PTR [r14+0x24]
  61a57c:	vmovups YMMWORD PTR [rsp+0x70],ymm0
  61a582:	vpbroadcastd ymm0,DWORD PTR [r14+0x20]
  61a588:	vmovdqu YMMWORD PTR [rsp+0x50],ymm0
  61a58e:	vmovdqa XMMWORD PTR [rsp+0x20],xmm6
  61a594:	jmp    61a980 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x630>
  61a599:	nop    DWORD PTR [rax+0x0]
  61a5a0:	mov    r12,r10
  61a5a3:	mov    r10,r15
  61a5a6:	vpunpckhqdq xmm11,xmm11,xmm12
  61a5ab:	vpunpckhdq xmm1,xmm2,xmm8
  61a5b0:	vpunpckhdq xmm0,xmm0,xmm7
  61a5b4:	vpunpcklqdq xmm2,xmm0,xmm1
  61a5b8:	vmovd  xmm0,r11d
  61a5bd:	vpbroadcastd ymm0,xmm0
  61a5c2:	mov    rdx,r10
  61a5c5:	shl    rdx,0x4
  61a5c9:	lea    r11,[rbx+0xc00]
  61a5d0:	vmovdqu XMMWORD PTR [r11+rdx*1],xmm5
  61a5d6:	vmovdqa xmm1,XMMWORD PTR [rsp+0x40]
  61a5dc:	vpshufb xmm5,xmm1,xmm14
  61a5e1:	vmovdqa xmm1,XMMWORD PTR [rsp+0x30]
  61a5e7:	vpshufb xmm1,xmm1,xmm14
  61a5ec:	vpunpcklbw xmm8,xmm5,xmm1
  61a5f0:	vpmovsxbw ymm7,xmm11
  61a5f5:	vpmovsxwd ymm12,xmm7
  61a5fa:	vextracti128 xmm7,ymm7,0x1
  61a600:	vpmovsxwd ymm7,xmm7
  61a605:	vpabsd ymm14,ymm12
  61a60a:	vpabsd ymm15,ymm7
  61a60f:	vpsrld ymm6,ymm14,0x4
  61a615:	vpbroadcastd ymm11,DWORD PTR [rip+0xffffffffffa02ba2]        # 1d1c0 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x160>
  61a61e:	vpmaxud ymm6,ymm6,ymm11
  61a623:	vpcmpeqd ymm4,ymm4,ymm4
  61a627:	vpaddd ymm6,ymm6,ymm4
  61a62b:	vpslld ymm10,ymm6,0x4
  61a630:	vpsubd ymm10,ymm14,ymm10
  61a635:	vpsrld ymm14,ymm15,0x4
  61a63b:	vpmaxud ymm14,ymm14,ymm11
  61a640:	vpaddd ymm14,ymm14,ymm4
  61a644:	vpsllvd ymm6,ymm10,ymm6
  61a649:	vpslld ymm10,ymm14,0x4
  61a64f:	vpsubd ymm10,ymm15,ymm10
  61a654:	vpsllvd ymm10,ymm10,ymm14
  61a659:	vpunpckhbw xmm1,xmm5,xmm1
  61a65d:	vpsrad ymm5,ymm12,0x1f
  61a663:	vpsrad ymm12,ymm7,0x1f
  61a668:	vpxor  ymm6,ymm6,ymm5
  61a66c:	vpxor  ymm10,ymm10,ymm12
  61a671:	vpsubd ymm7,ymm6,ymm5
  61a675:	vpsubd ymm5,ymm10,ymm12
  61a67a:	vpmovsxbw ymm2,xmm2
  61a67f:	vpmovsxwd ymm6,xmm2
  61a684:	vextracti128 xmm2,ymm2,0x1
  61a68a:	vpmovsxwd ymm10,xmm2
  61a68f:	vpabsd ymm2,ymm6
  61a694:	vpabsd ymm12,ymm10
  61a699:	vpsrld ymm14,ymm2,0x4
  61a69e:	vpsrld ymm15,ymm12,0x4
  61a6a4:	vpmaxud ymm14,ymm14,ymm11
  61a6a9:	vpaddd ymm14,ymm14,ymm4
  61a6ad:	vpmaxud ymm11,ymm15,ymm11
  61a6b2:	vpslld ymm15,ymm14,0x4
  61a6b8:	vpsubd ymm15,ymm2,ymm15
  61a6bd:	vpaddd ymm2,ymm0,YMMWORD PTR [rsp+0x170]
  61a6c6:	vpmovsxwd ymm8,xmm8
  61a6cb:	vmovdqu ymm3,YMMWORD PTR [rsp+0x150]
  61a6d4:	vpmulld ymm8,ymm3,ymm8
  61a6d9:	vpmovsxwd ymm1,xmm1
  61a6de:	vpmulld ymm13,ymm3,ymm1
  61a6e3:	vpaddd ymm1,ymm11,ymm4
  61a6e7:	vpsllvd ymm11,ymm15,ymm14
  61a6ec:	vpslld ymm14,ymm1,0x4
  61a6f1:	vpsubd ymm12,ymm12,ymm14
  61a6f6:	vpsllvd ymm1,ymm12,ymm1
  61a6fb:	vpsrad ymm6,ymm6,0x1f
  61a700:	vpsrad ymm10,ymm10,0x1f
  61a706:	vpxor  ymm11,ymm11,ymm6
  61a70a:	vpxor  ymm1,ymm10,ymm1
  61a70e:	vpsubd ymm12,ymm11,ymm6
  61a712:	vpsubd ymm1,ymm1,ymm10
  61a717:	vpmulld ymm6,ymm8,ymm7
  61a71c:	vpmulld ymm10,ymm13,ymm5
  61a721:	vpsrad ymm11,ymm6,0x1f
  61a726:	vpbroadcastd ymm15,DWORD PTR [rip+0xffffffffffa02ac9]        # 1d1f8 <anon.af0ccb9108eddc4c5519810828b65255.469.llvm.6902587646649311522+0x198>
  61a72f:	vpaddd ymm6,ymm15,ymm6
  61a733:	vpaddd ymm14,ymm11,ymm6
  61a737:	vpsrad ymm6,ymm10,0x1f
  61a73d:	vpaddd ymm10,ymm10,ymm15
  61a742:	vpmulld ymm8,ymm8,ymm12
  61a747:	vpmulld ymm13,ymm13,ymm1
  61a74c:	vpaddd ymm6,ymm10,ymm6
  61a750:	vpsrad ymm10,ymm8,0x1f
  61a756:	vpaddd ymm8,ymm8,ymm15
  61a75b:	vpaddd ymm8,ymm8,ymm10
  61a760:	vpaddd ymm11,ymm0,YMMWORD PTR [rsp+0x1d0]
  61a769:	vpaddd ymm10,ymm13,ymm15
  61a76e:	vpsrad ymm13,ymm13,0x1f
  61a774:	vpaddd ymm10,ymm10,ymm13
  61a779:	vpsrad ymm13,ymm14,0xe
  61a77f:	shl    r10,0x6
  61a783:	vmovdqu YMMWORD PTR [rsi+r10*1],ymm7
  61a789:	vpsrad ymm7,ymm6,0xe
  61a78e:	vmovdqu YMMWORD PTR [rsi+r10*1+0x20],ymm5
  61a795:	vpsrad ymm15,ymm8,0xe
  61a79b:	vmovdqu YMMWORD PTR [rsi+r10*1+0x100],ymm12
  61a7a5:	vmovdqu YMMWORD PTR [rsi+r10*1+0x120],ymm1
  61a7af:	vpsrad ymm1,ymm10,0xe
  61a7b5:	vpsrad ymm5,ymm6,0x1f
  61a7ba:	vpsrld ymm5,ymm5,0x1a
  61a7bf:	vpaddd ymm5,ymm5,ymm7
  61a7c3:	vpsrad ymm5,ymm5,0x6
  61a7c8:	vmovdqu ymm3,YMMWORD PTR [rsp+0x1b0]
  61a7d1:	vpaddd ymm5,ymm5,ymm3
  61a7d5:	vpbroadcastd ymm6,DWORD PTR [rsp+0x10]
  61a7dc:	vpand  ymm12,ymm5,ymm6
  61a7e0:	vpsrad ymm7,ymm14,0x1f
  61a7e6:	vpsrld ymm7,ymm7,0x1a
  61a7eb:	vpaddd ymm7,ymm13,ymm7
  61a7ef:	vpsrad ymm7,ymm7,0x6
  61a7f4:	vpaddd ymm7,ymm7,ymm3
  61a7f8:	vpand  ymm13,ymm7,ymm6
  61a7fc:	vpsrad ymm10,ymm10,0x1f
  61a802:	vpsrld ymm10,ymm10,0x1a
  61a808:	vpaddd ymm1,ymm10,ymm1
  61a80c:	vmovdqu ymm3,YMMWORD PTR [rsp+0x70]
  61a812:	vpminud ymm10,ymm3,ymm5
  61a817:	vpcmpeqd ymm10,ymm10,ymm3
  61a81b:	vpsrad ymm1,ymm1,0x6
  61a820:	vpaddd ymm1,ymm11,ymm1
  61a824:	vpminud ymm11,ymm3,ymm7
  61a829:	vpcmpeqd ymm11,ymm11,ymm3
  61a82d:	vpsrad ymm8,ymm8,0x1f
  61a833:	vpsrld ymm8,ymm8,0x1a
  61a839:	vpaddd ymm8,ymm8,ymm15
  61a83e:	vpand  ymm14,ymm1,ymm6
  61a842:	vpsrad ymm8,ymm8,0x6
  61a848:	vpaddd ymm8,ymm8,ymm2
  61a84c:	vpand  ymm6,ymm8,ymm6
  61a850:	vmovdqu ymm3,YMMWORD PTR [rsp+0x50]
  61a856:	vpminud ymm2,ymm3,ymm1
  61a85b:	vpcmpeqd ymm2,ymm3,ymm2
  61a85f:	vpor   ymm2,ymm10,ymm2
  61a863:	vpminud ymm10,ymm3,ymm8
  61a868:	vpcmpeqd ymm10,ymm10,ymm3
  61a86c:	vpor   ymm10,ymm11,ymm10
  61a871:	vmovdqu ymm3,YMMWORD PTR [rsp+0x110]
  61a87a:	vpsubd ymm11,ymm13,ymm3
  61a87e:	vpsubd ymm12,ymm12,ymm3
  61a882:	vmovdqu ymm3,YMMWORD PTR [rsp+0xf0]
  61a88b:	vpmulld ymm13,ymm11,ymm3
  61a890:	vpaddd ymm6,ymm13,ymm6
  61a894:	vpmulld ymm13,ymm12,ymm3
  61a899:	vpaddd ymm13,ymm13,ymm14
  61a89e:	vpsrad ymm11,ymm11,0x1f
  61a8a4:	vpor   ymm6,ymm11,ymm6
  61a8a8:	vpsrad ymm11,ymm12,0x1f
  61a8ae:	vpor   ymm11,ymm13,ymm11
  61a8b3:	vmovdqu YMMWORD PTR [rdi+r10*1],ymm6
  61a8b9:	vmovdqu YMMWORD PTR [rdi+r10*1+0x20],ymm11
  61a8c0:	vmovdqu ymm11,YMMWORD PTR [rsp+0x130]
  61a8c9:	vpand  ymm6,ymm8,ymm11
  61a8ce:	vpaddd ymm8,ymm0,YMMWORD PTR [rsp+0xb0]
  61a8d7:	vpsubd ymm6,ymm8,ymm6
  61a8db:	vpand  ymm1,ymm11,ymm1
  61a8df:	vpaddd ymm0,ymm0,YMMWORD PTR [rsp+0x90]
  61a8e8:	vpsubd ymm0,ymm0,ymm1
  61a8ec:	vpand  ymm1,ymm11,ymm7
  61a8f0:	vmovdqu ymm3,YMMWORD PTR [rsp+0x190]
  61a8f9:	vpcmpeqd ymm1,ymm1,ymm3
  61a8fd:	vmovdqu ymm7,YMMWORD PTR [rsp+0xd0]
  61a906:	vpminud ymm6,ymm7,ymm6
  61a90b:	vpcmpeqd ymm6,ymm7,ymm6
  61a90f:	vpandn ymm1,ymm6,ymm1
  61a913:	vpandn ymm1,ymm10,ymm1
  61a917:	vpand  ymm5,ymm11,ymm5
  61a91b:	vpcmpeqd ymm5,ymm5,ymm3
  61a91f:	vpminud ymm0,ymm7,ymm0
  61a924:	vpcmpeqd ymm0,ymm7,ymm0
  61a928:	vpandn ymm0,ymm0,ymm5
  61a92c:	vpandn ymm0,ymm2,ymm0
  61a930:	vpbroadcastd ymm2,DWORD PTR [rip+0xffffffffffa02327]        # 1cc60 <anon.649ecabb9e332bb1a240e71ce869be46.1546.llvm.17552640369805532478+0xc20>
  61a939:	vpand  ymm1,ymm1,ymm2
  61a93d:	vpand  ymm0,ymm0,ymm2
  61a941:	vextracti128 xmm2,ymm0,0x1
  61a947:	vpackusdw xmm0,xmm0,xmm2
  61a94c:	vextracti128 xmm2,ymm1,0x1
  61a952:	vpackusdw xmm1,xmm1,xmm2
  61a957:	vpackuswb xmm0,xmm1,xmm0
  61a95b:	vmovdqa xmm6,XMMWORD PTR [rsp+0x20]
  61a961:	vpand  xmm1,xmm9,xmm6
  61a965:	vpand  xmm0,xmm1,xmm0
  61a969:	vpxor  xmm1,xmm1,xmm1
  61a96d:	vpcmpgtb xmm0,xmm0,xmm1
  61a971:	vpmovmskb edx,xmm0
  61a975:	shlx   rdx,rdx,r9
  61a97a:	or     r8,rdx
  61a97d:	mov    r15,r12
  61a980:	cmp    r13,0x1
  61a984:	jne    61aa60 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x710>
  61a98a:	cmp    r15,rcx
  61a98d:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61a993:	mov    r9,r15
  61a996:	shl    r9,0x4
  61a99a:	lea    r11,[r9+rax*1]
  61a99e:	cmp    r11,0x7fffffff
  61a9a5:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61a9ab:	lea    rdx,[r15+r15*2]
  61a9af:	shl    rdx,0x5
  61a9b3:	vmovdqu xmm0,XMMWORD PTR [rbx+rdx*1]
  61a9b8:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x6]
  61a9be:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x30]
  61a9c4:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x36]
  61a9ca:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x10],0x4
  61a9d2:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x20],0x2
  61a9da:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+rdx*1+0x40],0x4
  61a9e2:	vpblendd xmm7,xmm2,XMMWORD PTR [rbx+rdx*1+0x50],0x2
  61a9ea:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdx*1+0x16],0x4
  61a9f2:	vpblendd xmm2,xmm1,XMMWORD PTR [rbx+rdx*1+0x26],0x2
  61a9fa:	vpblendd xmm1,xmm5,XMMWORD PTR [rbx+rdx*1+0x46],0x4
  61aa02:	vpblendd xmm8,xmm1,XMMWORD PTR [rbx+rdx*1+0x56],0x2
  61aa0a:	lea    r10,[r15+0x1]
  61aa0e:	vmovq  xmm3,QWORD PTR [rip+0xffffffffff9fb33a]        # 15d50 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1f00>
  61aa16:	vpshufb xmm1,xmm2,xmm3
  61aa1b:	vpshufb xmm5,xmm0,xmm3
  61aa20:	vpunpcklbw xmm11,xmm5,xmm1
  61aa24:	vpshufb xmm1,xmm8,xmm3
  61aa29:	vpshufb xmm5,xmm7,xmm3
  61aa2e:	vpunpcklbw xmm12,xmm5,xmm1
  61aa32:	vpunpcklqdq xmm5,xmm11,xmm12
  61aa37:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f9021]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61aa3f:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61aa44:	vpshufb xmm9,xmm1,xmm14
  61aa49:	vptest xmm9,xmm6
  61aa4e:	je     61ac6a <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x91a>
  61aa54:	mov    r12,r10
  61aa57:	mov    r10,r15
  61aa5a:	jmp    61b2f0 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfa0>
  61aa5f:	nop
  61aa60:	cmp    r15,rcx
  61aa63:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61aa69:	mov    r9,r15
  61aa6c:	shl    r9,0x4
  61aa70:	mov    r11,r9
  61aa73:	imul   r11,r13
  61aa77:	add    r11,rax
  61aa7a:	test   r11,0xffffffff80000000
  61aa81:	jne    61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61aa87:	lea    r10,[r15+0x1]
  61aa8b:	lea    rdx,[r15+r15*2]
  61aa8f:	shl    rdx,0x6
  61aa93:	vmovdqu xmm0,XMMWORD PTR [rbx+rdx*1]
  61aa98:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x20]
  61aa9e:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x30]
  61aaa4:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x50]
  61aaaa:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x10],0x4
  61aab2:	vmovdqa xmm3,XMMWORD PTR [rip+0xffffffffff9fad26]        # 157e0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1990>
  61aaba:	vpshufb xmm1,xmm1,xmm3
  61aabf:	vmovdqa xmm4,XMMWORD PTR [rip+0xffffffffff9fbc99]        # 16760 <anon.04501cfa98bd26ad8a51aa7d966155f9.109.llvm.3626723408307321437+0x290>
  61aac7:	vpshufb xmm0,xmm0,xmm4
  61aacc:	vpor   xmm0,xmm0,xmm1
  61aad0:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+rdx*1+0x40],0x4
  61aad8:	vpshufb xmm2,xmm5,xmm3
  61aadd:	vpshufb xmm1,xmm1,xmm4
  61aae2:	vpor   xmm7,xmm1,xmm2
  61aae6:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x80]
  61aaef:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x60]
  61aaf5:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+rdx*1+0x70],0x4
  61aafd:	vpshufb xmm1,xmm1,xmm3
  61ab02:	vpshufb xmm2,xmm2,xmm4
  61ab07:	vpor   xmm2,xmm2,xmm1
  61ab0b:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0xb0]
  61ab14:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x90]
  61ab1d:	vpblendd xmm5,xmm5,XMMWORD PTR [rbx+rdx*1+0xa0],0x4
  61ab28:	vpshufb xmm1,xmm1,xmm3
  61ab2d:	vpshufb xmm5,xmm5,xmm4
  61ab32:	vpor   xmm8,xmm5,xmm1
  61ab36:	vpunpckldq xmm11,xmm0,xmm7
  61ab3a:	vpunpckldq xmm12,xmm2,xmm8
  61ab3f:	vpunpcklqdq xmm5,xmm11,xmm12
  61ab44:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8f14]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61ab4c:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61ab51:	vpshufb xmm9,xmm1,xmm14
  61ab56:	vptest xmm9,xmm6
  61ab5b:	jne    61a5a0 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x250>
  61ab61:	cmp    r10,rcx
  61ab64:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61ab6a:	mov    r9,r10
  61ab6d:	shl    r9,0x4
  61ab71:	mov    r11,r9
  61ab74:	imul   r11,r13
  61ab78:	add    r11,rax
  61ab7b:	cmp    r11,0x7fffffff
  61ab82:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61ab88:	lea    r14,[r15+0x2]
  61ab8c:	lea    rdx,[r10+r10*2]
  61ab90:	shl    rdx,0x6
  61ab94:	vmovdqu xmm0,XMMWORD PTR [rbx+rdx*1]
  61ab99:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x20]
  61ab9f:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x30]
  61aba5:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x50]
  61abab:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x10],0x4
  61abb3:	vmovdqa xmm3,XMMWORD PTR [rip+0xffffffffff9fac25]        # 157e0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1990>
  61abbb:	vpshufb xmm1,xmm1,xmm3
  61abc0:	vmovdqa xmm4,XMMWORD PTR [rip+0xffffffffff9fbb98]        # 16760 <anon.04501cfa98bd26ad8a51aa7d966155f9.109.llvm.3626723408307321437+0x290>
  61abc8:	vpshufb xmm0,xmm0,xmm4
  61abcd:	vpor   xmm0,xmm0,xmm1
  61abd1:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+rdx*1+0x40],0x4
  61abd9:	vpshufb xmm2,xmm5,xmm3
  61abde:	vpshufb xmm1,xmm1,xmm4
  61abe3:	vpor   xmm7,xmm1,xmm2
  61abe7:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x80]
  61abf0:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x60]
  61abf6:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+rdx*1+0x70],0x4
  61abfe:	vpshufb xmm1,xmm1,xmm3
  61ac03:	vpshufb xmm2,xmm2,xmm4
  61ac08:	vpor   xmm2,xmm2,xmm1
  61ac0c:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0xb0]
  61ac15:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x90]
  61ac1e:	vpblendd xmm5,xmm5,XMMWORD PTR [rbx+rdx*1+0xa0],0x4
  61ac29:	vpshufb xmm1,xmm1,xmm3
  61ac2e:	vpshufb xmm5,xmm5,xmm4
  61ac33:	vpor   xmm8,xmm5,xmm1
  61ac37:	vpunpckldq xmm11,xmm0,xmm7
  61ac3b:	vpunpckldq xmm12,xmm2,xmm8
  61ac40:	vpunpcklqdq xmm5,xmm11,xmm12
  61ac45:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8e13]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61ac4d:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61ac52:	vpshufb xmm9,xmm1,xmm14
  61ac57:	vptest xmm9,xmm6
  61ac5c:	je     61ad3c <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x9ec>
  61ac62:	mov    r12,r14
  61ac65:	jmp    61a5a6 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x256>
  61ac6a:	cmp    r10,rcx
  61ac6d:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61ac73:	mov    r9,r10
  61ac76:	shl    r9,0x4
  61ac7a:	lea    r11,[r9+rax*1]
  61ac7e:	cmp    r11,0x7fffffff
  61ac85:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61ac8b:	lea    rdx,[r10+r10*2]
  61ac8f:	shl    rdx,0x5
  61ac93:	vmovdqu xmm0,XMMWORD PTR [rbx+rdx*1]
  61ac98:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x6]
  61ac9e:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x30]
  61aca4:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x36]
  61acaa:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x10],0x4
  61acb2:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x20],0x2
  61acba:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+rdx*1+0x40],0x4
  61acc2:	vpblendd xmm7,xmm2,XMMWORD PTR [rbx+rdx*1+0x50],0x2
  61acca:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdx*1+0x16],0x4
  61acd2:	vpblendd xmm2,xmm1,XMMWORD PTR [rbx+rdx*1+0x26],0x2
  61acda:	vpblendd xmm1,xmm5,XMMWORD PTR [rbx+rdx*1+0x46],0x4
  61ace2:	vpblendd xmm8,xmm1,XMMWORD PTR [rbx+rdx*1+0x56],0x2
  61acea:	lea    rdx,[r15+0x2]
  61acee:	vmovq  xmm3,QWORD PTR [rip+0xffffffffff9fb05a]        # 15d50 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1f00>
  61acf6:	vpshufb xmm1,xmm2,xmm3
  61acfb:	vpshufb xmm5,xmm0,xmm3
  61ad00:	vpunpcklbw xmm11,xmm5,xmm1
  61ad04:	vpshufb xmm1,xmm8,xmm3
  61ad09:	vpshufb xmm5,xmm7,xmm3
  61ad0e:	vpunpcklbw xmm12,xmm5,xmm1
  61ad12:	vpunpcklqdq xmm5,xmm11,xmm12
  61ad17:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8d41]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61ad1f:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61ad24:	vpshufb xmm9,xmm1,xmm14
  61ad29:	vptest xmm9,xmm6
  61ad2e:	je     61ae50 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xb00>
  61ad34:	mov    r12,rdx
  61ad37:	jmp    61b2f0 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfa0>
  61ad3c:	cmp    r14,rcx
  61ad3f:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61ad45:	mov    r9,r14
  61ad48:	shl    r9,0x4
  61ad4c:	mov    r11,r9
  61ad4f:	imul   r11,r13
  61ad53:	add    r11,rax
  61ad56:	cmp    r11,0x7fffffff
  61ad5d:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61ad63:	lea    rdx,[r15+0x3]
  61ad67:	lea    r10,[r14+r14*2]
  61ad6b:	shl    r10,0x6
  61ad6f:	vmovdqu xmm0,XMMWORD PTR [rbx+r10*1]
  61ad75:	vmovdqu xmm1,XMMWORD PTR [rbx+r10*1+0x20]
  61ad7c:	vmovdqu xmm2,XMMWORD PTR [rbx+r10*1+0x30]
  61ad83:	vmovdqu xmm5,XMMWORD PTR [rbx+r10*1+0x50]
  61ad8a:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r10*1+0x10],0x4
  61ad92:	vmovdqa xmm3,XMMWORD PTR [rip+0xffffffffff9faa46]        # 157e0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1990>
  61ad9a:	vpshufb xmm1,xmm1,xmm3
  61ad9f:	vmovdqa xmm4,XMMWORD PTR [rip+0xffffffffff9fb9b9]        # 16760 <anon.04501cfa98bd26ad8a51aa7d966155f9.109.llvm.3626723408307321437+0x290>
  61ada7:	vpshufb xmm0,xmm0,xmm4
  61adac:	vpor   xmm0,xmm0,xmm1
  61adb0:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+r10*1+0x40],0x4
  61adb8:	vpshufb xmm2,xmm5,xmm3
  61adbd:	vpshufb xmm1,xmm1,xmm4
  61adc2:	vpor   xmm7,xmm1,xmm2
  61adc6:	vmovdqu xmm1,XMMWORD PTR [rbx+r10*1+0x80]
  61add0:	vmovdqu xmm2,XMMWORD PTR [rbx+r10*1+0x60]
  61add7:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r10*1+0x70],0x4
  61addf:	vpshufb xmm1,xmm1,xmm3
  61ade4:	vpshufb xmm2,xmm2,xmm4
  61ade9:	vpor   xmm2,xmm2,xmm1
  61aded:	vmovdqu xmm1,XMMWORD PTR [rbx+r10*1+0xb0]
  61adf7:	vmovdqu xmm5,XMMWORD PTR [rbx+r10*1+0x90]
  61ae01:	vpblendd xmm5,xmm5,XMMWORD PTR [rbx+r10*1+0xa0],0x4
  61ae0c:	vpshufb xmm1,xmm1,xmm3
  61ae11:	vpshufb xmm5,xmm5,xmm4
  61ae16:	vpor   xmm8,xmm5,xmm1
  61ae1a:	vpunpckldq xmm11,xmm0,xmm7
  61ae1e:	vpunpckldq xmm12,xmm2,xmm8
  61ae23:	vpunpcklqdq xmm5,xmm11,xmm12
  61ae28:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8c30]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61ae30:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61ae35:	vpshufb xmm9,xmm1,xmm14
  61ae3a:	vptest xmm9,xmm6
  61ae3f:	je     61af29 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xbd9>
  61ae45:	mov    r12,rdx
  61ae48:	mov    r10,r14
  61ae4b:	jmp    61a5a6 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x256>
  61ae50:	cmp    rdx,rcx
  61ae53:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61ae59:	mov    r9,rdx
  61ae5c:	shl    r9,0x4
  61ae60:	lea    r11,[r9+rax*1]
  61ae64:	cmp    r11,0x7fffffff
  61ae6b:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61ae71:	lea    r10,[rdx+rdx*2]
  61ae75:	shl    r10,0x5
  61ae79:	vmovdqu xmm0,XMMWORD PTR [rbx+r10*1]
  61ae7f:	vmovdqu xmm1,XMMWORD PTR [rbx+r10*1+0x6]
  61ae86:	vmovdqu xmm2,XMMWORD PTR [rbx+r10*1+0x30]
  61ae8d:	vmovdqu xmm5,XMMWORD PTR [rbx+r10*1+0x36]
  61ae94:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r10*1+0x10],0x4
  61ae9c:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r10*1+0x20],0x2
  61aea4:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r10*1+0x40],0x4
  61aeac:	vpblendd xmm7,xmm2,XMMWORD PTR [rbx+r10*1+0x50],0x2
  61aeb4:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+r10*1+0x16],0x4
  61aebc:	vpblendd xmm2,xmm1,XMMWORD PTR [rbx+r10*1+0x26],0x2
  61aec4:	vpblendd xmm1,xmm5,XMMWORD PTR [rbx+r10*1+0x46],0x4
  61aecc:	vpblendd xmm8,xmm1,XMMWORD PTR [rbx+r10*1+0x56],0x2
  61aed4:	lea    r14,[r15+0x3]
  61aed8:	vmovq  xmm3,QWORD PTR [rip+0xffffffffff9fae70]        # 15d50 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1f00>
  61aee0:	vpshufb xmm1,xmm2,xmm3
  61aee5:	vpshufb xmm5,xmm0,xmm3
  61aeea:	vpunpcklbw xmm11,xmm5,xmm1
  61aeee:	vpshufb xmm1,xmm8,xmm3
  61aef3:	vpshufb xmm5,xmm7,xmm3
  61aef8:	vpunpcklbw xmm12,xmm5,xmm1
  61aefc:	vpunpcklqdq xmm5,xmm11,xmm12
  61af01:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8b57]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61af09:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61af0e:	vpshufb xmm9,xmm1,xmm14
  61af13:	vptest xmm9,xmm6
  61af18:	je     61b03d <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xced>
  61af1e:	mov    r12,r14
  61af21:	mov    r10,rdx
  61af24:	jmp    61b2f0 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfa0>
  61af29:	cmp    rdx,rcx
  61af2c:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61af32:	mov    r9,rdx
  61af35:	shl    r9,0x4
  61af39:	mov    r11,r9
  61af3c:	imul   r11,r13
  61af40:	add    r11,rax
  61af43:	cmp    r11,0x7fffffff
  61af4a:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61af50:	lea    r10,[r15+0x4]
  61af54:	lea    r14,[rdx+rdx*2]
  61af58:	shl    r14,0x6
  61af5c:	vmovdqu xmm0,XMMWORD PTR [rbx+r14*1]
  61af62:	vmovdqu xmm1,XMMWORD PTR [rbx+r14*1+0x20]
  61af69:	vmovdqu xmm2,XMMWORD PTR [rbx+r14*1+0x30]
  61af70:	vmovdqu xmm5,XMMWORD PTR [rbx+r14*1+0x50]
  61af77:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+r14*1+0x10],0x4
  61af7f:	vmovdqa xmm3,XMMWORD PTR [rip+0xffffffffff9fa859]        # 157e0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1990>
  61af87:	vpshufb xmm1,xmm1,xmm3
  61af8c:	vmovdqa xmm4,XMMWORD PTR [rip+0xffffffffff9fb7cc]        # 16760 <anon.04501cfa98bd26ad8a51aa7d966155f9.109.llvm.3626723408307321437+0x290>
  61af94:	vpshufb xmm0,xmm0,xmm4
  61af99:	vpor   xmm0,xmm0,xmm1
  61af9d:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+r14*1+0x40],0x4
  61afa5:	vpshufb xmm2,xmm5,xmm3
  61afaa:	vpshufb xmm1,xmm1,xmm4
  61afaf:	vpor   xmm7,xmm1,xmm2
  61afb3:	vmovdqu xmm1,XMMWORD PTR [rbx+r14*1+0x80]
  61afbd:	vmovdqu xmm2,XMMWORD PTR [rbx+r14*1+0x60]
  61afc4:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+r14*1+0x70],0x4
  61afcc:	vpshufb xmm1,xmm1,xmm3
  61afd1:	vpshufb xmm2,xmm2,xmm4
  61afd6:	vpor   xmm2,xmm2,xmm1
  61afda:	vmovdqu xmm1,XMMWORD PTR [rbx+r14*1+0xb0]
  61afe4:	vmovdqu xmm5,XMMWORD PTR [rbx+r14*1+0x90]
  61afee:	vpblendd xmm5,xmm5,XMMWORD PTR [rbx+r14*1+0xa0],0x4
  61aff9:	vpshufb xmm1,xmm1,xmm3
  61affe:	vpshufb xmm5,xmm5,xmm4
  61b003:	vpor   xmm8,xmm5,xmm1
  61b007:	vpunpckldq xmm11,xmm0,xmm7
  61b00b:	vpunpckldq xmm12,xmm2,xmm8
  61b010:	vpunpcklqdq xmm5,xmm11,xmm12
  61b015:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8a43]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61b01d:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61b022:	vpshufb xmm9,xmm1,xmm14
  61b027:	vptest xmm9,xmm6
  61b02c:	je     61b112 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xdc2>
  61b032:	mov    r12,r10
  61b035:	mov    r10,rdx
  61b038:	jmp    61a5a6 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x256>
  61b03d:	cmp    r14,rcx
  61b040:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61b046:	mov    r9,r14
  61b049:	shl    r9,0x4
  61b04d:	lea    r11,[r9+rax*1]
  61b051:	cmp    r11,0x7fffffff
  61b058:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61b05e:	lea    rdx,[r14+r14*2]
  61b062:	shl    rdx,0x5
  61b066:	vmovdqu xmm0,XMMWORD PTR [rbx+rdx*1]
  61b06b:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x6]
  61b071:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x30]
  61b077:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x36]
  61b07d:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x10],0x4
  61b085:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x20],0x2
  61b08d:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+rdx*1+0x40],0x4
  61b095:	vpblendd xmm7,xmm2,XMMWORD PTR [rbx+rdx*1+0x50],0x2
  61b09d:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdx*1+0x16],0x4
  61b0a5:	vpblendd xmm2,xmm1,XMMWORD PTR [rbx+rdx*1+0x26],0x2
  61b0ad:	vpblendd xmm1,xmm5,XMMWORD PTR [rbx+rdx*1+0x46],0x4
  61b0b5:	vpblendd xmm8,xmm1,XMMWORD PTR [rbx+rdx*1+0x56],0x2
  61b0bd:	lea    r10,[r15+0x4]
  61b0c1:	vmovq  xmm3,QWORD PTR [rip+0xffffffffff9fac87]        # 15d50 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1f00>
  61b0c9:	vpshufb xmm1,xmm2,xmm3
  61b0ce:	vpshufb xmm5,xmm0,xmm3
  61b0d3:	vpunpcklbw xmm11,xmm5,xmm1
  61b0d7:	vpshufb xmm1,xmm8,xmm3
  61b0dc:	vpshufb xmm5,xmm7,xmm3
  61b0e1:	vpunpcklbw xmm12,xmm5,xmm1
  61b0e5:	vpunpcklqdq xmm5,xmm11,xmm12
  61b0ea:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f896e]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61b0f2:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61b0f7:	vpshufb xmm9,xmm1,xmm14
  61b0fc:	vptest xmm9,xmm6
  61b101:	je     61b21b <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xecb>
  61b107:	mov    r12,r10
  61b10a:	mov    r10,r14
  61b10d:	jmp    61b2f0 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfa0>
  61b112:	cmp    r10,rcx
  61b115:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61b11b:	mov    r9,r10
  61b11e:	shl    r9,0x4
  61b122:	mov    r11,r9
  61b125:	imul   r11,r13
  61b129:	add    r11,rax
  61b12c:	cmp    r11,0x7fffffff
  61b133:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61b139:	lea    rdx,[r10+r10*2]
  61b13d:	shl    rdx,0x6
  61b141:	vmovdqu xmm0,XMMWORD PTR [rbx+rdx*1]
  61b146:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x20]
  61b14c:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x30]
  61b152:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x50]
  61b158:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x10],0x4
  61b160:	vmovdqa xmm3,XMMWORD PTR [rip+0xffffffffff9fa678]        # 157e0 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1990>
  61b168:	vpshufb xmm1,xmm1,xmm3
  61b16d:	vmovdqa xmm4,XMMWORD PTR [rip+0xffffffffff9fb5eb]        # 16760 <anon.04501cfa98bd26ad8a51aa7d966155f9.109.llvm.3626723408307321437+0x290>
  61b175:	vpshufb xmm0,xmm0,xmm4
  61b17a:	vpor   xmm0,xmm0,xmm1
  61b17e:	vpblendd xmm1,xmm2,XMMWORD PTR [rbx+rdx*1+0x40],0x4
  61b186:	vpshufb xmm2,xmm5,xmm3
  61b18b:	vpshufb xmm1,xmm1,xmm4
  61b190:	vpor   xmm7,xmm1,xmm2
  61b194:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x80]
  61b19d:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x60]
  61b1a3:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+rdx*1+0x70],0x4
  61b1ab:	vpshufb xmm1,xmm1,xmm3
  61b1b0:	vpshufb xmm2,xmm2,xmm4
  61b1b5:	vpor   xmm2,xmm2,xmm1
  61b1b9:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0xb0]
  61b1c2:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x90]
  61b1cb:	vpblendd xmm5,xmm5,XMMWORD PTR [rbx+rdx*1+0xa0],0x4
  61b1d6:	vpshufb xmm1,xmm1,xmm3
  61b1db:	vpshufb xmm5,xmm5,xmm4
  61b1e0:	vpor   xmm8,xmm5,xmm1
  61b1e4:	vpunpckldq xmm11,xmm0,xmm7
  61b1e8:	vpunpckldq xmm12,xmm2,xmm8
  61b1ed:	vpunpcklqdq xmm5,xmm11,xmm12
  61b1f2:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8866]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61b1fa:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61b1ff:	vpshufb xmm9,xmm1,xmm14
  61b204:	vptest xmm9,xmm6
  61b209:	je     61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61b20f:	add    r15,0x5
  61b213:	mov    r12,r15
  61b216:	jmp    61a5a6 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x256>
  61b21b:	cmp    r10,rcx
  61b21e:	jae    61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61b224:	mov    r9,r10
  61b227:	shl    r9,0x4
  61b22b:	lea    r11,[r9+rax*1]
  61b22f:	cmp    r11,0x7fffffff
  61b236:	ja     61b332 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe2>
  61b23c:	lea    rdx,[r10+r10*2]
  61b240:	shl    rdx,0x5
  61b244:	vmovdqu xmm0,XMMWORD PTR [rbx+rdx*1]
  61b249:	vmovdqu xmm1,XMMWORD PTR [rbx+rdx*1+0x6]
  61b24f:	vmovdqu xmm2,XMMWORD PTR [rbx+rdx*1+0x30]
  61b255:	vmovdqu xmm5,XMMWORD PTR [rbx+rdx*1+0x36]
  61b25b:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x10],0x4
  61b263:	vpblendd xmm0,xmm0,XMMWORD PTR [rbx+rdx*1+0x20],0x2
  61b26b:	vpblendd xmm2,xmm2,XMMWORD PTR [rbx+rdx*1+0x40],0x4
  61b273:	vpblendd xmm7,xmm2,XMMWORD PTR [rbx+rdx*1+0x50],0x2
  61b27b:	vpblendd xmm1,xmm1,XMMWORD PTR [rbx+rdx*1+0x16],0x4
  61b283:	vpblendd xmm2,xmm1,XMMWORD PTR [rbx+rdx*1+0x26],0x2
  61b28b:	vpblendd xmm1,xmm5,XMMWORD PTR [rbx+rdx*1+0x46],0x4
  61b293:	vpblendd xmm8,xmm1,XMMWORD PTR [rbx+rdx*1+0x56],0x2
  61b29b:	vmovq  xmm3,QWORD PTR [rip+0xffffffffff9faaad]        # 15d50 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x1f00>
  61b2a3:	vpshufb xmm1,xmm2,xmm3
  61b2a8:	vpshufb xmm5,xmm0,xmm3
  61b2ad:	vpunpcklbw xmm11,xmm5,xmm1
  61b2b1:	vpshufb xmm1,xmm8,xmm3
  61b2b6:	vpshufb xmm5,xmm7,xmm3
  61b2bb:	vpunpcklbw xmm12,xmm5,xmm1
  61b2bf:	vpunpcklqdq xmm5,xmm11,xmm12
  61b2c4:	vpaddusb xmm14,xmm5,XMMWORD PTR [rip+0xffffffffff9f8794]        # 13a60 <anon.6fd802c80714054f9ed2fdb588ad366e.0.llvm.496448681855621260+0x740>
  61b2cc:	vmovdqa xmm1,XMMWORD PTR [rsp]
  61b2d1:	vpshufb xmm9,xmm1,xmm14
  61b2d6:	vptest xmm9,xmm6
  61b2db:	je     61b31e <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfce>
  61b2dd:	add    r15,0x5
  61b2e1:	mov    r12,r15
  61b2e4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  61b2f0:	vpunpckhqdq xmm11,xmm11,xmm12
  61b2f5:	vmovd  xmm3,DWORD PTR [rip+0xffffffffff9f8f53]        # 14250 <anon.af0ccb9108eddc4c5519810828b65255.410.llvm.6902587646649311522+0x400>
  61b2fd:	vpshufb xmm1,xmm2,xmm3
  61b302:	vpshufb xmm0,xmm0,xmm3
  61b307:	vpunpcklbw xmm0,xmm0,xmm1
  61b30b:	vpshufb xmm1,xmm8,xmm3
  61b310:	vpshufb xmm2,xmm7,xmm3
  61b315:	vpunpcklbw xmm1,xmm2,xmm1
  61b319:	jmp    61a5b4 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0x264>
  61b31e:	cmp    rbp,0x1
  61b322:	adc    rbp,0x0
  61b326:	bzhi   rdx,r8,rbp
  61b32b:	mov    eax,0x1
  61b330:	jmp    61b334 <_RINvNtNtNtNtNtCsdbBTXDzdjsm_12splot_decode10prediction5inter13find_mv_stack8temporal4scan11chunk_lanesNtNtNtCs9DW4HO7zhlu_13fearless_simd9generated4avx24Avx2Kb0_EBc_+0xfe4>
  61b332:	xor    eax,eax
  61b334:	add    rsp,0x1f8
  61b33b:	pop    rbx
  61b33c:	pop    r12
  61b33e:	pop    r13
  61b340:	pop    r14
  61b342:	pop    r15
  61b344:	pop    rbp
  61b345:	vzeroupper
  61b348:	ret
  61b349:	lea    rdi,[rip+0x57b120]        # b96470 <anon.46ccc32afff085b8b120907cd1a28060.160.llvm.2116171125858951624+0x1d98>
  61b350:	call   QWORD PTR [rip+0x58c6a2]        # ba79f8 <_DYNAMIC+0x748>
