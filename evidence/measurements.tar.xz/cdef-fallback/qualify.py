"""Check full decode parity and report matched CDEF edges in two existing prefixes."""

from hashlib import sha256
from pathlib import Path
from runpy import run_path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BASELINE = ROOT / "final-integration/splot.full"
CANDIDATE = HERE / "target/release/splot"
STREAMS = {
    "Noise_Ocean": ("Noise_Ocean_1920x1080_60fps_qp135_130f.ivf", 130),
    "RitualDance": ("RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf", 600),
}
CALLGRIND = run_path(str(ROOT / "noise-stage-breakdown.py"))["read"]


def verify_hashes():
    print("stream\tframes\texact_base_sha256\tcandidate_sha256", flush=True)
    for name, (filename, frame_count) in STREAMS.items():
        source = ROOT / "ci-data" / filename
        hashes = {}
        for variant, binary in (("base", BASELINE), ("new", CANDIDATE)):
            output = subprocess.check_output([
                binary, "decode", source, "--threads", "1", "--frame-delay", "1",
                "--output-format", "hash", "-o", "-",
            ])
            count = sum(line.startswith(b"frame.output_index: ")
                        for line in output.splitlines())
            assert count == frame_count, (name, variant, count)
            (HERE / f"{name}-{variant}.hash").write_bytes(output)
            hashes[variant] = sha256(output).hexdigest()
        print(f"{name}\t{frame_count}\t{hashes['base']}\t{hashes['new']}", flush=True)
        assert hashes["base"] == hashes["new"], name


def matched_edge(edges, calls, source, target):
    matches = [(n, edges[a, b]) for (a, b), n in calls.items()
               if source in a and re.search(target, b)]
    return sum(n for n, _ in matches), sum(ir for _, ir in matches)


def report_counters():
    for name in STREAMS:
        pair = [CALLGRIND(HERE / f"{name}-{label}.cg") for label in ("base", "new")]
        base, candidate = (profile[0].total() for profile in pair)
        print(f"{name}\t{base}\t{candidate}\t{candidate - base:+d}\t{candidate / base - 1:+.3%}")
        for label, caller, callee in (
            ("padded interior luma", "::filter_pad_into", "false>::{closure#0}, bool>"),
            ("padded boundary planes", "::filter_pad_into", "true>::{closure#0}, bool>"),
            ("paired chroma", "::compute_cdef_chroma_pair", "cdef_filter_block_chroma_pair_with"),
            ("direction", "::OwnedFilterSetup", r"cdef_direction_padded_with(?:::)?<"),
            ("CDEF segment", "::OwnedFilterSetup", "::cdef_segment::"),
        ):
            previous, current = (matched_edge(edges, calls, caller, callee) for _, edges, calls in pair)
            print(f"  {label}: base {previous[0]:,} calls/{previous[1]:,} Ir, "
                  f"candidate {current[0]:,} calls/{current[1]:,} Ir")


if __name__ == "__main__":
    if sys.argv[1:] == ["hash"]:
        verify_hashes()
    elif sys.argv[1:] == ["counters"]:
        report_counters()
