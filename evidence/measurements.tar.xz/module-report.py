from pathlib import Path
import re, subprocess
root=Path(__file__).resolve().parent
timings=(root/'module-four-way.txt').read_text()
body=['## Shared CDEF module experiment on native AVX2',
'The measured source is `31028cc8` on `experiment/simd-1934-cdef-module`. The prototype moves the existing two-plane, 8-bit CDEF chroma gather into a shared Rust implementation and gives it concrete SSE2 and AVX2 entry points. The decoder and tile parsers each retain one implementation. Both units are linked into the CLI and C shared library. The AVX2 entry requires the capability token from the startup-selected backend.',
'The **function** and **module** builds use identical sources. The former uses normal portable release compilation. The latter applies the exact CPU-feature contract of Fearless SIMD 1.2.0 only to the AVX2 kernel unit, retaining the baseline target for the decoder. The previous **in-tree** build is `d67efd2d` before extraction, and **shipped** is the v3 reference `10279846`. An external Cargo consumer must opt into the prototype wrapper to get the separate compiler settings.',
'### Kernel results',
'On the i7-12700H (CPU 4), 12 alternating pairs from a standalone Rust consumer, each measuring one million gathers over 128 inputs, gave these results. Positive elapsed changes mean slower. Native SSE2, AVX2 and Auto matched an independent scalar oracle for all packed-output bytes and all four computed ranges, including partial writes on short input. Strict x86-64 emulation selected SSE2 and rejected forced AVX2.',
'```text\n'+(root/'micro-times.txt').read_text().strip()+'\n```',
'The module microbenchmark links the AVX2 loop as a 632-byte leaf with zero calls or CPUID instructions. The function-scoped reference has a separate vectorization wrapper and an outlined array helper. Both binaries retain a 1,662-byte SSE2 entry. The hardware dispatch policy is identical.',
'### End-to-end elapsed time',
'Twelve paired samples per workload and comparator, balanced across all four launch positions, with one pinned worker after a warmup. WITCHER3 and TunnelFlag use 40 frames each. Noise_Ocean uses its 16-frame CI prefix. The reported intervals are paired 95% bootstrap intervals.',
'| Input | Module vs function | Module vs in-tree | Module vs shipped v3 |\n|---|---:|---:|---:|']
for stream in ('WITCHER3','TunnelFlag','Noise'):
    values=[re.search(rf'^{stream} module/{base} elapsed: ([-+.0-9]+%) (\[[^\]]+\])',timings,re.M) for base in ('function','kernels','shipped')]
    body[-1]+='\n| '+('Noise_Ocean' if stream=='Noise' else stream)+' | '+' | '.join(f'{v[1]} {v[2]}' for v in values)+' |'
body+=['The AVX2 gather improved and the Noise_Ocean playback interval excludes zero. The other two same-source playback intervals include zero. Against the shipped decoder all three regressions exceed the release target. #1987 remains a draft. Measured revision `31028cc8` is preserved. Follow-up `1c862590` cleans up the wrapper’s handling of test targets and refreshes the fuzz lockfile.', '### Guest instructions and artifacts',
'Both columns use the same invocation and the same machine. This separates code generation from wall-clock variation.',
'| Input | Function instructions | Module instructions | Change |\n|---|---:|---:|---:|']
for stream in ('Noise_Ocean','WITCHER3','TunnelFlag'):
    vals=[]
    for variant in ('function','module'):
        profile = 'Noise_Ocean_qp135' if stream == 'Noise_Ocean' else stream
        vals.append(int(re.search(r'^summary: (\d+)',(root/f'cdef-{variant}/{profile}.cg').read_text(),re.M)[1]))
    body[-1]+=f'\n| {stream} | {vals[0]:,} | {vals[1]:,} | {(vals[1]/vals[0]-1)*100:+.3f}% |'
body+=['| Stripped artifact | Function | Module | Change |\n|---|---:|---:|---:|']
for name in ('splot','libsplot_capi.so'):
    sizes=[]
    for v in ('function','module'):
        exe=root/f'cdef-{v}/target/release'/name
        stripped=root/f'cdef-{v}'/(name+'.stripped')
        subprocess.run(['strip','-o',stripped,exe],check=True)
        sizes.append(stripped.stat().st_size)
    body[-1]+=f'\n| {name} | {sizes[0]:,} | {sizes[1]:,} | {sizes[1]-sizes[0]:+,} |'
assert len((root/'cdef-module/avm.txt').read_text().splitlines())==21
assert (root/'module-sse2-fixtures.log').read_text().count('PASS ')==10
body+=['The module build matched all 21 complete AVM hashes across seven streams at 1, 7 and 12 workers. Its CLI and C library matched the historical release in all 40 strict SSE2-emulated comparisons. Rust 1.100.0, Linux x86-64, ThinLTO, one codegen unit, default features, preserved symbols for disassembly.',
'Build the module variant from the experiment worktree with `RUSTC_WRAPPER="$PWD/scripts/rustc-cdef-prototype.py" CARGO_PROFILE_RELEASE_STRIP=none cargo build --release --locked -p splot-cli -p splot-capi`. Build the function variant in a fresh target directory with the same command and no wrapper. `tests/downstream/cdef-module.rs` provides the scalar parity and timing harness.',
'<details><summary>Raw paired process and kernel timings</summary>\n\n```csv\n'+(root/'module-four-way.csv').read_text().strip()+'\n```\n\n```csv\n'+(root/'micro-times.csv').read_text().strip()+'\n```\n</details>']
(root/'module-issue.md').write_text('\n\n'.join(body)+'\n')
