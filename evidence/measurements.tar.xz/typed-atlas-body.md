Part of #1882, #1886, #1889 and #1890. Feature IDs DECODE-MINIMAL-TIER-RUNTIME-SUCCESS and DECODE-MINIMAL-RAW-RUNTIME-OUTPUT. Qualification checks from #1976 and the decode-oracle fix from #1972 have merged. This PR targets main.

The streaming driver and typed synchronous readers now carry their startup-selected compute backend into frame walking, inline TIP work, finishing and display grain. A caller applying deferred grain to a retained picture enters the stored policy at that public API boundary. Forced AVX-512 shares AVX2 compute in this revision. The parity tests cover TIP output and applying deferred grain after decoder shutdown.

The first implementation caused downstream monomorphization to duplicate 2.35 MB of CLI code. Concrete library-owned entry points keep that code in the decoder library.

### Native AVX2

The integration head is `9d17fb2d` on main `a0bd8c0a`. The merge preserves BRU audit frame and motion-field collection inside the typed backend entry. All checks passed. Across five fixtures, the shipped-v3 instruction check recorded 13,011,001,499 instructions on main and 13,010,993,808 on this head (−7,691). The portable build experiment and its performance gate are tracked in #1934. [CI results](https://github.com/splotlabs/splot/actions/runs/45622473754) · [Instruction comparison](https://github.com/splotlabs/splot/actions/runs/45622473754/job/139233971512).

On an i7-12700H running Linux, Rust 1.100.0, `cargo build --release --locked -p splot-cli -p splot-capi` with checkout x86-64-v3 flags and the repository ThinLTO profile produced the following linked artifacts. The base is `10279846` and the candidate is `ae188672`.

| Stripped artifact | Main bytes | Candidate bytes | Total delta | .text delta | .rodata delta |
| --- | ---: | ---: | ---: | ---: | ---: |
| CLI | 12,324,840 | 12,325,256 | +416 | −432 | +32 |
| C shared library | 8,487,824 | 8,486,976 | −848 | −1,712 | +32 |

All seven full, manifest-verified #1883 streams matched their frozen AVM raw SHA-256 on this head with 1, 7 and 12 threads (21/21). The corpus includes 8-bit, 10-bit, film grain, screen content and tiled streams. The CLI command was `splot decode <input> --threads=N --output-format=raw -o - | sha256sum`. The pre-epic performance control is `b337fafe`. An earlier five-repeat wall-time matrix ran under competing compiler load and is inconclusive. Native timing qualification continues.

### Hardware and rollout

The Apple M2 Max agent independently verified the same 21 AVM outputs for the earlier candidate `657b6939`. Its machine-code check found repeated I8MM discovery in the existing 8-bit subpel path. The [subsequent M2 Max run](https://github.com/splotlabs/splot/issues/1980) verified corrected NEON dispatch on `093caccc`. The [two remaining native latency comparisons](https://github.com/splotlabs/splot/issues/1993) are pending. Exact-head native wall timing remains open. The x86-only unused-helper lint it reported on that SHA received a guard in #1972.

The native Xeon 6975P-C passed the four forced AVX-512 lifecycle/parity checks on the merged qualification infrastructure. [Run 45586869793](https://github.com/splotlabs/splot/actions/runs/45586869793). AVX-512 end-to-end throughput and strict full-corpus qualification are tracked in #1890 and #1891. #1934 tracks the separate portable x86 distribution experiment. This PR still uses the existing v3 checkout default.


