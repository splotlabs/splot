from pathlib import Path
import csv
import re
import statistics
import sys

q=Path(__file__).resolve().parent
def get(p):return (q/p).read_text().strip()
def ir(p):return int(re.search(r'^summary: (\d+)',get(p),re.M)[1])
def total_by(rows,case,name):
    return statistics.median(float(r['ns_per_run']) for r in rows if r['case']==case and r['build']==name)
def result(p):return '```text\n'+get(p)+'\n```'
section=[('External consumer','lr-external-control/ritual16.cg','lr-external-plain/ritual16.cg','lr-external-unit/ritual16.cg'),
         ('Release CLI','callback/ritual-early.cg','lr-product-plain/ritual16.cg','lr-product-unit/ritual16.cg')]
ir_rows=['| Program | Control | Ordinary Cargo | AVX2 unit flags | Ordinary vs control | Unit vs ordinary |','|---|---:|---:|---:|---:|---:|']
for label,a,b,c in section:
    a,b,c=ir(a),ir(b),ir(c)
    ir_rows.append(f'| {label} | {a:,} | {b:,} | {c:,} | {100*(b/a-1):+.3f}% | {100*(c/b-1):+.3f}% |')
size_rows=['| Stripped release artifact | Control | Ordinary Cargo | AVX2 unit flags |','|---|---:|---:|---:|']
for name in ('splot','libsplot_capi.so'):
    sizes=[(q/f'{case}/{name}.stripped').stat().st_size for case in ('callback','lr-product-plain','lr-product-unit')]
    size_rows.append('| '+name+' | '+' | '.join(f'{n:,}' for n in sizes)+' |')
micro=list(csv.DictReader((q/'lr-kernel-paired.csv').open()))
micro_abs=', '.join(f'{name} {total_by(micro,"luma runs",name):.2f} ns/run' for name in ('plain','unit'))
product=get('lr-product-paired.txt')
time_rows=['| Input | Ordinary vs separately compiled unit | Ordinary vs control | Ordinary vs shipped v3 |','|---|---:|---:|---:|']
for stream in ('WITCHER3','TunnelFlag','RitualDance','Noise'):
    cells=[re.search(rf'^{stream} plain/{name} elapsed: (.*?), slower',product,re.M)[1] for name in ('unit','callback','shipped')]
    time_rows.append('| '+('Noise_Ocean' if stream=='Noise' else stream)+' | '+' | '.join(cells)+' |')
for label in ('plain','unit'):
    assert get(f'lr-micro-{label}/parity.txt').startswith('64 scalar-oracle cases')
    assert len(get(f'lr-product-{label}/avm.txt').splitlines())==21
    assert get(f'lr-product-{label}/sse2.txt').count('PASS ')==10
    assert len(get(f'lr-external-{label}/raw.txt').splitlines())==15
    for mode in ('product','external','micro'):
        assert (q/f'lr-{mode}-{label}/codegen.tsv').is_file()
assert len(get('lr-external-control/raw.txt').splitlines())==15
raw=[]
for name in ('kernel','external','product'):
    raw.append(f'<details><summary>Raw {name} timings</summary>\n\n```csv\n'+get(f'lr-{name}-paired.csv')+'\n```\n</details>')
parts=['## Shared luma Wiener restoration experiment',
'The measured control is `07cdddce`. The experiment uses `9b8a8b63` on `experiment/simd-1934-lr-module`. The decoder hands the startup-selected AVX2 token, borrowed 10-bit rows, class weights, and output slice to one concrete luma Wiener run. PC-Wiener and luma retain their respective taps. The traversal and the AVX2 tap arithmetic are shared with existing code. SSE2 and NEON retain their own entries. The tested restoration scope is the 10-bit luma Wiener run, previously called 46,794 times in the 16-frame RitualDance control.',
'**Control** is the previous in-tree implementation. **Ordinary Cargo** builds the extracted code through normal path dependencies. **AVX2 unit flags** builds the same source with the optional experiment wrapper applying the Fearless SIMD 1.2.0 feature contract only to `splot_lr_avx2`. The main decoder and other crates build at baseline. The external program has no checkout Cargo configuration or custom release profile. Its release settings differ from the workspace CLI, so comparisons are paired within each program.',
'### External decoder playback',
'Twelve paired rounds per input, one pinned worker, frame delay one, null output, after warmup. Each of the six three-build launch orders appears twice. Changes are paired median elapsed time with 95% paired bootstrap intervals. Negative elapsed changes are faster.',
result('lr-external-paired.txt'),'### Linked release CLI playback',
'Four builds, 12 balanced rounds, one worker and null output. WITCHER3 and TunnelFlag use 40 frames. RitualDance and Noise_Ocean use 16. Shipped v3 is `10279846`.','\n'.join(time_rows),
'### Kernel and instruction measurements',f'The separate plain-Cargo kernel driver measured the same 64 input cases under both compiler settings. Median timings were {micro_abs}.',result('lr-kernel-paired.txt'),
'Callgrind guest instructions on the same 16 displayed RitualDance frames.','\n'.join(ir_rows),'\n'.join(size_rows),
 'The external application called the concrete luma run 46,794 times in the 16-frame trace. The in-tree control spent 191,465,491 guest instructions inside that call edge. The plain Cargo prototype spent 175,852,024 (8.15% fewer). Both ran the same 46,794 calls. The linked ordinary-Cargo AVX2 body in the external application contained 644 instructions, including 116 vector mnemonics and no CPUID. The explicitly compiled unit reduced the linked body to 573 instructions and 2,933 bytes and used 170,900,392 guest instructions across the same 46,794 calls. These instruction counts describe that function and do not measure application wall time.',
'### Hardware and source revisions',
'The native Intel Xeon 6975P-C passed all 63 full-stream comparisons on the measured prototype (21 Auto selecting AVX2, 21 forced AVX2 and 21 forced AVX-512) and four backend lifecycle tests. The first hosted VM lacked the required AVX-512 features and the hardware precondition rejected it. [Native run, attempt 2](https://github.com/splotlabs/splot/actions/runs/45634575719/attempts/2). Apple ARM64 cross-compilation passed for the reconstruction crate and its test targets. Native M2 Max first-picture timing remains tracked in [#1993](https://github.com/splotlabs/splot/issues/1993). The follow-up `deba2c41` removes an unused Clippy expectation while retaining the inlining attribute. Native all-target checks, Apple ARM64 cross-checks, and Clippy with `-D warnings` passed for the checked crates. The two prototype builds use identical kernel arithmetic.',
'### Correctness and reproducibility',
'Both variants matched the independent 64-case scalar oracle for signed tap weights, rounding, clipping, uniform and mixed classes, padded strides, partial multiples of 16, 1–8 rows and untouched output guards. Each external decoder matched the AVM raw hashes for all seven complete streams on native AVX2, and all four 8/10-bit Wiener and PC-Wiener fixtures on native AVX2 and strict emulated SSE2. Each release CLI matched 21/21 full AVM hashes across 1, 7 and 12 workers. Each CLI and C shared library matched 40/40 strict SSE2 comparisons.',
'Build a standalone Rust consumer with path dependencies on `splot-core` and `splot-decode` using `cargo build --release`. The standalone kernel driver is in `tests/downstream/restoration-module.rs`. The alternate comparison uses `RUSTC_WRAPPER=/absolute/path/to/scripts/rustc-lr-prototype.py` and a fresh target directory. Build the release CLI and C library with `CARGO_PROFILE_RELEASE_STRIP=none cargo build --release --locked -p splot-cli -p splot-capi`; strip the linked artifacts for size comparison. CPU 4 on i7-12700H, Linux x86-64, Rust 1.100.0, LLVM 23.1.5. Compilers and timed processes were serialized.',
'<details><summary>Reproduce the external Rust consumer</summary>\n\nWith the prototype checkout and consumer directory as siblings, adjust the dependency paths in this manifest. The control used the same program with its two paths pointing at its own checkout.\n\n```toml\n'+get('lr-external-plain/Cargo.toml')+'\n```\n\n```rust\n'+get('lr-external-example.rs')+'\n```\n\nThe command line is `lr-consumer avx2 INPUT.ivf null FRAME_LIMIT`. The executable asserts the startup choice before it reads the input. For raw parity pass `raw 99999`.\n</details>', *raw]
(q/'lr-issue.md').write_text('\n\n'.join(parts)+'\n')
print('\n'.join(time_rows+ir_rows+size_rows))
