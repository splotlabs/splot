
<WORKTREES>/qualification-1882/lr-micro-unit/target/release/lr-kernel-consumer:     file format elf64-x86-64


Disassembly of section .text:

000000000001cfa0 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run>:
   1cfa0:	push   %rbp
   1cfa1:	push   %r15
   1cfa3:	push   %r14
   1cfa5:	push   %r13
   1cfa7:	push   %r12
   1cfa9:	push   %rbx
   1cfaa:	sub    $0x798,%rsp
   1cfb1:	xor    %r12d,%r12d
   1cfb4:	sub    %rcx,%r8
   1cfb7:	cmovae %r8,%r12
   1cfbb:	mov    %r12,%r8
   1cfbe:	and    $0xfffffffffffffff0,%r8
   1cfc2:	sete   %r10b
   1cfc6:	test   %rdx,%rdx
   1cfc9:	sete   %al
   1cfcc:	or     %r10b,%al
   1cfcf:	cmp    $0x9,%rdx
   1cfd3:	setae  %r10b
   1cfd7:	or     %al,%r10b
   1cfda:	jne    1d010 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
   1cfdc:	mov    %r8,%r11
   1cfdf:	add    %rcx,%r11
   1cfe2:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1cfe4:	sub    $0xfffffffffffffff8,%r11
   1cfe8:	setae  %al
   1cfeb:	test   %rsi,%rsi
   1cfee:	sete   %r10b
   1cff2:	or     %al,%r10b
   1cff5:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1cff7:	mov    %r11,%r13
   1cffa:	sub    %rcx,%r13
   1cffd:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1cfff:	cmp    0x8(%rdi),%r11
   1d003:	ja     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d005:	lea    0x8(%rdx),%r15
   1d009:	cmp    %r15,%rsi
   1d00c:	jae    1d025 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x85>
   1d00e:	xor    %eax,%eax
   1d010:	add    $0x798,%rsp
   1d017:	pop    %rbx
   1d018:	pop    %r12
   1d01a:	pop    %r13
   1d01c:	pop    %r14
   1d01e:	pop    %r15
   1d020:	pop    %rbp
   1d021:	vzeroupper
   1d024:	ret
   1d025:	mov    0x7d0(%rsp),%r10
   1d02d:	mov    (%r10),%rax
   1d030:	mov    0x8(%r10),%r14
   1d034:	mov    0x10(%r10),%r10
   1d038:	mov    %r10,0x1b0(%rsp)
   1d040:	mov    (%rdi),%r10
   1d043:	lea    (%r10,%rcx,2),%r10
   1d047:	mov    %r10,0x18(%rsp)
   1d04c:	mov    %r13,0x20(%rsp)
   1d051:	mov    %r10,0x28(%rsp)
   1d056:	mov    %r13,0x30(%rsp)
   1d05b:	mov    %r10,0x38(%rsp)
   1d060:	mov    %r13,0x40(%rsp)
   1d065:	mov    %r10,0x48(%rsp)
   1d06a:	mov    %r13,0x50(%rsp)
   1d06f:	mov    %r10,0x58(%rsp)
   1d074:	mov    %r13,0x60(%rsp)
   1d079:	mov    %r10,0x68(%rsp)
   1d07e:	mov    %r13,0x70(%rsp)
   1d083:	mov    %r10,0x78(%rsp)
   1d088:	mov    %r13,0x80(%rsp)
   1d090:	mov    %r10,0x88(%rsp)
   1d098:	mov    %r13,0x90(%rsp)
   1d0a0:	mov    %r10,0x98(%rsp)
   1d0a8:	mov    %r13,0xa0(%rsp)
   1d0b0:	mov    %r10,0xa8(%rsp)
   1d0b8:	mov    %r13,0xb0(%rsp)
   1d0c0:	mov    %r10,0xb8(%rsp)
   1d0c8:	mov    %r13,0xc0(%rsp)
   1d0d0:	mov    %r10,0xc8(%rsp)
   1d0d8:	mov    %r13,0xd0(%rsp)
   1d0e0:	mov    %r10,0xd8(%rsp)
   1d0e8:	mov    %r13,0xe0(%rsp)
   1d0f0:	mov    %r10,0xe8(%rsp)
   1d0f8:	mov    %r13,0xf0(%rsp)
   1d100:	mov    %r10,0xf8(%rsp)
   1d108:	mov    %r13,0x100(%rsp)
   1d110:	mov    %r10,0x128(%rsp)
   1d118:	mov    %r10,0x108(%rsp)
   1d120:	cmp    $0x10,%rsi
   1d124:	mov    $0x10,%ebx
   1d129:	cmovb  %rsi,%rbx
   1d12d:	mov    %r13,0x110(%rsp)
   1d135:	shl    $0x4,%ebx
   1d138:	xor    %esi,%esi
   1d13a:	lea    (%rcx,%rcx,1),%r10
   1d13e:	xchg   %ax,%ax
   1d140:	cmp    %rsi,%rbx
   1d143:	je     1d16d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x1cd>
   1d145:	cmp    0x8(%rdi,%rsi,1),%r11
   1d14a:	ja     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d150:	dec    %r15
   1d153:	mov    (%rdi,%rsi,1),%rbp
   1d157:	add    %r10,%rbp
   1d15a:	mov    %rbp,0x18(%rsp,%rsi,1)
   1d15f:	mov    %r13,0x20(%rsp,%rsi,1)
   1d164:	add    $0x10,%rsi
   1d168:	test   %r15,%r15
   1d16b:	jne    1d140 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x1a0>
   1d16d:	vbroadcasti128 -0x171e6(%rip),%ymm0        # 5f90 <__abi_tag+0x5c94>
   1d176:	vmovdqu %ymm0,0x1d0(%rsp)
   1d17f:	vmovdqu %ymm0,0x1f0(%rsp)
   1d188:	vmovdqu %ymm0,0x210(%rsp)
   1d191:	vmovdqu %ymm0,0x230(%rsp)
   1d19a:	vmovdqu %ymm0,0x250(%rsp)
   1d1a3:	vmovdqu %ymm0,0x270(%rsp)
   1d1ac:	vmovdqu %ymm0,0x290(%rsp)
   1d1b5:	vmovdqu %ymm0,0x2b0(%rsp)
   1d1be:	mov    %r14,%rsi
   1d1c1:	sub    %rcx,%rsi
   1d1c4:	mov    0x1b0(%rsp),%r11
   1d1cc:	cmp    %r8,%r11
   1d1cf:	jae    1d208 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x268>
   1d1d1:	cmp    %rcx,%r14
   1d1d4:	setb   %dil
   1d1d8:	cmp    %r8,%rsi
   1d1db:	setb   %sil
   1d1df:	or     %dil,%sil
   1d1e2:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d1e8:	lea    (%rax,%rcx,2),%rax
   1d1ec:	mov    %rax,0x1d0(%rsp)
   1d1f4:	mov    %r8,0x1d8(%rsp)
   1d1fc:	cmp    $0x1,%rdx
   1d200:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d206:	jmp    1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
   1d208:	cmp    %rcx,%r14
   1d20b:	setb   %dil
   1d20f:	cmp    %r8,%rsi
   1d212:	setb   %r10b
   1d216:	or     %dil,%r10b
   1d219:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d21f:	lea    (%rax,%rcx,2),%rax
   1d223:	mov    %rax,0x1d0(%rsp)
   1d22b:	mov    %r8,0x1d8(%rsp)
   1d233:	cmp    $0x1,%rdx
   1d237:	jne    1d946 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x9a6>
   1d23d:	mov    (%r9),%r14
   1d240:	test   %r14,%r14
   1d243:	jne    1d278 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x2d8>
   1d245:	vpbroadcastq 0x8(%r9),%ymm0
   1d24b:	vmovdqu %ymm0,0x310(%rsp)
   1d254:	lea    0x558(%rsp),%rdi
   1d25c:	lea    0x310(%rsp),%rsi
   1d264:	mov    %r9,%rbx
   1d267:	mov    %rdx,%r15
   1d26a:	vzeroupper
   1d26d:	call   1dc20 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
   1d272:	mov    %r15,%rdx
   1d275:	mov    %rbx,%r9
   1d278:	shr    $0x4,%r12
   1d27c:	mov    $0x1,%al
   1d27e:	je     1d010 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
   1d284:	mov    %rdx,(%rsp)
   1d288:	lea    0x558(%rsp),%rax
   1d290:	movzwl 0x7d8(%rsp),%ecx
   1d298:	vmovd  %ecx,%xmm0
   1d29c:	vpbroadcastw %xmm0,%ymm0
   1d2a1:	vmovdqu %ymm0,0x2f0(%rsp)
   1d2aa:	xor    %ebx,%ebx
   1d2ac:	movq   $0x0,0x8(%rsp)
   1d2b5:	mov    %r14,0x120(%rsp)
   1d2bd:	mov    %rax,0x10(%rsp)
   1d2c2:	test   %r14,%r14
   1d2c5:	je     1d311 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x371>
   1d2c7:	lea    0x2d0(%rsp),%rdi
   1d2cf:	mov    %r9,%rsi
   1d2d2:	mov    0x8(%rsp),%rdx
   1d2d7:	mov    %r9,%r15
   1d2da:	vzeroupper
   1d2dd:	call   1db20 <_RNvMCs3HZP85FyIZE_15splot_lr_kernelNtB2_7Classes5group>
   1d2e2:	cmpq   $0x0,0x2d0(%rsp)
   1d2eb:	je     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d2f1:	lea    0x310(%rsp),%rbp
   1d2f9:	mov    %rbp,%rdi
   1d2fc:	lea    0x2d0(%rsp),%rsi
   1d304:	call   1dc20 <_RNvNvNvNtCs3HZP85FyIZE_15splot_lr_kernel4avx215in_lane_weights6kernel22___fearless_simd_kernel>
   1d309:	mov    %r15,%r9
   1d30c:	mov    %rbp,0x10(%rsp)
   1d311:	mov    %r13,%rcx
   1d314:	sub    %rbx,%rcx
   1d317:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d31d:	cmp    $0x18,%rcx
   1d321:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d327:	mov    0x128(%rsp),%rcx
   1d32f:	lea    (%rcx,%rbx,2),%rcx
   1d333:	vmovq  %rcx,%xmm0
   1d338:	vpbroadcastq %xmm0,%ymm0
   1d33d:	vmovdqu %ymm0,0x178(%rsp)
   1d346:	mov    %rcx,0x198(%rsp)
   1d34e:	mov    %rcx,0x1a0(%rsp)
   1d356:	mov    %rcx,0x1a8(%rsp)
   1d35e:	mov    0x20(%rsp),%rdx
   1d363:	sub    %rbx,%rdx
   1d366:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d36c:	cmp    $0x18,%rdx
   1d370:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d376:	lea    (%rbx,%rbx,1),%rdx
   1d37a:	mov    0x18(%rsp),%rcx
   1d37f:	add    %rdx,%rcx
   1d382:	mov    %rcx,0x130(%rsp)
   1d38a:	mov    0x30(%rsp),%rsi
   1d38f:	sub    %rbx,%rsi
   1d392:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d398:	cmp    $0x18,%rsi
   1d39c:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d3a2:	mov    0x28(%rsp),%rcx
   1d3a7:	add    %rdx,%rcx
   1d3aa:	mov    %rcx,0x138(%rsp)
   1d3b2:	mov    0x40(%rsp),%rsi
   1d3b7:	sub    %rbx,%rsi
   1d3ba:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d3c0:	cmp    $0x18,%rsi
   1d3c4:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d3ca:	mov    0x38(%rsp),%rcx
   1d3cf:	add    %rdx,%rcx
   1d3d2:	mov    %rcx,0x140(%rsp)
   1d3da:	mov    0x50(%rsp),%rsi
   1d3df:	sub    %rbx,%rsi
   1d3e2:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d3e8:	cmp    $0x18,%rsi
   1d3ec:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d3f2:	mov    0x48(%rsp),%rcx
   1d3f7:	add    %rdx,%rcx
   1d3fa:	mov    %rcx,0x148(%rsp)
   1d402:	mov    0x60(%rsp),%rsi
   1d407:	sub    %rbx,%rsi
   1d40a:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d410:	cmp    $0x18,%rsi
   1d414:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d41a:	mov    0x58(%rsp),%rcx
   1d41f:	add    %rdx,%rcx
   1d422:	mov    %rcx,0x150(%rsp)
   1d42a:	mov    0x70(%rsp),%rsi
   1d42f:	sub    %rbx,%rsi
   1d432:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d438:	cmp    $0x18,%rsi
   1d43c:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d442:	mov    0x68(%rsp),%rcx
   1d447:	add    %rdx,%rcx
   1d44a:	mov    %rcx,0x158(%rsp)
   1d452:	mov    0x80(%rsp),%rsi
   1d45a:	sub    %rbx,%rsi
   1d45d:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d463:	cmp    $0x18,%rsi
   1d467:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d46d:	mov    0x78(%rsp),%rcx
   1d472:	add    %rdx,%rcx
   1d475:	mov    %rcx,0x160(%rsp)
   1d47d:	mov    0x90(%rsp),%rsi
   1d485:	sub    %rbx,%rsi
   1d488:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d48e:	cmp    $0x18,%rsi
   1d492:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d498:	mov    0x88(%rsp),%rcx
   1d4a0:	add    %rdx,%rcx
   1d4a3:	mov    %rcx,0x168(%rsp)
   1d4ab:	mov    0xa0(%rsp),%rsi
   1d4b3:	sub    %rbx,%rsi
   1d4b6:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d4bc:	cmp    $0x18,%rsi
   1d4c0:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d4c6:	mov    0x98(%rsp),%rcx
   1d4ce:	add    %rdx,%rcx
   1d4d1:	mov    %rcx,0x170(%rsp)
   1d4d9:	cmpq   $0x1,(%rsp)
   1d4de:	je     1d65d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
   1d4e4:	mov    0xb0(%rsp),%rsi
   1d4ec:	sub    %rbx,%rsi
   1d4ef:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d4f5:	cmp    $0x18,%rsi
   1d4f9:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d4ff:	mov    0xa8(%rsp),%rcx
   1d507:	add    %rdx,%rcx
   1d50a:	mov    %rcx,0x178(%rsp)
   1d512:	cmpq   $0x2,(%rsp)
   1d517:	je     1d65d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
   1d51d:	mov    0xc0(%rsp),%rsi
   1d525:	sub    %rbx,%rsi
   1d528:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d52e:	cmp    $0x18,%rsi
   1d532:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d538:	mov    0xb8(%rsp),%rcx
   1d540:	add    %rdx,%rcx
   1d543:	mov    %rcx,0x180(%rsp)
   1d54b:	cmpq   $0x3,(%rsp)
   1d550:	je     1d65d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
   1d556:	mov    0xd0(%rsp),%rsi
   1d55e:	sub    %rbx,%rsi
   1d561:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d567:	cmp    $0x18,%rsi
   1d56b:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d571:	mov    0xc8(%rsp),%rcx
   1d579:	add    %rdx,%rcx
   1d57c:	mov    %rcx,0x188(%rsp)
   1d584:	cmpq   $0x4,(%rsp)
   1d589:	je     1d65d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
   1d58f:	mov    0xe0(%rsp),%rsi
   1d597:	sub    %rbx,%rsi
   1d59a:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d5a0:	cmp    $0x18,%rsi
   1d5a4:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d5aa:	mov    0xd8(%rsp),%rcx
   1d5b2:	add    %rdx,%rcx
   1d5b5:	mov    %rcx,0x190(%rsp)
   1d5bd:	cmpq   $0x5,(%rsp)
   1d5c2:	je     1d65d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
   1d5c8:	mov    0xf0(%rsp),%rsi
   1d5d0:	sub    %rbx,%rsi
   1d5d3:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d5d9:	cmp    $0x18,%rsi
   1d5dd:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d5e3:	mov    0xe8(%rsp),%rcx
   1d5eb:	add    %rdx,%rcx
   1d5ee:	mov    %rcx,0x198(%rsp)
   1d5f6:	cmpq   $0x6,(%rsp)
   1d5fb:	je     1d65d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
   1d5fd:	mov    0x100(%rsp),%rsi
   1d605:	sub    %rbx,%rsi
   1d608:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d60e:	cmp    $0x18,%rsi
   1d612:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d618:	mov    0xf8(%rsp),%rcx
   1d620:	add    %rdx,%rcx
   1d623:	mov    %rcx,0x1a0(%rsp)
   1d62b:	cmpq   $0x7,(%rsp)
   1d630:	je     1d65d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6bd>
   1d632:	mov    0x110(%rsp),%rsi
   1d63a:	sub    %rbx,%rsi
   1d63d:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d643:	cmp    $0x18,%rsi
   1d647:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d64d:	add    0x108(%rsp),%rdx
   1d655:	mov    %rdx,0x1a8(%rsp)
   1d65d:	lea    0x10(%rbx),%rax
   1d661:	mov    %rax,0x118(%rsp)
   1d669:	dec    %r12
   1d66c:	incq   0x8(%rsp)
   1d671:	lea    0x1d8(%rsp),%rsi
   1d679:	xor    %edi,%edi
   1d67b:	mov    (%rsi),%rdx
   1d67e:	sub    %rbx,%rdx
   1d681:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d687:	cmp    $0x10,%rdx
   1d68b:	jb     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d691:	cmp    $0x7,%rdi
   1d695:	ja     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d69b:	mov    0x158(%rsp,%rdi,8),%r10
   1d6a3:	mov    0x148(%rsp,%rdi,8),%r11
   1d6ab:	mov    0x150(%rsp,%rdi,8),%r8
   1d6b3:	vmovdqu (%r8),%ymm4
   1d6b8:	vmovdqu 0x2(%r8),%ymm6
   1d6be:	mov    0x160(%rsp,%rdi,8),%rdx
   1d6c6:	mov    0x140(%rsp,%rdi,8),%r15
   1d6ce:	vmovdqu 0x6(%r15),%ymm11
   1d6d4:	vmovdqu 0xa(%r15),%ymm10
   1d6da:	mov    0x168(%rsp,%rdi,8),%r14
   1d6e2:	mov    0x130(%rsp,%rdi,8),%rcx
   1d6ea:	mov    %rbx,%rax
   1d6ed:	mov    0x138(%rsp,%rdi,8),%rbx
   1d6f5:	mov    0x170(%rsp,%rdi,8),%rbp
   1d6fd:	vmovdqu 0x8(%rcx),%ymm2
   1d702:	vmovdqu 0x2(%rbx),%ymm0
   1d707:	vpaddw 0xe(%r14),%ymm0,%ymm0
   1d70d:	vmovdqu %ymm0,0x1b0(%rsp)
   1d716:	vmovdqu 0xe(%rbx),%ymm1
   1d71b:	vpaddw 0x2(%r14),%ymm1,%ymm1
   1d721:	vpunpckhwd %ymm1,%ymm0,%ymm5
   1d725:	mov    0x10(%rsp),%rcx
   1d72a:	vpmaddwd 0x1e0(%rcx),%ymm5,%ymm13
   1d732:	vpaddw 0x8(%rbp),%ymm2,%ymm2
   1d737:	vmovdqu 0x8(%rbx),%ymm5
   1d73c:	mov    %rax,%rbx
   1d73f:	vpaddw 0x10(%r8),%ymm4,%ymm4
   1d745:	vpunpckhwd %ymm4,%ymm2,%ymm7
   1d749:	vpmaddwd 0x1a0(%rcx),%ymm7,%ymm14
   1d751:	vpaddw 0x8(%r14),%ymm5,%ymm5
   1d757:	vmovdqu 0x4(%r11),%ymm7
   1d75d:	vpaddw 0xe(%r8),%ymm6,%ymm6
   1d763:	vpunpckhwd %ymm6,%ymm5,%ymm8
   1d767:	vpmaddwd 0x160(%rcx),%ymm8,%ymm15
   1d76f:	vpaddw 0xc(%r10),%ymm7,%ymm7
   1d775:	vmovdqu 0xc(%r11),%ymm8
   1d77b:	vpaddw 0x4(%r10),%ymm8,%ymm8
   1d781:	vpunpckhwd %ymm8,%ymm7,%ymm9
   1d786:	vpmaddwd 0x120(%rcx),%ymm9,%ymm3
   1d78e:	vpaddw 0xa(%rdx),%ymm11,%ymm9
   1d793:	vmovdqu 0x6(%r11),%ymm11
   1d799:	vpaddw 0x6(%rdx),%ymm10,%ymm10
   1d79e:	vpunpckhwd %ymm10,%ymm9,%ymm12
   1d7a3:	vpmaddwd 0xe0(%rcx),%ymm12,%ymm0
   1d7ab:	vpaddw 0xa(%r10),%ymm11,%ymm11
   1d7b1:	vmovdqu 0x6(%r10),%ymm12
   1d7b7:	vpaddw 0xa(%r11),%ymm12,%ymm12
   1d7bd:	vpaddd %ymm13,%ymm14,%ymm14
   1d7c2:	vpunpckhwd %ymm12,%ymm11,%ymm13
   1d7c7:	vpmaddwd 0xa0(%rcx),%ymm13,%ymm13
   1d7cf:	vpaddd %ymm3,%ymm15,%ymm3
   1d7d3:	vmovdqu 0x8(%r15),%ymm15
   1d7d9:	vpaddw 0x8(%rdx),%ymm15,%ymm15
   1d7de:	vpaddd %ymm3,%ymm14,%ymm3
   1d7e2:	vmovdqu 0x4(%r8),%ymm14
   1d7e8:	vpaddw 0xc(%r8),%ymm14,%ymm14
   1d7ee:	vpaddd %ymm0,%ymm13,%ymm0
   1d7f2:	vpunpckhwd %ymm14,%ymm15,%ymm13
   1d7f7:	vpmaddwd 0x60(%rcx),%ymm13,%ymm13
   1d7fc:	vpaddd %ymm0,%ymm13,%ymm0
   1d800:	vpaddd %ymm0,%ymm3,%ymm3
   1d804:	vmovdqu 0x1b0(%rsp),%ymm0
   1d80d:	vpunpcklwd %ymm1,%ymm0,%ymm0
   1d811:	vpunpcklwd %ymm4,%ymm2,%ymm1
   1d815:	vpmaddwd 0x1c0(%rcx),%ymm0,%ymm0
   1d81d:	vpmaddwd 0x180(%rcx),%ymm1,%ymm1
   1d825:	vpaddd %ymm0,%ymm1,%ymm0
   1d829:	vpunpcklwd %ymm6,%ymm5,%ymm1
   1d82d:	vpmaddwd 0x140(%rcx),%ymm1,%ymm1
   1d835:	vpunpcklwd %ymm8,%ymm7,%ymm2
   1d83a:	vpmaddwd 0x100(%rcx),%ymm2,%ymm2
   1d842:	vpaddd %ymm2,%ymm1,%ymm1
   1d846:	vpaddd %ymm1,%ymm0,%ymm0
   1d84a:	vpunpcklwd %ymm10,%ymm9,%ymm1
   1d84f:	vpunpcklwd %ymm12,%ymm11,%ymm2
   1d854:	vmovdqu 0x6(%r8),%ymm4
   1d85a:	vpunpcklwd %ymm14,%ymm15,%ymm5
   1d85f:	vmovdqu 0x8(%r11),%ymm6
   1d865:	vpaddw 0x8(%r10),%ymm6,%ymm6
   1d86b:	vpaddw 0xa(%r8),%ymm4,%ymm4
   1d871:	vpmaddwd 0xc0(%rcx),%ymm1,%ymm1
   1d879:	vpmaddwd 0x80(%rcx),%ymm2,%ymm2
   1d881:	vpmaddwd 0x40(%rcx),%ymm5,%ymm5
   1d886:	vpaddd %ymm2,%ymm1,%ymm1
   1d88a:	vpaddd %ymm5,%ymm1,%ymm1
   1d88e:	vpunpckhwd %ymm4,%ymm6,%ymm2
   1d892:	vpaddd %ymm1,%ymm0,%ymm0
   1d896:	vpunpcklwd %ymm4,%ymm6,%ymm1
   1d89a:	vpmaddwd (%rcx),%ymm1,%ymm1
   1d89e:	vmovdqu 0x8(%r8),%ymm4
   1d8a4:	vpunpcklwd -0x175ec(%rip),%ymm4,%ymm5        # 62c0 <__abi_tag+0x5fc4>
   1d8ac:	vpshufb -0x175b5(%rip),%ymm5,%ymm5        # 6300 <__abi_tag+0x6004>
   1d8b5:	vpmaddwd 0x200(%rcx),%ymm5,%ymm5
   1d8bd:	vpaddd %ymm5,%ymm1,%ymm1
   1d8c1:	vpaddd %ymm1,%ymm0,%ymm0
   1d8c5:	vpmaddwd 0x20(%rcx),%ymm2,%ymm1
   1d8ca:	vpunpckhwd -0x17592(%rip),%ymm4,%ymm2        # 6340 <__abi_tag+0x6044>
   1d8d2:	vpshufb -0x1763b(%rip),%ymm2,%ymm2        # 62a0 <__abi_tag+0x5fa4>
   1d8db:	vpmaddwd 0x220(%rcx),%ymm2,%ymm2
   1d8e3:	vpaddd %ymm2,%ymm1,%ymm1
   1d8e7:	vpaddd %ymm1,%ymm3,%ymm1
   1d8eb:	vpsrad $0x7,%ymm0,%ymm0
   1d8f0:	vpsrad $0x7,%ymm1,%ymm1
   1d8f5:	vpackusdw %ymm1,%ymm0,%ymm0
   1d8fa:	mov    -0x8(%rsi),%rcx
   1d8fe:	vpminuw 0x2f0(%rsp),%ymm0,%ymm0
   1d908:	vmovdqu %ymm0,(%rcx,%rax,2)
   1d90d:	inc    %rdi
   1d910:	add    $0x10,%rsi
   1d914:	cmp    %rdi,(%rsp)
   1d918:	jne    1d67b <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6db>
   1d91e:	mov    0x118(%rsp),%rbx
   1d926:	test   %r12,%r12
   1d929:	mov    0x120(%rsp),%r14
   1d931:	lea    0x558(%rsp),%rax
   1d939:	jne    1d2bd <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x31d>
   1d93f:	mov    $0x1,%al
   1d941:	jmp    1d010 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
   1d946:	sub    %r11,%rsi
   1d949:	setb   %cl
   1d94c:	cmp    %r8,%rsi
   1d94f:	setb   %dil
   1d953:	or     %cl,%dil
   1d956:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d95c:	lea    (%rax,%r11,2),%rax
   1d960:	mov    %rax,0x1e0(%rsp)
   1d968:	mov    %r8,0x1e8(%rsp)
   1d970:	cmp    $0x2,%rdx
   1d974:	je     1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
   1d97a:	sub    %r11,%rsi
   1d97d:	setb   %cl
   1d980:	cmp    %r8,%rsi
   1d983:	setb   %dil
   1d987:	or     %cl,%dil
   1d98a:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d990:	lea    (%rax,%r11,2),%rax
   1d994:	mov    %rax,0x1f0(%rsp)
   1d99c:	mov    %r8,0x1f8(%rsp)
   1d9a4:	cmp    $0x3,%rdx
   1d9a8:	je     1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
   1d9ae:	sub    %r11,%rsi
   1d9b1:	setb   %cl
   1d9b4:	cmp    %r8,%rsi
   1d9b7:	setb   %dil
   1d9bb:	or     %cl,%dil
   1d9be:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d9c4:	lea    (%rax,%r11,2),%rax
   1d9c8:	mov    %rax,0x200(%rsp)
   1d9d0:	mov    %r8,0x208(%rsp)
   1d9d8:	cmp    $0x4,%rdx
   1d9dc:	je     1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
   1d9e2:	mov    %rdx,%rcx
   1d9e5:	mov    %r9,%rdi
   1d9e8:	sub    %r11,%rsi
   1d9eb:	setb   %dl
   1d9ee:	cmp    %r8,%rsi
   1d9f1:	setb   %r9b
   1d9f5:	or     %dl,%r9b
   1d9f8:	jne    1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1d9fe:	mov    0x1b0(%rsp),%r11
   1da06:	lea    (%rax,%r11,2),%r10
   1da0a:	mov    %r10,0x210(%rsp)
   1da12:	mov    %r8,0x218(%rsp)
   1da1a:	mov    %rcx,%rdx
   1da1d:	cmp    $0x5,%rcx
   1da21:	mov    %rdi,%r9
   1da24:	je     1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
   1da2a:	xor    %eax,%eax
   1da2c:	sub    %r11,%rsi
   1da2f:	lea    (%r10,%r11,2),%r10
   1da33:	mov    $0x0,%edx
   1da38:	cmovae %r10,%rdx
   1da3c:	test   %rdx,%rdx
   1da3f:	sete   %r9b
   1da43:	cmp    %r8,%rsi
   1da46:	setb   %r11b
   1da4a:	or     %r9b,%r11b
   1da4d:	jne    1d010 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
   1da53:	mov    %rdx,0x220(%rsp)
   1da5b:	mov    %r8,0x228(%rsp)
   1da63:	mov    %rcx,%rdx
   1da66:	cmp    $0x6,%rcx
   1da6a:	mov    %rdi,%r9
   1da6d:	mov    0x1b0(%rsp),%r11
   1da75:	je     1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
   1da7b:	xor    %eax,%eax
   1da7d:	sub    %r11,%rsi
   1da80:	lea    (%r10,%r11,2),%r10
   1da84:	mov    $0x0,%edx
   1da89:	cmovae %r10,%rdx
   1da8d:	test   %rdx,%rdx
   1da90:	sete   %r9b
   1da94:	cmp    %r8,%rsi
   1da97:	setb   %r11b
   1da9b:	or     %r9b,%r11b
   1da9e:	jne    1d010 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
   1daa4:	mov    %rdx,0x230(%rsp)
   1daac:	mov    %r8,0x238(%rsp)
   1dab4:	mov    %rcx,%rdx
   1dab7:	cmp    $0x7,%rcx
   1dabb:	mov    %rdi,%r9
   1dabe:	mov    0x1b0(%rsp),%r11
   1dac6:	je     1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
   1dacc:	xor    %eax,%eax
   1dace:	sub    %r11,%rsi
   1dad1:	lea    (%r10,%r11,2),%rdx
   1dad5:	cmovb  %rax,%rdx
   1dad9:	setae  %al
   1dadc:	cmp    %r8,%rsi
   1dadf:	setb   %sil
   1dae3:	test   %rdx,%rdx
   1dae6:	je     1d00e <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x6e>
   1daec:	and    %sil,%al
   1daef:	mov    $0x0,%eax
   1daf4:	jne    1d010 <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x70>
   1dafa:	mov    %rdx,0x240(%rsp)
   1db02:	mov    %r8,0x248(%rsp)
   1db0a:	mov    %rdi,%r9
   1db0d:	mov    %rcx,%rdx
   1db10:	jmp    1d23d <_RNvCs6Qcs5Yj40FL_13splot_lr_avx215filter_luma_run+0x29d>
