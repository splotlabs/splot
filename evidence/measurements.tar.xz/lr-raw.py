import hashlib
from pathlib import Path
import re
import subprocess
import sys
import tomllib
root=Path(__file__).resolve().parent
label=sys.argv[1]
directory=root/f'lr-external-{label}'
exe=directory/'target/release/lr-consumer'
fixtures_dir=root.parent/'splot-1934-blend-callback/tests/conformance'
manifest=tomllib.loads((fixtures_dir/'decoder-oracle.toml').read_text())
small=[record for record in manifest['fixture'] if record['id'] in {f'syn-bru-lr-stripe-{kind}-{bits}bit' for kind in ('wienerns','pcwiener') for bits in (8,10)}]
assert len(small)==4
def run(input_file,cpu,expected,count=None,nbytes=None):
    cmd=[str(exe),cpu,str(input_file),'raw','99999']
    if cpu=='sse2':
        cmd=[str(root/'qemu/usr/bin/qemu-x86_64'),'-cpu','qemu64,-pni,-sse4a,-ssse3,-sse4.1,-sse4.2',*cmd]
    h=hashlib.sha256()
    size=0
    with subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as proc:
        while data:=proc.stdout.read(1024*1024):
            h.update(data)
            size+=len(data)
        err=proc.stderr.read().decode()
        assert proc.wait()==0,err
    frames=int(re.search(r'(\d+) displayed pictures',err)[1])
    assert h.hexdigest()==expected,(input_file,cpu,h.hexdigest(),expected)
    if count is not None: assert frames==count
    if nbytes is not None: assert size==nbytes
    print(input_file.name,cpu,frames,size,h.hexdigest(),flush=True)
for record in small:
    path=fixtures_dir/'vectors/valid'/(record['id']+'.ivf')
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['ivf_sha256']
    for backend in ('avx2','sse2'):
        run(path,backend,record['avm_raw_sha256'])
for row in (root/'ci-data/simd-cases.tsv').read_text().splitlines():
    name,sha,frames,size=row.split('\t')
    run(root/'ci-data'/name,'avx2',sha,int(frames),int(size))
