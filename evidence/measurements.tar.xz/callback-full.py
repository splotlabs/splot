import csv
import itertools
import os
from pathlib import Path
import random
import statistics
import subprocess
import time

root = Path(__file__).resolve().parent
os.sched_setaffinity(0, {4})
bins = {name: root / f'{name}/target/release/splot' for name in ('callback', 'shipped', 'frozen')}
streams = [root / 'ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf', next((root / 'ci-data').glob('RitualDance*.ivf'))]
orders = list(itertools.permutations(bins))
def run(binary, src):
    start = time.perf_counter()
    subprocess.run([binary, 'decode', src, '--threads', '1', '--frame-delay', '1', '--output-format', 'null'], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return time.perf_counter() - start
for src in streams:
    for binary in bins.values():
        run(binary, src)
samples = {}
with (root / 'callback-full.csv').open('x') as file:
    writer = csv.writer(file)
    writer.writerow(['stream', 'round', 'position', 'build', 'elapsed_s'])
    for i in range(12):
        for src in (streams if i % 2 == 0 else reversed(streams)):
            order = orders[(i + 3 * streams.index(src)) % 6]
            for pos, name in enumerate(order):
                sample = run(bins[name], src)
                samples[src, i, name] = sample
                writer.writerow([src.name, i + 1, pos + 1, name, sample])
                file.flush()
for src in streams:
    for base in ('shipped', 'frozen'):
        paired = [100 * (samples[src, i, 'callback'] / samples[src, i, base] - 1) for i in range(12)]
        rng = random.Random(1882)
        interval = sorted(statistics.median(rng.choices(paired, k=12)) for _ in range(10000))
        print(src.name, 'vs', base, 'paired elapsed %', *(round(x, 2) for x in (statistics.median(paired), interval[250], interval[-251])), 'slower', sum(p > 0 for p in paired), 'of 12', flush=True)
