"""Counterbalanced single-threaded AVX2 decode comparison; preserves each raw observation."""
import csv
from pathlib import Path
import random
import resource
import os
import statistics
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
work = root.parent
variants = {
    "callback": root / "callback/target/release/splot",
    "native": root / "native/target/release/splot",
    "compound": root / "compound/target/release/splot",
    "module": root / "cdef-module/target/release/splot",
    "function": root / "cdef-function/target/release/splot",
    "kernels": work / "splot-1934-tip-overlap/target/release/splot",
    "gdf": work / "splot-1934-gdf-order/target/release/splot",
    "parser": work / "splot-1934-parser/target/release/splot",
    "control": work / "splot-1934-parser-control-snapshot-2a04d218/splot",
    "shipped": root / "shipped/target/release/splot",
    "frozen": root / "frozen/target/release/splot",
}
streams = [next((root / "data").glob(f"{prefix}*.ivf")) for prefix in ("WITCHER3","TunnelFlag")]
def cpu():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return usage.ru_utime + usage.ru_stime
def timed(name, stream):
    start_cpu = cpu()
    start = time.perf_counter()
    frames = "16" if stream.name.startswith(("Noise_Ocean","RitualDance")) else "40"
    subprocess.run([variants[name],"decode",stream,"--threads","1","--limit",frames,"--output-format","null"], check=True, stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return (time.perf_counter()-start, cpu()-start_cpu)
def summaries(rows, names):
    for stream in streams:
        records = {(r[1],r[3]):r[4:] for r in rows if r[0]==stream.name}
        for base in names[1:]:
            for col,metric in enumerate(("elapsed","CPU")):
                ratios = [records[i,names[0]][col]/records[i,base][col] for i in range(1,13)]
                rng=random.Random(1882)
                sims=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
                print(f"{stream.name.split('_')[0]} {names[0]}/{base} {metric}: {(statistics.median(ratios)-1)*100:+.2f}% [{(sims[250]-1)*100:+.2f}, {(sims[-251]-1)*100:+.2f}], slower {sum(r>1 for r in ratios)}/12",flush=True)
if __name__ == "__main__":
    names=sys.argv[2:]
    if any(key in names for key in ("module","native","callback")):
        streams.append(root / "ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf")
    if "native" in names or "callback" in names:
        streams.append(next((root / "ci-data").glob("RitualDance*.ivf")))
    if len(names)==2:
        offsets=(0,1)
    elif len(names)==4:
        offsets=(0,1,3,2)
    else:
        raise ValueError("require two or four binaries")
    os.sched_setaffinity(0,{4})
    for stream in streams:
        for name in names:
            timed(name,stream)
    rows=[]
    with (root/sys.argv[1]).open('x') as f:
        writer=csv.writer(f)
        writer.writerow(["stream","round","order","version","elapsed_s","cpu_s"])
        for r in range(12):
            indices=range(len(streams))
            for s in (indices if r%2==0 else reversed(indices)):
                for pos,j in enumerate(offsets):
                    name=names[(r+s*(len(names)//2)+j)%len(names)]
                    row=(streams[s].name,r+1,pos+1,name,*timed(name,streams[s]))
                    rows.append(row)
                    writer.writerow(row)
                    f.flush()
                    os.fsync(f.fileno())
    summaries(rows,names)
