# Repeat first-picture timing on Apple M2 Max for the NEON decoder candidate

The native M2 Max run in #1980 verified startup selection and all 21 AVM hash comparisons. Concurrent builds and benchmarks prevented a usable wall-time comparison. Repeat the one-thread first-picture wall-time measurement for BlueSky (8-bit) and RitualDance (10-bit). RitualDance showed a small reproducible first-picture slowdown in #1975.

- Frozen pre-epic reference: `b337fafec51041ee5ffe64cc7e20f79a49c0cc79`
- NEON candidate: `093caccc7e8fb90b29e7fccf889bb5a3442d44ff`

Use both revisions on the same Apple M2 Max in native arm64 macOS, on AC power. Reuse the exact measured release CLI binaries from #1980 if available and verifiable. If either needs a rebuild, finish builds before timing and use the recorded Rust 1.100.0 toolchain, default features and target flags, and `cargo build --release --locked -p splot-cli`. Record full revisions, binary and input SHA-256s, macOS and toolchain versions, and any settings that differ from #1980.

Use the original IVF inputs from the published manifest and run each revision with:

```sh
/usr/bin/time -l "$splot" decode --threads=1 --frame-delay=1 \
    --output-format=null --limit 1 "$input"
```

Measure elapsed wall time with the original harness's nanosecond process timer. Warm up each revision once per input, then collect eight pairs per stream with alternating reference-first and candidate-first order. Check for competing builds or benchmarks before and after each pair. If the machine becomes busy, stop, flag and retain the affected pair, and resume with a fresh warmup once the host is idle. Repeat a case independently only if it shows a possible slowdown.

Attach the raw paired CSV with stream, round, launch order, revision, elapsed wall time and host-load observations. Report per-case medians, the paired relative difference with a 95% interval, and a GO or HOLD for these two timing cases. Reuse the existing conformance evidence. Full performance qualification remains outside this timing follow-up.

[Native M2 Max results and commands](https://github.com/splotlabs/splot/issues/1980#issuecomment-7161230010) · [Original harness and AVM manifest](https://github.com/splotlabs/splot/issues/1975#issuecomment-7159427081)
