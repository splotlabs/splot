# Noise_Ocean control profile

Existing portable AVX2 control `2a04d218`. The input SHA-256 is `e6617f91dcf60c8f547de40863bf1c3ed913c1f9ab8bd73c96b0d43dda3b28a7`, matching #1980. Callgrind collected 1,769,987,493 Ir. CI's different counter and binaries reported 1,204,560,800 base and 1,667,396,164 head instructions (+38.424%). One control trace locates hotspots. Attribution of the CI delta requires matched base/head profiles.

```sh
taskset -c 2 valgrind --tool=callgrind \
  --callgrind-out-file=qualification-1882/control-Noise_Ocean.cg \
  --log-file=qualification-1882/control-Noise_Ocean.cglog \
  ./splot-1934-parser-control-snapshot-2a04d218/splot decode --threads 1 \
  --frame-delay 1 --output-format null --limit 16 \
  qualification-1882/ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf
```

The inclusive edge counts below identify direct callers. Nested rows overlap, so sum only disjoint edges or function self costs.

| Direct caller → callee | Calls | Inclusive Ir |
| --- | ---: | ---: |
| `cdef_segment` → `CdefPairSegment::gather_with_mode` | 88,876 | 82,476,928 |
| `cdef_segment` → AVX2 `LumaBytesGather` | 84,930 | 32,188,470 |
| `cdef_segment` → AVX2 `cdef_filter_segment_with` | 88,876 | 281,721,866 |
| Direction-0 wide-byte `byte_quad` → AVX2 `unpack_padded_rows` | 1,737,365 | 8,686,825 |
| AVX2 `PairGather` → `try_map` on byte rows | 177,752 | 35,194,896 |
| AVX2 temporal scan → `ChunkWalk::project_tracked<true>` | 19,980 | 160,143,181 |
| AVX2 temporal scan → `ChunkWalk::project_tracked<false>` | 7,020 | 39,764,760 |
| `wiener_ns_filter_luma_block_padded_layout_into` → AVX2 `filter_row` | 589,740 | 91,409,700 |
| `EightBitLuma::stage` → libc memcpy | 82,344 | 4,351,136 |
| `Window::emulate` → typed AVX2 `emulate_chunks<u8,false>` | 3,253 | 11,286,932 |
| `FrontierRows::append_rows` → libc memcpy | 876 | 25,779,008 |
| `FramePlane::copy_rows` → libc memcpy | 209 | 15,629,280 |

The CDEF byte row helper is only five instructions in its callee per call. Its repeated ABI crossing at `cdef_filter/segment/byte_filter.rs:222` via `segment.rs:959` is a concrete avoidable cost; `8eed417f` targets the surrounding closure in the local sync tree, and its effect needs validation. `filters/cdef.rs:1171`–`1227` provides a second boundary to inspect for sibling gather and filter transitions. `temporal/scan.rs:354`–`356` calls the scalar walk from the AVX2 scope, while `scan.rs:410` contains trajectory extension, observation and ordered projection writes. The profile supports investigation there, but those operations are required, so the two self costs are not estimates of avoidable instructions. Wiener row filtering is similarly substantive. Staging and frontier copies expose separate opportunities whose ownership and halo requirements must be preserved.
