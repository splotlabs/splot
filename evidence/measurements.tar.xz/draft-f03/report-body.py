from pathlib import Path
import re
q=Path(__file__).resolve().parent
original=(q/'previous-body.md').read_text()
text=original[:original.index('### Native AVX2 performance')]
text+='''### Native AVX2 performance

The current integration head is `f03b06e2`. It includes the measured 8-bit chroma gather, 10-bit CDEF quad, subpel, and compound blend fixes. CI counted 15,115,930,132 instructions across five workloads against 13,011,006,968 on its base, a **16.178% regression**. The preceding draft was 22.777% over its base. Noise_Ocean improved from +38.418% to +20.460%. Each workload still misses the instruction gate. [Exact performance check](https://github.com/splotlabs/splot/actions/runs/45633257032/job/139271832212).

On the i7-12700H each build used Auto, one decode thread, a frame delay of one and null output. Twelve paired rounds on CPU 4 follow warmup and cover all six launch orders twice. Positive numbers mean the portable draft took longer. Brackets give 95% paired bootstrap intervals.

| Stream | Frames | Draft vs shipped `10279846` | Draft vs frozen `b337fafe` |
|---|---:|---:|---:|
'''
rows=(q/'paired.txt').read_text()
for case,n in [('WITCHER3',40),('TunnelFlag',40),('Noise_Ocean',16),('RitualDance',16)]:
    row=[re.search(rf'^{case}[^\n]*? \| draft/{ref} \| wall \| (.+?) \| slower',rows,re.M)[1] for ref in ['shipped','frozen']]
    text+=f'| {case} | {n} | {row[0]} | {row[1]} |\n'
assert len((q/'avm.txt').read_text().strip().splitlines())==21
text+='''
The separate shared-module and parser experiments are tracked in #1934. The full-stream ordinary-Cargo control at `07cdddce` took 24.32% longer on Noise_Ocean and 19.21% longer on RitualDance than shipped. Those timings identify the control used for the restoration experiment. [Raw full-stream comparisons](https://github.com/splotlabs/splot/issues/1934#issuecomment-7165803305).

### Correctness and hardware

At `f03b06e2`, seven full streams matched AVM at 1, 7 and 12 workers (21/21). The normal CI and external x86 consumer checks passed. The experimental kernel control passed all 63 full-stream comparisons across Auto, forced AVX2 and forced AVX-512 on a native Xeon. [Native AVX-512 results](https://github.com/splotlabs/splot/actions/runs/45629837549). The M2 Max agent verified corrected NEON dispatch and all 21 output comparisons. Two first-picture latency comparisons remain open. [Apple results](https://github.com/splotlabs/splot/issues/1980) · [Latency follow-up](https://github.com/splotlabs/splot/issues/1993).

### Linux x86-64 linked size

On GitHub CI the stripped release CLI measured 16,668,776 bytes (ceiling 16,680,000), and the C shared library measured 12,951,168 bytes (ceiling 12,970,000). Both pass the accepted dual-backend allowance. The AVX2 speed regression keeps the rollout in draft.
'''
(q/'updated-body.md').write_text(text)
