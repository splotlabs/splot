Tracks #1934 under #1882. This draft includes the typed-driver work in #1977 and the portable x86 backend. Keep it in draft while the AVX2 throughput gate is open.

### Changes

Replace the checkout-wide x86-64-v3 and AVX-512-disabling flags with startup backend selection. A baseline x86-64 decoder can select SSE2; a qualified AVX2 host selects AVX2. The forced AVX-512 path remains available on supported machines. The current automatic wide-kernel policy remains conservative. The external consumer workflow exercises a Cargo project built outside this checkout.

Keep the existing decoder and kernel algorithms. Compile measured CDEF, GDF, transform, restoration, motion and prediction loops inside the selected SIMD scope so portable builds can inline their vector operations.

### Native AVX2 performance

On the i7-12700H, [4a23b9bc](https://github.com/splotlabs/splot/commit/4a23b9bcde3e14e35e1dd0b61f6254267906b09a) still takes longer than both the previous packaged v3 build (10279846) and the frozen pre-epic release (b337fafe). All builds used Auto, one decode thread and the same first 40 frames with null output. Each clip had a warm-up followed by 12 three-way rounds on CPU 4 covering all six executable orders twice. Host compilation was active. Paired process CPU results closely matched wall time.

| Stream | Additional elapsed time vs v3 | Additional elapsed time vs frozen |
|---|---:|---:|
| WITCHER3 1080p 8-bit QP135 | 12.9% | 17.5% |
| TunnelFlag 1080p 10-bit QP135 | 15.7% | 11.1% |

The previous v3 control won 11/12 WITCHER3 pairs and 12/12 TunnelFlag pairs. Earlier loop fixes, test methodology and outputs are in the [portability measurements](https://github.com/splotlabs/splot/issues/1934#issuecomment-7159880589). Native timing decides rollout. The full speed matrix is still open.

A separately built follow-up carried the backend through both parsers and specialized the CDEF gather. It still took 13.41% longer on WITCHER3, 17.08% longer on TunnelFlag and 37.78% longer on Noise_Ocean than the shipped reference. These measurements apply to the experimental branch. [Raw timings and exact revisions](https://github.com/splotlabs/splot/issues/1934#issuecomment-7163536585).

### Correctness

At 4a23b9bc, seven complete AVM raw hashes matched at 1, 7 and 12 threads (21/21). With QEMU masking features above SSE2, all ten checked-in 8/10-bit fixtures matched v3 through the CLI at 1, 3 and 8 threads and the external C consumer (40/40). The integration tip also contains current main’s multistream lifecycle update. CI will test the combined source. The [initial M2 Max correctness qualification](https://github.com/splotlabs/splot/issues/1980) is complete. [#1993](https://github.com/splotlabs/splot/issues/1993) tracks the two remaining first-picture latency comparisons.


### Linux x86-64 dual-backend size allowance

The release CLI with baseline and runtime-selected optimized kernels measured 16,659,288 stripped bytes on GitHub CI. The matching C shared library measured 12,947,536 stripped bytes. The owner accepted the size increase from compiling both backends. The Linux ceilings are 16,680,000 and 12,970,000 bytes respectively, allowing 20,712 and 22,464 bytes for host variation. All throughput and instruction gates still apply. The AVX2 end-to-end regression keeps this PR in draft.


