from hashlib import sha256
from pathlib import Path
import subprocess

OUTPUT = Path(__file__).resolve().parent
DATA = OUTPUT.parent / "ci-data"
BINARY = OUTPUT / "target/release/splot"

def verify():
    fixtures = (DATA / "simd-cases.tsv").read_text().splitlines()
    if len(fixtures) != 7:
        raise RuntimeError(f"Expected seven fixtures, got {len(fixtures)}")
    failures = []
    for fixture in fixtures:
        name, expected_hash, frames, expected_bytes = fixture.split("\t")
        for workers in (1, 7, 12):
            command = [
                BINARY, "decode", DATA / name, "--threads", str(workers),
                "--output-format", "raw", "-o", "-",
            ]
            digest = sha256()
            size = 0
            with subprocess.Popen(command, stdout=subprocess.PIPE) as decode:
                with decode.stdout:
                    for chunk in iter(lambda: decode.stdout.read(2**20), b""):
                        size += len(chunk)
                        digest.update(chunk)
                returncode = decode.wait()
            actual_hash = digest.hexdigest()
            good = returncode == 0 and actual_hash == expected_hash and size == int(expected_bytes)
            print(f"{'PASS' if good else 'FAIL'} {name} {workers} {frames} {size} {actual_hash}",
                  flush=True)
            if not good:
                failures.append((name, workers, returncode, expected_bytes, expected_hash))
    if failures:
        raise RuntimeError(failures)

if __name__ == "__main__":
    verify()
