"""Compare the two symbolized builds, preserving the raw evidence."""

from hashlib import sha256
from pathlib import Path
import csv
import os
import random
import re
import resource
from statistics import median
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
CONTROL = ROOT / "final-integration/splot.full"
CANDIDATE = OUT / "target/release/splot"
BINARIES = {"control": CONTROL, "decision": CANDIDATE}
STREAMS = {
    "Noise_Ocean": ROOT / "ci-data/Noise_Ocean_1920x1080_60fps_qp135_130f.ivf",
    "RitualDance": next((ROOT / "ci-data").glob("RitualDance*.ivf")),
}

def decode(binary, stream, *options):
    return [binary, "decode", stream, "--threads", "1", "--frame-delay", "1", *options]

def qualify():
    for name, stream in STREAMS.items():
        subprocess.run([
            "taskset", "-c", "3", "valgrind", "--tool=callgrind",
            f"--callgrind-out-file={OUT / (name + '.cg')}",
            f"--log-file={OUT / (name + '.cg.log')}",
            *decode(CANDIDATE, stream, "--output-format", "null", "--limit", "16"),
        ], check=True)

    expected = {}
    for row in (ROOT / "final-integration/avm.txt").read_text().splitlines():
        result, filename, workers, frames, size, digest = row.split()
        if result == "PASS" and workers == "1":
            expected[filename] = int(frames), int(size), digest
    failed = False
    with (OUT / "hashes.txt").open("x") as log:
        for name, stream in STREAMS.items():
            command = decode(CANDIDATE, stream, "--output-format", "raw", "-o", "-")
            digest = sha256()
            size = 0
            with subprocess.Popen(["taskset", "-c", "3", *command], stdout=subprocess.PIPE) as process:
                with process.stdout as output:
                    for block in iter(lambda: output.read(2**20), b""):
                        size += len(block)
                        digest.update(block)
                returncode = process.wait()
            frames, expected_size, expected_digest = expected[stream.name]
            good = returncode == 0 and size == expected_size and digest.hexdigest() == expected_digest
            print("PASS" if good else "FAIL", name, frames, size, digest.hexdigest(), file=log, flush=True)
            failed |= not good
    if failed:
        raise RuntimeError("Full clip output differed from the qualified control")

    deltas = []
    with (OUT / "instructions.txt").open("x") as log:
        for name in STREAMS:
            base = ROOT / f"cdef-boundary-ab/direct/{name}-base.cg.log"
            candidate = OUT / f"{name}.cg.log"
            old, new = (int(re.search(r"Collected\s*:\s*(\d+)", path.read_text())[1])
                        for path in (base, candidate))
            ratio = new / old - 1
            deltas.append((new - old, ratio))
            print(f"{name}: {old:,} -> {new:,} Ir, {new-old:+,} ({ratio:+.2%})", file=log)
    if sum(change for change, _ in deltas) < 0 and all(ratio <= 0.005 for _, ratio in deltas):
        (OUT / "wall-qualified").touch()

def child_cpu():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return usage.ru_utime + usage.ru_stime

def timed(binary, stream):
    cpu_start = child_cpu()
    start = time.perf_counter()
    subprocess.run(decode(binary, stream, "--output-format", "null", "--limit", "64"),
                   check=True, stdout=subprocess.DEVNULL)
    return time.perf_counter() - start, child_cpu() - cpu_start

def wall():
    assert os.sched_getaffinity(0) == {4}
    assert (OUT / "wall-qualified").exists()
    records = {}
    variants = tuple(BINARIES)
    for stream in STREAMS.values():
        for binary in BINARIES.values():
            timed(binary, stream)
    with (OUT / "wall.csv").open("x", newline="") as log:
        writer = csv.writer(log)
        writer.writerow(("stream", "pair", "position", "variant", "wall_s", "cpu_s"))
        for pair in range(1, 11):
            streams = tuple(STREAMS)
            for index, name in enumerate(streams if pair % 2 else streams[::-1]):
                order = variants if index == 0 else variants[::-1]
                for position, variant in enumerate(order, 1):
                    sample = timed(BINARIES[variant], STREAMS[name])
                    records[name, pair, variant] = sample
                    writer.writerow((name, pair, position, variant, *sample))
                log.flush()
    for name in STREAMS:
        for col, metric in enumerate(("wall", "CPU")):
            ratios = [records[name, pair, "decision"][col] / records[name, pair, "control"][col]
                      for pair in range(1, 11)]
            rng = random.Random(1882)
            bootstrap = sorted(median(rng.choices(ratios, k=10)) for _ in range(10000))
            lo, hi = bootstrap[250], bootstrap[9749]
            print(f"{name} {metric}: {median(ratios) - 1:+.2%} "
                  f"[{lo-1:+.2%}, {hi-1:+.2%}], slower {sum(r > 1 for r in ratios)}/10")

if __name__ == "__main__":
    {"qualify": qualify, "wall": wall}[sys.argv[1]]()
