
final-integration/splot.full:     file format elf64-x86-64


Disassembly of section .text:

0000000000a785c0 <_RNCINvNtNtNtCs9wFupXeM1Jn_11splot_recon14deblock_filter5edges8portable6decideNtNtNtCscIM9z48VHAb_13fearless_simd9generated4avx24Avx2Es8_0CsiiWGwn0QfU0_12splot_decode>:
  a785c0:	push   rbp
  a785c1:	push   r15
  a785c3:	push   r14
  a785c5:	push   r12
  a785c7:	push   rbx
  a785c8:	sub    rsp,0xb0
  a785cf:	movaps XMMWORD PTR [rsp+0x60],xmm1
  a785d4:	mov    r14d,edx
  a785d7:	movaps XMMWORD PTR [rsp+0x20],xmm0
  a785dc:	mov    r15,rsi
  a785df:	mov    rbx,rdi
  a785e2:	mov    rax,QWORD PTR [rsi]
  a785e5:	movaps xmm0,XMMWORD PTR [rax]
  a785e8:	movaps XMMWORD PTR [rsp+0x40],xmm0
  a785ed:	mov    rdi,rsp
  a785f0:	mov    esi,ecx
  a785f2:	call   c16840 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11splat_i16x86kernel22___fearless_simd_kernel>
  a785f7:	movaps xmm1,XMMWORD PTR [rsp]
  a785fb:	lea    rdi,[rsp+0x10]
  a78600:	movaps xmm0,XMMWORD PTR [rsp+0x40]
  a78605:	call   c17020 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9mul_i16x86kernel22___fearless_simd_kernel>
  a7860a:	movaps xmm0,XMMWORD PTR [rsp+0x10]
  a7860f:	lea    rdi,[rsp+0x70]
  a78614:	mov    esi,0x4
  a78619:	call   c170d0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9shr_i16x86kernel22___fearless_simd_kernel>
  a7861e:	mov    rax,QWORD PTR [r15+0x8]
  a78622:	movaps xmm0,XMMWORD PTR [rax]
  a78625:	movaps XMMWORD PTR [rsp+0x40],xmm0
  a7862a:	mov    rdi,rsp
  a7862d:	mov    esi,r14d
  a78630:	call   c16840 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11splat_i16x86kernel22___fearless_simd_kernel>
  a78635:	movaps xmm0,XMMWORD PTR [rsp]
  a78639:	lea    rdi,[rsp+0x10]
  a7863e:	movaps xmm1,XMMWORD PTR [rsp+0x40]
  a78643:	call   c16ac0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13simd_le_i16x86kernel22___fearless_simd_kernel>
  a78648:	movaps xmm1,XMMWORD PTR [rsp+0x10]
  a7864d:	lea    rdi,[rsp+0x30]
  a78652:	movaps xmm0,XMMWORD PTR [rsp+0x20]
  a78657:	call   c16960 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12and_mask16x86kernel22___fearless_simd_kernel>
  a7865c:	mov    rax,QWORD PTR [r15+0x18]
  a78660:	movaps xmm1,XMMWORD PTR [rsp+0x70]
  a78665:	movaps xmm0,XMMWORD PTR [rax]
  a78668:	mov    rdi,rsp
  a7866b:	call   c16ac0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13simd_le_i16x86kernel22___fearless_simd_kernel>
  a78670:	movaps xmm0,XMMWORD PTR [rsp+0x30]
  a78675:	movaps xmm1,XMMWORD PTR [rsp]
  a78679:	lea    rdi,[rsp+0x80]
  a78681:	call   c16960 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12and_mask16x86kernel22___fearless_simd_kernel>
  a78686:	mov    r15,QWORD PTR [r15+0x20]
  a7868a:	cmp    r14w,0x7
  a7868f:	mov    ebp,0x7
  a78694:	cmovb  ebp,r14d
  a78698:	mov    rax,QWORD PTR [r15]
  a7869b:	movaps xmm0,XMMWORD PTR [rax]
  a7869e:	movaps XMMWORD PTR [rsp+0x20],xmm0
  a786a3:	mov    rdi,rsp
  a786a6:	mov    esi,ebp
  a786a8:	call   c16840 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11splat_i16x86kernel22___fearless_simd_kernel>
  a786ad:	movaps xmm1,XMMWORD PTR [rsp]
  a786b1:	lea    rdi,[rsp+0xa0]
  a786b9:	movaps xmm0,XMMWORD PTR [rsp+0x20]
  a786be:	call   c16af0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13simd_lt_i16x86kernel22___fearless_simd_kernel>
  a786c3:	movzx  r14d,bp
  a786c7:	mov    eax,r14d
  a786ca:	xor    eax,0x7
  a786cd:	mov    rcx,QWORD PTR [r15+0x18]
  a786d1:	mov    rdx,QWORD PTR [r15+0x20]
  a786d5:	movaps xmm0,XMMWORD PTR [rdx]
  a786d8:	movaps XMMWORD PTR [rsp+0x20],xmm0
  a786dd:	movaps xmm0,XMMWORD PTR [rcx]
  a786e0:	movaps XMMWORD PTR [rsp+0x40],xmm0
  a786e5:	mov    rcx,QWORD PTR [r15+0x28]
  a786e9:	mov    r12,QWORD PTR [rcx]
  a786ec:	shl    eax,0x4
  a786ef:	movaps xmm1,XMMWORD PTR [r12+rax*1]
  a786f4:	lea    rdi,[rsp+0x50]
  a786f9:	call   c17170 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9sub_i16x86kernel22___fearless_simd_kernel>
  a786fe:	lea    rdi,[rsp+0x10]
  a78703:	movaps xmm0,XMMWORD PTR [rsp+0x40]
  a78708:	movaps xmm1,XMMWORD PTR [rsp+0x20]
  a7870d:	call   c17170 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9sub_i16x86kernel22___fearless_simd_kernel>
  a78712:	mov    rdi,rsp
  a78715:	mov    esi,ebp
  a78717:	call   c16840 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11splat_i16x86kernel22___fearless_simd_kernel>
  a7871c:	movaps xmm0,XMMWORD PTR [rsp+0x10]
  a78721:	movaps xmm1,XMMWORD PTR [rsp]
  a78725:	lea    rdi,[rsp+0x30]
  a7872a:	call   c17020 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9mul_i16x86kernel22___fearless_simd_kernel>
  a7872f:	movaps xmm0,XMMWORD PTR [rsp+0x50]
  a78734:	movaps xmm1,XMMWORD PTR [rsp+0x30]
  a78739:	mov    rdi,rsp
  a7873c:	call   c17170 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9sub_i16x86kernel22___fearless_simd_kernel>
  a78741:	movaps xmm0,XMMWORD PTR [rsp]
  a78745:	lea    rdi,[rsp+0x50]
  a7874a:	call   c16ee0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9abs_i16x86kernel22___fearless_simd_kernel>
  a7874f:	movaps xmm0,XMMWORD PTR [rsp+0x50]
  a78754:	movaps XMMWORD PTR [rsp+0x20],xmm0
  a78759:	mov    edi,0x8
  a7875e:	movaps xmm1,xmm0
  a78761:	call   c0da40 <_RNvNvNtNtCscIM9z48VHAb_13fearless_simd9generated4avx214dyn_alignr_12822___fearless_simd_kernel>
  a78766:	movaps xmm1,xmm0
  a78769:	lea    rdi,[rsp+0x10]
  a7876e:	movaps xmm0,XMMWORD PTR [rsp+0x20]
  a78773:	call   c16f10 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9add_i16x86kernel22___fearless_simd_kernel>
  a78778:	mov    rdi,rsp
  a7877b:	mov    esi,0x1
  a78780:	call   c16840 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11splat_i16x86kernel22___fearless_simd_kernel>
  a78785:	movaps xmm0,XMMWORD PTR [rsp+0x10]
  a7878a:	movaps xmm1,XMMWORD PTR [rsp]
  a7878e:	lea    rdi,[rsp+0x30]
  a78793:	call   c16f10 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9add_i16x86kernel22___fearless_simd_kernel>
  a78798:	movaps xmm0,XMMWORD PTR [rsp+0x30]
  a7879d:	mov    rdi,rsp
  a787a0:	mov    esi,0x1
  a787a5:	call   c17110 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9shr_u16x86kernel22___fearless_simd_kernel>
  a787aa:	movaps xmm0,XMMWORD PTR [rsp]
  a787ae:	lea    rdi,[rsp+0x10]
  a787b3:	movaps xmm1,XMMWORD PTR [rsp+0x60]
  a787b8:	call   c16ac0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13simd_le_i16x86kernel22___fearless_simd_kernel>
  a787bd:	movaps xmm0,XMMWORD PTR [rsp+0xa0]
  a787c5:	movaps xmm1,XMMWORD PTR [rsp+0x10]
  a787ca:	lea    rdi,[rsp+0x90]
  a787d2:	call   c16820 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11or_mask16x86kernel22___fearless_simd_kernel>
  a787d7:	mov    rax,QWORD PTR [r15+0x30]
  a787db:	mov    rcx,QWORD PTR [r15+0x38]
  a787df:	movaps xmm0,XMMWORD PTR [rcx]
  a787e2:	movaps XMMWORD PTR [rsp+0x20],xmm0
  a787e7:	movaps xmm0,XMMWORD PTR [rax]
  a787ea:	movaps XMMWORD PTR [rsp+0x40],xmm0
  a787ef:	shl    r14d,0x4
  a787f3:	movaps xmm1,XMMWORD PTR [r12+r14*1+0x80]
  a787fc:	lea    rdi,[rsp+0x50]
  a78801:	call   c17170 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9sub_i16x86kernel22___fearless_simd_kernel>
  a78806:	lea    rdi,[rsp+0x10]
  a7880b:	movaps xmm0,XMMWORD PTR [rsp+0x40]
  a78810:	movaps xmm1,XMMWORD PTR [rsp+0x20]
  a78815:	call   c17170 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9sub_i16x86kernel22___fearless_simd_kernel>
  a7881a:	mov    rdi,rsp
  a7881d:	mov    esi,ebp
  a7881f:	call   c16840 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11splat_i16x86kernel22___fearless_simd_kernel>
  a78824:	movaps xmm0,XMMWORD PTR [rsp+0x10]
  a78829:	movaps xmm1,XMMWORD PTR [rsp]
  a7882d:	lea    rdi,[rsp+0x30]
  a78832:	call   c17020 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9mul_i16x86kernel22___fearless_simd_kernel>
  a78837:	movaps xmm0,XMMWORD PTR [rsp+0x50]
  a7883c:	movaps xmm1,XMMWORD PTR [rsp+0x30]
  a78841:	mov    rdi,rsp
  a78844:	call   c17170 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9sub_i16x86kernel22___fearless_simd_kernel>
  a78849:	movaps xmm0,XMMWORD PTR [rsp]
  a7884d:	lea    rdi,[rsp+0x50]
  a78852:	call   c16ee0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9abs_i16x86kernel22___fearless_simd_kernel>
  a78857:	movaps xmm0,XMMWORD PTR [rsp+0x50]
  a7885c:	movaps XMMWORD PTR [rsp+0x20],xmm0
  a78861:	mov    edi,0x8
  a78866:	movaps xmm1,xmm0
  a78869:	call   c0da40 <_RNvNvNtNtCscIM9z48VHAb_13fearless_simd9generated4avx214dyn_alignr_12822___fearless_simd_kernel>
  a7886e:	movaps xmm1,xmm0
  a78871:	lea    rdi,[rsp+0x10]
  a78876:	movaps xmm0,XMMWORD PTR [rsp+0x20]
  a7887b:	call   c16f10 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9add_i16x86kernel22___fearless_simd_kernel>
  a78880:	mov    rdi,rsp
  a78883:	mov    esi,0x1
  a78888:	call   c16840 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd11splat_i16x86kernel22___fearless_simd_kernel>
  a7888d:	movaps xmm0,XMMWORD PTR [rsp+0x10]
  a78892:	movaps xmm1,XMMWORD PTR [rsp]
  a78896:	lea    rdi,[rsp+0x30]
  a7889b:	call   c16f10 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9add_i16x86kernel22___fearless_simd_kernel>
  a788a0:	movaps xmm0,XMMWORD PTR [rsp+0x30]
  a788a5:	mov    rdi,rsp
  a788a8:	mov    esi,0x1
  a788ad:	call   c17110 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd9shr_u16x86kernel22___fearless_simd_kernel>
  a788b2:	movaps xmm0,XMMWORD PTR [rsp]
  a788b6:	lea    rdi,[rsp+0x10]
  a788bb:	movaps xmm1,XMMWORD PTR [rsp+0x60]
  a788c0:	call   c16ac0 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd13simd_le_i16x86kernel22___fearless_simd_kernel>
  a788c5:	movaps xmm0,XMMWORD PTR [rsp+0x90]
  a788cd:	movaps xmm1,XMMWORD PTR [rsp+0x10]
  a788d2:	mov    rdi,rsp
  a788d5:	call   c16960 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12and_mask16x86kernel22___fearless_simd_kernel>
  a788da:	movaps xmm0,XMMWORD PTR [rsp+0x80]
  a788e2:	movaps xmm1,XMMWORD PTR [rsp]
  a788e6:	mov    rdi,rbx
  a788e9:	add    rsp,0xb0
  a788f0:	pop    rbx
  a788f1:	pop    r12
  a788f3:	pop    r14
  a788f5:	pop    r15
  a788f7:	pop    rbp
  a788f8:	jmp    c16960 <_RNvNvNvXs2_NtNtCscIM9z48VHAb_13fearless_simd9generated4avx2NtB9_4Avx2NtNtBb_10simd_trait4Simd12and_mask16x86kernel22___fearless_simd_kernel>
