# Deblock application on RitualDance

The 16-frame symbolized shipped and merged traces show 918 calls to each pass from FrameDeblock. Vertical PassEdges::apply grows by 63,326,945 instructions and horizontal by 4,983,428 instructions, totaling 68,310,373.

| Matched part | Calls per build | Shipped Ir | Merged Ir | Increase |
|---|---:|---:|---:|---:|
| Vertical PassEdges::apply | 918 | 99,556,298 | 162,883,243 | 63,326,945 |
| Horizontal PassEdges::apply | 918 | 60,532,951 | 65,516,379 | 4,983,428 |
| Vertical u16 chunks | 136,332 | 87,263,735 | 148,747,318 | 61,483,583 |

The merged vertical chunk is split into a runner scope with 4,907,952 self Ir, an inner SIMD scope with 98,462,448 self Ir, and the wide-width decision closure with 45,376,918 inclusive Ir. The last appears only in the merged trace and is 26,307,477 self Ir plus leaf helpers. The decision closure is called 139,193 times, retires approximately 326 instructions per call, and contains 36 statically linked calls to individual AVX2 helper functions. It has zero VEX instructions. The shipped vertical chunk already inlines the decision.

Commit 334bb2e5 moved the portable chunk selection into its target scope. Commit 18397558 forced inlining for the inner end-distance test. The captured width eligibility closure still escapes the scope. Commit 23189db2 expands the shared width eligibility expression at the three fixed distances inside the existing chunk. It preserves all thresholds, width ordering and sample writeback. The focused candidate compares against the exact symbolized 7c50 control. Its base 6387 differs only in the binary size budget.
