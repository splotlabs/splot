"""Summarize the three-way release comparison with one ratio per rotation."""
from collections import defaultdict
from pathlib import Path
import csv
import random
from statistics import median

here = Path(__file__).parent
raw = defaultdict(dict)
for row in csv.DictReader((here/'xeon-release.csv').open()):
    case = (row['stream'],int(row['threads']),int(row['frames']),int(row['round']))
    raw[case][row['revision']] = float(row['wall_seconds'])
assert len(raw)==21*12
groups = defaultdict(list)
for (case,threads,frames,round_no), timings in sorted(raw.items()):
    assert timings.keys() == {'frozen','parent','candidate'}
    groups[case,threads,frames].append(timings)
rng = random.Random(1882)
def interval(group, control):
    values = [g['candidate']/g[control] for g in group]
    dist=sorted(median(rng.choices(values,k=len(values))) for _ in range(10000))
    return tuple(100*(v-1) for v in (median(values),dist[249],dist[9749]))
lines = ['| Stream | Workers | Frames | vs parent [95% interval] | vs frozen [95% interval] |','|---|---:|---:|---:|---:|']
for (name,t,f),group in groups.items():
    assert len(group)==12
    name=('OldTown' if name.startswith('old_town') else name.split('_')[0])+(' grain' if 'filmgrain' in name else '')
    spans=[f'{m:+.2f}% [{l:+.2f}, {h:+.2f}]' for m,l,h in [interval(group,ctl) for ctl in ('parent','frozen')]]
    lines.append(f'| {name} | {t} | {f} | '+ ' | '.join(spans)+' |')
print('\n'.join(lines))
(here/'summary.md').write_text('\n'.join(lines)+'\n')
