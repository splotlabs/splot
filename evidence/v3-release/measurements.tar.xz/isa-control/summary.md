# Same-ISA multiversioning comparison

Both executables used the same 91fbc921 product sources, v3 compiler floor, release profile and native Xeon 6975P-C. The single-policy control removes the AVX2 session variant and rejects machines lacking the complete AVX-512 feature set. Both retain identical narrow kernels inside the wide policy. The dual CLI and shared library match the c9a9a960 matched ELF files byte-for-byte. Linked symbols, sections and checksums appear alongside this file. All 14 full AVM comparisons passed.

One warmup and 24 alternating pairs per case. Single-worker runs were CPU-pinned. The host exposed four vCPUs. Frame delay was capped at four. Positive values indicate greater elapsed time in the shipping dual artifact than in the single-wide control. Intervals use a 10,000-resample paired median bootstrap.

| Stream | Workers | Frames | Pairs | Dual vs single [95% interval] |
|---|---:|---:|---:|---:|
| BlueSky | 1 | 64 | 24 | -0.24% [-0.48%, -0.01%] |
| BlueSky | 7 | 64 | 24 | +1.37% [-0.51%, +1.91%] |
| BlueSky | 12 | 64 | 24 | +0.37% [-1.79%, +1.30%] |
| Noise grain | 1 | 130 | 24 | +0.01% [-0.27%, +0.20%] |
| Noise grain | 7 | 130 | 24 | -0.16% [-0.81%, +0.39%] |
| Noise grain | 12 | 130 | 24 | -0.73% [-1.42%, +0.18%] |
| RitualDance | 1 | 64 | 24 | +0.05% [-0.48%, +0.13%] |
| RitualDance | 7 | 64 | 24 | -0.66% [-0.81%, +0.47%] |
| RitualDance | 12 | 64 | 24 | -0.35% [-1.73%, -0.26%] |
