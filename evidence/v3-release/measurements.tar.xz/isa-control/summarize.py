"""Elapsed cost of carrying a second dispatch policy with identical AVX-512 work."""
from collections import defaultdict
import csv
from pathlib import Path
import random
from statistics import median
root=Path(__file__).resolve().parent
cases=defaultdict(lambda:defaultdict(dict))
for row in csv.DictReader((root/'single-isa.csv').open()):
    name=row['stream']
    case=('Noise grain' if 'filmgrain' in name else name.split('_')[0],int(row['workers']),row['frames'])
    slot=cases[case][int(row['round'])]
    assert row['mode'] not in slot
    slot[row['mode']]=float(row['seconds'])
assert len(cases)==9
rng=random.Random(1882)
out=['# Same-ISA multiversioning comparison','','Both executables used the same 91fbc921 product sources, v3 compiler floor, release profile and native Xeon 6975P-C. The single-policy control removes the AVX2 session variant and rejects machines lacking the complete AVX-512 feature set. Both retain identical narrow kernels inside the wide policy. The dual CLI and shared library match the c9a9a960 matched ELF files byte-for-byte. Linked symbols, sections and checksums appear alongside this file. All 14 full AVM comparisons passed.','','One warmup and 24 alternating pairs per case. Single-worker runs were CPU-pinned. The host exposed four vCPUs. Frame delay was capped at four. Positive values indicate greater elapsed time in the shipping dual artifact than in the single-wide control. Intervals use a 10,000-resample paired median bootstrap.','','| Stream | Workers | Frames | Pairs | Dual vs single [95% interval] |','|---|---:|---:|---:|---:|']
for (name,workers,frames),rounds in sorted(cases.items()):
    assert len(rounds)==24
    v=[t['dual']/t['single'] for t in rounds.values()]
    dist=sorted(median(rng.choices(v,k=len(v))) for _ in range(10000))
    pct=lambda x:f'{(x-1)*100:+.2f}%'
    out.append(f'| {name} | {workers} | {frames} | {len(v)} | {pct(median(v))} [{pct(dist[249])}, {pct(dist[9749])}] |')
(root/'summary.md').write_text('\n'.join(out)+'\n')
print('\n'.join(out[-9:]))
