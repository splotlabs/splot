| Case | Workers or row width | Pairs | Median AVX-512 elapsed delta [95% paired bootstrap interval] |
|---|---:|---:|---:|
| BlueSky_360p25_v2_qp110_130f | 1 | 48 | -0.22% [-0.61%, +0.11%] |
| BlueSky_360p25_v2_qp110_130f | 7 | 48 | +0.16% [-0.43%, +0.60%] |
| BlueSky_360p25_v2_qp110_130f | 12 | 48 | +0.04% [-1.02%, +0.65%] |
| Noise_Ocean | 1 | 48 | +0.01% [-0.17%, +0.19%] |
| Noise_Ocean | 7 | 48 | -0.30% [-0.78%, +0.08%] |
| Noise_Ocean | 12 | 48 | +0.09% [-0.54%, +0.61%] |
