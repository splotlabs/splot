"""Capture linked ELF sections, dispatch edges, and SIMD disassembly."""

from collections import Counter
from pathlib import Path
import csv
import re
import struct
import subprocess
import sys


def capture(command, path):
    with path.open("w") as stream:
        subprocess.run(command, stdout=stream, check=True)


LABEL = re.compile(r"^([0-9a-f]+) <(.*)>:$")
INSTR = re.compile(r"^\s*([0-9a-f]+):\s*((?:[0-9a-f]{2} )+)\s*([a-z][a-z0-9]*)\s*(.*)$")
EDGE = re.compile(r"^([0-9a-f]+) <(.*)>$")
RIP_SLOT = re.compile(r"\[rip[^\]]*\]\s*# ([0-9a-f]+) <")
ZMM = re.compile(r"\bzmm\d+\b")
YMM = re.compile(r"\bymm\d+\b")
MASK = re.compile(r"\bk[1-7]\b")
GRAIN = re.compile(r"(?:film_grain::|apply_film_grain|add_noise_lan|add_noise_row)")
DISPATCH = re.compile(
    r"(?:simd::resolve_backend|simd::CACHED_LEVEL|avx512_qualified_for_auto|"
    r"Decoder>::new_with_external_atlases|CACHED_LEVEL|fearless_simd::Level.*::new|"
    r"splot_capi::open_decoder|splot_open|Picture>::apply_film_grain|"
    r"splot_cli::commands::decode::.*run|splot_get_picture|decoder::.*DriverLaunch)"
)


def linked_slots(binary, symbols):
    image = binary.read_bytes()
    assert image[:6] == b"\x7fELF\x02\x01"
    phoff, phentsize, phnum = struct.unpack_from("<Q14xHH", image, 32)
    loads = []
    for index in range(phnum):
        kind, _, offset, address, _, size = struct.unpack_from("<IIQQQQ", image, phoff + index * phentsize)
        if kind == 1:
            loads.append((address, address + size, offset))
    names = {}
    for line in symbols.read_text().splitlines():
        if entry := re.match(r"^([0-9a-f]+)(?: [0-9a-f]+)? \w (.*)$", line):
            names[int(entry[1], 16)] = entry[2]

    def target(address):
        for start, limit, offset in loads:
            if start <= address <= limit - 8:
                pointer = struct.unpack_from("<Q", image, offset + address - start)[0]
                return pointer, names.get(pointer, "")
        return 0, ""

    return target


def scan(binary, out):
    slot_target = linked_slots(binary, out / "symbols.txt")
    with (
        (out / "functions.tsv").open("w") as fn,
        (out / "edges.tsv").open("w") as edges,
        (out / "focused.asm").open("w") as assembly,
        subprocess.Popen(
            ["objdump", "-dC", "-Mintel", "--insn-width=16", str(binary)],
            stdout=subprocess.PIPE,
            text=True,
        ) as objdump,
    ):
        functions = csv.writer(fn, delimiter="\t", lineterminator="\n")
        functions.writerow(("address", "last_instruction", "instructions", "zmm", "ymm", "mask", "evex", "name"))
        calls = csv.writer(edges, delimiter="\t", lineterminator="\n")
        calls.writerow(("caller_address", "edge_address", "operation", "target_address", "caller", "target"))
        addr, name, last = "", "", ""
        lines = []
        counts = Counter()

        def flush():
            if counts["instructions"] and (GRAIN.search(name) or DISPATCH.search(name) or counts["evex"]):
                functions.writerow((
                    addr, last, counts["instructions"], counts["zmm"], counts["ymm"], counts["mask"],
                    counts["evex"], name,
                ))
                if GRAIN.search(name) or DISPATCH.search(name):
                    assembly.writelines(lines)
                    assembly.write("\n")

        for line in objdump.stdout:
            if symbol := LABEL.match(line):
                flush()
                addr, name = symbol.groups()
                lines = [line]
                counts.clear()
                continue
            if not (instruction := INSTR.match(line)):
                continue
            last, encoding, opcode, arguments = instruction.groups()
            lines.append(line)
            counts["instructions"] += 1
            counts["zmm"] += bool(ZMM.search(arguments))
            counts["ymm"] += bool(YMM.search(arguments))
            counts["mask"] += bool(MASK.search(arguments))
            counts["evex"] += encoding.startswith("62 ")
            if opcode in ("call", "jmp", "je", "jne", "ja", "jb", "jbe", "jae"):
                if destination := EDGE.match(arguments):
                    target, symbol = destination.groups()
                elif opcode in ("call", "jmp") and (slot := RIP_SLOT.search(arguments)):
                    pointer, symbol = slot_target(int(slot[1], 16))
                    target = f"{pointer:x}"
                    opcode += "-linked-slot"
                else:
                    continue
                if symbol != name and not symbol.startswith(name + "+") and (
                    GRAIN.search(symbol) or DISPATCH.search(symbol)
                ):
                    calls.writerow((addr, last, opcode, target, name, symbol))
        flush()
        if objdump.wait():
            raise subprocess.CalledProcessError(objdump.returncode, objdump.args)


def main():
    sources = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    for filename in ("splot", "libsplot_capi.so"):
        binary = sources / filename
        out = output / filename
        out.mkdir(parents=True, exist_ok=True)
        stripped = out / (filename + ".stripped")
        subprocess.run(["strip", "--strip-all", "-o", str(stripped), str(binary)], check=True)
        capture(["size", "-A", "-d", str(stripped)], out / "sections.txt")
        capture(["readelf", "-nVd", str(binary)], out / "elf-metadata.txt")
        capture(["nm", "-nCS", "--defined-only", str(binary)], out / "symbols.txt")
        scan(binary, out)


if __name__ == "__main__":
    main()
