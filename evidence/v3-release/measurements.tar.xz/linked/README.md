# Matched linked x86-64-v3 release inspection

## Build and artifact verification

[Actions run 45671134269](https://github.com/splotlabs/splot/actions/runs/45671134269) completed successfully. It built [main `d171d824`](https://github.com/splotlabs/splot/commit/d171d82416a67140e1f6696eeba8e08e56af5763) and [the signed runtime-wide candidate `a55cff38`](https://github.com/splotlabs/splot/commit/a55cff38f4d5a5855af54e75aeac25b92a09531f). The workflow commit is `5f5dee9be1dc0c909265f85212698579afab7b6d`. The GitHub artifact IDs are `15050576422` for main and `15049572984` for the candidate. Both ZIPs matched the SHA-256 from the Actions API. All four binaries matched their embedded manifests. The originals retain their symbols and are in `release-main/` and `release-wide/`.

Both builds used an Ubuntu 24.04 runner, rustc 1.100.0 `0ef1bc386059596dada8fb65b50425aab2ea637a`, LLVM 23.1.5, Cargo ThinLTO, and one codegen unit. The build command was `cargo build --release --locked -j1 -p splot-cli -p splot-capi` with `CARGO_PROFILE_RELEASE_STRIP=none`. Both revisions' Cargo configuration targets `x86-64-v3` and links packed relative relocations. Main additionally builds with `--cfg disable_dispatch_avx512`. All four ELF files record `GLIBC_ABI_DT_RELR`. Their highest numbered glibc symbol version is `GLIBC_2.34`. The DT_RELR ABI also requires a glibc loader with DT_RELR support.

See `workflow.yml`, `run.json`, `artifacts.json`, `input-archives.SHA256SUMS` and each extracted artifact's `revision.txt`, `toolchain.txt` and `SHA256SUMS`.

## Stripped artifact sizes

Measurements use GNU strip 2.46 `--strip-all` on duplicate files. Each copy retains the exact `.text` and `.rodata` bytes of its symbolized input. These are local post-strip file sizes for the matched hosted builds.

| Measure | Main CLI | Candidate CLI | Change | Main C library | Candidate C library | Change |
|---|---:|---:|---:|---:|---:|---:|
| Symbolized file | 16,145,488 | 16,179,912 | +34,424 | 13,345,408 | 13,380,136 | +34,728 |
| Stripped file | 12,464,680 | 12,491,576 | **+26,896 (+0.216%)** | 8,549,296 | 8,577,680 | **+28,384 (+0.332%)** |
| `.text` | 10,498,215 | 10,523,735 | +25,520 | 6,766,851 | 6,792,739 | +25,888 |
| `.rodata` | 1,716,930 | 1,717,282 | +352 | 1,282,188 | 1,282,444 | +256 |
| `.data.rel.ro` | 124,552 | 124,832 | +280 | 39,776 | 39,936 | +160 |

The two film-grain wide scopes contribute 2,445 bytes of CLI symbols and 2,099 bytes of C-library symbols. The complete delta includes changes to other code and layout. Section hashes and stripped file hashes are in `section-verification.tsv` and `post-strip.SHA256SUMS`.

## Startup selection and linked row loops

The candidate's CLI decode calls the constructor from the CLI main closure at `0x21d977 → 0x7603b0` via a linked slot. The constructor inlines backend resolution and loads `CACHED_LEVEL` at `0x7605c5`. Its two typed driver launch edges are direct calls at `0x760b84` and `0x760c40`. Main's CLI has one AVX2 launch path.

The candidate's C ABI `splot_open` directly calls `open_decoder` at `0x190d10 → 0x190050`. Linked slots connect `open_decoder` to the constructor at `0x190220 → 0x58c260` and the constructor to `resolve_backend` at `0x58c4f9 → 0x7c0760`. The resolver loads `CACHED_LEVEL`, then the constructor calls the typed driver at `0x58c971` or `0x58ca29`. The public `splot_apply_grain` goes through `Picture::apply_film_grain` via a linked slot. Each pixel width reaches the corresponding `display` and `output::film_grain::apply` routine.

The source resolves `Auto` to AVX-512 only when the process-cached fearless_simd CPU and OS capability probe supplies both AVX2 and AVX-512. The stored session backend is passed to grain output. The tagged grain output uses the narrow row for unselected AVX-512, bit depth above ten, and row widths below 32. The row width comparisons in the candidate are at `0x52ba25`, `0x530244`, `0x3a08a4` and `0x3a59e8`. No new CPU capability probe is present in either row loop.

| Artifact and sample | Candidate row direct call → AVX-512 scope | ZMM multiply example | Candidate inlined AVX2 multiply example | Main inlined AVX2 multiply example |
|---|---|---|---|---|
| CLI `u8` | `0x52ba8f → 0x65de20` | `0x65dfde` | `0x529c30` | `0x446070` |
| CLI `u16` | `0x530170 → 0x65e2e0` | `0x65e3c5` | `0x52f880` | `0x449840` |
| C library `u8` | `0x3a090e → 0x4c9ec0` | `0x4ca0a3` | `0x39ee10` | `0x2beee0` |
| C library `u16` | `0x3a5a52 → 0x4ca300` | `0x4ca4d6` | `0x3a5150` | `0x2c2ba0` |

The wide row scopes contain native 32-lane signed-word multiplies, shifts and clamps. Each scope contains 39 decoded ZMM instructions, counting both arithmetic branches. Both main artifacts have zero decoded EVEX instructions. In both candidate artifacts, every decoded EVEX instruction is in the two film-grain scopes. The corresponding AVX2 arithmetic uses VEX-encoded YMM instructions inside the output routines. These linked inspections establish instruction placement and call paths. Native timing and output parity are separate measurements.

See `main-analysis/` and `wide-analysis/` for ELF metadata, symbols, section sizes, focused disassembly with instruction bytes, and the extracted call and instruction tables. Reproduce with `python3 inspect.py release-main main-analysis` and `python3 inspect.py release-wide wide-analysis`.
