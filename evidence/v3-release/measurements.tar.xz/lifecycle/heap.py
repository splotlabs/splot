"""Use Valgrind DHAT on the matched release CLIs and committed I420 outputs."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib
out=Path(__file__).resolve().parent
products=out.parent/'consumer-sizes'
manifest=tomllib.loads((products/'parent/source/tests/conformance/decoder-oracle.toml').read_text())
with (out/'heap.tsv').open('w') as summary:
    w=csv.writer(summary,delimiter='\t',lineterminator='\n')
    w.writerow(['case','build','total_blocks','total_bytes','bytes_at_global_max','blocks_at_global_max','output_sha256'])
    for case in ('syn-filmgrain-intra-64x64','syn-3frame-filmgrain-inter-64x64-10bit','syn-8frame-opfl-refine-all-64x64-q120'):
        fixture=products/'parent/source'/manifest['vectors_dir']/(case+'.ivf')
        expected=next(e['avm_raw_sha256'] for e in manifest['fixture'] if e['id']==case)
        for mode in ('parent','final'):
            tag=case+'-'+mode
            cmd=['valgrind','--tool=dhat','--num-callers=3','--dhat-out-file='+str(out/(tag+'.json')),'--log-file='+str(out/(tag+'.log')),products/mode/'splot','decode',fixture,'--threads','1','--frame-delay','1','--output-format','raw','-o','-']
            raw=subprocess.check_output(cmd)
            digest=hashlib.sha256(raw).hexdigest()
            assert digest==expected
            points=json.loads((out/(tag+'.json')).read_text())['pps']
            w.writerow([case,mode,*[sum(p[k] for p in points) for k in ('tbk','tb','gb','gbk')],digest])
            summary.flush()
