"""Paired medians of intervals measured through the public streaming decoder."""
import csv
from collections import defaultdict
from pathlib import Path
import random
from statistics import median,quantiles
root=Path(__file__).resolve().parent
cases=defaultdict(lambda:defaultdict(dict))
with (root/'events.csv').open() as f:
    rows=csv.reader(f)
    next(rows)
    for stream,workers,r,pos,mode,*raw in rows:
        start,opened,drain,drained,closed,*pictures = map(int,raw)
        steps=[later-earlier for earlier,later in zip(pictures,pictures[1:])]
        assert min(steps)>0 and start<=opened<=drain<=drained<=closed
        cases[stream,int(workers)][int(r)][mode]={
            'open':opened-start,'first':pictures[0]-start,
            'p95 inter-picture':quantiles(steps,n=100,method='inclusive')[94],
            'drain':drained-drain,'close':closed-drained,'total':closed-start,
        }
rng=random.Random(1882)
out=['# AVX2 public C decoder latency','',
     'Matched release libraries from main 9df30e91 and the dual typed implementation c9a9a960. Each input contains 64 IVF records. The grained Noise stream yields 123 displayed pictures and 10-bit RitualDance yields 120. Both revisions use the same C executable and ABI. Each whole decode process records monotonic timestamps at open, each received picture, final drain and close. It writes raw samples to /dev/null, including the selected grain. The measurements include framework and output work between consecutive picture notifications. The p95 is computed within each decode, then paired across revisions. Inter-picture time measures delivery cadence.','',
     'Twelve warmed alternating pairs per cell on the AVX2 workstation, pinned to CPU 4 for one worker, with all 20 logical CPUs available for seven and twelve. Frame delay equals worker count. Some multithread runs overlapped a bounded single-worker build on cores 12–15. Intervals are percentile bootstrap intervals for the median paired ratio, conditional on these runs. The six endpoints and six cases are exploratory, with no multiplicity correction.','',
     '| Stream | Workers | Endpoint | Main median, ms | Candidate median, ms | Paired elapsed change [95% interval] |','|---|---:|---|---:|---:|---:|']
for (s,w),data in sorted(cases.items()):
    assert len(data)==12
    for metric in next(iter(data.values()))['main']:
        before=[d['main'][metric] for d in data.values()]
        after=[d['candidate'][metric] for d in data.values()]
        ratios=[b/a for a,b in zip(before,after)]
        dist=sorted(median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
        pct=lambda x: f'{(x-1)*100:+.2f}%'
        out.append(f'| {s} | {w} | {metric} | {median(before)/1e6:.3f} | {median(after)/1e6:.3f} | {pct(median(ratios))} [{pct(dist[249])}, {pct(dist[9749])}] |')
(root/'summary.md').write_text('\n'.join(out)+'\n')
