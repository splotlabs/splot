"""Time the public C decoder at the API boundary for both matched linked release builds."""
import csv
import hashlib
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
libs = {key: root.parent/'consumer-sizes'/label/'c-host' for key,label in (('main','parent'),('candidate','final'))}
streams = {p.name.split('_')[0]: p for p in (root.parent/'consumer-sizes').glob('*prefix64.ivf')}
cases = [(label,workers) for workers in (1,7,12) for label in sorted(streams)]
def sample(label, workers, build):
    cpus = '4' if workers == 1 else '0-19'
    env = {**os.environ,'LD_LIBRARY_PATH':str(libs[build])}
    proc = subprocess.run(['taskset','-c',cpus,root/'measure',streams[label],os.devnull,str(workers)],env=env,capture_output=True,check=True,text=True)
    return [int(n) for n in proc.stdout.strip().split(',')]
if __name__ == '__main__':
    sizes = {}
    for build in libs:
        for label, workers in cases:
            raw = sample(label,workers,build)
            count = len(raw)-5
            assert sizes.setdefault(label,count) == count and count>10
    print('warmup, picture counts',sizes,flush=True)
    with (root/'events.csv').open('w') as f:
        writer=csv.writer(f)
        writer.writerow(['stream','workers','round','position','revision','open_start_ns','open_end_ns','drain_start_ns','drain_end_ns','close_end_ns','picture_times_ns ...'])
        for r in range(12):
            for i in range(len(cases)):
                label, workers = cases[(r+i)%len(cases)]
                order = list(libs) if (r+cases.index((label,workers)))%2==0 else list(reversed(libs))
                for pos, build in enumerate(order):
                    events = sample(label,workers,build)
                    assert len(events)-5 == sizes[label]
                    writer.writerow([label,workers,r+1,pos+1,build,*events])
                f.flush()
            print('completed round',r+1,flush=True)
    for key,path in libs.items():
        with (path/'libsplot_capi.so').open('rb') as f: print(key,hashlib.file_digest(f,'sha256').hexdigest())
