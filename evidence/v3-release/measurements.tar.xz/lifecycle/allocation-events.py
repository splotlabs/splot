"""Count named Rust allocation and Arc last-owner calls in the saved linked traces."""
import csv
from collections import Counter
from pathlib import Path
import re
root=Path(__file__).resolve().parent.parent
out=root/'lifecycle'/'allocation-events.tsv'
stamps=root/'typed-screen'/'traces'
with out.open('w') as file:
    w=csv.writer(file,delimiter='\t',lineterminator='\n')
    w.writerow(['stream','variant','rust_alloc','rust_alloc_zeroed','rust_realloc','rust_dealloc','arc_drop_slow','relative_trace'])
    for f in sorted([*stamps.glob('*.cg'),*(root/'matched').glob('*-main.cg')]):
        lines=f.read_text().splitlines()
        names={}
        for row in lines:
            m=re.match(r'c?fn=\((\d+)\) (.+)$',row)
            if m: names[m[1]]=m[2]
        counts=Counter()
        callee=None
        for row in lines:
            if row.startswith('cfn='):
                callee=names[re.match(r'cfn=\((\d+)\)',row)[1]]
            elif row.startswith('calls='):
                assert callee is not None
                count=int(row.split()[0].split('=')[1])
                counts[callee]+=count
            elif row.startswith('fn='):
                callee=None
        name,variant=f.stem.rsplit('-',1)
        drop=sum(v for k,v in counts.items() if k.startswith('<alloc::sync::Arc<') and k.endswith('>::drop_slow'))
        w.writerow([name,variant,*[counts['__rustc::__rust_'+n] for n in ('alloc','alloc_zeroed','realloc','dealloc')],drop,f.relative_to(root)])
