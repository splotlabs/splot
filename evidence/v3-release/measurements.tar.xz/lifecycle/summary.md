# AVX2 public C decoder latency

Matched release libraries from main 9df30e91 and the dual typed implementation c9a9a960. Each input contains 64 IVF records. The grained Noise stream yields 123 displayed pictures and 10-bit RitualDance yields 120. Both revisions use the same C executable and ABI. Each whole decode process records monotonic timestamps at open, each received picture, final drain and close. It writes raw samples to /dev/null, including the selected grain. The measurements include framework and output work between consecutive picture notifications. The p95 is computed within each decode, then paired across revisions. Inter-picture time measures delivery cadence.

Twelve warmed alternating pairs per cell on the AVX2 workstation, pinned to CPU 4 for one worker, with all 20 logical CPUs available for seven and twelve. Frame delay equals worker count. Some multithread runs overlapped a bounded single-worker build on cores 12–15. Intervals are percentile bootstrap intervals for the median paired ratio, conditional on these runs. The six endpoints and six cases are exploratory, with no multiplicity correction.

| Stream | Workers | Endpoint | Main median, ms | Candidate median, ms | Paired elapsed change [95% interval] |
|---|---:|---|---:|---:|---:|
| Noise | 1 | open | 0.079 | 0.077 | -4.29% [-18.31%, +14.34%] |
| Noise | 1 | first | 24.399 | 24.362 | +2.55% [-9.22%, +11.09%] |
| Noise | 1 | p95 inter-picture | 37.993 | 38.385 | +0.75% [-3.07%, +5.92%] |
| Noise | 1 | drain | 54.545 | 56.409 | +2.98% [-6.44%, +11.30%] |
| Noise | 1 | close | 2.113 | 2.142 | -0.45% [-7.41%, +7.62%] |
| Noise | 1 | total | 1145.035 | 1172.543 | +3.46% [-0.24%, +4.86%] |
| Noise | 7 | open | 0.422 | 0.392 | -11.66% [-24.71%, +25.99%] |
| Noise | 7 | first | 27.325 | 24.233 | +0.15% [-19.08%, +9.12%] |
| Noise | 7 | p95 inter-picture | 10.845 | 10.895 | +0.55% [-10.56%, +8.06%] |
| Noise | 7 | drain | 104.277 | 99.708 | +3.44% [-6.93%, +6.01%] |
| Noise | 7 | close | 11.074 | 10.680 | -5.01% [-10.38%, +10.13%] |
| Noise | 7 | total | 670.163 | 634.015 | -5.17% [-18.65%, +0.43%] |
| Noise | 12 | open | 0.659 | 0.616 | -10.28% [-26.57%, +4.06%] |
| Noise | 12 | first | 31.457 | 32.316 | +2.05% [-8.23%, +12.57%] |
| Noise | 12 | p95 inter-picture | 15.535 | 15.295 | -2.14% [-8.15%, +22.66%] |
| Noise | 12 | drain | 206.043 | 205.256 | -3.52% [-16.70%, +18.80%] |
| Noise | 12 | close | 15.151 | 14.966 | -0.60% [-16.85%, +14.43%] |
| Noise | 12 | total | 766.930 | 739.864 | +1.32% [-9.10%, +8.77%] |
| RitualDance | 1 | open | 0.085 | 0.060 | -29.67% [-38.54%, -15.22%] |
| RitualDance | 1 | first | 45.488 | 45.663 | -0.62% [-7.16%, +4.15%] |
| RitualDance | 1 | p95 inter-picture | 113.121 | 114.866 | +1.97% [-1.37%, +4.28%] |
| RitualDance | 1 | drain | 44.794 | 46.828 | +1.77% [-5.99%, +6.24%] |
| RitualDance | 1 | close | 3.362 | 3.544 | +4.90% [-7.50%, +11.71%] |
| RitualDance | 1 | total | 2962.766 | 2961.026 | +0.71% [-1.07%, +1.37%] |
| RitualDance | 7 | open | 0.458 | 0.475 | +1.73% [-27.13%, +25.00%] |
| RitualDance | 7 | first | 42.135 | 42.439 | -3.75% [-15.57%, +7.75%] |
| RitualDance | 7 | p95 inter-picture | 50.893 | 50.800 | -0.68% [-5.68%, +5.53%] |
| RitualDance | 7 | drain | 199.599 | 193.407 | -0.61% [-8.00%, +4.20%] |
| RitualDance | 7 | close | 21.047 | 19.915 | -6.65% [-20.75%, +6.01%] |
| RitualDance | 7 | total | 1426.609 | 1437.879 | -1.48% [-4.49%, +0.68%] |
| RitualDance | 12 | open | 0.696 | 0.662 | -1.81% [-14.93%, +16.07%] |
| RitualDance | 12 | first | 42.539 | 40.856 | +2.79% [-14.08%, +24.01%] |
| RitualDance | 12 | p95 inter-picture | 52.749 | 53.855 | +1.85% [-1.20%, +6.45%] |
| RitualDance | 12 | drain | 382.063 | 388.049 | -4.27% [-12.25%, +19.82%] |
| RitualDance | 12 | close | 26.481 | 27.036 | +1.17% [-7.32%, +18.89%] |
| RitualDance | 12 | total | 1512.497 | 1531.979 | +2.37% [-1.90%, +5.28%] |

## Allocation and lifetime counters

On three committed fixtures, Valgrind DHAT counted identical allocations and peak live heap bytes in matched parent and candidate CLIs. The one-frame 8-bit grain case used 652 allocations and peaked at 1,433,339 bytes. The three-frame 10-bit grain case used 824 and peaked at 1,729,442 bytes. The eight-frame inter-prediction case used 751 and peaked at 1,695,404 bytes. All six hashes matched AVM. The candidate's total allocated bytes were one byte lower in each process, which can depend on process arguments.

The saved Callgrind traces count named Rust allocator edges and out-of-line Arc last-owner destructions in the actual products. All seven 16-frame main and typed candidate pairs had identical last-owner counts and named allocator call counts. These counters do not cover inlined Arc retains/releases or every allocator entry point. The repository also tests warmed synchronous and streaming allocation ceilings in its normal CI.
