| Case | Workers or row width | Pairs | Median AVX-512 elapsed delta [95% paired bootstrap interval] |
|---|---:|---:|---:|
| Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f | 1 | 48 | -0.56% [-0.86%, -0.29%] |
| Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f | 7 | 48 | -0.53% [-1.18%, -0.27%] |
| Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f | 12 | 48 | -1.05% [-1.42%, -0.35%] |
