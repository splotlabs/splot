# Independent v3 consumer footprint

The exact source snapshots are main `9df30e915bd27da01769ccf41bb53bfa99d69063` and release `c9a9a960d9630c5033c3a16e7fa4c12d99dea916`. The independent Rust executables use the same public streaming `Decoder` program, manifest, and lockfile outside the SPLOT workspace. Both used local rustc 1.100.0, `-C target-cpu=x86-64-v3`, `DT_RELR`, ThinLTO, one codegen unit, aborting panics, and symbol stripping. The Cargo builds were offline, serial, and resource capped.

The independent C program uses the repository's public example and header with fixed one-worker, one-frame-delay settings. It was compiled as a separate executable in each configuration, with `-O2 -march=x86-64-v3` and an `$ORIGIN` runpath. Loader inspection resolved each matching shared library. The C host files are byte-identical and the library retains the same 14 exported symbols. GNU stripping used the same command on the verified hosted release CLI and C library artifacts. [Matched producer artifacts](https://github.com/splotlabs/splot/actions/runs/45674741726)

## Linked size

| Artifact | Stripped file, parent → final | `.text`, parent → final | `.rodata`, parent → final |
|---|---:|---:|---:|
| Standalone Rust | 8,589,320 → 8,623,272 | 6,803,853 → 6,834,669 | 1,304,781 → 1,305,005 |
| Standalone C host | 14,544 → 14,544 | 1,653 → 1,653 | 184 → 184 |
| Separate C shared library | 8,549,296 → 8,583,312 | 6,766,851 → 6,797,587 | 1,282,188 → 1,282,444 |
| Release CLI | 12,464,680 → 12,508,008 | 10,498,215 → 10,539,959 | 1,716,930 → 1,717,282 |

The Rust consumer grew by 33,952 stripped bytes (+0.395%), including 30,816 executable bytes (+0.453%). The dynamically linked C host stayed byte-identical. Its separate shared library grew by 34,016 stripped bytes (+0.398%), including 30,736 executable bytes (+0.454%). These matched-parent changes are below the provisionally allowed +10% stripped and +15% executable-code increases for dual artifacts. They establish no independent-consumer footprint blocker. The CLI and C library at this exact `c9a9a960` snapshot separately exceed its inherited packaged Linux caps by 6,008 and 4,312 bytes. [Size policy](https://github.com/splotlabs/splot/issues/1892)

The unlinked Rust archives are recorded separately. The `splot_decode` `.rlib` grew from 45,830,872 to 50,791,116 bytes. Its size includes serialized build material as well as object data. Fresh standalone builds took 3:00.01 and 3:04.44 respectively. GNU time reported maximum command-tree RSS of 2,695,096 and 3,083,972 KiB. These are single build observations.

## Output and backend

All 12 raw comparisons matched the pinned AVM hashes. The CLI, standalone Rust and independent C host each decoded one 8-bit and one 10-bit film-grain fixture on each revision. The Rust public API reported AVX2 in both bit-depth runs against both versions on the Core i7-12700H. The C loader paths and raw output were checked through the public C ABI. [Raw hash log](<WORKTREES>/qualification-1882/v3-release/consumer-sizes/hashes.txt)

## Peak resident memory

GNU time sampled each process three times per bit depth and revision with one worker and frame delay one on CPU 4. Each input contains the first 64 IVF records of the corresponding frozen 1080p clip. All interfaces write raw samples to `/dev/null` without retaining output. The CLI uses `-o -` with stdout redirected so its raw writer runs. Values are the median peak RSS followed by the observed range in KiB. C host peaks include resident shared-library pages. Separate shared-library file bytes are listed in the linked-size table.

| Input | Artifact | Parent median (range), KiB | Final median (range), KiB |
|---|---|---:|---:|
| Noise with grain, 8-bit | CLI | 55,460 (55,404–55,528) | 54,672 (54,460–54,688) |
| Noise with grain, 8-bit | Rust consumer | 55,352 (55,312–55,468) | 55,136 (55,080–55,240) |
| Noise with grain, 8-bit | C host | 54,712 (51,668–54,712) | 54,952 (51,908–54,952) |
| RitualDance, 10-bit | CLI | 82,272 (82,184–82,484) | 82,180 (82,160–82,500) |
| RitualDance, 10-bit | Rust consumer | 80,156 (80,080–80,200) | 80,004 (79,980–80,076) |
| RitualDance, 10-bit | C host | 79,256 (79,252–79,416) | 79,304 (79,304–79,304) |

The largest upward median difference was 240 KiB in the 8-bit C host, inside its run-to-run spread. These samples are peak process RSS on the two specified workloads. [RSS samples](<WORKTREES>/qualification-1882/v3-release/consumer-sizes/rss.csv)
