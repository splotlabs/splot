import csv
import hashlib
import os
from pathlib import Path
import re
from statistics import median
import struct
import subprocess
import sys
import tomllib


HERE = Path(__file__).resolve().parent
QUAL = HERE.parent.parent
FIXTURES = ('syn-filmgrain-intra-64x64', 'syn-3frame-filmgrain-inter-64x64-10bit')
CPU_OPTIONS = ('--threads', '1', '--frame-delay', '1')
VARIANTS = ('parent', 'final')
UNITS = ('Rust consumer', 'C host', 'C shared library', 'CLI')
SECTION = re.compile(r'^\s*\[\s*\d+\]\s+(\S+)\s+\S+\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)\s')


def artifacts(variant):
    root = HERE / variant
    return {
        'Rust consumer': root / 'target/release/splot-v3-consumer',
        'C host': root / 'c-host/c-consumer',
        'C shared library': root / 'c-host/libsplot_capi.so',
        'CLI': root / 'splot',
    }


def clean_loader_env():
    return {key: value for key, value in os.environ.items() if key not in ('LD_LIBRARY_PATH', 'LD_PRELOAD')}


def decode_commands(variant, path, output):
    binaries = artifacts(variant)
    return {
        'Rust consumer': [binaries['Rust consumer'], path],
        'C host': [binaries['C host'], path, output],
        'CLI': [binaries['CLI'], 'decode', path, *CPU_OPTIONS, '--output-format', 'raw', '-o', '-'],
    }


def run_oracles():
    for variant in VARIANTS:
        root = HERE / variant
        conformance = root / 'source/tests/conformance'
        inputs = {row['id']: row for row in tomllib.loads((conformance / 'decoder-oracle.toml').read_text())['fixture']}
        for fixture in FIXTURES:
            path = conformance / 'vectors/valid' / f'{fixture}.ivf'
            contract = inputs[fixture]
            assert hashlib.sha256(path.read_bytes()).hexdigest() == contract['ivf_sha256']
            c_output = root / f'{fixture}.c.yuv'
            for component, command in decode_commands(variant, path, c_output).items():
                result = subprocess.run(command, capture_output=True, check=True, env=clean_loader_env())
                raw = c_output.read_bytes() if component == 'C host' else result.stdout
                digest = hashlib.sha256(raw).hexdigest()
                if digest != contract['avm_raw_sha256']:
                    raise RuntimeError(f'{variant} {component} {fixture}: got {digest}')
                if component == 'Rust consumer':
                    assert b'selected backend: avx2\n' in result.stderr
                selection = ' selected=avx2' if component == 'Rust consumer' else ''
                print(f'PASS {variant} {component} {fixture} {len(raw)} bytes {digest}{selection}', flush=True)


def write_ivf_prefix(source, destination, length):
    with source.open('rb') as original, destination.open('wb') as abbreviated:
        header = bytearray(original.read(32))
        assert header.startswith(b'DKIF') and struct.unpack_from('<H', header, 6)[0] == len(header)
        struct.pack_into('<I', header, 24, length)
        abbreviated.write(header)
        for _ in range(length):
            record = original.read(12)
            size = struct.unpack_from('<I', record)[0]
            content = original.read(size)
            assert len(content) == size
            abbreviated.write(record)
            abbreviated.write(content)


def sample_rss():
    sources = {
        'Noise grain 8-bit': 'Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f.ivf',
        'RitualDance 10-bit': 'RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf',
    }
    cases = {case: HERE / f'{filename.removesuffix(".ivf")}-prefix64.ivf' for case, filename in sources.items()}
    for case, path in cases.items():
        write_ivf_prefix(QUAL / 'ci-data' / sources[case], path, 64)

    values = {}
    with (HERE / 'rss.csv').open('x', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(('case', 'variant', 'artifact', 'run', 'peak_rss_kib'))
        for case, path in cases.items():
            for repeat in range(3):
                order = VARIANTS if repeat % 2 == 0 else VARIANTS[::-1]
                for variant in order:
                    for component, command in decode_commands(variant, path, '/dev/null').items():
                        measurement = HERE / 'rss-last.txt'
                        subprocess.run(['/usr/bin/time', '-f', '%M', '-o', measurement, *command],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True, env=clean_loader_env())
                        peak = int(measurement.read_text())
                        values.setdefault((case, component, variant), []).append(peak)
                        writer.writerow((case, variant, component, repeat + 1, peak))
                        file.flush()

    for case in cases:
        for component in ('CLI', 'Rust consumer', 'C host'):
            parent, final = (values[case, component, variant] for variant in VARIANTS)
            formatted = lambda series: f'{median(series):,} ({min(series):,}–{max(series):,})'
            print(f'{case} | {component} | {formatted(parent)} → {formatted(final)} KiB', flush=True)


def section_sizes(path):
    output = subprocess.check_output(['readelf', '-SW', path], text=True)
    return {match[1]: int(match[2], 16) for line in output.splitlines() if (match := SECTION.match(line))}


def linked_sizes():
    rows = {}
    with (HERE / 'sizes.csv').open('x', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(('artifact', 'variant', 'file_bytes', 'text_bytes', 'rodata_bytes'))
        for variant in VARIANTS:
            for component, path in artifacts(variant).items():
                sections = section_sizes(path)
                values = path.stat().st_size, sections['.text'], sections['.rodata']
                rows[component, variant] = values
                writer.writerow((component, variant, *values))
                print(f'{variant} {component}: {values[0]:,} total, {values[1]:,} .text, {values[2]:,} .rodata')
    for component in UNITS:
        previous, current = (rows[component, variant] for variant in VARIANTS)
        differences = [f'{new-old:+,} ({(new/old-1)*100:+.3f}%)' for old, new in zip(previous, current)]
        print(f'{component} delta: {differences[0]} total, {differences[1]} .text, {differences[2]} .rodata')


if __name__ == '__main__':
    {'raw': run_oracles, 'rss': sample_rss, 'sizes': linked_sizes}[sys.argv[1]]()
