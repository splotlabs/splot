// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// SPDX-FileCopyrightText: 2026 Bartosz Tomczyk <bartekplus@gmail.com>

use std::io::Write;

use splot_core::stream_reader::{StreamUnit, TemporalUnitReader};
use splot_decode::{
    DataProps, Decoder, DecoderSettings, FrameDelay, PictureSamples, PlaneId, SelectedBackend,
    SendStatus, ThreadCount,
};

fn write_ready_pictures(decoder: &mut Decoder, output: &mut impl Write) {
    while let Some(picture) = decoder.get_picture().unwrap() {
        for plane in [PlaneId::Y, PlaneId::U, PlaneId::V] {
            match picture.plane(plane).unwrap() {
                PictureSamples::Eight(plane) => {
                    for row in plane.visible_rows() {
                        output.write_all(row).unwrap();
                    }
                }
                PictureSamples::Ten(plane) => {
                    for sample in plane.visible_rows().flatten() {
                        output.write_all(&sample.to_le_bytes()).unwrap();
                    }
                }
            }
        }
    }
}

fn main() {
    let filename = std::env::args_os()
        .nth(1)
        .expect("usage: consumer <file.ivf>");
    assert!(
        cfg!(target_feature = "avx2")
            && cfg!(target_feature = "fma")
            && cfg!(target_feature = "bmi2")
    );
    let settings = DecoderSettings::default()
        .with_threads(ThreadCount::from(1usize))
        .with_frame_delay(FrameDelay::from(1usize));
    let mut decoder = Decoder::new(settings).unwrap();
    let backend = decoder.selected_backend();
    assert_eq!(backend, SelectedBackend::Avx2);
    eprintln!("selected backend: {}", backend.as_str());

    let input = std::fs::read(filename).unwrap();
    let mut reader = TemporalUnitReader::new(input.as_slice());
    let mut output = std::io::BufWriter::new(std::io::stdout().lock());
    while let Some(unit) = reader.next_unit().unwrap() {
        let StreamUnit::IvfFrame { payload, .. } = unit else {
            panic!("expected IVF frame");
        };
        while decoder.send_data(payload, DataProps::default()).unwrap() == SendStatus::Full {
            write_ready_pictures(&mut decoder, &mut output);
        }
        write_ready_pictures(&mut decoder, &mut output);
    }
    decoder.drain();
    write_ready_pictures(&mut decoder, &mut output);
    output.flush().unwrap();
}
