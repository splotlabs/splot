"""Report CPU-feature cache references within linked subpel and MC functions."""

import gzip
from pathlib import Path
import re

root = Path(__file__).resolve().parent
header = re.compile(r"^[0-9a-f]+ <(.*)>:$")

for product in ("splot", "libsplot_capi.dylib"):
    for variant in ("base", "startup", "shared"):
        folder = root / variant
        with gzip.open(folder / f"{product}.symbols.txt.gz", "rt") as symbols:
            [cache] = [line for line in symbols if "10std_detect6detect5cache5CACHE" in line]
        address = int(cache.split()[0], 16)
        cache_page = re.compile(rf"\badrp\s+\w+, 0x{address & ~0xfff:x}\b")
        cache_refs = []
        initializers = []
        symbol = ""
        with gzip.open(folder / f"{product}.disassembly.txt.gz", "rt") as disassembly:
            for raw in disassembly:
                line = raw.rstrip()
                if match := header.match(line):
                    symbol = match[1]
                if not ("subpel_mc::" in symbol or "prediction::inter::mc::" in symbol):
                    continue
                if cache_page.search(line):
                    cache_refs.append((symbol, line))
                if "std_detect::detect::cache::detect_and_initialize" in line:
                    initializers.append((symbol, line))
        print(
            f"{product}\t{variant}\tCACHE=0x{address:x}\t"
            f"{len(cache_refs)} cache-page references\t{len(initializers)} initializer calls\t"
            f"{len(set(symbol for symbol, _ in initializers))} functions with initializer calls"
        )
        for symbol, line in initializers:
            print(f"{symbol}\t{line.lstrip()}")
