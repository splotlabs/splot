# Hosted NEON startup-selection comparison

[Completed native arm64 run](https://github.com/splotlabs/splot/actions/runs/45674773435). This independent experiment used exact main `9df30e91`, startup parent `98b65418`, and sharing child `f72349d1`. The rebase keeps the current generic `SimdScope` and its public context. Both commits' signatures verified locally. The child passed capped Apple Darwin release type-check and strict Clippy.

A standard Apple M1 (Virtual) VM reported native arm64, NEON, dotprod, and no I8MM. All six full reference checks passed for BlueSky and RitualDance. The hosted M1 exercised the SDOT profile. The linked USDOT profile is visible in both candidate products, and the idle M2 Max remains necessary to exercise it with native output and latency.

| Product | Main post-strip bytes | Startup bytes | Sharing bytes | Sharing minus startup | Main / startup / sharing `__text` bytes |
| --- | ---: | ---: | ---: | ---: | --- |
| CLI | 10,861,864 | 11,330,408 | 11,476,840 | +146,432 | 8,197,348 / 8,649,572 / 8,791,204 |
| C dylib | 6,867,824 | 7,297,648 | 7,363,744 | +66,096 | 5,308,520 / 5,729,960 / 5,800,616 |

Covers same-runner pinned Rust 1.100.0 release builds with symbols retained for audit. File sizes above came from separately stripped copies of that link, using `strip -S -x`. This comparison does not reuse file sizes from default Cargo-stripped artifacts.

| First picture | Startup vs main | Sharing vs startup | Sharing vs main |
| --- | ---: | ---: | ---: |
| BlueSky | −5.20% [−22.29, +13.61] | +4.26% [−3.10, +16.35] | −3.44% [−12.42, +8.60] |
| RitualDance | −7.08% [−14.19, +7.48] | −4.94% [−18.16, +11.45] | −9.79% [−13.97, −2.36] |

The estimates are based on 12 rotating-order one-thread rounds on the same VM. Positive values are slower. The sharing child added text relative to the startup parent on this rebase. The M1 result and growth leave production adoption open under [the M2 Max handoff](https://github.com/splotlabs/splot/issues/1993#issuecomment-7170365932).

## Linked dispatch audit

Both baseline products contained 18 references to the linked `std_detect` cache page and 18 initializer edges across seven named subpel or motion-compensation functions. Both candidates had zero of either in those function groups. Main's CLI `block::kernels` at `0x100293940` forms the exact feature-cache address `0x1009c0120`, loads it, and tests I8MM. The candidate disassemblies contain distinct concrete `NeonSdot` and `NeonUsdot` hot functions. This is a linked, named-function audit. It does not assign the hosted first-picture delta to a particular kernel.

The raw disassemblies and their SHA-256s, [audit script](check-linked-dispatch.py), audit TSV, timing CSV, linked-size logs, full job log, and host metadata accompany this summary. GitHub shortened the artifact retention to one day, and the files are preserved here.
