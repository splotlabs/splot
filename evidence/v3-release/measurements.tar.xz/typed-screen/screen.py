import argparse
import csv
import hashlib
import os
from pathlib import Path
import random
from statistics import median
import subprocess
import sys


HERE = Path(__file__).resolve().parent
RELEASE = HERE.parent
QUAL = RELEASE.parent
sys.path.insert(0, str(RELEASE))
from qualify import decode, digest_stream, timed


BINARIES = {
    'frozen': HERE / 'frozen/splot',
    'typed': HERE / 'typed/splot',
    'main': RELEASE / 'linked/release-main/splot',
    'pr2006': RELEASE / 'linked/release-wide/splot',
}
LABELS = {
    'BlueSky': 'BlueSky_',
    'DOTA2': 'DOTA2_',
    'Slides1': 'Slides1_',
    'Noise': 'Noise_Ocean_1920x1080_60fps_qp135_',
    'Noise-grain': 'Noise_Ocean_1920x1080_60fps_filmgrain_',
    'OldTown': 'old_town_cross_',
    'RitualDance': 'RitualDance_',
}
INPUTS = {}
for manifest_line in (QUAL / 'ci-data/simd-cases.tsv').read_text().splitlines():
    name, digest, frames, size = manifest_line.split('\t')
    [label] = [label for label, prefix in LABELS.items() if name.startswith(prefix)]
    INPUTS[label] = (QUAL / 'ci-data' / name, digest, int(frames), int(size))


def raw_output(variants, threads, labels):
    failures = []
    for variant in variants:
        binary = BINARIES[variant]
        for label in labels:
            stream, expected, frames, size = INPUTS[label]
            for count in threads:
                options = ['--threads', str(count), '--output-format', 'raw', '-o', '-']
                if count == 1:
                    options += ['--frame-delay', '1']
                name = f'{variant} {label} {count} workers {frames} frames'
                try:
                    actual = digest_stream([binary, 'decode', stream, *options])
                except RuntimeError as error:
                    print(f'FAIL {name}: {error}', flush=True)
                    failures.append(name)
                    continue
                if actual == (expected, size):
                    print(f'PASS {name} {size} bytes {expected}', flush=True)
                else:
                    print(f'FAIL {name}: {actual!r} versus expected {(expected, size)!r}', flush=True)
                    failures.append(name)
    if failures:
        raise RuntimeError(f'{len(failures)} of {len(variants) * len(labels) * len(threads)} checks failed')


def capture(variants, labels):
    output = HERE / 'traces'
    output.mkdir(exist_ok=True)
    for label in labels:
        stream = INPUTS[label][0]
        for variant in variants:
            path = output / f'{label}-{variant}.cg'
            if not path.exists() or path.stat().st_size == 0:
                subprocess.run([
                    'valgrind', '--tool=callgrind', f'--log-file={path}.log', f'--callgrind-out-file={path}',
                    *decode(BINARIES[variant], stream, '--limit', '16', '--output-format', 'null'),
                ], check=True)
            with path.open() as statistics:
                instructions = int(next(line.split()[1] for line in statistics if line.startswith('summary:')))
            print(f'{label}\t{variant}\t{instructions}', flush=True)


def interval(ratios):
    rng = random.Random(1882)
    resamples = sorted(median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return [(value - 1) * 100 for value in (median(ratios), resamples[250], resamples[9749])]


def playback(variants, labels, rounds, output_name):
    if os.sched_getaffinity(0) != {4}:
        raise RuntimeError('Use CPU 4 for native playback')
    normal = ('--output-format', 'null')
    commands = {}
    for label in labels:
        stream, _, frames, _ = INPUTS[label]
        limit = frames if label in ('BlueSky', 'Noise-grain') else min(64, frames)
        for variant in variants:
            commands[label, variant] = decode(BINARIES[variant], stream, *normal, '--limit', str(limit))
    for command in commands.values():
        timed(command)

    records = {}
    with (HERE / output_name).open('x', newline='') as output:
        writer = csv.writer(output)
        writer.writerow(('case', 'round', 'position', 'variant', 'wall_seconds', 'cpu_seconds'))
        order_template = (0, 1, 3, 2) if len(variants) == 4 else tuple(range(len(variants)))
        for r in range(rounds):
            for next_case in range(len(labels)):
                case_index = (r + next_case) % len(labels)
                label = labels[case_index]
                order = [variants[(r + case_index + i) % len(variants)] for i in order_template]
                for position, variant in enumerate(order, 1):
                    timing = timed(commands[label, variant])
                    records[label, r, variant] = timing
                    writer.writerow((label, r + 1, position, variant, *timing))
                output.flush()
            print(f'Round {r+1}/{rounds}', flush=True)

    candidate = 'typed'
    for label in labels:
        print(f'{label} frames={commands[label, candidate][-1]}')
        for reference in variants:
            if reference == candidate:
                continue
            for column, metric in enumerate(('wall', 'child CPU')):
                timings = {variant: [records[label, r, variant][column] for r in range(rounds)]
                           for variant in (candidate, reference)}
                ratios = [new / old for new, old in zip(timings[candidate], timings[reference])]
                change, low, high = interval(ratios)
                print(f'  {candidate}/{reference} {metric}: {change:+.2f}% [{low:+.2f}%, {high:+.2f}%] '
                      f'(medians {1000*median(timings[reference]):.2f} → {1000*median(timings[candidate]):.2f} ms)')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('raw', 'trace', 'wall'))
    parser.add_argument('--variants', nargs='+', choices=BINARIES, default=['frozen', 'typed'])
    parser.add_argument('--labels', nargs='+', choices=INPUTS, default=list(INPUTS))
    parser.add_argument('--threads', nargs='+', type=int, default=[1])
    parser.add_argument('--rounds', type=int, default=8)
    parser.add_argument('--output', default='wall.csv')
    args = parser.parse_args()
    if args.action == 'raw':
        raw_output(args.variants, args.threads, args.labels)
    elif args.action == 'trace':
        capture(args.variants, args.labels)
    else:
        playback(args.variants, args.labels, args.rounds, args.output)


if __name__ == '__main__':
    main()
