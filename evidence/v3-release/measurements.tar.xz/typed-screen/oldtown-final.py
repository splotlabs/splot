import csv
import math
import os
from pathlib import Path
import random
from statistics import median
import threading
import time

from screen import HERE, INPUTS, decode, timed


FINAL = HERE.parent / 'linked-final'
BUILD = {'parent': FINAL / 'release-parent/splot', 'final': FINAL / 'release-final/splot'}
FREQUENCY = Path('/sys/devices/system/cpu/cpu4/cpufreq/scaling_cur_freq')
THERMAL = next(zone / 'temp' for zone in Path('/sys/class/thermal').glob('thermal_zone*')
               if (zone / 'type').read_text().strip() == 'x86_pkg_temp')
ROUNDS = 20


def sample_clock(stop, output, samples):
    os.sched_setaffinity(0, {3})
    with output.open('x', newline='') as log:
        writer = csv.writer(log)
        writer.writerow(('monotonic_ns', 'cpu4_scaling_khz', 'package_temperature_millicelsius'))
        while not stop.is_set():
            sample = (time.monotonic_ns(), int(FREQUENCY.read_text()), int(THERMAL.read_text()))
            writer.writerow(sample)
            samples.append(sample)
            stop.wait(0.04)


def interval(log_values):
    rng = random.Random(1882)
    refits = sorted(median(rng.choices(log_values, k=len(log_values))) for _ in range(10000))
    return [100 * math.expm1(value) for value in (median(log_values), refits[250], refits[9749])]


def main():
    if os.sched_getaffinity(0) != {4}:
        raise RuntimeError('Run pinned to CPU 4')
    commands = {name: decode(binary, INPUTS['OldTown'][0], '--limit', '64', '--output-format', 'null')
                for name, binary in BUILD.items()}
    for command in commands.values():
        timed(command)

    stop = threading.Event()
    clocks = []
    monitor = threading.Thread(target=sample_clock, args=(stop, HERE / 'OldTown64-final-clock.csv', clocks))
    monitor.start()
    records = {name: [] for name in BUILD}
    try:
        with (HERE / 'OldTown64-final-timing.csv').open('x', newline='') as log:
            writer = csv.writer(log)
            writer.writerow(('block', 'position', 'variant', 'start_ns', 'end_ns', 'wall_seconds', 'cpu_seconds'))
            for block in range(ROUNDS):
                order = ('parent', 'final', 'final', 'parent')
                if block % 2:
                    order = tuple('parent' if name == 'final' else 'final' for name in order)
                for position, variant in enumerate(order, 1):
                    start = time.monotonic_ns()
                    wall, cpu = timed(commands[variant])
                    end = time.monotonic_ns()
                    records[variant].append((start, end, wall, cpu))
                    writer.writerow((block + 1, position, variant, start, end, wall, cpu))
                log.flush()
                print(f'Completed block {block + 1}/{ROUNDS}', flush=True)
    finally:
        stop.set()
        monitor.join()

    for component, name in [(2, 'wall time'), (3, 'child CPU time')]:
        log_ratios = []
        for block in range(ROUNDS):
            ratio = {
                variant: sum(math.log(row[component]) for row in rows[2 * block:2 * block + 2]) / 2
                for variant, rows in records.items()
            }
            log_ratios.append(ratio['final'] - ratio['parent'])
        estimate, low, high = interval(log_ratios)
        medians = [median(row[component] for row in records[variant]) * 1000 for variant in BUILD]
        print(f'{name}: {estimate:+.2f}% [{low:+.2f}%, {high:+.2f}%], samples median {medians[0]:.2f} to {medians[1]:.2f} ms')

    clock_proxy = {}
    for variant, timings in records.items():
        windows = [[(frequency, temperature) for timestamp, frequency, temperature in clocks
                    if start + 25_000_000 <= timestamp <= end - 25_000_000]
                   for start, end, _, _ in timings]
        clock_proxy[variant] = [median(freq for freq, _ in window) for window in windows]
        temperatures = [temp / 1000 for window in windows for _, temp in window]
        print(f'{variant}: {sum(map(len, windows))} clock samples, median per-run clock {median(clock_proxy[variant])/1000:.1f} MHz, '
              f'package temperature median {median(temperatures):.1f}°C, range {min(temperatures):.1f} to {max(temperatures):.1f}°C')
    log_ratios = [(sum(math.log(v) for v in clock_proxy['final'][2*b:2*b+2]) -
                   sum(math.log(v) for v in clock_proxy['parent'][2*b:2*b+2])) / 2
                  for b in range(ROUNDS)]
    estimate, low, high = interval(log_ratios)
    print(f'Kernel clock proxy: {estimate:+.2f}% [{low:+.2f}%, {high:+.2f}%]')


if __name__ == '__main__':
    main()
