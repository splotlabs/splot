# Native AVX2 comparison of frozen and typed release builds

Actions run `45673211431` built frozen `b337fafec51041ee5ffe64cc7e20f79a49c0cc79` and typed `3cddb13ac1905f197347c4b33020a3081e67dafe` with the same Ubuntu runner profile and rustc 1.100.0 with LLVM 23.1.5. Both use x86-64-v3 plus packed relative relocations. The older release retains its committed Fearless AVX-512 dispatch cfg. Both downloaded CLI and C library SHA-256 manifests passed. [Focused Actions run](https://github.com/splotlabs/splot/actions/runs/45673211431)

The closer controls are `d171d824` main and `a55cff38`, which has the same production code as PR #2006 head `45707e9d`. They were built with the same release settings in Actions run `45671134269`. The typed revision differs from #2006 by its single display-loop typing commit. The frozen-to-typed comparison covers accumulated changes across 415 files. [Matched control artifacts](https://github.com/splotlabs/splot/actions/runs/45671134269)

## Linked artifact size

| Revision | CLI, bytes | CLI `.text`, bytes | C shared library, bytes | C `.text`, bytes |
|---|---:|---:|---:|---:|
| Frozen `b337fafe` | 12,043,648 | 10,095,815 | 8,283,360 | 6,520,883 |
| Main `d171d824` | 12,464,680 | 10,498,215 | 8,549,296 | 6,766,851 |
| #2006 `a55cff38` | 12,491,576 | 10,523,735 | 8,577,680 | 6,792,739 |
| Typed `3cddb13a` | 12,508,008 | 10,539,959 | 8,583,312 | 6,797,587 |

GNU stripping used the same command for all four builds. Typed adds 16,432 CLI bytes and 5,632 C library bytes to #2006. It exceeds #2006's updated Linux caps by 6,008 and 4,312 bytes. All artifacts retain `DT_RELR`.

## Exact instruction comparison

Callgrind on the AVX2-only Core i7-12700H captured the first 16 outputs at one worker and frame delay one. Each build used its normal null output path, which applies signalled grain. Negative values mean fewer guest instructions in typed `3cddb13a` than in the comparator.

| Input | Typed guest instructions | vs frozen | vs main | vs #2006 |
|---|---:|---:|---:|---:|
| BlueSky | 586,067,116 | +0.0086% | −0.0024% | −0.0004% |
| DOTA2 | 2,611,441,768 | +0.0970% | −0.0009% | −0.0001% |
| Slides1 | 1,491,631,121 | +0.0298% | −0.0015% | −0.0002% |
| Noise Ocean | 1,305,670,558 | −0.6830% | −0.0014% | −0.0002% |
| Noise Ocean, with grain | 2,047,070,261 | −0.9678% | −0.3924% | −0.0018% |
| OldTown | 3,428,042,359 | +0.1038% | −0.0020% | −0.0001% |
| RitualDance | 4,436,220,093 | −0.4218% | −0.0023% | −0.0001% |

The typed-only commit removes the per-frame backend match from synchronous output and the eager streaming loop. The public deferred-grain operation still enters the stored backend when the caller invokes it. On this AVX2 host the typed-only guest-instruction differences are at most 0.0018% per measured case.

The sum across the seven equal-length windows was 15,906,143,276 guest instructions for typed. That is −0.2583% vs frozen, −0.0522% vs main, and −0.00033% vs #2006.

## Raw output parity

Both frozen and typed matched the seven pinned AVM SHA-256 digests and exact byte counts at one worker and frame delay one. Both also matched the full 130-frame grain-bearing Noise Ocean and 600-frame 10-bit RitualDance outputs at seven and twelve requested workers using the normal frame delay. All 22 comparisons passed.

## Native wall time

Eight counterbalanced rounds included all four binaries. Every run used CPU 4, one worker and frame delay one. Grain remains enabled for the grain-bearing Noise clip. The table shows medians of within-round wall ratios and 95% bootstrap intervals. Separate binary medians in `wall.log` can differ in direction because the ratios preserve pairing.

| Input | Frames | vs frozen | vs main | vs #2006 |
|---|---:|---:|---:|---:|
| BlueSky | 130 | −0.59% [−3.38%, +3.16%] | −3.03% [−7.41%, +0.37%] | −4.35% [−17.88%, +1.56%] |
| DOTA2 | 64 | −3.41% [−4.36%, +3.80%] | +0.37% [−4.35%, +6.70%] | −2.36% [−4.43%, +4.76%] |
| Slides1 | 64 | +2.01% [−3.92%, +7.02%] | +2.00% [−10.63%, +7.47%] | −0.22% [−3.95%, +6.56%] |
| Noise Ocean | 64 | +3.39% [−1.75%, +9.61%] | +1.65% [−0.93%, +10.59%] | +4.85% [−1.20%, +9.65%] |
| Noise Ocean, with grain | 130 | −2.76% [−5.88%, +5.98%] | −0.31% [−1.22%, +6.54%] | +1.18% [−4.69%, +2.42%] |
| OldTown | 64 | +4.61% [−0.68%, +11.06%] | +4.73% [−2.02%, +8.31%] | +4.63% [−2.16%, +9.79%] |
| RitualDance | 64 | −0.10% [−3.64%, +3.74%] | −0.40% [−6.04%, +4.41%] | −2.19% [−5.00%, +0.99%] |

All intervals include zero. The two positive point estimates above 4% versus #2006 triggered an independent two-case repeat.

### Focused repeat against #2006

Twelve four-run blocks per case alternated ABBA and BAAB on CPU 4. At one worker, frame delay one and 64 frames, the Noise Ocean wall estimate was −0.79% [−2.37%, +1.63%] and the OldTown estimate was +3.06% [+1.10%, +5.09%]. Child CPU time closely agreed. The earlier Noise point estimate did not repeat. The OldTown interval exceeds +0.5% on this secondary comparison.

The corresponding OldTown64 Callgrind counts were 12,480,791,354 for #2006 and 12,480,788,923 for typed, a change of −0.000019%. Both outputs were 199,065,600 bytes with SHA-256 `55ceedab7e50a7498ae4d035507dfda321125a08f3c7c908a0e3415a6c57c131`.

### OldTown64 against current main and final release

The build artifacts from run `45674741726` are main `9df30e91` and final `c9a9a960`, verified against the Actions SHA-256 manifests. The main CLI is byte-identical to the `d171d824` control. The final CLI and `3cddb13a` share the same stripped and `.text` sizes and have different `.text` bytes. [Exact current build artifacts](https://github.com/splotlabs/splot/actions/runs/45674741726)

Twenty ABBA/BAAB blocks on CPU 4 measured OldTown64 at one worker and frame delay one. The final candidate's wall change was −1.75% [−3.06%, −0.37%] with child CPU time −1.74% [−3.05%, −0.37%]. The current matched comparison supports the +0.5% elapsed bound for this case on this host.

A separate sampler on CPU 3 recorded the CPU 4 kernel frequency proxy and package temperature at roughly 40 ms intervals. Per-run median clock averages across the sample were 4400.0 MHz for main and 4473.6 MHz for the final build, with a paired median change of +1.18% [−0.17%, +2.79%]. Package temperature medians were 87°C and 88°C, with a shared observed range of 67–97°C. A sensitivity calculation multiplying wall time by the per-run median clock proxy gives −0.60% [−0.90%, −0.01%]. This calculation uses a sampled kernel value. Hardware cycles and instructions were unavailable with `perf_event_paranoid=4`, and package power was unavailable. The result establishes no code-level cause or generalizable wall speedup.

The wall results provide independent evidence for the specified OldTown windows. The screening intervals still leave the +0.5% wall criterion unresolved for most other cases. The exact 16-frame instruction results quantify the guest-work delta separately.
