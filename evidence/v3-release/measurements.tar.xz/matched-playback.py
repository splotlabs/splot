import argparse
import csv
import math
import os
from pathlib import Path
import random
from statistics import median

from qualify import GRAIN, RITUAL, TUNNEL, decode, timed


CASES = (
    ('TunnelFlag40', TUNNEL, ('--limit', '40')),
    ('RitualDance64', RITUAL, ('--limit', '64')),
    ('Noise grain on 130', GRAIN, ()),
)


def confidence_interval(values):
    rng = random.Random(1882)
    sampling = sorted(median(rng.choices(values, k=len(values))) for _ in range(10000))
    return [100 * math.expm1(log_ratio) for log_ratio in (median(values), sampling[250], sampling[9749])]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--main', type=Path, required=True)
    parser.add_argument('--release', type=Path, required=True)
    parser.add_argument('--blocks', type=int, default=18)
    parser.add_argument('--write', type=Path, required=True)
    args = parser.parse_args()
    if os.sched_getaffinity(0) != {4}:
        raise RuntimeError('Run playback pinned to CPU 4')
    binaries = {'main': args.main, 'release': args.release}
    commands = {
        (case, variant): decode(binary, path, '--output-format', 'null', *options)
        for case, path, options in CASES
        for variant, binary in binaries.items()
    }
    for command in commands.values():
        timed(command)

    records = {(case, variant): [] for case, variant in commands}
    with args.write.open('x', newline='') as measurements:
        writing = csv.writer(measurements)
        writing.writerow(('case', 'block', 'position', 'variant', 'wall_seconds', 'cpu_seconds'))
        for block in range(args.blocks):
            for offset in range(len(CASES)):
                case_index = (block + offset) % len(CASES)
                case = CASES[case_index][0]
                # ABBA/BAAB cancels first-order drift within a matched four-run block.
                order = ('main', 'release', 'release', 'main')
                if (block + case_index) % 2:
                    order = ('release', 'main', 'main', 'release')
                for position, variant in enumerate(order, 1):
                    measurement = timed(commands[case, variant])
                    records[case, variant].append(measurement)
                    writing.writerow((case, block + 1, position, variant, *measurement))
                measurements.flush()
            print(f'Completed block {block + 1}/{args.blocks}', flush=True)

    for case, _, _ in CASES:
        for metric, label in enumerate(('wall', 'child CPU')):
            seconds = {variant: [row[metric] for row in records[case, variant]] for variant in binaries}
            log_ratios = []
            for block in range(args.blocks):
                first = 2 * block
                last = first + 2
                sums = {variant: sum(math.log(value) for value in values[first:last]) for variant, values in seconds.items()}
                log_ratios.append((sums['release'] - sums['main']) / 2)
            center, low, high = confidence_interval(log_ratios)
            threshold = ('upper interval below +0.5%' if high < 0.5 else
                         'lower interval above +0.5%' if low > 0.5 else
                         '+0.5% unresolved')
            print(f'{case} | {label} | main {median(seconds["main"])*1000:.2f} ms | '
                  f'release {median(seconds["release"])*1000:.2f} ms | '
                  f'{center:+.2f}% [{low:+.2f}%, {high:+.2f}%] | {threshold}')


if __name__ == '__main__':
    main()
