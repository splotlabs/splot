from pathlib import Path
import subprocess
import sys

from qualify import GRAIN, NOISE, RITUAL, TUNNEL, decode, digest_stream


HERE = Path(__file__).resolve().parent
OUT = HERE / 'matched'
BINARIES = {name: HERE / f'linked/release-{name}/splot' for name in ('main', 'wide')}
CASES = (
    ('RitualDance', RITUAL),
    ('Noise-grain', GRAIN),
    ('Noise', NOISE),
    ('TunnelFlag', TUNNEL),
)


def trace(case, input_path):
    threads = 1
    options = ('--limit', '16')
    raw = {}
    counts = {}
    for name, binary in BINARIES.items():
        raw[name] = digest_stream(decode(binary, input_path, *options, '--output-format', 'raw', '-o', '-', threads=threads))
        trace_path = OUT / f'{case}-{name}.cg'
        subprocess.run([
            'valgrind', '--tool=callgrind', f'--log-file={trace_path}.log', f'--callgrind-out-file={trace_path}',
            *decode(binary, input_path, *options, '--output-format', 'null', threads=threads),
        ], check=True)
        with trace_path.open() as statistics:
            counts[name] = int(next(line.split()[1] for line in statistics if line.startswith('summary:')))
    if raw['main'] != raw['wide']:
        raise RuntimeError(f'Mismatched raw output for {case}: {raw!r}')
    ratio = counts['wide'] / counts['main'] - 1
    print(f'{case} 16 frames | Ir {counts["main"]:,} → {counts["wide"]:,} ({ratio:+.3%}) | '
          f'raw bytes {raw["main"][1]:,} SHA-256 {raw["main"][0]}', flush=True)


if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    requested = set(sys.argv[1:]) if len(sys.argv) > 1 else {case for case, _ in CASES}
    for case, path in CASES:
        if case in requested:
            trace(case, path)
