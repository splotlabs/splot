"""Summarize the paired native AVX-512 qualification log."""
import csv
import math
from collections import defaultdict
from pathlib import Path
import random
import re
from statistics import median
import sys

path=Path(sys.argv[1])
stem=path.with_suffix('')
text=path.read_text()
timings=defaultdict(dict)
rx=r'(\S+\.ivf) threads=(\d+) policy=(avx2|avx512) pair=(\d+) frames=(\d+) decode_seconds=([\d.]+)'
for fname,threads,policy,pair,frames,sec in re.findall(rx,text):
    row=timings[(fname,int(threads),int(pair),int(frames))]
    assert policy not in row
    row[policy]=float(sec)
micro=defaultdict(dict)
for depth,width,pair,first,second in re.findall(r'(?m)\b(8|10),(\d+),(\d+),([\d.]+),([\d.]+)\s*$',text):
    micro[(int(depth),int(width),int(pair))]=(float(first),float(second))
grouped=defaultdict(list)
def write_samples():
    with Path(str(stem)+'-timings.csv').open('w') as file:
        writer=csv.writer(file,lineterminator='\n')
        writer.writerow(('operation','threads_or_width','pair','frames_or_depth','avx2','avx512'))
        for (name,threads,pair,frames),sample in sorted(timings.items()):
            a,b=sample['avx2'],sample['avx512']
            writer.writerow((name,threads,pair,frames,a,b))
            grouped[(name.split('_1920')[0] if '_1920' in name and 'filmgrain' not in name else name.split('.ivf')[0],threads)].append(b/a)
        for (depth,width,pair),(a,b) in sorted(micro.items()):
            writer.writerow(('grain row (ns)',width,pair,depth,a,b))
            grouped[(f'{depth}-bit grain row (ns)',width)].append(b/a)
def summarize():
    rng=random.Random(1882)
    lines=['| Case | Workers or row width | Pairs | Median AVX-512 elapsed delta [95% paired bootstrap interval] |','|---|---:|---:|---:|']
    for (case,parameter),ratios in grouped.items():
        boots=sorted(median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
        def delta(x): return f'{100*(x-1):+.2f}%'
        lines.append(f'| {case} | {parameter} | {len(ratios)} | {delta(median(ratios))} [{delta(boots[249])}, {delta(boots[9749])}] |')
    Path(str(stem)+'-timings.md').write_text('\n'.join(lines)+'\n')
    print('\n'.join(lines))
if not timings and not micro:
    sys.exit('No timing samples recorded.')
write_samples()
summarize()
