| Case | Workers or row width | Pairs | Median AVX-512 elapsed delta [95% paired bootstrap interval] |
|---|---:|---:|---:|
| Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f | 1 | 10 | -0.58% [-1.44%, +0.37%] |
| Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f | 7 | 10 | -1.45% [-2.07%, +0.17%] |
| Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f | 12 | 10 | -0.38% [-1.41%, +0.27%] |
| 8-bit grain row (ns) | 1920 | 12 | -14.14% [-14.96%, -12.91%] |
| 10-bit grain row (ns) | 1920 | 12 | -18.54% [-19.16%, -18.07%] |
