# Downstream release consumers

## Linux x86-64 static C

This comparison uses the default release profile and x86-64-v3 floor at main
`9df30e915bd27da01769ccf41bb53bfa99d69063` and release candidate
`91fbc9218814c1a0eebe73074c03fd35f3a2f932`. The exact existing candidate Rust
static archive comes from the final CLI and CAPI product build. Main's CAPI-only
build ran offline with Rust 1.100.0 and one Cargo job under the shared compiler
lock. The main source snapshot was independently checked against 1,620 tracked
blob IDs. The two builds both enable the default decode and recon Cargo features,
and use an identical C header.

`check-static.py` recompiles the existing turnkey C consumer twice with the
same C compiler, archive-link options, and public header. The link map and
defined API symbols show that the consumer includes the static Splot
implementation. The stripped host's dynamic table confirms that there is no
dependency on a Splot shared library. The executable still uses the system
dynamic loader and C runtime.

The smoke inputs are two synthetic AVM-backed film-grain streams, and two
64-record prefixes of the existing 8-bit Noise Ocean and 10-bit RitualDance
inputs. The latter compare the full raw output of each prefix with the same
input decoded by main. The harness requests one worker and drains the decoder.
Peak RSS is the maximum reported by GNU time while decoding each prefix to
the null device, on CPU 12, across three alternating pairs. These are
C consumer observations on the local x86 host, without AVX-512.

Reproduce the comparison with `python3 -B check-static.py` from this directory
using the existing archives and prepared IVF prefixes. The main build command,
platform and compiler versions, linked sizes, digests, and process logs are
preserved alongside the script.

### Results

| Measurement | Main | Candidate | Change |
|---|---:|---:|---:|
| Rust C static archive | 76,347,930 B | 81,726,262 B | +5,378,332 B (+7.045%) |
| Stripped downstream C host | 8,659,344 B | 8,692,112 B | +32,768 B (+0.378%) |
| Linked `.text` | 6,763,050 B | 6,793,450 B | +30,400 B (+0.450%) |
| Linked `.rodata` | 1,323,052 B | 1,325,228 B | +2,176 B (+0.164%) |

The `splot_decode` member accounts for 5,324,520 B of archive growth, including
4,197,620 B of embedded LLVM bitcode and 858,897 B of unlinked `.text`. Both
builds matched both AVM oracles. They also produced byte-identical raw output
for both representative prefixes, 382,579,200 B for Noise Ocean and
746,496,000 B for RitualDance. Size and exact input/output hash receipts are in
`sizes.csv` and `decode.csv`.

Median peak RSS was 54,444 → 54,708 KiB for Noise Ocean
(range 54,396–54,476 → 54,564–54,832) and 79,064 → 79,116 KiB for RitualDance
(range 78,648–79,248 → 78,980–79,248). Each cell has three observations.
Raw samples are in `rss.csv`.

## Windows

No Windows release artifact or Windows consumer test is available. The pinned
workflow inventory has no Windows jobs, the repository documents source
installation, and the public release page has no releases. This leaves
Windows artifact and native consumer coverage unqualified. Source builds on
Windows were outside this check.

[Public Splot releases](https://github.com/splotlabs/splot/releases) ·
[Tracked workflows](https://github.com/splotlabs/splot/tree/91fbc9218814c1a0eebe73074c03fd35f3a2f932/.github/workflows) ·
[C archive configuration](https://github.com/splotlabs/splot/blob/91fbc9218814c1a0eebe73074c03fd35f3a2f932/crates/splot-capi/Cargo.toml#L14-L16)
