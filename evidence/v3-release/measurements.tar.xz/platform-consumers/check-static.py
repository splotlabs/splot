import csv
import hashlib
import os
import re
import shutil
import subprocess
import tomllib
from pathlib import Path

HERE = Path(__file__).resolve().parent
QUAL = HERE.parents[1]
V3 = HERE.parent
OLD = V3 / "consumer-sizes"
CANDIDATE = QUAL.parent / "splot-1882-v3-release"
PARENT = OLD / "parent/source"
HEADS = {
    "parent": "9df30e915bd27da01769ccf41bb53bfa99d69063",
    "candidate": "91fbc9218814c1a0eebe73074c03fd35f3a2f932",
}
ARCHIVES = {
    "parent": HERE / "target-parent/release/libsplot_capi.a",
    "candidate": V3 / "final-product/target/release/libsplot_capi.a",
}
SOURCES = {"parent": PARENT, "candidate": CANDIDATE}
FIXTURES = ("syn-filmgrain-intra-64x64", "syn-3frame-filmgrain-inter-64x64-10bit")
SAMPLES = (
    "Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f-prefix64",
    "RitualDance_1920x1080_60fps_10bit_420_qp135_600f-prefix64",
)
SECTIONS = re.compile(r"^\s*\[\s*\d+\]\s+(\S+)\s+\S+\s+[\da-f]+\s+[\da-f]+\s+([\da-f]+)\s")
ENV = {key: value for key, value in os.environ.items() if key not in ("LD_LIBRARY_PATH", "LD_PRELOAD")}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def capture(log, command):
    command = [str(arg) for arg in command]
    with log.open("w") as out:
        print(repr(command), file=out, flush=True)
        subprocess.run(command, stdout=out, stderr=subprocess.STDOUT, env=ENV, check=True)
    return log.read_text()


def consumer(variant):
    target = HERE / variant
    target.mkdir(exist_ok=True)
    binary = target / "c-consumer"
    stripped = target / "c-consumer.stripped"
    header = SOURCES[variant] / "crates/splot-capi/include"
    archive = ARCHIVES[variant]
    capture(target / "link.log", [
        "cc", "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-I", header,
        OLD / "consumer.c", archive, "-o", binary, "-ldl", "-lpthread", "-lm",
        "-Wl,--gc-sections", f"-Wl,-Map,{target / 'link.map'}",
    ])
    shutil.copyfile(binary, stripped)
    stripped.chmod(0o755)
    capture(target / "strip.log", ["strip", "--strip-all", stripped])
    dyn = capture(target / "dynamic.log", ["readelf", "-d", stripped])
    assert "libc.so.6" in dyn and "libsplot" not in dyn
    symbols = capture(target / "symbols.log", ["nm", "-C", "--defined-only", binary])
    for symbol in ("splot_open", "splot_send_data", "splot_get_picture", "splot_drain", "splot_close"):
        assert re.search(rf"\bT {symbol}$", symbols, re.M), symbol
    sections = capture(target / "sections.log", ["readelf", "-SW", stripped])
    sizes = {match[1]: int(match[2], 16) for line in sections.splitlines() if (match := SECTIONS.match(line))}
    return (variant, HEADS[variant], archive.stat().st_size, digest(archive),
            binary.stat().st_size, stripped.stat().st_size, sizes[".text"], sizes[".rodata"], digest(stripped))


def main():
    inputs = PARENT / "tests/conformance"
    manifest = tomllib.loads((inputs / "decoder-oracle.toml").read_text())
    records = {row["id"]: row for row in manifest["fixture"]}
    with (HERE / "sizes.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("variant", "revision", "archive_bytes", "archive_sha256",
                         "consumer_before_strip_bytes", "consumer_bytes", "text_bytes",
                         "rodata_bytes", "consumer_sha256"))
        for variant in HEADS:
            writer.writerow(consumer(variant))
            stream.flush()

    all_cases = {case: (inputs / "vectors/valid" / f"{case}.ivf", records[case]["avm_raw_sha256"])
                 for case in FIXTURES}
    for case, (source, _) in all_cases.items():
        assert digest(source) == records[case]["ivf_sha256"], case
    all_cases.update({case: (OLD / f"{case}.ivf", None) for case in SAMPLES})

    with (HERE / "decode.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("case", "variant", "input_sha256", "decoded_bytes", "output_sha256", "oracle"))
        for case, (source, oracle) in all_cases.items():
            for variant in HEADS:
                target = HERE / variant
                raw = target / "output.yuv"
                capture(target / f"{case}.log", ["taskset", "-c", "12", target / "c-consumer.stripped", source, raw])
                output_hash = digest(raw)
                writer.writerow((case, variant, digest(source), raw.stat().st_size, output_hash,
                                 "AVM manifest" if case in FIXTURES else "matched parent"))
                stream.flush()
                if oracle is None:
                    oracle = output_hash
                assert output_hash == oracle, (variant, case, output_hash, oracle)
                raw.unlink()


def sample_rss():
    with (HERE / "rss.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("case", "round", "variant", "max_rss_kib"))
        for case in SAMPLES:
            source = OLD / f"{case}.ivf"
            for ordinal in range(3):
                order = tuple(HEADS) if ordinal % 2 == 0 else tuple(reversed(HEADS))
                for variant in order:
                    target = HERE / variant
                    log = target / f"{case}-rss-{ordinal + 1}.log"
                    time = target / f"{case}-rss-{ordinal + 1}.txt"
                    capture(log, ["taskset", "-c", "12", "/usr/bin/time", "-f", "%M", "-o", time,
                                  target / "c-consumer.stripped", source, "/dev/null"])
                    writer.writerow((case, ordinal + 1, variant, int(time.read_text().strip())))
                    stream.flush()


if __name__ == "__main__":
    main()
    sample_rss()
