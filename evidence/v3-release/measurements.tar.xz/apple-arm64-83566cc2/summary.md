# Final typed release on hosted Apple Silicon

[Completed run](https://github.com/splotlabs/splot/actions/runs/45677604248) for exact release head `83566cc2a716603280a8b0773fc026f1fe86676e`, executed by signed experiment workflow `c55e1501`. GitHub `macos-15` reported native arm64 and NEON, Apple M1 (Virtual), VirtualMac2,1, macOS 15.8.2 (24H232), Xcode 16.4, and Rust 1.100.0.

The ordinary optimized release CLI matched all 21 full output hashes and byte lengths, covering seven frozen streams at 1, 7 and 12 threads. The four native backend and lifecycle integration tests passed under the CI profile. The C example loaded the candidate's measured dylib and matched the AVM grained fixture.

| Product | Main file bytes | Candidate file bytes | File delta | `__text` delta |
| --- | ---: | ---: | ---: | ---: |
| CLI | 10,490,528 | 10,495,312 | +4,784 B | −896 B |
| C dylib | 6,867,792 | 6,867,808 | +16 B | +384 B |

Main's size numbers come from the [prior hosted comparison](https://github.com/splotlabs/splot/actions/runs/45670988686) at `d171d824`. The `9df30e91` comparator has identical crate sources, lockfile, Cargo config, toolchain and default release settings. Its manifest adds the optional `ci-release` profile. The size comparison uses separate VM instances of the same hardware and toolchain class. Timings for the final typed revision on an idle [M2 Max remain open](https://github.com/splotlabs/splot/issues/1993#issuecomment-7170365932).
