"""Check monomorphic output edges in the optimized artifacts."""

from pathlib import Path
import csv
import sys


def rows(path):
    with path.open() as file:
        return list(csv.DictReader(file, delimiter="\t"))


def pick(edges, caller, target, annotation, kind=None):
    selected = [edge for edge in edges if caller in edge["caller"] and target in edge["target"]
                and (kind is None or edge["operation"] == kind)]
    assert selected, (annotation, caller, target)
    for edge in selected:
        print(annotation, edge["edge_address"], edge["operation"], edge["target_address"],
              edge["caller"], edge["target"], sep="\t")


def main(directory):
    print("route\taddress\toperation\tdestination\tcaller\ttarget")
    for product in ("splot", "libsplot_capi.so"):
        path = directory / product
        edges = rows(path / "edges.tsv")
        functions = rows(path / "functions.tsv")
        wide = [fn for fn in functions if int(fn["evex"])]
        assert len(wide) == 2 and all("vectorize_avx512" in fn["name"]
                                      and "film_grain" in fn["name"] for fn in wide)
        assert "splot_core::simd::Sse2Backend" not in (path / "symbols.txt").read_text()
        for backend in ("Avx2", "Avx512"):
            for sample in ("u8", "u16"):
                grain = f"film_grain::apply::<{sample}, splot_core::simd::{backend}Backend>"
                if product == "splot":
                    for sync in ("write_raw_stream_from_plan", "discard_raw_stream_from_plan",
                                 "write_y4m_stream_to_writer"):
                        pick(edges, f"{sync}::<splot_core::simd::{backend}Backend>", grain,
                             "CLI synchronous grain", kind="call")
                    pick(edges, f"run_driver_session::<splot_core::simd::{backend}Backend>", grain,
                         "CLI streaming grain", kind="call")
                else:
                    display = f"decoder::display::<{sample}, splot_core::simd::{backend}Backend>"
                    pick(edges, f"run_driver_session::<splot_core::simd::{backend}Backend>",
                         display, "C streaming display", kind="call")
                    pick(edges, display, grain, "C typed grain", kind="call")
                    pick(edges, "Picture>::apply_film_grain", display, "C deferred display", kind="call")
                if backend == "Avx512":
                    pick(edges, grain, "vectorize_avx512", f"{product} wide row", kind="call")
        if product == "libsplot_capi.so":
            pick(edges, "splot_apply_grain", "Picture>::apply_film_grain", "C deferred public boundary")


if __name__ == "__main__":
    main(Path(sys.argv[1]))
