"""Summarize matched symbol and section sizes and verify stripped code bytes."""

from collections import Counter
from pathlib import Path
import csv
import hashlib
import re
import subprocess

HERE = Path(__file__).resolve().parent
VARIANTS = {
    "previous-main": (HERE.parent / "linked/release-main", HERE.parent / "linked/main-analysis"),
    "previous-wide": (HERE.parent / "linked/release-wide", HERE.parent / "linked/wide-analysis"),
    "typed-screen": (HERE.parent / "typed-screen/typed", HERE / "typed-analysis"),
    "parent": (HERE / "release-parent", HERE / "parent-analysis"),
    "final": (HERE / "release-final", HERE / "final-analysis"),
}
PRODUCTS = ("splot", "libsplot_capi.so")
SYMBOL = re.compile(r"^([0-9a-f]+) ([0-9a-f]+) [tTwW] (.*)$")
SECTION = re.compile(
    r"^\s*\[\s*\d+\]\s+(\.(?:text|rodata))\s+\w+\s+[a-f0-9]+\s+([a-f0-9]+)\s+([a-f0-9]+)"
)


def write_tsv(path, header, rows):
    with path.open("w") as file:
        writer = csv.writer(file, delimiter="\t", lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def sections(binary):
    raw = binary.read_bytes()
    result = {}
    for line in subprocess.check_output(["readelf", "-SW", binary], text=True).splitlines():
        if match := SECTION.match(line):
            name, offset, size = match.groups()
            offset, size = int(offset, 16), int(size, 16)
            result[name] = (size, hashlib.sha256(raw[offset : offset + size]).hexdigest())
    assert result.keys() == {".text", ".rodata"}, binary
    return result


def symbol_bytes(path):
    text = Counter()
    used = set()
    for line in path.read_text().splitlines():
        if match := SYMBOL.match(line):
            addr, size, symbol = match.groups()
            if addr not in used:
                text[re.sub(r"\.llvm\.\d+", ".llvm", symbol)] += int(size, 16)
                used.add(addr)
    return text


def main():
    sizes, checks = [], []
    for variant, (sources, analysis) in VARIANTS.items():
        revision = (sources / "revision.txt").read_text().strip()
        for product in PRODUCTS:
            unstripped = sources / product
            stripped = analysis / product / f"{product}.stripped"
            original_sect = sections(unstripped)
            stripped_sect = sections(stripped)
            assert original_sect == stripped_sect, product
            sizes.append((
                variant, revision, product, unstripped.stat().st_size,
                stripped.stat().st_size, original_sect[".text"][0],
                original_sect[".rodata"][0],
            ))
            checks.extend((variant, product, name, size, digest)
                          for name, (size, digest) in sorted(original_sect.items()))
    write_tsv(HERE / "sizes.tsv",
              ("variant", "revision", "product", "symbolized_bytes", "stripped_bytes", "text_bytes", "rodata_bytes"),
              sizes)
    write_tsv(HERE / "section-verification.tsv",
              ("variant", "product", "section", "bytes", "sha256"), checks)

    for control in ("parent", "typed-screen", "previous-wide"):
        for product in PRODUCTS:
            prev = symbol_bytes(VARIANTS[control][1] / product / "symbols.txt")
            final = symbol_bytes(VARIANTS["final"][1] / product / "symbols.txt")
            deltas = sorted(
                ((final[name] - prev[name], final[name], prev[name], name) for name in final.keys() | prev.keys()
                 if final[name] != prev[name]),
                key=lambda row: (-abs(row[0]), row[-1]),
            )
            write_tsv(HERE / f"symbol-delta-{control}-{product}.tsv",
                      ("delta_bytes", "final_bytes", "control_bytes", "name"), deltas)


if __name__ == "__main__":
    main()
