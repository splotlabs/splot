# Final linked v3 release audit

## Matched artifacts and C header

[Actions run 45674741726](https://github.com/splotlabs/splot/actions/runs/45674741726) completed successfully. It built [candidate `c9a9a960`](https://github.com/splotlabs/splot/commit/c9a9a960d9630c5033c3a16e7fa4c12d99dea916) and [parent `9df30e91`](https://github.com/splotlabs/splot/commit/9df30e915bd27da01769ccf41bb53bfa99d69063) on Ubuntu 24.04 with rustc 1.100.0 and LLVM 23.1.5. Both used the release profile with ThinLTO, one codegen unit, `target-cpu=x86-64-v3`, packed relative relocations and a symbols-preserving strip override. The parent adds `--cfg disable_dispatch_avx512`. All four ELFs report `GLIBC_ABI_DT_RELR`.

Both ZIP digests match the Actions API and all four payload digests match their embedded manifests. Candidate artifact ID is `15051078344` and parent is `15051477493`. The public `splot.h` source blob is `865678622e7579f0f5b3b7180c06d4d29060321b` in both revisions. The same 14 defined dynamic C exports are present in both shared libraries. See `workflow.yml`, `artifacts.json`, `input-archives.SHA256SUMS`, the extracted manifests and each analysis directory's `elf-metadata.txt` and `exports.txt`.

## Stripped size and symbol attribution

GNU strip 2.46 `--strip-all` operated on duplicate files. Each copy has the original section bytes for `.text` and `.rodata`. The symbolized and stripped parent files are byte-identical to the prior matched `d171d824` main files.

| Measure | Parent CLI | Final CLI | Change | Parent C library | Final C library | Change |
|---|---:|---:|---:|---:|---:|---:|
| Symbolized file | 16,145,488 | 16,200,232 | +54,744 | 13,345,408 | 13,387,960 | +42,552 |
| Stripped file | 12,464,680 | 12,508,008 | **+43,328 (+0.348%)** | 8,549,296 | 8,583,312 | **+34,016 (+0.398%)** |
| `.text` | 10,498,215 | 10,539,959 | +41,744 | 6,766,851 | 6,797,587 | +30,736 |
| `.rodata` | 1,716,930 | 1,717,282 | +352 | 1,282,188 | 1,282,444 | +256 |

The previous runtime-wide `a55cff38` build stripped to 12,491,576 and 8,577,680 bytes. The final increases are +16,432 CLI and +5,632 C library over that build. Final and typed screen `3cddb13a` have identical stripped lengths, section lengths and normalized function sizes. The final ELF files differ bytewise from the screen. At the same section offsets, the CLI has 11,782 differing text bytes and the C library has 175. Every named grain, display, streaming callback, deferred application and resolver body checked in `final-vs-typed-code.tsv` is byte-identical. The 33 captured row/display edges match at identical addresses. The screen timings therefore describe the earlier binary.

The four typed frame-grain implementations sum to 48,767 CLI bytes and 48,278 C library bytes, about 20 KiB more than the parent's two AVX2-only implementations. The previous runtime-wide build's two backend-switching grain implementations totaled 48,648 and 48,501 bytes, respectively. The two wide row scopes add 2,445 CLI bytes and 2,099 C library bytes versus the parent. Their lengths match both earlier wide builds.

The largest new-name entry is `decode_frames_in_order::<Avx2Backend>`. The corresponding parent function is 2,624 bytes larger in the CLI and 2,349 larger in the C library. The largest added grain symbol is 12,401 CLI bytes and 12,299 C library bytes. The new typed streaming callbacks total 5,944 CLI and 2,964 C library bytes. The previous wide build's shared named streaming output callback was 493 bytes per artifact and called a separate combined `Picture::new`. CLI output also has separate typed raw and Y4M write callbacks and out-of-line serialization helpers. `symbol-delta-*.tsv` records exact-name differences, including moved or renamed definitions.

## Typed synchronous and streaming output

The CLI synchronous entry selects the concrete `Discard`, `Raw` or `Y4m` implementation for AVX2 or AVX-512 before walking frames. The per-frame callbacks have backend-specific code and directly call the matching typed grain implementation for each sample width. For example, the CLI AVX2 raw callback calls the u16 and u8 grain bodies at `0x694cfe → 0x5300b0` and `0x694f3f → 0x52a0d0`. Its AVX-512 counterpart calls the corresponding wide-eligible grain bodies at `0x6954fe → 0x532f30` and `0x69573f → 0x52d150`. The discard and Y4M edges follow the same typed structure. The hash API retains the narrow decode path.

For streaming, both linked products launch one of two concrete driver closures at decoder startup after resolving cached host capabilities. The CLI startup directly calls the two specialized spawn routines from the constructor. In the C library, the constructor calls the cached resolver via its linked slot at `0x58dac9 → 0x7c1d30`, then directly launches at `0x58df41` or `0x58dff9`. The shared frame pipeline still invokes its callback interface. The backend-specific callback's subsequent output calls are direct. The CLI streaming AVX2 callback calls its own u8/u16 grain bodies at `0x68f4b8` and `0x68f2ab`. The AVX-512 callback uses the corresponding bodies at `0x690058` and `0x68fe4b`. The C library has four streaming edges from the typed drivers to separately typed `decoder::display` bodies, each followed by a direct matching grain call.

The automatic per-frame grain path uses the concrete backend already present in its callback. There is no repeated resolver or `ResolvedBackend` match in those typed display bodies. Remaining branches select sample width, grain presence and wide row eligibility. The streaming driver retains the resolved tag in the output picture for callers that request deferred synthesis. The external `splot_apply_grain` enters `Picture::apply_film_grain` via `0x190ad5 → 0x542250`. That one boundary selects using the stored tag and directly calls a typed `display` body. It performs no fresh host probe.

| Artifact and row | Direct call to AVX-512 leaf | ZMM multiply example |
|---|---|---|
| CLI u8 | `0x52f17e → 0x663170` | `0x66332e` |
| CLI u16 | `0x534d61 → 0x663630` | `0x663715` |
| C library u8 | `0x3a23dc → 0x4cad40` | `0x4caf23` |
| C library u16 | `0x3a8275 → 0x4cb180` | `0x4cb356` |

Both artifacts contain exactly two functions with EVEX instructions, the u8 and u16 AVX-512 grain scopes, each with 39 EVEX instructions on ZMM operands across the arithmetic branches. AVX2 grain remains VEX/YMM, and the AVX-512 backend retains AVX2 for narrow work. No SSE2 decoder-backend specialization appears in either full-v3 symbol table. See `final-paths.tsv` and the focused assembly.

## Stack scratch

The table gives explicit stack reservation from each frame-grain function prologue, excluding saved registers, caller frames and any heap usage. The typed result and the prior typed screen have identical `stack.tsv` records.

| Artifact and sample | Parent AVX2-only | Previous wide, shared body | Final using AVX2 | Final using AVX-512 |
|---|---:|---:|---:|---:|
| CLI u8 | 2,616 B | 3,272 B | 2,840 B | 2,776 B |
| CLI u16 | 2,488 B | 3,384 B | 2,792 B | 2,888 B |
| C library u8 | 2,616 B | 3,208 B | 2,824 B | 2,760 B |
| C library u16 | 2,584 B | 3,288 B | 2,824 B | 2,872 B |

The final driver output callback reserves 1,880 bytes in the CLI and 968 bytes in the C library for either backend. The C library's typed display wrappers each reserve 800 bytes. The existing output-plane reuse remains visible in the code. These are per-function reservations. Runtime peak stack, heap use, RSS, output parity and elapsed time require their own measurements.

Run `inspect.py` on the extracted symbolized binaries, then `compare.py` and `check-paths.py final-analysis` for the linked scope and size audit.
