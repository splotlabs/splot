import csv
import hashlib
import os
from pathlib import Path
import random
import resource
from statistics import median
import subprocess
import sys
import time
import tomllib


OUT = Path(__file__).resolve().parent
QUAL = OUT.parent
SOURCE = QUAL.parent / 'splot-1882-v3-release'
MAIN = QUAL / 'v3-screen/playback-main/splot.stripped'
NATIVE = OUT / 'native/target/release'
BASELINE = OUT / 'baseline/target/release'
QEMU = QUAL / 'qemu/usr/bin/qemu-x86_64'
SSE2_CPU = 'qemu64,-pni,-sse4a,-ssse3,-sse4.1,-sse4.2,-avx,-avx2,-popcnt,-fma,-bmi1,-bmi2'
FIXTURES = (
    'syn-3frame-multiref-64x64',
    'syn-8frame-opfl-refine-all-64x64-q120',
    'syn-3frame-deblock-subpu-chroma-64x32-10bit-q90',
    'syn-filmgrain-intra-64x64',
    'syn-3frame-filmgrain-inter-64x64-10bit',
    'syn-bru-lr-stripe-wienerns-8bit',
    'syn-bru-lr-stripe-wienerns-10bit',
)


def clip(directory, prefix):
    [path] = (QUAL / directory).glob(f'{prefix}*.ivf')
    return path


WITCHER = clip('data', 'WITCHER3')
TUNNEL = clip('data', 'TunnelFlag')
NOISE = clip('ci-data', 'Noise_Ocean_1920x1080_60fps_qp135_')
GRAIN = clip('ci-data', 'Noise_Ocean_1920x1080_60fps_filmgrain_')
RITUAL = clip('ci-data', 'RitualDance')


def decode(binary, stream, *options, threads=1, prefix=()):
    return [*prefix, binary, 'decode', stream, '--threads', str(threads), '--frame-delay', '1', *options]


def cpu_seconds():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return usage.ru_utime + usage.ru_stime


def timed(command):
    cpu_start = cpu_seconds()
    start = time.perf_counter()
    subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, check=True)
    return time.perf_counter() - start, cpu_seconds() - cpu_start


def benchmark():
    if os.sched_getaffinity(0) != {4}:
        raise RuntimeError('Run native playback pinned to CPU 4')
    cases = (
        ('Witcher3', WITCHER, ('--limit', '40')),
        ('TunnelFlag', TUNNEL, ('--limit', '40')),
        ('Noise', NOISE, ('--limit', '64')),
        ('RitualDance', RITUAL, ('--limit', '64')),
        ('Noise grain on', GRAIN, ()),
        ('Noise grain off', GRAIN, ('--skip-film-grain',)),
        ('Noise first output incl. process start', NOISE, ('--limit', '1')),
    )
    binaries = {'main': MAIN, 'release': NATIVE / 'splot'}
    commands = {
        (name, variant): decode(binary, path, '--output-format', 'null', *options)
        for name, path, options in cases
        for variant, binary in binaries.items()
    }
    for command in commands.values():
        timed(command)

    rounds = 12
    data = {}
    with (OUT / 'native/paired.csv').open('x', newline='') as measurements:
        writer = csv.writer(measurements)
        writer.writerow(('case', 'round', 'position', 'variant', 'wall_seconds', 'cpu_seconds'))
        for index in range(rounds):
            for offset in range(len(cases)):
                case_index = (index + offset) % len(cases)
                name = cases[case_index][0]
                order = ('main', 'release') if (index + case_index) % 2 == 0 else ('release', 'main')
                for position, variant in enumerate(order, 1):
                    timing = timed(commands[name, variant])
                    data[name, index, variant] = timing
                    writer.writerow((name, index + 1, position, variant, *timing))
                measurements.flush()
            print(f'Completed paired round {index + 1}/{rounds}', flush=True)

    print('Case | metric | median main ms | median release ms | paired median change and bootstrap interval | release slower')
    for name, _, _ in cases:
        for metric, label in enumerate(('wall', 'child CPU')):
            main = [data[name, r, 'main'][metric] for r in range(rounds)]
            release = [data[name, r, 'release'][metric] for r in range(rounds)]
            ratios = [candidate / reference for candidate, reference in zip(release, main)]
            slower = sum(ratio > 1 for ratio in ratios)
            rng = random.Random(1882)
            bootstraps = sorted(median(rng.choices(ratios, k=rounds)) for _ in range(10000))
            center, low, high = (100 * (value - 1) for value in (median(ratios), bootstraps[250], bootstraps[9749]))
            print(f'{name} | {label} | {1000*median(main):.2f} | {1000*median(release):.2f} | '
                  f'{center:+.2f}% [{low:+.2f}%, {high:+.2f}%] | {slower}/{rounds}', flush=True)


def digest_stream(command):
    hasher = hashlib.sha256()
    size = 0
    with subprocess.Popen(command, stdout=subprocess.PIPE) as process:
        for chunk in iter(lambda: process.stdout.read(2**20), b''):
            hasher.update(chunk)
            size += len(chunk)
        if process.wait() != 0:
            raise RuntimeError(f'Decode failed: {command!r}')
    return hasher.hexdigest(), size


def full_hashes():
    expectations = {}
    for line in (QUAL / 'ci-data/simd-cases.tsv').read_text().splitlines():
        name, sha, _, size = line.split('\t')
        expectations[name] = (sha, int(size))

    for stream in (NOISE, RITUAL, GRAIN):
        candidate = digest_stream(decode(NATIVE / 'splot', stream, '--output-format', 'raw', '-o', '-'))
        if candidate != expectations[stream.name]:
            raise RuntimeError(f'Frozen oracle mismatch for {stream.name}: {candidate!r}')
        print(f'PASS release {stream.name} bytes={candidate[1]} sha256={candidate[0]}', flush=True)

    main_grain = digest_stream(decode(MAIN, GRAIN, '--output-format', 'raw', '-o', '-'))
    if main_grain != expectations[GRAIN.name]:
        raise RuntimeError(f'Main grain oracle mismatch: {main_grain!r}')
    print(f'PASS main {GRAIN.name} bytes={main_grain[1]} sha256={main_grain[0]}', flush=True)

    for name, binary in (('main', MAIN), ('release', NATIVE / 'splot')):
        ungrained = digest_stream(decode(binary, GRAIN, '--output-format', 'raw', '-o', '-', '--skip-film-grain'))
        if ungrained[0] == expectations[GRAIN.name][0] or ungrained[1] != expectations[GRAIN.name][1]:
            raise RuntimeError(f'Explicit skip-grain control failed for {name}: {ungrained!r}')
        print(f'PASS {name} skip-grain negative control bytes={ungrained[1]} sha256={ungrained[0]}', flush=True)
        if name == 'main':
            main_ungrained = ungrained
        elif ungrained != main_ungrained:
            raise RuntimeError(f'Explicit skip-grain release/main mismatch: {ungrained!r} versus {main_ungrained!r}')


def consumer_checks(mode):
    release = BASELINE if mode == 'baseline' else NATIVE
    prefix = [QEMU, '-cpu', SSE2_CPU] if mode == 'baseline' else []
    output = OUT / mode
    capi = SOURCE / 'crates/splot-capi'
    conformance = SOURCE / 'tests/conformance'
    fixtures = {entry['id']: entry for entry in tomllib.loads((conformance / 'decoder-oracle.toml').read_text())['fixture']}
    example = output / 'c-example'
    subprocess.run([
        'cc', '-O2', '-march=x86-64', '-I', capi / 'include', capi / 'examples/decode.c',
        '-L', release, '-lsplot_capi', f'-Wl,-rpath,{release}', '-o', example,
    ], check=True)
    for fixture_id in FIXTURES:
        fixture = conformance / 'vectors/valid' / f'{fixture_id}.ivf'
        oracle = fixtures[fixture_id]
        if hashlib.sha256(fixture.read_bytes()).hexdigest() != oracle['ivf_sha256']:
            raise RuntimeError(f'Frozen input mismatch: {fixture_id}')
        expected = oracle['avm_raw_sha256']
        for threads in (1, 3):
            actual, size = digest_stream(decode(release / 'splot', fixture, '--output-format', 'raw', '-o', '-',
                                                threads=threads, prefix=prefix))
            if actual != expected:
                raise RuntimeError(f'{mode} CLI {threads} thread oracle mismatch: {fixture_id} {actual}')
            print(f'PASS {mode} CLI {threads} thread {fixture_id} {size} {actual}', flush=True)
        c_raw = output / f'{fixture_id}.c-api.yuv'
        env = {name: value for name, value in os.environ.items() if name not in ('LD_LIBRARY_PATH', 'LD_PRELOAD')}
        subprocess.run([*prefix, example, fixture, c_raw], check=True, env=env)
        actual = hashlib.sha256(c_raw.read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f'{mode} C ABI oracle mismatch: {fixture_id} {actual}')
        print(f'PASS {mode} C ABI {fixture_id} {c_raw.stat().st_size} {actual}', flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    actions = {
        'bench': benchmark,
        'hashes': full_hashes,
        'native': lambda: consumer_checks('native'),
        'baseline': lambda: consumer_checks('baseline'),
    }
    actions[action]()
