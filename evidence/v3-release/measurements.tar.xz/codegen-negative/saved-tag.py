"""Check the saved-tag branch in the linked C deferred-grain entry."""

from collections import deque
from pathlib import Path
from runpy import run_path
import subprocess


HERE = Path(__file__).resolve().parent
CHECK = run_path(str(HERE / 'exercise.py'))
LINKED = CHECK['LINKED']
ELF = CHECK['ELF']
TARGET = CHECK['TARGET']


def main():
    binary = LINKED / 'release-final/libsplot_capi.so'
    functions = CHECK['rows'](LINKED / 'final-analysis/libsplot_capi.so/functions.tsv')
    method = CHECK['exactly_one'](fn for fn in functions if fn['name'] == '<splot_decode::decoder::Picture>::apply_film_grain')
    start = int(method['address'], 16)
    end = int(method['last_instruction'], 16) + 1
    listing = subprocess.check_output([
        'objdump', '-dC', '-Mintel', '--insn-width=16', f'--start-address={start}', f'--stop-address={end}', binary,
    ], text=True)
    (HERE / 'deferred-picture.asm').write_text(listing)
    instructions = {}
    for line in listing.splitlines():
        if instruction := ELF['INSTR'].match(line):
            at, _, op, arguments = instruction.groups()
            instructions[int(at, 16)] = op, arguments
    addresses = list(instructions)
    fallthrough = dict(zip(addresses, addresses[1:]))
    compare = CHECK['exactly_one'](at for at, instruction in instructions.items()
                                     if instruction == ('cmp', 'BYTE PTR [rsi+0x1a1],0x1'))
    branch = fallthrough[compare]
    opcode, arguments = instructions[branch]
    assert opcode == 'jne' and (target := TARGET.match(arguments)), (branch, opcode, arguments)
    print(f'0x{compare:x} compares the stored Picture backend byte at +0x1a1 against 1')
    print(f'0x{branch:x}: tag=0 → 0x{int(target[1], 16):x}; tag=1 → 0x{fallthrough[branch]:x}')

    for tag, entry, backend in ((0, int(target[1], 16), CHECK['AVX2']), (1, fallthrough[branch], CHECK['WIDE'])):
        todo = deque([entry])
        visited = set()
        displays = {}
        while todo:
            at = todo.popleft()
            if at not in instructions or at in visited:
                continue
            visited.add(at)
            operation, operands = instructions[at]
            if operation == 'call' and 'splot_decode::decoder::display::<' in operands:
                displays[at] = operands
            if operation.startswith('j') and (destination := TARGET.match(operands)):
                todo.append(int(destination[1], 16))
            if operation not in ('jmp', 'ret', 'ud2') and at in fallthrough:
                todo.append(fallthrough[at])
        expected = {f'display::<{sample}, {backend}>' for sample in ('u8', 'u16')}
        assert len(displays) == len(expected) and all(any(name in operand for operand in displays.values()) for name in expected), displays
        for at, display in sorted(displays.items()):
            print(f'PASS tag={tag} reaches typed display at 0x{at:x}: {display}')


if __name__ == '__main__':
    main()
