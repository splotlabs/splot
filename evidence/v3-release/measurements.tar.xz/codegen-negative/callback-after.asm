
<WORKTREES>/qualification-1882/v3-release/codegen-negative/injected-splot.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000694f3f <splot_decode::output::raw::write_raw_stream_from_plan::<splot_core::simd::Avx2Backend>::{closure#1}+0x47f>:
  694f3f:	e8 0c 82 e9 ff       	call   52d150 <splot_decode::output::film_grain::apply::<u8, splot_core::simd::Avx512Backend>>
