# Linked x86 codegen regression exercise

The control binaries are the symbolized x86-64-v3 CLI and shared C library for `c9a9a960d9630c5033c3a16e7fa4c12d99dea916`, archived in `../linked-final/release-final` with their SHA-256 manifest. This exercise validates the linked review procedure on that exact input. [Hosted build](https://github.com/splotlabs/splot/actions/runs/45674741726)

## Injected route

The fixture redirects one real five-byte `call rel32` at CLI virtual address `0x694f3f` (file offset `0x693f3f`). Its caller is the AVX2 raw-output callback. The original destination `0x52a0d0` is the typed AVX2 u8 grain function. The injected destination `0x52d150` is the corresponding AVX-512 u8 grain function. The callee's existent second call at `0x52f17e` then reaches the wide u8 row at `0x663170`. Only the displacement changes. The fixture is mode 0644 and intended for static inspection.

| Artifact | First call bytes | Stock checker |
|---|---|---:|
| Control | `e8 8c 51 e9 ff` | Exit 0 |
| Injected | `e8 0c 82 e9 ff` | Exit 1 |

The original checker fails because the required AVX2 raw edge is missing. The additional graph check independently identifies the two-hop AVX2-to-wide path. The u16 route remains unreachable through the captured graph. Wide-leaf incoming calls themselves are unchanged in the injection, so checking only those immediate edges would miss this wrong route.

## Reachability on the controls

| Product | Wide leaf | Only resolved outside incoming call |
|---|---|---|
| CLI | u8 `0x663170` | AVX-512 u8 `apply` at `0x52f17e` |
| CLI | u16 `0x663630` | AVX-512 u16 `apply` at `0x534d61` |
| C library | u8 `0x4cad40` | AVX-512 u8 `apply` at `0x3a23dc` |
| C library | u16 `0x4cb180` | AVX-512 u16 `apply` at `0x3a8275` |

The stock disassembly check finds all decoded EVEX instructions within the two designated grain leaves in each product. An independent traversal of direct branches and statically resolvable RIP-linked call slots finds no path from the already-selected AVX2 output roots to either leaf. It covers 11 CLI roots and five C library roots. The analyzer reports unresolved indirect sites in the traversed closure and checks the decoded references it can attribute. The result is static evidence over resolved transfers. It leaves arbitrary register- and data-dependent control-flow targets outside the proof.

The shared C deferred-grain dispatch needs the stored backend's value. In this build, `splot_apply_grain` enters `Picture::apply_film_grain` at `0x542250`. Its comparison at `0x542272` branches on the stored byte. The exact intraprocedural control flow for tag 0 reaches only the u8/u16 AVX2 display calls. Tag 1 reaches only the u8/u16 AVX-512 display calls. The AVX2 typed display paths are roots in the separate graph check. These tag values describe the exact artifact layout.

## Reproduce

From this directory with the adjacent `linked-final` inputs and analysis present, run:

```sh
python3 -B -u exercise.py > results.log 2>&1
python3 -B saved-tag.py > deferred-tag.log
```

`exercise.py` reuses `linked-final/inspect.py` and `linked-final/check-paths.py`, checks both controls, and expects the injected artifact to fail. The logs retain the callback disassembly before and after patching, both checker statuses, the resolved reachability results, and the saved-tag branch evidence.
