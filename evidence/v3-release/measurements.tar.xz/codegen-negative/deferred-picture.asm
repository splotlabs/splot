
<WORKTREES>/qualification-1882/v3-release/linked-final/release-final/libsplot_capi.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000542250 <<splot_decode::decoder::Picture>::apply_film_grain>:
  542250:	55                                              	push   rbp
  542251:	41 57                                           	push   r15
  542253:	41 56                                           	push   r14
  542255:	41 55                                           	push   r13
  542257:	41 54                                           	push   r12
  542259:	53                                              	push   rbx
  54225a:	48 81 ec f8 00 00 00                            	sub    rsp,0xf8
  542261:	49 89 f6                                        	mov    r14,rsi
  542264:	48 89 fb                                        	mov    rbx,rdi
  542267:	48 8d 56 28                                     	lea    rdx,[rsi+0x28]
  54226b:	48 8d 8e 98 01 00 00                            	lea    rcx,[rsi+0x198]
  542272:	80 be a1 01 00 00 01                            	cmp    BYTE PTR [rsi+0x1a1],0x1
  542279:	75 6b                                           	jne    5422e6 <<splot_decode::decoder::Picture>::apply_film_grain+0x96>
  54227b:	31 f6                                           	xor    esi,esi
  54227d:	49 83 7e 28 ff                                  	cmp    QWORD PTR [r14+0x28],0xffffffffffffffff
  542282:	49 8b 06                                        	mov    rax,QWORD PTR [r14]
  542285:	48 0f 44 d6                                     	cmove  rdx,rsi
  542289:	4d 8b be 98 01 00 00                            	mov    r15,QWORD PTR [r14+0x198]
  542290:	4d 85 ff                                        	test   r15,r15
  542293:	49 0f 44 cf                                     	cmove  rcx,r15
  542297:	48 85 c0                                        	test   rax,rax
  54229a:	0f 84 ad 00 00 00                               	je     54234d <<splot_decode::decoder::Picture>::apply_film_grain+0xfd>
  5422a0:	83 f8 02                                        	cmp    eax,0x2
  5422a3:	0f 85 09 01 00 00                               	jne    5423b2 <<splot_decode::decoder::Picture>::apply_film_grain+0x162>
  5422a9:	c4 c1 7c 10 86 20 01 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0x120]
  5422b2:	c4 c1 7c 10 8e 40 01 00 00                      	vmovups ymm1,YMMWORD PTR [r14+0x140]
  5422bb:	c4 c1 7c 10 96 50 01 00 00                      	vmovups ymm2,YMMWORD PTR [r14+0x150]
  5422c4:	c5 fc 11 54 24 40                               	vmovups YMMWORD PTR [rsp+0x40],ymm2
  5422ca:	c5 fc 11 4c 24 30                               	vmovups YMMWORD PTR [rsp+0x30],ymm1
  5422d0:	c5 fc 11 44 24 10                               	vmovups YMMWORD PTR [rsp+0x10],ymm0
  5422d6:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
  5422db:	41 bc 02 00 00 00                               	mov    r12d,0x2
  5422e1:	e9 37 01 00 00                                  	jmp    54241d <<splot_decode::decoder::Picture>::apply_film_grain+0x1cd>
  5422e6:	31 f6                                           	xor    esi,esi
  5422e8:	49 83 7e 28 ff                                  	cmp    QWORD PTR [r14+0x28],0xffffffffffffffff
  5422ed:	49 8b 06                                        	mov    rax,QWORD PTR [r14]
  5422f0:	48 0f 44 d6                                     	cmove  rdx,rsi
  5422f4:	4d 8b be 98 01 00 00                            	mov    r15,QWORD PTR [r14+0x198]
  5422fb:	4d 85 ff                                        	test   r15,r15
  5422fe:	49 0f 44 cf                                     	cmove  rcx,r15
  542302:	48 85 c0                                        	test   rax,rax
  542305:	74 77                                           	je     54237e <<splot_decode::decoder::Picture>::apply_film_grain+0x12e>
  542307:	83 f8 02                                        	cmp    eax,0x2
  54230a:	0f 85 92 01 00 00                               	jne    5424a2 <<splot_decode::decoder::Picture>::apply_film_grain+0x252>
  542310:	c4 c1 7c 10 86 20 01 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0x120]
  542319:	c4 c1 7c 10 8e 40 01 00 00                      	vmovups ymm1,YMMWORD PTR [r14+0x140]
  542322:	c4 c1 7c 10 96 50 01 00 00                      	vmovups ymm2,YMMWORD PTR [r14+0x150]
  54232b:	c5 fc 11 54 24 40                               	vmovups YMMWORD PTR [rsp+0x40],ymm2
  542331:	c5 fc 11 4c 24 30                               	vmovups YMMWORD PTR [rsp+0x30],ymm1
  542337:	c5 fc 11 44 24 10                               	vmovups YMMWORD PTR [rsp+0x10],ymm0
  54233d:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
  542342:	41 bc 02 00 00 00                               	mov    r12d,0x2
  542348:	e9 e5 02 00 00                                  	jmp    542632 <<splot_decode::decoder::Picture>::apply_film_grain+0x3e2>
  54234d:	49 8b 76 08                                     	mov    rsi,QWORD PTR [r14+0x8]
  542351:	f0 48 ff 06                                     	lock inc QWORD PTR [rsi]
  542355:	0f 8e 6c 04 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  54235b:	48 8d 7c 24 10                                  	lea    rdi,[rsp+0x10]
  542360:	e8 db 06 dc ff                                  	call   302a40 <splot_decode::decoder::display::<u8, splot_core::simd::Avx512Backend>>
  542365:	48 8b 44 24 10                                  	mov    rax,QWORD PTR [rsp+0x10]
  54236a:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
  54236f:	48 83 f8 ff                                     	cmp    rax,0xffffffffffffffff
  542373:	0f 85 55 01 00 00                               	jne    5424ce <<splot_decode::decoder::Picture>::apply_film_grain+0x27e>
  542379:	45 31 e4                                        	xor    r12d,r12d
  54237c:	eb 66                                           	jmp    5423e4 <<splot_decode::decoder::Picture>::apply_film_grain+0x194>
  54237e:	49 8b 76 08                                     	mov    rsi,QWORD PTR [r14+0x8]
  542382:	f0 48 ff 06                                     	lock inc QWORD PTR [rsi]
  542386:	0f 8e 3b 04 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  54238c:	48 8d 7c 24 10                                  	lea    rdi,[rsp+0x10]
  542391:	e8 aa 03 dc ff                                  	call   302740 <splot_decode::decoder::display::<u8, splot_core::simd::Avx2Backend>>
  542396:	48 8b 44 24 10                                  	mov    rax,QWORD PTR [rsp+0x10]
  54239b:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
  5423a0:	48 83 f8 ff                                     	cmp    rax,0xffffffffffffffff
  5423a4:	0f 85 24 01 00 00                               	jne    5424ce <<splot_decode::decoder::Picture>::apply_film_grain+0x27e>
  5423aa:	45 31 e4                                        	xor    r12d,r12d
  5423ad:	e9 47 02 00 00                                  	jmp    5425f9 <<splot_decode::decoder::Picture>::apply_film_grain+0x3a9>
  5423b2:	49 8b 76 08                                     	mov    rsi,QWORD PTR [r14+0x8]
  5423b6:	f0 48 ff 06                                     	lock inc QWORD PTR [rsi]
  5423ba:	0f 8e 07 04 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  5423c0:	48 8d 7c 24 10                                  	lea    rdi,[rsp+0x10]
  5423c5:	e8 76 0c dc ff                                  	call   303040 <splot_decode::decoder::display::<u16, splot_core::simd::Avx512Backend>>
  5423ca:	48 8b 44 24 10                                  	mov    rax,QWORD PTR [rsp+0x10]
  5423cf:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
  5423d4:	48 83 f8 ff                                     	cmp    rax,0xffffffffffffffff
  5423d8:	0f 85 f0 00 00 00                               	jne    5424ce <<splot_decode::decoder::Picture>::apply_film_grain+0x27e>
  5423de:	41 bc 01 00 00 00                               	mov    r12d,0x1
  5423e4:	c4 c1 7c 10 86 40 01 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0x140]
  5423ed:	c4 c1 7c 10 8e 50 01 00 00                      	vmovups ymm1,YMMWORD PTR [r14+0x150]
  5423f6:	c5 fc 11 4c 24 40                               	vmovups YMMWORD PTR [rsp+0x40],ymm1
  5423fc:	c5 fc 11 44 24 30                               	vmovups YMMWORD PTR [rsp+0x30],ymm0
  542402:	c4 c1 7c 10 86 20 01 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0x120]
  54240b:	c5 fc 11 44 24 10                               	vmovups YMMWORD PTR [rsp+0x10],ymm0
  542411:	48 89 54 24 08                                  	mov    QWORD PTR [rsp+0x8],rdx
  542416:	48 8d 82 18 01 00 00                            	lea    rax,[rdx+0x118]
  54241d:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
  542421:	c5 fc 10 48 20                                  	vmovups ymm1,YMMWORD PTR [rax+0x20]
  542426:	c5 fc 10 50 30                                  	vmovups ymm2,YMMWORD PTR [rax+0x30]
  54242b:	c5 fc 11 94 24 d0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xd0],ymm2
  542434:	c5 fc 11 8c 24 c0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xc0],ymm1
  54243d:	c5 fc 11 84 24 a0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xa0],ymm0
  542446:	49 8b 86 80 01 00 00                            	mov    rax,QWORD PTR [r14+0x180]
  54244d:	48 89 84 24 80 00 00 00                         	mov    QWORD PTR [rsp+0x80],rax
  542455:	c4 c1 78 10 86 70 01 00 00                      	vmovups xmm0,XMMWORD PTR [r14+0x170]
  54245e:	c5 f8 29 44 24 70                               	vmovaps XMMWORD PTR [rsp+0x70],xmm0
  542464:	c4 c1 7c 10 86 e0 00 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0xe0]
  54246d:	c4 c1 7c 10 8e 00 01 00 00                      	vmovups ymm1,YMMWORD PTR [r14+0x100]
  542476:	c5 fc 11 4c 24 30                               	vmovups YMMWORD PTR [rsp+0x30],ymm1
  54247c:	c5 fc 11 44 24 10                               	vmovups YMMWORD PTR [rsp+0x10],ymm0
  542482:	49 8b ae 88 01 00 00                            	mov    rbp,QWORD PTR [r14+0x188]
  542489:	48 85 ed                                        	test   rbp,rbp
  54248c:	74 75                                           	je     542503 <<splot_decode::decoder::Picture>::apply_film_grain+0x2b3>
  54248e:	f0 48 ff 45 00                                  	lock inc QWORD PTR [rbp+0x0]
  542493:	0f 8e 2e 03 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  542499:	4d 8b ae 90 01 00 00                            	mov    r13,QWORD PTR [r14+0x190]
  5424a0:	eb 61                                           	jmp    542503 <<splot_decode::decoder::Picture>::apply_film_grain+0x2b3>
  5424a2:	49 8b 76 08                                     	mov    rsi,QWORD PTR [r14+0x8]
  5424a6:	f0 48 ff 06                                     	lock inc QWORD PTR [rsi]
  5424aa:	0f 8e 17 03 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  5424b0:	48 8d 7c 24 10                                  	lea    rdi,[rsp+0x10]
  5424b5:	e8 86 08 dc ff                                  	call   302d40 <splot_decode::decoder::display::<u16, splot_core::simd::Avx2Backend>>
  5424ba:	48 8b 44 24 10                                  	mov    rax,QWORD PTR [rsp+0x10]
  5424bf:	48 8b 54 24 18                                  	mov    rdx,QWORD PTR [rsp+0x18]
  5424c4:	48 83 f8 ff                                     	cmp    rax,0xffffffffffffffff
  5424c8:	0f 84 25 01 00 00                               	je     5425f3 <<splot_decode::decoder::Picture>::apply_film_grain+0x3a3>
  5424ce:	c5 fc 10 44 24 20                               	vmovups ymm0,YMMWORD PTR [rsp+0x20]
  5424d4:	c5 fc 10 4c 24 40                               	vmovups ymm1,YMMWORD PTR [rsp+0x40]
  5424da:	c5 fc 10 54 24 50                               	vmovups ymm2,YMMWORD PTR [rsp+0x50]
  5424e0:	c5 fc 11 53 48                                  	vmovups YMMWORD PTR [rbx+0x48],ymm2
  5424e5:	c5 fc 11 4b 38                                  	vmovups YMMWORD PTR [rbx+0x38],ymm1
  5424ea:	c5 fc 11 43 18                                  	vmovups YMMWORD PTR [rbx+0x18],ymm0
  5424ef:	48 89 43 08                                     	mov    QWORD PTR [rbx+0x8],rax
  5424f3:	48 89 53 10                                     	mov    QWORD PTR [rbx+0x10],rdx
  5424f7:	48 c7 03 ff ff ff ff                            	mov    QWORD PTR [rbx],0xffffffffffffffff
  5424fe:	e9 ac 02 00 00                                  	jmp    5427af <<splot_decode::decoder::Picture>::apply_film_grain+0x55f>
  542503:	49 8b 76 18                                     	mov    rsi,QWORD PTR [r14+0x18]
  542507:	49 8b 56 20                                     	mov    rdx,QWORD PTR [r14+0x20]
  54250b:	48 8d bc 24 88 00 00 00                         	lea    rdi,[rsp+0x88]
  542513:	c5 f8 77                                        	vzeroupper
  542516:	e8 55 52 0f 00                                  	call   637770 <<alloc::vec::Vec<splot_decode::pipeline::atlas::AtlasAssociation> as core::clone::Clone>::clone>
  54251b:	4d 85 ff                                        	test   r15,r15
  54251e:	74 0a                                           	je     54252a <<splot_decode::decoder::Picture>::apply_film_grain+0x2da>
  542520:	f0 49 ff 07                                     	lock inc QWORD PTR [r15]
  542524:	0f 8e 9d 02 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  54252a:	c5 fc 10 84 24 a0 00 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+0xa0]
  542533:	c5 fc 10 8c 24 c0 00 00 00                      	vmovups ymm1,YMMWORD PTR [rsp+0xc0]
  54253c:	c5 fc 10 94 24 d0 00 00 00                      	vmovups ymm2,YMMWORD PTR [rsp+0xd0]
  542545:	c5 fc 11 93 50 01 00 00                         	vmovups YMMWORD PTR [rbx+0x150],ymm2
  54254d:	c5 fc 11 8b 40 01 00 00                         	vmovups YMMWORD PTR [rbx+0x140],ymm1
  542555:	c5 fc 11 83 20 01 00 00                         	vmovups YMMWORD PTR [rbx+0x120],ymm0
  54255d:	48 8b 84 24 80 00 00 00                         	mov    rax,QWORD PTR [rsp+0x80]
  542565:	48 89 83 80 01 00 00                            	mov    QWORD PTR [rbx+0x180],rax
  54256c:	c5 f8 28 44 24 70                               	vmovaps xmm0,XMMWORD PTR [rsp+0x70]
  542572:	c5 f8 11 83 70 01 00 00                         	vmovups XMMWORD PTR [rbx+0x170],xmm0
  54257a:	c5 fc 10 44 24 10                               	vmovups ymm0,YMMWORD PTR [rsp+0x10]
  542580:	c5 fc 10 4c 24 30                               	vmovups ymm1,YMMWORD PTR [rsp+0x30]
  542586:	c5 fc 11 8b 00 01 00 00                         	vmovups YMMWORD PTR [rbx+0x100],ymm1
  54258e:	c5 fc 11 83 e0 00 00 00                         	vmovups YMMWORD PTR [rbx+0xe0],ymm0
  542596:	41 0f b6 86 a0 01 00 00                         	movzx  eax,BYTE PTR [r14+0x1a0]
  54259e:	c5 f8 10 84 24 88 00 00 00                      	vmovups xmm0,XMMWORD PTR [rsp+0x88]
  5425a7:	c5 f8 11 43 10                                  	vmovups XMMWORD PTR [rbx+0x10],xmm0
  5425ac:	48 8b 8c 24 98 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x98]
  5425b4:	48 89 4b 20                                     	mov    QWORD PTR [rbx+0x20],rcx
  5425b8:	4c 89 23                                        	mov    QWORD PTR [rbx],r12
  5425bb:	48 8b 4c 24 08                                  	mov    rcx,QWORD PTR [rsp+0x8]
  5425c0:	48 89 4b 08                                     	mov    QWORD PTR [rbx+0x8],rcx
  5425c4:	48 c7 43 28 ff ff ff ff                         	mov    QWORD PTR [rbx+0x28],0xffffffffffffffff
  5425cc:	48 89 ab 88 01 00 00                            	mov    QWORD PTR [rbx+0x188],rbp
  5425d3:	4c 89 ab 90 01 00 00                            	mov    QWORD PTR [rbx+0x190],r13
  5425da:	4c 89 bb 98 01 00 00                            	mov    QWORD PTR [rbx+0x198],r15
  5425e1:	88 83 a0 01 00 00                               	mov    BYTE PTR [rbx+0x1a0],al
  5425e7:	c6 83 a1 01 00 00 01                            	mov    BYTE PTR [rbx+0x1a1],0x1
  5425ee:	e9 af 01 00 00                                  	jmp    5427a2 <<splot_decode::decoder::Picture>::apply_film_grain+0x552>
  5425f3:	41 bc 01 00 00 00                               	mov    r12d,0x1
  5425f9:	c4 c1 7c 10 86 40 01 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0x140]
  542602:	c4 c1 7c 10 8e 50 01 00 00                      	vmovups ymm1,YMMWORD PTR [r14+0x150]
  54260b:	c5 fc 11 4c 24 40                               	vmovups YMMWORD PTR [rsp+0x40],ymm1
  542611:	c5 fc 11 44 24 30                               	vmovups YMMWORD PTR [rsp+0x30],ymm0
  542617:	c4 c1 7c 10 86 20 01 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0x120]
  542620:	c5 fc 11 44 24 10                               	vmovups YMMWORD PTR [rsp+0x10],ymm0
  542626:	48 89 54 24 08                                  	mov    QWORD PTR [rsp+0x8],rdx
  54262b:	48 8d 82 18 01 00 00                            	lea    rax,[rdx+0x118]
  542632:	c5 fc 10 00                                     	vmovups ymm0,YMMWORD PTR [rax]
  542636:	c5 fc 10 48 20                                  	vmovups ymm1,YMMWORD PTR [rax+0x20]
  54263b:	c5 fc 10 50 30                                  	vmovups ymm2,YMMWORD PTR [rax+0x30]
  542640:	c5 fc 11 94 24 d0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xd0],ymm2
  542649:	c5 fc 11 8c 24 c0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xc0],ymm1
  542652:	c5 fc 11 84 24 a0 00 00 00                      	vmovups YMMWORD PTR [rsp+0xa0],ymm0
  54265b:	49 8b 86 80 01 00 00                            	mov    rax,QWORD PTR [r14+0x180]
  542662:	48 89 84 24 80 00 00 00                         	mov    QWORD PTR [rsp+0x80],rax
  54266a:	c4 c1 78 10 86 70 01 00 00                      	vmovups xmm0,XMMWORD PTR [r14+0x170]
  542673:	c5 f8 29 44 24 70                               	vmovaps XMMWORD PTR [rsp+0x70],xmm0
  542679:	c4 c1 7c 10 86 e0 00 00 00                      	vmovups ymm0,YMMWORD PTR [r14+0xe0]
  542682:	c4 c1 7c 10 8e 00 01 00 00                      	vmovups ymm1,YMMWORD PTR [r14+0x100]
  54268b:	c5 fc 11 4c 24 30                               	vmovups YMMWORD PTR [rsp+0x30],ymm1
  542691:	c5 fc 11 44 24 10                               	vmovups YMMWORD PTR [rsp+0x10],ymm0
  542697:	49 8b ae 88 01 00 00                            	mov    rbp,QWORD PTR [r14+0x188]
  54269e:	48 85 ed                                        	test   rbp,rbp
  5426a1:	74 14                                           	je     5426b7 <<splot_decode::decoder::Picture>::apply_film_grain+0x467>
  5426a3:	f0 48 ff 45 00                                  	lock inc QWORD PTR [rbp+0x0]
  5426a8:	0f 8e 19 01 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  5426ae:	4d 8b ae 90 01 00 00                            	mov    r13,QWORD PTR [r14+0x190]
  5426b5:	eb 00                                           	jmp    5426b7 <<splot_decode::decoder::Picture>::apply_film_grain+0x467>
  5426b7:	49 8b 76 18                                     	mov    rsi,QWORD PTR [r14+0x18]
  5426bb:	49 8b 56 20                                     	mov    rdx,QWORD PTR [r14+0x20]
  5426bf:	48 8d bc 24 88 00 00 00                         	lea    rdi,[rsp+0x88]
  5426c7:	c5 f8 77                                        	vzeroupper
  5426ca:	e8 a1 50 0f 00                                  	call   637770 <<alloc::vec::Vec<splot_decode::pipeline::atlas::AtlasAssociation> as core::clone::Clone>::clone>
  5426cf:	4d 85 ff                                        	test   r15,r15
  5426d2:	74 0a                                           	je     5426de <<splot_decode::decoder::Picture>::apply_film_grain+0x48e>
  5426d4:	f0 49 ff 07                                     	lock inc QWORD PTR [r15]
  5426d8:	0f 8e e9 00 00 00                               	jle    5427c7 <<splot_decode::decoder::Picture>::apply_film_grain+0x577>
  5426de:	c5 fc 10 84 24 a0 00 00 00                      	vmovups ymm0,YMMWORD PTR [rsp+0xa0]
  5426e7:	c5 fc 10 8c 24 c0 00 00 00                      	vmovups ymm1,YMMWORD PTR [rsp+0xc0]
  5426f0:	c5 fc 10 94 24 d0 00 00 00                      	vmovups ymm2,YMMWORD PTR [rsp+0xd0]
  5426f9:	c5 fc 11 93 50 01 00 00                         	vmovups YMMWORD PTR [rbx+0x150],ymm2
  542701:	c5 fc 11 8b 40 01 00 00                         	vmovups YMMWORD PTR [rbx+0x140],ymm1
  542709:	c5 fc 11 83 20 01 00 00                         	vmovups YMMWORD PTR [rbx+0x120],ymm0
  542711:	48 8b 84 24 80 00 00 00                         	mov    rax,QWORD PTR [rsp+0x80]
  542719:	48 89 83 80 01 00 00                            	mov    QWORD PTR [rbx+0x180],rax
  542720:	c5 f8 28 44 24 70                               	vmovaps xmm0,XMMWORD PTR [rsp+0x70]
  542726:	c5 f8 11 83 70 01 00 00                         	vmovups XMMWORD PTR [rbx+0x170],xmm0
  54272e:	c5 fc 10 44 24 10                               	vmovups ymm0,YMMWORD PTR [rsp+0x10]
  542734:	c5 fc 10 4c 24 30                               	vmovups ymm1,YMMWORD PTR [rsp+0x30]
  54273a:	c5 fc 11 8b 00 01 00 00                         	vmovups YMMWORD PTR [rbx+0x100],ymm1
  542742:	c5 fc 11 83 e0 00 00 00                         	vmovups YMMWORD PTR [rbx+0xe0],ymm0
  54274a:	41 0f b6 86 a0 01 00 00                         	movzx  eax,BYTE PTR [r14+0x1a0]
  542752:	c5 f8 10 84 24 88 00 00 00                      	vmovups xmm0,XMMWORD PTR [rsp+0x88]
  54275b:	c5 f8 11 43 10                                  	vmovups XMMWORD PTR [rbx+0x10],xmm0
  542760:	48 8b 8c 24 98 00 00 00                         	mov    rcx,QWORD PTR [rsp+0x98]
  542768:	48 89 4b 20                                     	mov    QWORD PTR [rbx+0x20],rcx
  54276c:	4c 89 23                                        	mov    QWORD PTR [rbx],r12
  54276f:	48 8b 4c 24 08                                  	mov    rcx,QWORD PTR [rsp+0x8]
  542774:	48 89 4b 08                                     	mov    QWORD PTR [rbx+0x8],rcx
  542778:	48 c7 43 28 ff ff ff ff                         	mov    QWORD PTR [rbx+0x28],0xffffffffffffffff
  542780:	48 89 ab 88 01 00 00                            	mov    QWORD PTR [rbx+0x188],rbp
  542787:	4c 89 ab 90 01 00 00                            	mov    QWORD PTR [rbx+0x190],r13
  54278e:	4c 89 bb 98 01 00 00                            	mov    QWORD PTR [rbx+0x198],r15
  542795:	88 83 a0 01 00 00                               	mov    BYTE PTR [rbx+0x1a0],al
  54279b:	c6 83 a1 01 00 00 00                            	mov    BYTE PTR [rbx+0x1a1],0x0
  5427a2:	41 8b 86 a2 01 00 00                            	mov    eax,DWORD PTR [r14+0x1a2]
  5427a9:	89 83 a2 01 00 00                               	mov    DWORD PTR [rbx+0x1a2],eax
  5427af:	48 89 d8                                        	mov    rax,rbx
  5427b2:	48 81 c4 f8 00 00 00                            	add    rsp,0xf8
  5427b9:	5b                                              	pop    rbx
  5427ba:	41 5c                                           	pop    r12
  5427bc:	41 5d                                           	pop    r13
  5427be:	41 5e                                           	pop    r14
  5427c0:	41 5f                                           	pop    r15
  5427c2:	5d                                              	pop    rbp
  5427c3:	c5 f8 77                                        	vzeroupper
  5427c6:	c3                                              	ret
  5427c7:	0f 0b                                           	ud2
  5427c9:	cc                                              	int3
  5427ca:	cc                                              	int3
  5427cb:	cc                                              	int3
  5427cc:	cc                                              	int3
  5427cd:	cc                                              	int3
  5427ce:	cc                                              	int3
  5427cf:	cc                                              	int3
