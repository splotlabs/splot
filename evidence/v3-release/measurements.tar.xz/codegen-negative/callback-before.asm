
<WORKTREES>/qualification-1882/v3-release/linked-final/release-final/splot:     file format elf64-x86-64


Disassembly of section .text:

0000000000694f3f <splot_decode::output::raw::write_raw_stream_from_plan::<splot_core::simd::Avx2Backend>::{closure#1}+0x47f>:
  694f3f:	e8 8c 51 e9 ff       	call   52a0d0 <splot_decode::output::film_grain::apply::<u8, splot_core::simd::Avx2Backend>>
