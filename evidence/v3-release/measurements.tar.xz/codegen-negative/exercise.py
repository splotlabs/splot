"""Review linked decoder routes and test them with one post-link mutation."""

from bisect import bisect_right
from collections import defaultdict, deque
import csv
from hashlib import sha256
from pathlib import Path
import re
from runpy import run_path
import shutil
import struct
import subprocess
import sys


HERE = Path(__file__).resolve().parent
LINKED = HERE.parent / 'linked-final'
PRODUCTS = ('splot', 'libsplot_capi.so')
ELF = run_path(str(LINKED / 'inspect.py'))
CHECK = LINKED / 'check-paths.py'
AVX2 = 'splot_core::simd::Avx2Backend'
WIDE = 'splot_core::simd::Avx512Backend'
TARGET = re.compile(r'^(?:0x)?([0-9a-f]+)(?:\s|$)')


def rows(path):
    with path.open() as stream:
        return list(csv.DictReader(stream, delimiter='\t'))


def grain(depth, backend):
    return f'splot_decode::output::film_grain::apply::<{depth}, {backend}>'


def exactly_one(entries):
    [entry] = entries
    return entry


def executable_offset(image, address):
    assert image[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', image, 18) == (62,)
    phoff, phentsize, phnum = struct.unpack_from('<Q14xHH', image, 32)
    for index in range(phnum):
        kind, flags, offset, start, _, size = struct.unpack_from('<IIQQQQ', image, phoff + index * phentsize)
        if kind == 1 and flags & 1 and start <= address <= start + size - 5:
            return offset + address - start
    raise ValueError(f'0x{address:x} has no executable file mapping')


def inject(source, analysis, destination):
    edge = exactly_one(row for row in rows(analysis / 'edges.tsv') if
                       f'write_raw_stream_from_plan::<{AVX2}>' in row['caller'] and
                       row['target'] == grain('u8', AVX2) and row['operation'] == 'call')
    wide_apply = exactly_one(fn for fn in rows(analysis / 'functions.tsv') if fn['name'] == grain('u8', WIDE))
    pc = int(edge['edge_address'], 16)
    original_target = int(edge['target_address'], 16)
    wrong_target = int(wide_apply['address'], 16)
    raw = source.read_bytes()
    offset = executable_offset(raw, pc)
    assert raw[offset] == 0xe8
    assert pc + 5 + struct.unpack_from('<i', raw, offset + 1)[0] == original_target
    edited = bytearray(raw)
    struct.pack_into('<i', edited, offset + 1, wrong_target - (pc + 5))
    destination.write_bytes(edited)
    destination.chmod(0o644)
    print(f'site=0x{pc:x} file_offset=0x{offset:x} old_target=0x{original_target:x} new_target=0x{wrong_target:x}')
    print(f'before={raw[offset:offset + 5].hex(" ")} after={edited[offset:offset + 5].hex(" ")}')
    print(f'source sha256={sha256(raw).hexdigest()}\nmutation sha256={sha256(edited).hexdigest()}')
    for name, binary in (('before', source), ('after', destination)):
        with (HERE / f'callback-{name}.asm').open('w') as stream:
            subprocess.run(['objdump', '-dC', '-Mintel', f'--start-address={pc}', f'--stop-address={pc + 5}', binary],
                           check=True, stdout=stream)


def transfers(binary, symbols):
    labels = {}
    edges = []
    references = []
    unresolved = defaultdict(int)
    resolve_slot = ELF['linked_slots'](binary, symbols)
    caller = None
    with subprocess.Popen(['objdump', '-dC', '-Mintel', '--insn-width=16', binary],
                          text=True, stdout=subprocess.PIPE) as disassembler:
        for line in disassembler.stdout:
            if label := ELF['LABEL'].match(line):
                caller = int(label[1], 16)
                labels[caller] = label[2]
                continue
            if caller is None or not (instruction := ELF['INSTR'].match(line)):
                continue
            pc, _, op, args = instruction.groups()
            pc = int(pc, 16)
            branch = op == 'call' or op.startswith('j')
            if branch and (direct := TARGET.match(args)):
                edges.append((caller, pc, op, int(direct[1], 16)))
            elif op in ('call', 'jmp') and (slot := ELF['RIP_SLOT'].search(args)):
                pointer, name = resolve_slot(int(slot[1], 16))
                if pointer and name:
                    edges.append((caller, pc, f'{op}-linked-slot', pointer))
                else:
                    unresolved[caller] += 1
            elif op in ('call', 'jmp'):
                unresolved[caller] += 1
            elif 'vectorize_avx512' in args and (address := re.search(r'# ([0-9a-f]+) <', args)):
                references.append((caller, pc, op, int(address[1], 16)))
        assert disassembler.wait() == 0

    starts = sorted(labels)
    next_edges = defaultdict(list)
    for caller, at, op, destination in edges:
        position = bisect_right(starts, destination) - 1
        if position >= 0 and starts[position] != caller:
            next_edges[caller].append((at, op, destination, starts[position]))
    return labels, next_edges, unresolved, references


def output_root(name):
    if 'splot_decode::context::' in name and 'StaticSimdScope' in name and name.endswith('::run_avx2'):
        return True
    return AVX2 in name and any(part in name for part in (
        'decoder::run_driver_session::<', 'decoder::display::<', 'film_grain::apply::<',
        'write_raw_stream_from_plan::<', 'discard_raw_stream_from_plan::<', 'write_y4m_stream_to_writer::<',
    ))


def check_links(binary, analysis):
    labels, outgoing, unresolved, references = transfers(binary, analysis / 'symbols.txt')
    print(f'{binary.name} symbols={len(labels)} resolved inter-function edges={sum(map(len, outgoing.values()))}')
    evex = [fn for fn in rows(analysis / 'functions.tsv') if int(fn['evex'])]
    leaf_by_address = {int(fn['address'], 16): fn for fn in evex}
    roots = sorted(address for address, name in labels.items() if output_root(name))
    assert roots and len(leaf_by_address) == 2
    for root in roots:
        print(f'AVX2 root 0x{root:x} {labels[root]}')
    verified = True
    for address, fn in leaf_by_address.items():
        assert 'film_grain' in fn['name'] and 'vectorize_avx512' in fn['name']
        depth = exactly_one(depth for depth in ('u8', 'u16') if f'Backend, {depth}>' in fn['name'])
        inbound = [(caller, at, op, dest) for caller, edges in outgoing.items() for at, op, dest, target in edges
                   if target == address]
        assert inbound, fn
        for caller, at, op, dest in inbound:
            correct = op == 'call' and dest == address and labels[caller] == grain(depth, WIDE)
            verified &= correct
            print(f'{"PASS" if correct else "FAIL"} inbound {depth} 0x{at:x} {op} 0x{dest:x} {labels[caller]}')
        for caller, at, op, dest in references:
            if address <= dest <= int(fn['last_instruction'], 16):
                verified = False
                print(f'FAIL address-taken {depth} 0x{at:x} {op} 0x{dest:x} {labels[caller]}')

    pending = deque(roots)
    seen = dict.fromkeys(roots)
    while pending:
        caller = pending.popleft()
        for at, op, dest, target in outgoing[caller]:
            if target not in seen:
                seen[target] = (caller, at, op, dest)
                pending.append(target)
    for leaf, fn in leaf_by_address.items():
        if leaf not in seen:
            print(f'PASS no resolved AVX2 path to 0x{leaf:x} ({fn["evex"]} EVEX instructions)')
            continue
        verified = False
        current = leaf
        path = []
        while (step := seen[current]) is not None:
            caller, at, op, dest = step
            path.append(f'0x{at:x} {op} 0x{dest:x}: {labels[caller]} → {labels[current]}')
            current = caller
        print(f'FAIL resolved AVX2 path to 0x{leaf:x}\n' + '\n'.join(reversed(path)))
    print(f'Static closure: {len(seen)} visited symbols, {sum(unresolved[addr] for addr in seen)} unresolved indirect sites')
    return verified


def stock(directory, logfile):
    with logfile.open('w') as log:
        result = subprocess.run([sys.executable, '-B', CHECK, directory], stdout=log, stderr=subprocess.STDOUT)
        log.write(f'\nexit_status={result.returncode}\n')
    return result.returncode


def main():
    source = LINKED / 'release-final'
    analysis = LINKED / 'final-analysis'
    injected = HERE / 'injected-splot.elf'
    injected_analysis = HERE / 'injected-analysis'
    cli = injected_analysis / 'splot'
    cli.mkdir(parents=True, exist_ok=True)
    capi = injected_analysis / 'libsplot_capi.so'
    if not capi.exists():
        capi.symlink_to(analysis / 'libsplot_capi.so', target_is_directory=True)
    shutil.copyfile(analysis / 'splot/symbols.txt', cli / 'symbols.txt')
    inject(source / 'splot', analysis / 'splot', injected)
    ELF['scan'](injected, cli)
    clean = stock(analysis, HERE / 'control-stock.log')
    malformed = stock(injected_analysis, HERE / 'injected-stock.log')
    assert clean == 0 and malformed != 0, (clean, malformed)
    print(f'Stock checker exit status: control={clean}, injected={malformed}')
    for name in PRODUCTS:
        print(f'\nControl {name}')
        assert check_links(source / name, analysis / name)
    print('\nInjected CLI')
    assert not check_links(injected, cli)


if __name__ == '__main__':
    main()
