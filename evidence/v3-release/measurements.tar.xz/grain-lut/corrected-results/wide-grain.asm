0000000000663470 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>>:
  663470:	55                   	push   %rbp
  663471:	41 57                	push   %r15
  663473:	41 56                	push   %r14
  663475:	41 55                	push   %r13
  663477:	41 54                	push   %r12
  663479:	53                   	push   %rbx
  66347a:	48 83 ec 38          	sub    $0x38,%rsp
  66347e:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  663483:	4c 8b 46 08          	mov    0x8(%rsi),%r8
  663487:	48 8b 5e 10          	mov    0x10(%rsi),%rbx
  66348b:	4c 8b 4e 18          	mov    0x18(%rsi),%r9
  66348f:	48 8b 56 20          	mov    0x20(%rsi),%rdx
  663493:	4c 8b 56 28          	mov    0x28(%rsi),%r10
  663497:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
  66349b:	4c 8b 7e 38          	mov    0x38(%rsi),%r15
  66349f:	41 8b 07             	mov    (%r15),%eax
  6634a2:	41 8b 4f 04          	mov    0x4(%r15),%ecx
  6634a6:	41 0f b6 77 08       	movzbl 0x8(%r15),%esi
  6634ab:	81 f9 ff 00 00 00    	cmp    $0xff,%ecx
  6634b1:	0f 8e 07 01 00 00    	jle    6635be <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x14e>
  6634b7:	45 31 db             	xor    %r11d,%r11d
  6634ba:	48 39 d3             	cmp    %rdx,%rbx
  6634bd:	48 0f 42 d3          	cmovb  %rbx,%rdx
  6634c1:	48 39 fa             	cmp    %rdi,%rdx
  6634c4:	48 0f 43 d7          	cmovae %rdi,%rdx
  6634c8:	39 c8                	cmp    %ecx,%eax
  6634ca:	0f 8f fd 03 00 00    	jg     6638cd <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x45d>
  6634d0:	40 84 f6             	test   %sil,%sil
  6634d3:	0f 84 cb 01 00 00    	je     6636a4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x234>
  6634d9:	8d 7e ff             	lea    -0x1(%rsi),%edi
  6634dc:	bb 01 00 00 00       	mov    $0x1,%ebx
  6634e1:	c4 e2 41 f7 eb       	shlx   %edi,%ebx,%ebp
  6634e6:	40 80 e6 1f          	and    $0x1f,%sil
  6634ea:	49 89 d6             	mov    %rdx,%r14
  6634ed:	49 f7 de             	neg    %r14
  6634f0:	45 31 ff             	xor    %r15d,%r15d
  6634f3:	4d 85 db             	test   %r11,%r11
  6634f6:	0f 84 b4 00 00 00    	je     6635b0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x140>
  6634fc:	eb 57                	jmp    663555 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0xe5>
  6634fe:	66 90                	xchg   %ax,%ax
  663500:	4d 8d 5f 01          	lea    0x1(%r15),%r11
  663504:	43 0f bf 3c 79       	movswl (%r9,%r15,2),%edi
  663509:	47 0f bf 24 7a       	movswl (%r10,%r15,2),%r12d
  66350e:	44 0f af e7          	imul   %edi,%r12d
  663512:	41 01 ec             	add    %ebp,%r12d
  663515:	c4 c2 4a f7 fc       	sarx   %esi,%r12d,%edi
  66351a:	47 0f b6 2c 38       	movzbl (%r8,%r15,1),%r13d
  66351f:	41 01 fd             	add    %edi,%r13d
  663522:	41 39 cd             	cmp    %ecx,%r13d
  663525:	41 89 cc             	mov    %ecx,%r12d
  663528:	45 0f 4c e5          	cmovl  %r13d,%r12d
  66352c:	41 39 c5             	cmp    %eax,%r13d
  66352f:	44 0f 4c e0          	cmovl  %eax,%r12d
  663533:	41 0f b7 fc          	movzwl %r12w,%edi
  663537:	81 ff ff 00 00 00    	cmp    $0xff,%edi
  66353d:	0f 87 20 02 00 00    	ja     663763 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2f3>
  663543:	47 88 24 38          	mov    %r12b,(%r8,%r15,1)
  663547:	4d 89 df             	mov    %r11,%r15
  66354a:	45 31 db             	xor    %r11d,%r11d
  66354d:	44 89 e3             	mov    %r12d,%ebx
  663550:	4d 85 db             	test   %r11,%r11
  663553:	74 5b                	je     6635b0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x140>
  663555:	49 89 d5             	mov    %rdx,%r13
  663558:	4d 29 fd             	sub    %r15,%r13
  66355b:	4d 39 eb             	cmp    %r13,%r11
  66355e:	4d 0f 42 eb          	cmovb  %r11,%r13
  663562:	4f 8d 24 2f          	lea    (%r15,%r13,1),%r12
  663566:	4d 39 e7             	cmp    %r12,%r15
  663569:	4d 0f 47 e7          	cmova  %r15,%r12
  66356d:	49 39 d4             	cmp    %rdx,%r12
  663570:	0f 83 e3 01 00 00    	jae    663759 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  663576:	4d 29 dd             	sub    %r11,%r13
  663579:	4f 8d 3c 26          	lea    (%r14,%r12,1),%r15
  66357d:	45 31 db             	xor    %r11d,%r11d
  663580:	4d 39 dd             	cmp    %r11,%r13
  663583:	74 0d                	je     663592 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x122>
  663585:	49 ff cb             	dec    %r11
  663588:	4d 39 df             	cmp    %r11,%r15
  66358b:	75 f3                	jne    663580 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x110>
  66358d:	e9 c7 01 00 00       	jmp    663759 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  663592:	4d 29 dc             	sub    %r11,%r12
  663595:	4d 8d 5c 24 01       	lea    0x1(%r12),%r11
  66359a:	4d 89 e7             	mov    %r12,%r15
  66359d:	e9 62 ff ff ff       	jmp    663504 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x94>
  6635a2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6635a9:	1f 84 00 00 00 00 00 
  6635b0:	4c 39 fa             	cmp    %r15,%rdx
  6635b3:	0f 87 47 ff ff ff    	ja     663500 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x90>
  6635b9:	e9 9b 01 00 00       	jmp    663759 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  6635be:	44 0f b6 de          	movzbl %sil,%r11d
  6635c2:	48 83 fb 20          	cmp    $0x20,%rbx
  6635c6:	41 0f 92 c6          	setb   %r14b
  6635ca:	48 83 fa 20          	cmp    $0x20,%rdx
  6635ce:	41 0f 92 c4          	setb   %r12b
  6635d2:	48 83 ff 20          	cmp    $0x20,%rdi
  6635d6:	40 0f 92 c5          	setb   %bpl
  6635da:	44 08 f5             	or     %r14b,%bpl
  6635dd:	44 08 e5             	or     %r12b,%bpl
  6635e0:	41 f6 47 09 01       	testb  $0x1,0x9(%r15)
  6635e5:	0f 84 b3 01 00 00    	je     66379e <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x32e>
  6635eb:	40 84 ed             	test   %bpl,%bpl
  6635ee:	0f 85 c3 fe ff ff    	jne    6634b7 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x47>
  6635f4:	41 ff cb             	dec    %r11d
  6635f7:	c4 c1 79 6e c3       	vmovd  %r11d,%xmm0
  6635fc:	62 f2 7d 48 7b c8    	vpbroadcastw %eax,%zmm1
  663602:	62 f2 7d 48 7b d1    	vpbroadcastw %ecx,%zmm2
  663608:	4c 8d 7b e0          	lea    -0x20(%rbx),%r15
  66360c:	4c 8d 62 e0          	lea    -0x20(%rdx),%r12
  663610:	4c 8d 6f e0          	lea    -0x20(%rdi),%r13
  663614:	45 31 db             	xor    %r11d,%r11d
  663617:	62 f3 65 48 25 db ff 	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
  66361e:	66 90                	xchg   %ax,%ax
  663620:	62 92 7d 48 30 24 18 	vpmovzxbw (%r8,%r11,1),%zmm4
  663627:	62 91 fe 48 6f 2c 5a 	vmovdqu64 (%r10,%r11,2),%zmm5
  66362e:	62 91 55 48 d5 2c 59 	vpmullw (%r9,%r11,2),%zmm5,%zmm5
  663635:	62 f1 55 48 e1 e8    	vpsraw %xmm0,%zmm5,%zmm5
  66363b:	62 f1 55 48 f9 eb    	vpsubw %zmm3,%zmm5,%zmm5
  663641:	62 f1 55 48 71 e5 01 	vpsraw $0x1,%zmm5,%zmm5
  663648:	62 f1 55 48 fd e4    	vpaddw %zmm4,%zmm5,%zmm4
  66364e:	62 f1 5d 48 ee e1    	vpmaxsw %zmm1,%zmm4,%zmm4
  663654:	62 f1 5d 48 ea e2    	vpminsw %zmm2,%zmm4,%zmm4
  66365a:	62 92 7e 48 30 24 18 	vpmovwb %zmm4,(%r8,%r11,1)
  663661:	49 83 c3 20          	add    $0x20,%r11
  663665:	49 83 ef 20          	sub    $0x20,%r15
  663669:	41 0f 92 c6          	setb   %r14b
  66366d:	49 83 ec 20          	sub    $0x20,%r12
  663671:	40 0f 92 c5          	setb   %bpl
  663675:	49 83 ed 20          	sub    $0x20,%r13
  663679:	0f 82 3b fe ff ff    	jb     6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  66367f:	4c 39 db             	cmp    %r11,%rbx
  663682:	0f 82 32 fe ff ff    	jb     6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  663688:	45 84 f6             	test   %r14b,%r14b
  66368b:	0f 85 29 fe ff ff    	jne    6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  663691:	4c 39 da             	cmp    %r11,%rdx
  663694:	0f 82 20 fe ff ff    	jb     6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  66369a:	40 84 ed             	test   %bpl,%bpl
  66369d:	74 81                	je     663620 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x1b0>
  66369f:	e9 16 fe ff ff       	jmp    6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6636a4:	48 89 d6             	mov    %rdx,%rsi
  6636a7:	48 f7 de             	neg    %rsi
  6636aa:	45 31 f6             	xor    %r14d,%r14d
  6636ad:	4d 85 db             	test   %r11,%r11
  6636b0:	0f 84 9a 00 00 00    	je     663750 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e0>
  6636b6:	eb 4d                	jmp    663705 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x295>
  6636b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6636bf:	00 
  6636c0:	4d 8d 5e 01          	lea    0x1(%r14),%r11
  6636c4:	43 0f bf 3c 71       	movswl (%r9,%r14,2),%edi
  6636c9:	43 0f bf 2c 72       	movswl (%r10,%r14,2),%ebp
  6636ce:	0f af ef             	imul   %edi,%ebp
  6636d1:	43 0f b6 3c 30       	movzbl (%r8,%r14,1),%edi
  6636d6:	01 ef                	add    %ebp,%edi
  6636d8:	39 cf                	cmp    %ecx,%edi
  6636da:	41 89 cc             	mov    %ecx,%r12d
  6636dd:	44 0f 4c e7          	cmovl  %edi,%r12d
  6636e1:	39 c7                	cmp    %eax,%edi
  6636e3:	44 0f 4c e0          	cmovl  %eax,%r12d
  6636e7:	41 0f b7 fc          	movzwl %r12w,%edi
  6636eb:	81 ff ff 00 00 00    	cmp    $0xff,%edi
  6636f1:	77 70                	ja     663763 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2f3>
  6636f3:	47 88 24 30          	mov    %r12b,(%r8,%r14,1)
  6636f7:	4d 89 de             	mov    %r11,%r14
  6636fa:	45 31 db             	xor    %r11d,%r11d
  6636fd:	44 89 e3             	mov    %r12d,%ebx
  663700:	4d 85 db             	test   %r11,%r11
  663703:	74 4b                	je     663750 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e0>
  663705:	49 89 d4             	mov    %rdx,%r12
  663708:	4d 29 f4             	sub    %r14,%r12
  66370b:	4d 39 e3             	cmp    %r12,%r11
  66370e:	4d 0f 42 e3          	cmovb  %r11,%r12
  663712:	4f 8d 3c 34          	lea    (%r12,%r14,1),%r15
  663716:	4d 39 fe             	cmp    %r15,%r14
  663719:	4d 0f 47 fe          	cmova  %r14,%r15
  66371d:	49 39 d7             	cmp    %rdx,%r15
  663720:	73 37                	jae    663759 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  663722:	4d 29 dc             	sub    %r11,%r12
  663725:	4e 8d 34 3e          	lea    (%rsi,%r15,1),%r14
  663729:	45 31 db             	xor    %r11d,%r11d
  66372c:	4d 39 dc             	cmp    %r11,%r12
  66372f:	74 0a                	je     66373b <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2cb>
  663731:	49 ff cb             	dec    %r11
  663734:	4d 39 de             	cmp    %r11,%r14
  663737:	75 f3                	jne    66372c <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2bc>
  663739:	eb 1e                	jmp    663759 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  66373b:	4d 29 df             	sub    %r11,%r15
  66373e:	4d 8d 5f 01          	lea    0x1(%r15),%r11
  663742:	4d 89 fe             	mov    %r15,%r14
  663745:	e9 7a ff ff ff       	jmp    6636c4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x254>
  66374a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  663750:	4c 39 f2             	cmp    %r14,%rdx
  663753:	0f 87 67 ff ff ff    	ja     6636c0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x250>
  663759:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66375e:	c6 00 ff             	movb   $0xff,(%rax)
  663761:	eb 29                	jmp    66378c <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x31c>
  663763:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  663768:	c6 01 10             	movb   $0x10,(%rcx)
  66376b:	88 59 01             	mov    %bl,0x1(%rcx)
  66376e:	66 44 89 61 02       	mov    %r12w,0x2(%rcx)
  663773:	66 c7 41 04 ff 00    	movw   $0xff,0x4(%rcx)
  663779:	48 8d 05 70 87 9e ff 	lea    -0x617890(%rip),%rax        # 4bef0 <splot_decode::bitstream::tile_payload::coeff_state::ZERO_QUANT_SIGN+0xa38>
  663780:	48 89 41 08          	mov    %rax,0x8(%rcx)
  663784:	48 c7 41 10 02 00 00 	movq   $0x2,0x10(%rcx)
  66378b:	00 
  66378c:	48 83 c4 38          	add    $0x38,%rsp
  663790:	5b                   	pop    %rbx
  663791:	41 5c                	pop    %r12
  663793:	41 5d                	pop    %r13
  663795:	41 5e                	pop    %r14
  663797:	41 5f                	pop    %r15
  663799:	5d                   	pop    %rbp
  66379a:	c5 f8 77             	vzeroupper
  66379d:	c3                   	ret
  66379e:	40 84 ed             	test   %bpl,%bpl
  6637a1:	0f 85 10 fd ff ff    	jne    6634b7 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x47>
  6637a7:	bd 01 00 00 00       	mov    $0x1,%ebp
  6637ac:	c4 e2 21 f7 ed       	shlx   %r11d,%ebp,%ebp
  6637b1:	d1 fd                	sar    $1,%ebp
  6637b3:	62 f2 7d 48 7c c5    	vpbroadcastd %ebp,%zmm0
  6637b9:	c5 f9 6e d0          	vmovd  %eax,%xmm2
  6637bd:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
  6637c1:	c4 c1 79 6e cb       	vmovd  %r11d,%xmm1
  6637c6:	62 f2 7d 48 58 d2    	vpbroadcastd %xmm2,%zmm2
  6637cc:	62 f2 7d 48 58 db    	vpbroadcastd %xmm3,%zmm3
  6637d2:	4c 8d 7b e0          	lea    -0x20(%rbx),%r15
  6637d6:	4c 8d 62 e0          	lea    -0x20(%rdx),%r12
  6637da:	4c 8d 6f e0          	lea    -0x20(%rdi),%r13
  6637de:	45 31 db             	xor    %r11d,%r11d
  6637e1:	62 f1 fd 48 6f 25 55 	vmovdqa64 -0x61c6ab(%rip),%zmm4        # 47140 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0xfc>
  6637e8:	39 9e ff 
  6637eb:	62 f1 fd 48 6f 2d 8b 	vmovdqa64 -0x61c675(%rip),%zmm5        # 47180 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0x13c>
  6637f2:	39 9e ff 
  6637f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6637fc:	00 00 00 00 
  663800:	62 92 7d 48 31 34 18 	vpmovzxbd (%r8,%r11,1),%zmm6
  663807:	62 92 7d 48 31 7c 18 	vpmovzxbd 0x10(%r8,%r11,1),%zmm7
  66380e:	01 
  66380f:	62 11 fe 48 6f 04 59 	vmovdqu64 (%r9,%r11,2),%zmm8
  663816:	62 11 fe 48 6f 0c 5a 	vmovdqu64 (%r10,%r11,2),%zmm9
  66381d:	62 51 35 48 d5 d0    	vpmullw %zmm8,%zmm9,%zmm10
  663823:	62 51 35 48 e5 c0    	vpmulhw %zmm8,%zmm9,%zmm8
  663829:	62 51 fd 48 6f ca    	vmovdqa64 %zmm10,%zmm9
  66382f:	62 52 dd 48 7d c8    	vpermt2w %zmm8,%zmm4,%zmm9
  663835:	62 51 7d 48 fe c9    	vpaddd %zmm9,%zmm0,%zmm9
  66383b:	62 71 35 48 e2 c9    	vpsrad %xmm1,%zmm9,%zmm9
  663841:	62 52 d5 48 7d d0    	vpermt2w %zmm8,%zmm5,%zmm10
  663847:	62 51 7d 48 fe c2    	vpaddd %zmm10,%zmm0,%zmm8
  66384d:	62 71 3d 48 e2 c1    	vpsrad %xmm1,%zmm8,%zmm8
  663853:	62 f1 35 48 fe f6    	vpaddd %zmm6,%zmm9,%zmm6
  663859:	62 f1 3d 48 fe ff    	vpaddd %zmm7,%zmm8,%zmm7
  66385f:	62 f2 4d 48 3d f2    	vpmaxsd %zmm2,%zmm6,%zmm6
  663865:	62 f2 45 48 3d fa    	vpmaxsd %zmm2,%zmm7,%zmm7
  66386b:	62 f2 45 48 39 fb    	vpminsd %zmm3,%zmm7,%zmm7
  663871:	62 f2 4d 48 39 f3    	vpminsd %zmm3,%zmm6,%zmm6
  663877:	62 92 7e 48 31 34 18 	vpmovdb %zmm6,(%r8,%r11,1)
  66387e:	62 92 7e 48 31 7c 18 	vpmovdb %zmm7,0x10(%r8,%r11,1)
  663885:	01 
  663886:	49 83 c3 20          	add    $0x20,%r11
  66388a:	49 83 ef 20          	sub    $0x20,%r15
  66388e:	41 0f 92 c6          	setb   %r14b
  663892:	49 83 ec 20          	sub    $0x20,%r12
  663896:	40 0f 92 c5          	setb   %bpl
  66389a:	49 83 ed 20          	sub    $0x20,%r13
  66389e:	0f 82 16 fc ff ff    	jb     6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6638a4:	4c 39 db             	cmp    %r11,%rbx
  6638a7:	0f 82 0d fc ff ff    	jb     6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6638ad:	45 84 f6             	test   %r14b,%r14b
  6638b0:	0f 85 04 fc ff ff    	jne    6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6638b6:	4c 39 da             	cmp    %r11,%rdx
  6638b9:	0f 82 fb fb ff ff    	jb     6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6638bf:	40 84 ed             	test   %bpl,%bpl
  6638c2:	0f 84 38 ff ff ff    	je     663800 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x390>
  6638c8:	e9 ed fb ff ff       	jmp    6634ba <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6638cd:	4d 85 db             	test   %r11,%r11
  6638d0:	75 52                	jne    663924 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4b4>
  6638d2:	48 85 d2             	test   %rdx,%rdx
  6638d5:	0f 84 7e fe ff ff    	je     663759 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  6638db:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6638df:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
  6638e3:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  6638e8:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6638ed:	48 8d 05 1c 88 1c 00 	lea    0x1c881c(%rip),%rax        # 82c110 <<i32 as core::fmt::Debug>::fmt>
  6638f4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6638f9:	48 8d 4c 24 0c       	lea    0xc(%rsp),%rcx
  6638fe:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  663903:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  663908:	48 8d 3d 21 6b 9a ff 	lea    -0x6594df(%rip),%rdi        # a430 <anon.42fab95c888da61b1e919ac44bbba854.230.llvm.10426147197465607828>
  66390f:	48 8d 15 62 dd 55 00 	lea    0x55dd62(%rip),%rdx        # bc1678 <anon.d0737aeb7bbf3866d88b3a389feb0b4f.160.llvm.17283402442207905531+0x898>
  663916:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  66391b:	c5 f8 77             	vzeroupper
  66391e:	ff 15 14 0a 57 00    	call   *0x570a14(%rip)        # bd4338 <_DYNAMIC+0x290>
  663924:	49 39 d3             	cmp    %rdx,%r11
  663927:	0f 83 2c fe ff ff    	jae    663759 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  66392d:	eb ac                	jmp    6638db <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x46b>
  66392f:	cc                   	int3

0000000000663930 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>>:
  663930:	55                   	push   %rbp
  663931:	48 89 e5             	mov    %rsp,%rbp
  663934:	41 57                	push   %r15
  663936:	41 56                	push   %r14
  663938:	41 55                	push   %r13
  66393a:	41 54                	push   %r12
  66393c:	53                   	push   %rbx
  66393d:	48 83 e4 c0          	and    $0xffffffffffffffc0,%rsp
  663941:	48 81 ec 40 02 00 00 	sub    $0x240,%rsp
  663948:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
  66394c:	48 8b 47 10          	mov    0x10(%rdi),%rax
  663950:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  663954:	4c 8b 6f 20          	mov    0x20(%rdi),%r13
  663958:	4c 8b 67 28          	mov    0x28(%rdi),%r12
  66395c:	48 8b 57 30          	mov    0x30(%rdi),%rdx
  663960:	8b 3a                	mov    (%rdx),%edi
  663962:	8b 72 04             	mov    0x4(%rdx),%esi
  663965:	44 0f b6 42 08       	movzbl 0x8(%rdx),%r8d
  66396a:	62 f1 fe 48 6f 39    	vmovdqu64 (%rcx),%zmm7
  663970:	62 71 fe 48 6f 49 01 	vmovdqu64 0x40(%rcx),%zmm9
  663977:	62 71 fe 48 6f 41 02 	vmovdqu64 0x80(%rcx),%zmm8
  66397e:	62 71 fe 48 6f 51 03 	vmovdqu64 0xc0(%rcx),%zmm10
  663985:	41 89 c6             	mov    %eax,%r14d
  663988:	41 83 e6 3f          	and    $0x3f,%r14d
  66398c:	4c 89 e2             	mov    %r12,%rdx
  66398f:	48 c1 ea 06          	shr    $0x6,%rdx
  663993:	48 89 c1             	mov    %rax,%rcx
  663996:	48 c1 e9 06          	shr    $0x6,%rcx
  66399a:	48 39 d1             	cmp    %rdx,%rcx
  66399d:	48 0f 43 ca          	cmovae %rdx,%rcx
  6639a1:	48 85 c9             	test   %rcx,%rcx
  6639a4:	0f 84 e3 00 00 00    	je     663a8d <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0x15d>
  6639aa:	41 8d 50 ff          	lea    -0x1(%r8),%edx
  6639ae:	c5 f9 6e c2          	vmovd  %edx,%xmm0
  6639b2:	62 f2 7d 48 7b cf    	vpbroadcastw %edi,%zmm1
  6639b8:	62 f2 7d 48 7b d6    	vpbroadcastw %esi,%zmm2
  6639be:	31 d2                	xor    %edx,%edx
  6639c0:	62 f3 65 48 25 db ff 	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
  6639c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6639ce:	00 00 
  6639d0:	62 f1 fe 48 6f 24 13 	vmovdqu64 (%rbx,%rdx,1),%zmm4
  6639d7:	62 f2 7e 48 29 cc    	vpmovb2m %zmm4,%k1
  6639dd:	62 d1 fd 48 6f e8    	vmovdqa64 %zmm8,%zmm5
  6639e3:	62 d2 5d 48 7d ea    	vpermt2b %zmm10,%zmm4,%zmm5
  6639e9:	62 d2 45 48 75 e1    	vpermi2b %zmm9,%zmm7,%zmm4
  6639ef:	62 f1 7f 49 6f e5    	vmovdqu8 %zmm5,%zmm4{%k1}
  6639f5:	62 f2 7d 48 30 ec    	vpmovzxbw %ymm4,%zmm5
  6639fb:	62 f3 fd 48 3b e4 01 	vextracti64x4 $0x1,%zmm4,%ymm4
  663a02:	62 f2 7d 48 30 e4    	vpmovzxbw %ymm4,%zmm4
  663a08:	62 d1 55 48 d5 6c 55 	vpmullw 0x0(%r13,%rdx,2),%zmm5,%zmm5
  663a0f:	00 
  663a10:	62 f1 55 48 e1 e8    	vpsraw %xmm0,%zmm5,%zmm5
  663a16:	62 d1 5d 48 d5 64 55 	vpmullw 0x40(%r13,%rdx,2),%zmm4,%zmm4
  663a1d:	01 
  663a1e:	62 f1 5d 48 e1 e0    	vpsraw %xmm0,%zmm4,%zmm4
  663a24:	62 f1 5d 48 f9 e3    	vpsubw %zmm3,%zmm4,%zmm4
  663a2a:	62 f1 55 48 f9 eb    	vpsubw %zmm3,%zmm5,%zmm5
  663a30:	62 f2 7d 48 30 34 13 	vpmovzxbw (%rbx,%rdx,1),%zmm6
  663a37:	62 f1 55 48 71 e5 01 	vpsraw $0x1,%zmm5,%zmm5
  663a3e:	62 f1 55 48 fd ee    	vpaddw %zmm6,%zmm5,%zmm5
  663a44:	62 f2 7d 48 30 74 13 	vpmovzxbw 0x20(%rbx,%rdx,1),%zmm6
  663a4b:	01 
  663a4c:	62 f1 5d 48 71 e4 01 	vpsraw $0x1,%zmm4,%zmm4
  663a53:	62 f1 5d 48 fd e6    	vpaddw %zmm6,%zmm4,%zmm4
  663a59:	62 f1 55 48 ee e9    	vpmaxsw %zmm1,%zmm5,%zmm5
  663a5f:	62 f1 5d 48 ee e1    	vpmaxsw %zmm1,%zmm4,%zmm4
  663a65:	62 f1 5d 48 ea e2    	vpminsw %zmm2,%zmm4,%zmm4
  663a6b:	62 f1 55 48 ea ea    	vpminsw %zmm2,%zmm5,%zmm5
  663a71:	62 f2 7e 48 30 2c 13 	vpmovwb %zmm5,(%rbx,%rdx,1)
  663a78:	62 f2 7e 48 30 64 13 	vpmovwb %zmm4,0x20(%rbx,%rdx,1)
  663a7f:	01 
  663a80:	48 83 c2 40          	add    $0x40,%rdx
  663a84:	48 ff c9             	dec    %rcx
  663a87:	0f 85 43 ff ff ff    	jne    6639d0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0xa0>
  663a8d:	4d 85 f6             	test   %r14,%r14
  663a90:	0f 84 a3 01 00 00    	je     663c39 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0x309>
  663a96:	62 71 fd 48 7f 54 24 	vmovdqa64 %zmm10,0x100(%rsp)
  663a9d:	04 
  663a9e:	62 71 fd 48 7f 4c 24 	vmovdqa64 %zmm9,0x140(%rsp)
  663aa5:	05 
  663aa6:	62 71 fd 48 7f 44 24 	vmovdqa64 %zmm8,0x180(%rsp)
  663aad:	06 
  663aae:	62 f1 fd 48 7f 7c 24 	vmovdqa64 %zmm7,0x1c0(%rsp)
  663ab5:	07 
  663ab6:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  663abb:	89 7c 24 30          	mov    %edi,0x30(%rsp)
  663abf:	89 74 24 34          	mov    %esi,0x34(%rsp)
  663ac3:	48 b9 c0 ff ff ff ff 	movabs $0x7fffffffffffffc0,%rcx
  663aca:	ff ff 7f 
  663acd:	48 21 c8             	and    %rcx,%rax
  663ad0:	45 89 e7             	mov    %r12d,%r15d
  663ad3:	41 83 e7 3f          	and    $0x3f,%r15d
  663ad7:	48 01 c3             	add    %rax,%rbx
  663ada:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
  663ade:	62 f1 fd 48 7f 44 24 	vmovdqa64 %zmm0,0x40(%rsp)
  663ae5:	01 
  663ae6:	62 f1 fd 48 7f 44 24 	vmovdqa64 %zmm0,0xc0(%rsp)
  663aed:	03 
  663aee:	62 f1 fd 48 7f 44 24 	vmovdqa64 %zmm0,0x80(%rsp)
  663af5:	02 
  663af6:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  663afb:	48 89 de             	mov    %rbx,%rsi
  663afe:	4c 89 f2             	mov    %r14,%rdx
  663b01:	c5 f8 77             	vzeroupper
  663b04:	ff 15 ee 07 57 00    	call   *0x5707ee(%rip)        # bd42f8 <memcpy@GLIBC_2.14>
  663b0a:	4d 39 fe             	cmp    %r15,%r14
  663b0d:	0f 85 38 01 00 00    	jne    663c4b <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0x31b>
  663b13:	48 b8 c0 ff ff ff ff 	movabs $0x3fffffffffffffc0,%rax
  663b1a:	ff ff 3f 
  663b1d:	49 21 c4             	and    %rax,%r12
  663b20:	4a 8d 34 65 00 00 00 	lea    0x0(,%r12,2),%rsi
  663b27:	00 
  663b28:	4c 01 ee             	add    %r13,%rsi
  663b2b:	43 8d 14 36          	lea    (%r14,%r14,1),%edx
  663b2f:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  663b36:	00 
  663b37:	4c 8b 3d ba 07 57 00 	mov    0x5707ba(%rip),%r15        # bd42f8 <memcpy@GLIBC_2.14>
  663b3e:	41 ff d7             	call   *%r15
  663b41:	62 f1 fd 48 6f 44 24 	vmovdqa64 0x40(%rsp),%zmm0
  663b48:	01 
  663b49:	62 f2 7e 48 29 c8    	vpmovb2m %zmm0,%k1
  663b4f:	62 f1 fd 48 6f 54 24 	vmovdqa64 0x180(%rsp),%zmm2
  663b56:	06 
  663b57:	62 f2 7d 48 7d 54 24 	vpermt2b 0x100(%rsp),%zmm0,%zmm2
  663b5e:	04 
  663b5f:	62 f1 fd 48 6f 4c 24 	vmovdqa64 0x1c0(%rsp),%zmm1
  663b66:	07 
  663b67:	62 f2 7d 48 7d 4c 24 	vpermt2b 0x140(%rsp),%zmm0,%zmm1
  663b6e:	05 
  663b6f:	62 f1 7f 49 6f ca    	vmovdqu8 %zmm2,%zmm1{%k1}
  663b75:	62 f2 7d 48 30 c1    	vpmovzxbw %ymm1,%zmm0
  663b7b:	62 f3 fd 48 3b c9 01 	vextracti64x4 $0x1,%zmm1,%ymm1
  663b82:	62 f2 7d 48 30 c9    	vpmovzxbw %ymm1,%zmm1
  663b88:	62 f1 7d 48 d5 44 24 	vpmullw 0x80(%rsp),%zmm0,%zmm0
  663b8f:	02 
  663b90:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  663b95:	ff c8                	dec    %eax
  663b97:	c5 f9 6e d0          	vmovd  %eax,%xmm2
  663b9b:	62 f1 7d 48 e1 c2    	vpsraw %xmm2,%zmm0,%zmm0
  663ba1:	62 f1 75 48 d5 4c 24 	vpmullw 0xc0(%rsp),%zmm1,%zmm1
  663ba8:	03 
  663ba9:	62 f1 75 48 e1 ca    	vpsraw %xmm2,%zmm1,%zmm1
  663baf:	62 f3 6d 48 25 d2 ff 	vpternlogd $0xff,%zmm2,%zmm2,%zmm2
  663bb6:	62 f1 75 48 f9 ca    	vpsubw %zmm2,%zmm1,%zmm1
  663bbc:	62 f1 7d 48 f9 c2    	vpsubw %zmm2,%zmm0,%zmm0
  663bc2:	62 f1 7d 48 71 e0 01 	vpsraw $0x1,%zmm0,%zmm0
  663bc9:	62 f1 75 48 71 e1 01 	vpsraw $0x1,%zmm1,%zmm1
  663bd0:	62 f2 7d 48 30 54 24 	vpmovzxbw 0x40(%rsp),%zmm2
  663bd7:	02 
  663bd8:	62 f2 7d 48 30 5c 24 	vpmovzxbw 0x60(%rsp),%zmm3
  663bdf:	03 
  663be0:	62 f1 7d 48 fd c2    	vpaddw %zmm2,%zmm0,%zmm0
  663be6:	62 f1 75 48 fd cb    	vpaddw %zmm3,%zmm1,%zmm1
  663bec:	8b 44 24 30          	mov    0x30(%rsp),%eax
  663bf0:	62 f2 7d 48 7b d0    	vpbroadcastw %eax,%zmm2
  663bf6:	62 f1 7d 48 ee c2    	vpmaxsw %zmm2,%zmm0,%zmm0
  663bfc:	62 f1 75 48 ee ca    	vpmaxsw %zmm2,%zmm1,%zmm1
  663c02:	8b 44 24 34          	mov    0x34(%rsp),%eax
  663c06:	62 f2 7d 48 7b d0    	vpbroadcastw %eax,%zmm2
  663c0c:	62 f1 75 48 ea ca    	vpminsw %zmm2,%zmm1,%zmm1
  663c12:	62 f1 7d 48 ea c2    	vpminsw %zmm2,%zmm0,%zmm0
  663c18:	62 f2 7e 48 30 44 24 	vpmovwb %zmm0,0x40(%rsp)
  663c1f:	02 
  663c20:	62 f2 7e 48 30 4c 24 	vpmovwb %zmm1,0x60(%rsp)
  663c27:	03 
  663c28:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  663c2d:	48 89 df             	mov    %rbx,%rdi
  663c30:	4c 89 f2             	mov    %r14,%rdx
  663c33:	c5 f8 77             	vzeroupper
  663c36:	41 ff d7             	call   *%r15
  663c39:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
  663c3d:	5b                   	pop    %rbx
  663c3e:	41 5c                	pop    %r12
  663c40:	41 5d                	pop    %r13
  663c42:	41 5e                	pop    %r14
  663c44:	41 5f                	pop    %r15
  663c46:	5d                   	pop    %rbp
  663c47:	c5 f8 77             	vzeroupper
  663c4a:	c3                   	ret
  663c4b:	48 8d 15 16 e5 55 00 	lea    0x55e516(%rip),%rdx        # bc2168 <anon.d0737aeb7bbf3866d88b3a389feb0b4f.160.llvm.17283402442207905531+0x1388>
  663c52:	4c 89 f7             	mov    %r14,%rdi
  663c55:	4c 89 fe             	mov    %r15,%rsi
  663c58:	ff 15 e2 0b 57 00    	call   *0x570be2(%rip)        # bd4840 <_DYNAMIC+0x798>
  663c5e:	cc                   	int3
  663c5f:	cc                   	int3

0000000000663c60 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>>:
  663c60:	55                   	push   %rbp
  663c61:	41 57                	push   %r15
  663c63:	41 56                	push   %r14
  663c65:	41 55                	push   %r13
  663c67:	41 54                	push   %r12
  663c69:	53                   	push   %rbx
  663c6a:	48 83 ec 48          	sub    $0x48,%rsp
  663c6e:	4c 8b 46 08          	mov    0x8(%rsi),%r8
  663c72:	48 8b 5e 10          	mov    0x10(%rsi),%rbx
  663c76:	4c 8b 4e 18          	mov    0x18(%rsi),%r9
  663c7a:	48 8b 56 20          	mov    0x20(%rsi),%rdx
  663c7e:	4c 8b 56 28          	mov    0x28(%rsi),%r10
  663c82:	4c 8b 6e 30          	mov    0x30(%rsi),%r13
  663c86:	4c 8b 76 38          	mov    0x38(%rsi),%r14
  663c8a:	41 8b 06             	mov    (%r14),%eax
  663c8d:	41 8b 4e 04          	mov    0x4(%r14),%ecx
  663c91:	41 0f b6 76 08       	movzbl 0x8(%r14),%esi
  663c96:	81 f9 ff ff 00 00    	cmp    $0xffff,%ecx
  663c9c:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  663ca1:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  663ca6:	7e 08                	jle    663cb0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x50>
  663ca8:	45 31 db             	xor    %r11d,%r11d
  663cab:	e9 29 01 00 00       	jmp    663dd9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x179>
  663cb0:	45 31 ff             	xor    %r15d,%r15d
  663cb3:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
  663cb8:	48 83 fb 20          	cmp    $0x20,%rbx
  663cbc:	0f 92 c3             	setb   %bl
  663cbf:	4d 0f 43 f8          	cmovae %r8,%r15
  663cc3:	44 0f b6 de          	movzbl %sil,%r11d
  663cc7:	48 83 fa 20          	cmp    $0x20,%rdx
  663ccb:	40 0f 92 c5          	setb   %bpl
  663ccf:	49 83 fd 20          	cmp    $0x20,%r13
  663cd3:	41 0f 92 c4          	setb   %r12b
  663cd7:	41 08 dc             	or     %bl,%r12b
  663cda:	41 08 ec             	or     %bpl,%r12b
  663cdd:	41 f6 46 09 01       	testb  $0x1,0x9(%r14)
  663ce2:	0f 84 e0 00 00 00    	je     663dc8 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x168>
  663ce8:	45 84 e4             	test   %r12b,%r12b
  663ceb:	0f 85 e0 00 00 00    	jne    663dd1 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x171>
  663cf1:	41 ff cb             	dec    %r11d
  663cf4:	c4 c1 79 6e c3       	vmovd  %r11d,%xmm0
  663cf9:	62 f2 7d 48 7b c8    	vpbroadcastw %eax,%zmm1
  663cff:	62 f2 7d 48 7b d1    	vpbroadcastw %ecx,%zmm2
  663d05:	4c 8d 72 e0          	lea    -0x20(%rdx),%r14
  663d09:	4d 8d 65 e0          	lea    -0x20(%r13),%r12
  663d0d:	4d 8d 68 40          	lea    0x40(%r8),%r13
  663d11:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  663d16:	48 8d 6b e0          	lea    -0x20(%rbx),%rbp
  663d1a:	45 31 db             	xor    %r11d,%r11d
  663d1d:	62 f3 65 48 25 db ff 	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
  663d24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  663d2b:	00 00 00 00 00 
  663d30:	c4 81 7e 6f 24 58    	vmovdqu (%r8,%r11,2),%ymm4
  663d36:	62 91 fe 48 6f 2c 5a 	vmovdqu64 (%r10,%r11,2),%zmm5
  663d3d:	62 d3 dd 48 3a 67 01 	vinserti64x4 $0x1,0x20(%r15),%zmm4,%zmm4
  663d44:	01 
  663d45:	62 91 55 48 d5 2c 59 	vpmullw (%r9,%r11,2),%zmm5,%zmm5
  663d4c:	62 f1 55 48 e1 e8    	vpsraw %xmm0,%zmm5,%zmm5
  663d52:	62 f1 55 48 f9 eb    	vpsubw %zmm3,%zmm5,%zmm5
  663d58:	62 f1 55 48 71 e5 01 	vpsraw $0x1,%zmm5,%zmm5
  663d5f:	62 f1 55 48 fd e4    	vpaddw %zmm4,%zmm5,%zmm4
  663d65:	62 f1 5d 48 ee e1    	vpmaxsw %zmm1,%zmm4,%zmm4
  663d6b:	62 f1 5d 48 ea e2    	vpminsw %zmm2,%zmm4,%zmm4
  663d71:	c4 81 7e 7f 24 58    	vmovdqu %ymm4,(%r8,%r11,2)
  663d77:	62 d3 fd 48 3b 67 01 	vextracti64x4 $0x1,%zmm4,0x20(%r15)
  663d7e:	01 
  663d7f:	49 83 c3 20          	add    $0x20,%r11
  663d83:	4c 39 db             	cmp    %r11,%rbx
  663d86:	0f 92 c3             	setb   %bl
  663d89:	48 83 ed 20          	sub    $0x20,%rbp
  663d8d:	40 0f 92 c7          	setb   %dil
  663d91:	40 08 df             	or     %bl,%dil
  663d94:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  663d9a:	4d 0f 44 fd          	cmove  %r13,%r15
  663d9e:	49 83 ee 20          	sub    $0x20,%r14
  663da2:	0f 92 c3             	setb   %bl
  663da5:	49 83 ec 20          	sub    $0x20,%r12
  663da9:	72 29                	jb     663dd4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  663dab:	40 84 ff             	test   %dil,%dil
  663dae:	75 24                	jne    663dd4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  663db0:	4c 39 da             	cmp    %r11,%rdx
  663db3:	72 1f                	jb     663dd4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  663db5:	49 83 c5 40          	add    $0x40,%r13
  663db9:	84 db                	test   %bl,%bl
  663dbb:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  663dc0:	0f 84 6a ff ff ff    	je     663d30 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0xd0>
  663dc6:	eb 11                	jmp    663dd9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x179>
  663dc8:	45 84 e4             	test   %r12b,%r12b
  663dcb:	0f 84 c2 01 00 00    	je     663f93 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x333>
  663dd1:	45 31 db             	xor    %r11d,%r11d
  663dd4:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  663dd9:	48 39 d3             	cmp    %rdx,%rbx
  663ddc:	48 0f 42 d3          	cmovb  %rbx,%rdx
  663de0:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  663de5:	48 39 fa             	cmp    %rdi,%rdx
  663de8:	48 0f 43 d7          	cmovae %rdi,%rdx
  663dec:	39 c8                	cmp    %ecx,%eax
  663dee:	0f 8f d8 02 00 00    	jg     6640cc <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x46c>
  663df4:	40 84 f6             	test   %sil,%sil
  663df7:	0f 84 d1 00 00 00    	je     663ece <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x26e>
  663dfd:	8d 7e ff             	lea    -0x1(%rsi),%edi
  663e00:	bb 01 00 00 00       	mov    $0x1,%ebx
  663e05:	c4 e2 41 f7 db       	shlx   %edi,%ebx,%ebx
  663e0a:	40 80 e6 1f          	and    $0x1f,%sil
  663e0e:	49 89 d6             	mov    %rdx,%r14
  663e11:	49 f7 de             	neg    %r14
  663e14:	31 ff                	xor    %edi,%edi
  663e16:	4d 85 db             	test   %r11,%r11
  663e19:	0f 84 a1 00 00 00    	je     663ec0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x260>
  663e1f:	eb 50                	jmp    663e71 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x211>
  663e21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  663e28:	0f 1f 84 00 00 00 00 
  663e2f:	00 
  663e30:	4c 8d 5f 01          	lea    0x1(%rdi),%r11
  663e34:	41 0f bf 2c 79       	movswl (%r9,%rdi,2),%ebp
  663e39:	45 0f bf 3c 7a       	movswl (%r10,%rdi,2),%r15d
  663e3e:	44 0f af fd          	imul   %ebp,%r15d
  663e42:	41 01 df             	add    %ebx,%r15d
  663e45:	c4 c2 4a f7 ef       	sarx   %esi,%r15d,%ebp
  663e4a:	45 0f b7 3c 78       	movzwl (%r8,%rdi,2),%r15d
  663e4f:	41 01 ef             	add    %ebp,%r15d
  663e52:	41 39 cf             	cmp    %ecx,%r15d
  663e55:	89 cd                	mov    %ecx,%ebp
  663e57:	41 0f 4c ef          	cmovl  %r15d,%ebp
  663e5b:	41 39 c7             	cmp    %eax,%r15d
  663e5e:	0f 4c e8             	cmovl  %eax,%ebp
  663e61:	66 41 89 2c 78       	mov    %bp,(%r8,%rdi,2)
  663e66:	4c 89 df             	mov    %r11,%rdi
  663e69:	45 31 db             	xor    %r11d,%r11d
  663e6c:	4d 85 db             	test   %r11,%r11
  663e6f:	74 4f                	je     663ec0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x260>
  663e71:	49 89 d4             	mov    %rdx,%r12
  663e74:	49 29 fc             	sub    %rdi,%r12
  663e77:	4d 39 e3             	cmp    %r12,%r11
  663e7a:	4d 0f 42 e3          	cmovb  %r11,%r12
  663e7e:	4d 8d 3c 3c          	lea    (%r12,%rdi,1),%r15
  663e82:	4c 39 ff             	cmp    %r15,%rdi
  663e85:	4c 0f 47 ff          	cmova  %rdi,%r15
  663e89:	49 39 d7             	cmp    %rdx,%r15
  663e8c:	0f 83 e7 00 00 00    	jae    663f79 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663e92:	4d 29 dc             	sub    %r11,%r12
  663e95:	4f 8d 1c 3e          	lea    (%r14,%r15,1),%r11
  663e99:	31 ff                	xor    %edi,%edi
  663e9b:	49 39 fc             	cmp    %rdi,%r12
  663e9e:	74 0d                	je     663ead <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x24d>
  663ea0:	48 ff cf             	dec    %rdi
  663ea3:	49 39 fb             	cmp    %rdi,%r11
  663ea6:	75 f3                	jne    663e9b <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x23b>
  663ea8:	e9 cc 00 00 00       	jmp    663f79 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663ead:	49 29 ff             	sub    %rdi,%r15
  663eb0:	4d 8d 5f 01          	lea    0x1(%r15),%r11
  663eb4:	4c 89 ff             	mov    %r15,%rdi
  663eb7:	e9 78 ff ff ff       	jmp    663e34 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x1d4>
  663ebc:	0f 1f 40 00          	nopl   0x0(%rax)
  663ec0:	48 39 fa             	cmp    %rdi,%rdx
  663ec3:	0f 87 67 ff ff ff    	ja     663e30 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x1d0>
  663ec9:	e9 ab 00 00 00       	jmp    663f79 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663ece:	48 89 d6             	mov    %rdx,%rsi
  663ed1:	48 f7 de             	neg    %rsi
  663ed4:	31 ff                	xor    %edi,%edi
  663ed6:	4d 85 db             	test   %r11,%r11
  663ed9:	0f 84 91 00 00 00    	je     663f70 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x310>
  663edf:	eb 43                	jmp    663f24 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2c4>
  663ee1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  663ee8:	0f 1f 84 00 00 00 00 
  663eef:	00 
  663ef0:	4c 8d 5f 01          	lea    0x1(%rdi),%r11
  663ef4:	41 0f bf 1c 79       	movswl (%r9,%rdi,2),%ebx
  663ef9:	41 0f bf 2c 7a       	movswl (%r10,%rdi,2),%ebp
  663efe:	0f af eb             	imul   %ebx,%ebp
  663f01:	41 0f b7 1c 78       	movzwl (%r8,%rdi,2),%ebx
  663f06:	01 eb                	add    %ebp,%ebx
  663f08:	39 cb                	cmp    %ecx,%ebx
  663f0a:	89 cd                	mov    %ecx,%ebp
  663f0c:	0f 4c eb             	cmovl  %ebx,%ebp
  663f0f:	39 c3                	cmp    %eax,%ebx
  663f11:	0f 4c e8             	cmovl  %eax,%ebp
  663f14:	66 41 89 2c 78       	mov    %bp,(%r8,%rdi,2)
  663f19:	4c 89 df             	mov    %r11,%rdi
  663f1c:	45 31 db             	xor    %r11d,%r11d
  663f1f:	4d 85 db             	test   %r11,%r11
  663f22:	74 4c                	je     663f70 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x310>
  663f24:	49 89 d6             	mov    %rdx,%r14
  663f27:	49 29 fe             	sub    %rdi,%r14
  663f2a:	4d 39 f3             	cmp    %r14,%r11
  663f2d:	4d 0f 42 f3          	cmovb  %r11,%r14
  663f31:	49 8d 1c 3e          	lea    (%r14,%rdi,1),%rbx
  663f35:	48 39 df             	cmp    %rbx,%rdi
  663f38:	48 0f 47 df          	cmova  %rdi,%rbx
  663f3c:	48 39 d3             	cmp    %rdx,%rbx
  663f3f:	73 38                	jae    663f79 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663f41:	4d 29 de             	sub    %r11,%r14
  663f44:	4c 8d 1c 1e          	lea    (%rsi,%rbx,1),%r11
  663f48:	31 ff                	xor    %edi,%edi
  663f4a:	49 39 fe             	cmp    %rdi,%r14
  663f4d:	74 0a                	je     663f59 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2f9>
  663f4f:	48 ff cf             	dec    %rdi
  663f52:	49 39 fb             	cmp    %rdi,%r11
  663f55:	75 f3                	jne    663f4a <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2ea>
  663f57:	eb 20                	jmp    663f79 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663f59:	48 29 fb             	sub    %rdi,%rbx
  663f5c:	4c 8d 5b 01          	lea    0x1(%rbx),%r11
  663f60:	48 89 df             	mov    %rbx,%rdi
  663f63:	eb 8f                	jmp    663ef4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x294>
  663f65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  663f6c:	00 00 00 00 
  663f70:	48 39 fa             	cmp    %rdi,%rdx
  663f73:	0f 87 77 ff ff ff    	ja     663ef0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x290>
  663f79:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  663f7e:	c6 00 ff             	movb   $0xff,(%rax)
  663f81:	48 83 c4 48          	add    $0x48,%rsp
  663f85:	5b                   	pop    %rbx
  663f86:	41 5c                	pop    %r12
  663f88:	41 5d                	pop    %r13
  663f8a:	41 5e                	pop    %r14
  663f8c:	41 5f                	pop    %r15
  663f8e:	5d                   	pop    %rbp
  663f8f:	c5 f8 77             	vzeroupper
  663f92:	c3                   	ret
  663f93:	bf 01 00 00 00       	mov    $0x1,%edi
  663f98:	c4 e2 21 f7 ff       	shlx   %r11d,%edi,%edi
  663f9d:	d1 ff                	sar    $1,%edi
  663f9f:	62 f2 7d 48 7c c7    	vpbroadcastd %edi,%zmm0
  663fa5:	62 f2 7d 48 7c c8    	vpbroadcastd %eax,%zmm1
  663fab:	62 f2 7d 48 7c d1    	vpbroadcastd %ecx,%zmm2
  663fb1:	c4 c1 79 6e db       	vmovd  %r11d,%xmm3
  663fb6:	4c 8d 62 e0          	lea    -0x20(%rdx),%r12
  663fba:	49 83 c5 e0          	add    $0xffffffffffffffe0,%r13
  663fbe:	49 8d 68 40          	lea    0x40(%r8),%rbp
  663fc2:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  663fc7:	4c 8d 73 e0          	lea    -0x20(%rbx),%r14
  663fcb:	45 31 db             	xor    %r11d,%r11d
  663fce:	62 f1 fd 48 6f 25 e8 	vmovdqa64 -0x61ce18(%rip),%zmm4        # 471c0 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0x17c>
  663fd5:	31 9e ff 
  663fd8:	62 f1 fd 48 6f 2d 1e 	vmovdqa64 -0x61cde2(%rip),%zmm5        # 47200 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0x1bc>
  663fdf:	32 9e ff 
  663fe2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  663fe9:	1f 84 00 00 00 00 00 
  663ff0:	62 92 7d 48 23 34 58 	vpmovsxwd (%r8,%r11,2),%zmm6
  663ff7:	62 d2 7d 48 23 7f 01 	vpmovsxwd 0x20(%r15),%zmm7
  663ffe:	62 11 fe 48 6f 04 59 	vmovdqu64 (%r9,%r11,2),%zmm8
  664005:	62 11 fe 48 6f 0c 5a 	vmovdqu64 (%r10,%r11,2),%zmm9
  66400c:	62 51 35 48 d5 d0    	vpmullw %zmm8,%zmm9,%zmm10
  664012:	62 51 35 48 e5 c0    	vpmulhw %zmm8,%zmm9,%zmm8
  664018:	62 51 fd 48 6f ca    	vmovdqa64 %zmm10,%zmm9
  66401e:	62 52 dd 48 7d c8    	vpermt2w %zmm8,%zmm4,%zmm9
  664024:	62 52 d5 48 7d d0    	vpermt2w %zmm8,%zmm5,%zmm10
  66402a:	62 51 7d 48 fe c1    	vpaddd %zmm9,%zmm0,%zmm8
  664030:	62 71 3d 48 e2 c3    	vpsrad %xmm3,%zmm8,%zmm8
  664036:	62 f1 3d 48 fe f6    	vpaddd %zmm6,%zmm8,%zmm6
  66403c:	62 f2 4d 48 3d f1    	vpmaxsd %zmm1,%zmm6,%zmm6
  664042:	62 f2 4d 48 39 f2    	vpminsd %zmm2,%zmm6,%zmm6
  664048:	62 51 7d 48 fe c2    	vpaddd %zmm10,%zmm0,%zmm8
  66404e:	62 71 3d 48 e2 c3    	vpsrad %xmm3,%zmm8,%zmm8
  664054:	62 f1 3d 48 fe ff    	vpaddd %zmm7,%zmm8,%zmm7
  66405a:	62 f2 45 48 3d f9    	vpmaxsd %zmm1,%zmm7,%zmm7
  664060:	62 92 7e 48 33 34 58 	vpmovdw %zmm6,(%r8,%r11,2)
  664067:	62 f2 45 48 39 f2    	vpminsd %zmm2,%zmm7,%zmm6
  66406d:	62 d2 7e 48 33 77 01 	vpmovdw %zmm6,0x20(%r15)
  664074:	49 83 c3 20          	add    $0x20,%r11
  664078:	4c 39 db             	cmp    %r11,%rbx
  66407b:	0f 92 c3             	setb   %bl
  66407e:	49 83 ee 20          	sub    $0x20,%r14
  664082:	40 0f 92 c7          	setb   %dil
  664086:	40 08 df             	or     %bl,%dil
  664089:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  66408f:	4c 0f 44 fd          	cmove  %rbp,%r15
  664093:	49 83 ec 20          	sub    $0x20,%r12
  664097:	0f 92 c3             	setb   %bl
  66409a:	49 83 ed 20          	sub    $0x20,%r13
  66409e:	0f 82 30 fd ff ff    	jb     663dd4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  6640a4:	40 84 ff             	test   %dil,%dil
  6640a7:	0f 85 27 fd ff ff    	jne    663dd4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  6640ad:	4c 39 da             	cmp    %r11,%rdx
  6640b0:	0f 82 1e fd ff ff    	jb     663dd4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  6640b6:	48 83 c5 40          	add    $0x40,%rbp
  6640ba:	84 db                	test   %bl,%bl
  6640bc:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  6640c1:	0f 84 29 ff ff ff    	je     663ff0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x390>
  6640c7:	e9 0d fd ff ff       	jmp    663dd9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x179>
  6640cc:	4d 85 db             	test   %r11,%r11
  6640cf:	75 52                	jne    664123 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4c3>
  6640d1:	48 85 d2             	test   %rdx,%rdx
  6640d4:	0f 84 9f fe ff ff    	je     663f79 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  6640da:	89 44 24 10          	mov    %eax,0x10(%rsp)
  6640de:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
  6640e2:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
  6640e7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6640ec:	48 8d 05 1d 80 1c 00 	lea    0x1c801d(%rip),%rax        # 82c110 <<i32 as core::fmt::Debug>::fmt>
  6640f3:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6640f8:	48 8d 4c 24 14       	lea    0x14(%rsp),%rcx
  6640fd:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  664102:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  664107:	48 8d 3d 22 63 9a ff 	lea    -0x659cde(%rip),%rdi        # a430 <anon.42fab95c888da61b1e919ac44bbba854.230.llvm.10426147197465607828>
  66410e:	48 8d 15 63 d5 55 00 	lea    0x55d563(%rip),%rdx        # bc1678 <anon.d0737aeb7bbf3866d88b3a389feb0b4f.160.llvm.17283402442207905531+0x898>
  664115:	48 8d 74 24 28       	lea    0x28(%rsp),%rsi
  66411a:	c5 f8 77             	vzeroupper
  66411d:	ff 15 15 02 57 00    	call   *0x570215(%rip)        # bd4338 <_DYNAMIC+0x290>
  664123:	49 39 d3             	cmp    %rdx,%r11
  664126:	0f 83 4d fe ff ff    	jae    663f79 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  66412c:	eb ac                	jmp    6640da <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x47a>
  66412e:	cc                   	int3
  66412f:	cc                   	int3

