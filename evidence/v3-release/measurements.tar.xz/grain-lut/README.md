# Native AVX-512 luma grain LUT experiment

## Local attribution

The existing 32-lane AVX-512 arithmetic wins on a directly measured row. Whole-stream cost also includes a separate gather before the arithmetic. This experiment measures whether fusing the 8-bit luma gather and arithmetic improves the full operation.

Callgrind captured 16 frames of grain-bearing 1920×1080 Noise Ocean, one worker and frame delay one, using the signed, matched `c9a9a960` CLI on an AVX2-only i7-12700H. Null output still applies grain. The trace records 2,047,069,931 guest instructions.

| Loop | Linked address range | Instructions per group | Executed groups | Guest instructions | Whole decode |
|---|---|---:|---:|---:|---:|
| Luma scale gather and scratch store | `0x52bfe3–0x52c0ca` | 39 | 2,073,600 | 80,870,400 | 3.951% |
| Indexed chroma scale gather and scratch store | `0x52bf10–0x52bf75` | 23 | 4,147,200 | 95,385,600 | 4.660% |

These counts include loop overhead and the separately recorded first group of each of 17,280 rows in each case. They establish the cost and hot instruction ranges on this host. The native experiment measures elapsed time on a separate host with VBMI. The exact inputs, commands, original trace and checksums are stored here and in the linked release audit.

```sh
taskset -c 12 valgrind --tool=callgrind --dump-instr=yes \
  --callgrind-out-file=exact-avx2-grain.cg --log-file=exact-avx2-grain.log \
  ../v3-release/linked-final/release-final/splot decode \
  ../ci-data/Noise_Ocean_1920x1080_60fps_filmgrain_qp135_130f.ivf \
  --threads 1 --frame-delay 1 --limit 16 --output-format null
```

## Prototype scope

The candidate makes a packed copy of the exact 256-entry scale LUT once per 8-bit luma frame. A 64-pixel group uses the low seven bits for two VBMI concatenated permutations and the high bit to select the appropriate half. Both permutations receive only in-range indices. The result widens into two groups of 32 and reuses the existing exact rounding and clipping. A short final group uses padded vector scratch with no heap allocation. Smaller rows, chroma, 10-bit, narrow backends and unsupported LUT values keep their existing source paths.

The control for both runs is `83566cc2a716603280a8b0773fc026f1fe86676e`. The dedicated branch preserves the first version and the one change that keeps its block helper in the AVX-512 row scope. The existing release qualification is independent. [First signed candidate](https://github.com/splotlabs/splot/commit/0a4494bbdf03291e5c32db074cc8e5b96ed1c2ba) · [Corrected signed candidate](https://github.com/splotlabs/splot/commit/33b33595447e4798dd29ff36880aad8fccc4ee19)

## Native protocol

The workflow requires a native AVX-512 token and a VBMI-capable CPU. It compares against a scalar oracle for every byte index, legal shift range, limited and full clipping, and short and unaligned row lengths. The direct benchmark alternates complete old gather-plus-arithmetic and fused row operations 24 times on the same core. Exact release CLI builds use the same toolchain and flags.

The whole-stream test compares full Noise Ocean and RitualDance output digests and byte counts against AVM. The two builds also compare raw outputs with grain disabled on Noise Ocean. Timing measures 24 counterbalanced foreground pairs on the full 130-frame grain-bearing Noise stream at one worker and another 24 pairs at seven workers. Both build identities, post-strip length, linked assembly, all rows and expected outputs remain in the results archive. Report paired-median changes and 95% bootstrap intervals.

## Rejected outline shape

The first native run on a Xeon 6975P-C passed the scalar parity test. The median row times were 450.890 and 1,787.715 ns over 24 pairs. The paired increase was **+298.609%** with a 95% interval from +295.402% to +299.633%. The stripped CLI grew 4,416 bytes. The row feature scope called an outlined generic block once per 64 pixels and contained no VBMI permutation instructions. The feature-scope gate stopped before the whole-stream check. The original job log and all 24 row pairs are retained in `rejected-job.log`, `rejected-results/` and `rejected-results.zip`. [Rejected run](https://github.com/splotlabs/splot/actions/runs/45677957869)

The one correction replaces the outlined closure with an always-inlined block helper. A local code-generation-only probe using the exact old and new source showed a call per block before the correction and direct VBMI permutations inside the AVX-512 row after it. The saved assembly and probe sources are in `codegen/`. This check executed no AVX-512 instructions on the local host.

## Corrected native result

The corrected run uses the same control, workload and workflow. It is pending. [Corrected native run](https://github.com/splotlabs/splot/actions/runs/45682311244)

Local offline focused Clippy passed for the first prototype library and tests.
