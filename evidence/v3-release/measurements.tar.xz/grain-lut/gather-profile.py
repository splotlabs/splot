"""Attribute the two scale-gather loops in the preserved AVX2 trace."""

from collections import defaultdict
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
SYMBOL = "splot_decode::output::film_grain::apply::<u8, splot_core::simd::Avx2Backend>"
FUNCTION = re.compile(r"^fn=\((\d+)\)(?: (.*))?$")
INSTRUCTION = re.compile(r"^\s*([0-9a-f]+):\s+[0-9a-f]{2}", re.M)
LOOPS = (
    ("luma", 0x52BFE3, 0x52C0CA, 1920 * 1080, 16),
    ("chroma", 0x52BF10, 0x52BF75, 2 * 960 * 540, 4),
)


def main():
    lines = (HERE / "exact-avx2-grain.cg").read_text().splitlines()
    assembly = (HERE.parent / "v3-release/linked-final/final-analysis/splot/focused.asm").read_text()
    addresses = [int(addr, 16) for addr in INSTRUCTION.findall(assembly)]
    total = int(next(line.split()[1] for line in lines if line.startswith("summary:")))
    identifier = next(match[1] for line in lines if (match := FUNCTION.match(line)) and match[2] == SYMBOL)
    direct = defaultdict(int)
    active, call, ip = False, False, 0
    for line in lines:
        if match := FUNCTION.match(line):
            active, call = match[1] == identifier, False
        if line.startswith("calls="):
            call = True
        fields = line.split()
        if not active or len(fields) != 3 or not fields[2].isdigit():
            continue
        loc, _, count = fields
        if loc.startswith("0x"):
            ip = int(loc, 16)
        elif loc.startswith(("+", "-")):
            ip += int(loc)
        elif loc != "*":
            continue
        if not call:
            direct[ip] += int(count)
        call = False

    print("kernel\tstart\tend\tinstructions_per_group\tgroups\tguest_instructions\tpercent_total_instructions")
    for label, start, end, pixels, lanes in LOOPS:
        counts = [direct[addr] for addr in addresses if start <= addr <= end]
        groups = 16 * pixels // lanes
        assert counts and all(n == groups for n in counts), label
        print(label, hex(start), hex(end), len(counts), groups, sum(counts),
              f"{sum(counts) / total * 100:.3f}", sep="\t")
    print(f"all\t\t\t\t\t{total}\t100.000")


if __name__ == "__main__":
    main()
