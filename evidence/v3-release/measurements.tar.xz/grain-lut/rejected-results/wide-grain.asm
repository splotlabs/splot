00000000006635b0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>>:
  6635b0:	55                   	push   %rbp
  6635b1:	41 57                	push   %r15
  6635b3:	41 56                	push   %r14
  6635b5:	41 55                	push   %r13
  6635b7:	41 54                	push   %r12
  6635b9:	53                   	push   %rbx
  6635ba:	48 83 ec 38          	sub    $0x38,%rsp
  6635be:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6635c3:	4c 8b 46 08          	mov    0x8(%rsi),%r8
  6635c7:	48 8b 5e 10          	mov    0x10(%rsi),%rbx
  6635cb:	4c 8b 4e 18          	mov    0x18(%rsi),%r9
  6635cf:	48 8b 56 20          	mov    0x20(%rsi),%rdx
  6635d3:	4c 8b 56 28          	mov    0x28(%rsi),%r10
  6635d7:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
  6635db:	4c 8b 7e 38          	mov    0x38(%rsi),%r15
  6635df:	41 8b 07             	mov    (%r15),%eax
  6635e2:	41 8b 4f 04          	mov    0x4(%r15),%ecx
  6635e6:	41 0f b6 77 08       	movzbl 0x8(%r15),%esi
  6635eb:	81 f9 ff 00 00 00    	cmp    $0xff,%ecx
  6635f1:	0f 8e 07 01 00 00    	jle    6636fe <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x14e>
  6635f7:	45 31 db             	xor    %r11d,%r11d
  6635fa:	48 39 d3             	cmp    %rdx,%rbx
  6635fd:	48 0f 42 d3          	cmovb  %rbx,%rdx
  663601:	48 39 fa             	cmp    %rdi,%rdx
  663604:	48 0f 43 d7          	cmovae %rdi,%rdx
  663608:	39 c8                	cmp    %ecx,%eax
  66360a:	0f 8f fd 03 00 00    	jg     663a0d <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x45d>
  663610:	40 84 f6             	test   %sil,%sil
  663613:	0f 84 cb 01 00 00    	je     6637e4 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x234>
  663619:	8d 7e ff             	lea    -0x1(%rsi),%edi
  66361c:	bb 01 00 00 00       	mov    $0x1,%ebx
  663621:	c4 e2 41 f7 eb       	shlx   %edi,%ebx,%ebp
  663626:	40 80 e6 1f          	and    $0x1f,%sil
  66362a:	49 89 d6             	mov    %rdx,%r14
  66362d:	49 f7 de             	neg    %r14
  663630:	45 31 ff             	xor    %r15d,%r15d
  663633:	4d 85 db             	test   %r11,%r11
  663636:	0f 84 b4 00 00 00    	je     6636f0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x140>
  66363c:	eb 57                	jmp    663695 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0xe5>
  66363e:	66 90                	xchg   %ax,%ax
  663640:	4d 8d 5f 01          	lea    0x1(%r15),%r11
  663644:	43 0f bf 3c 79       	movswl (%r9,%r15,2),%edi
  663649:	47 0f bf 24 7a       	movswl (%r10,%r15,2),%r12d
  66364e:	44 0f af e7          	imul   %edi,%r12d
  663652:	41 01 ec             	add    %ebp,%r12d
  663655:	c4 c2 4a f7 fc       	sarx   %esi,%r12d,%edi
  66365a:	47 0f b6 2c 38       	movzbl (%r8,%r15,1),%r13d
  66365f:	41 01 fd             	add    %edi,%r13d
  663662:	41 39 cd             	cmp    %ecx,%r13d
  663665:	41 89 cc             	mov    %ecx,%r12d
  663668:	45 0f 4c e5          	cmovl  %r13d,%r12d
  66366c:	41 39 c5             	cmp    %eax,%r13d
  66366f:	44 0f 4c e0          	cmovl  %eax,%r12d
  663673:	41 0f b7 fc          	movzwl %r12w,%edi
  663677:	81 ff ff 00 00 00    	cmp    $0xff,%edi
  66367d:	0f 87 20 02 00 00    	ja     6638a3 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2f3>
  663683:	47 88 24 38          	mov    %r12b,(%r8,%r15,1)
  663687:	4d 89 df             	mov    %r11,%r15
  66368a:	45 31 db             	xor    %r11d,%r11d
  66368d:	44 89 e3             	mov    %r12d,%ebx
  663690:	4d 85 db             	test   %r11,%r11
  663693:	74 5b                	je     6636f0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x140>
  663695:	49 89 d5             	mov    %rdx,%r13
  663698:	4d 29 fd             	sub    %r15,%r13
  66369b:	4d 39 eb             	cmp    %r13,%r11
  66369e:	4d 0f 42 eb          	cmovb  %r11,%r13
  6636a2:	4f 8d 24 2f          	lea    (%r15,%r13,1),%r12
  6636a6:	4d 39 e7             	cmp    %r12,%r15
  6636a9:	4d 0f 47 e7          	cmova  %r15,%r12
  6636ad:	49 39 d4             	cmp    %rdx,%r12
  6636b0:	0f 83 e3 01 00 00    	jae    663899 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  6636b6:	4d 29 dd             	sub    %r11,%r13
  6636b9:	4f 8d 3c 26          	lea    (%r14,%r12,1),%r15
  6636bd:	45 31 db             	xor    %r11d,%r11d
  6636c0:	4d 39 dd             	cmp    %r11,%r13
  6636c3:	74 0d                	je     6636d2 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x122>
  6636c5:	49 ff cb             	dec    %r11
  6636c8:	4d 39 df             	cmp    %r11,%r15
  6636cb:	75 f3                	jne    6636c0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x110>
  6636cd:	e9 c7 01 00 00       	jmp    663899 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  6636d2:	4d 29 dc             	sub    %r11,%r12
  6636d5:	4d 8d 5c 24 01       	lea    0x1(%r12),%r11
  6636da:	4d 89 e7             	mov    %r12,%r15
  6636dd:	e9 62 ff ff ff       	jmp    663644 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x94>
  6636e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6636e9:	1f 84 00 00 00 00 00 
  6636f0:	4c 39 fa             	cmp    %r15,%rdx
  6636f3:	0f 87 47 ff ff ff    	ja     663640 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x90>
  6636f9:	e9 9b 01 00 00       	jmp    663899 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  6636fe:	44 0f b6 de          	movzbl %sil,%r11d
  663702:	48 83 fb 20          	cmp    $0x20,%rbx
  663706:	41 0f 92 c6          	setb   %r14b
  66370a:	48 83 fa 20          	cmp    $0x20,%rdx
  66370e:	41 0f 92 c4          	setb   %r12b
  663712:	48 83 ff 20          	cmp    $0x20,%rdi
  663716:	40 0f 92 c5          	setb   %bpl
  66371a:	44 08 f5             	or     %r14b,%bpl
  66371d:	44 08 e5             	or     %r12b,%bpl
  663720:	41 f6 47 09 01       	testb  $0x1,0x9(%r15)
  663725:	0f 84 b3 01 00 00    	je     6638de <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x32e>
  66372b:	40 84 ed             	test   %bpl,%bpl
  66372e:	0f 85 c3 fe ff ff    	jne    6635f7 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x47>
  663734:	41 ff cb             	dec    %r11d
  663737:	c4 c1 79 6e c3       	vmovd  %r11d,%xmm0
  66373c:	62 f2 7d 48 7b c8    	vpbroadcastw %eax,%zmm1
  663742:	62 f2 7d 48 7b d1    	vpbroadcastw %ecx,%zmm2
  663748:	4c 8d 7b e0          	lea    -0x20(%rbx),%r15
  66374c:	4c 8d 62 e0          	lea    -0x20(%rdx),%r12
  663750:	4c 8d 6f e0          	lea    -0x20(%rdi),%r13
  663754:	45 31 db             	xor    %r11d,%r11d
  663757:	62 f3 65 48 25 db ff 	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
  66375e:	66 90                	xchg   %ax,%ax
  663760:	62 92 7d 48 30 24 18 	vpmovzxbw (%r8,%r11,1),%zmm4
  663767:	62 91 fe 48 6f 2c 5a 	vmovdqu64 (%r10,%r11,2),%zmm5
  66376e:	62 91 55 48 d5 2c 59 	vpmullw (%r9,%r11,2),%zmm5,%zmm5
  663775:	62 f1 55 48 e1 e8    	vpsraw %xmm0,%zmm5,%zmm5
  66377b:	62 f1 55 48 f9 eb    	vpsubw %zmm3,%zmm5,%zmm5
  663781:	62 f1 55 48 71 e5 01 	vpsraw $0x1,%zmm5,%zmm5
  663788:	62 f1 55 48 fd e4    	vpaddw %zmm4,%zmm5,%zmm4
  66378e:	62 f1 5d 48 ee e1    	vpmaxsw %zmm1,%zmm4,%zmm4
  663794:	62 f1 5d 48 ea e2    	vpminsw %zmm2,%zmm4,%zmm4
  66379a:	62 92 7e 48 30 24 18 	vpmovwb %zmm4,(%r8,%r11,1)
  6637a1:	49 83 c3 20          	add    $0x20,%r11
  6637a5:	49 83 ef 20          	sub    $0x20,%r15
  6637a9:	41 0f 92 c6          	setb   %r14b
  6637ad:	49 83 ec 20          	sub    $0x20,%r12
  6637b1:	40 0f 92 c5          	setb   %bpl
  6637b5:	49 83 ed 20          	sub    $0x20,%r13
  6637b9:	0f 82 3b fe ff ff    	jb     6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6637bf:	4c 39 db             	cmp    %r11,%rbx
  6637c2:	0f 82 32 fe ff ff    	jb     6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6637c8:	45 84 f6             	test   %r14b,%r14b
  6637cb:	0f 85 29 fe ff ff    	jne    6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6637d1:	4c 39 da             	cmp    %r11,%rdx
  6637d4:	0f 82 20 fe ff ff    	jb     6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6637da:	40 84 ed             	test   %bpl,%bpl
  6637dd:	74 81                	je     663760 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x1b0>
  6637df:	e9 16 fe ff ff       	jmp    6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6637e4:	48 89 d6             	mov    %rdx,%rsi
  6637e7:	48 f7 de             	neg    %rsi
  6637ea:	45 31 f6             	xor    %r14d,%r14d
  6637ed:	4d 85 db             	test   %r11,%r11
  6637f0:	0f 84 9a 00 00 00    	je     663890 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e0>
  6637f6:	eb 4d                	jmp    663845 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x295>
  6637f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6637ff:	00 
  663800:	4d 8d 5e 01          	lea    0x1(%r14),%r11
  663804:	43 0f bf 3c 71       	movswl (%r9,%r14,2),%edi
  663809:	43 0f bf 2c 72       	movswl (%r10,%r14,2),%ebp
  66380e:	0f af ef             	imul   %edi,%ebp
  663811:	43 0f b6 3c 30       	movzbl (%r8,%r14,1),%edi
  663816:	01 ef                	add    %ebp,%edi
  663818:	39 cf                	cmp    %ecx,%edi
  66381a:	41 89 cc             	mov    %ecx,%r12d
  66381d:	44 0f 4c e7          	cmovl  %edi,%r12d
  663821:	39 c7                	cmp    %eax,%edi
  663823:	44 0f 4c e0          	cmovl  %eax,%r12d
  663827:	41 0f b7 fc          	movzwl %r12w,%edi
  66382b:	81 ff ff 00 00 00    	cmp    $0xff,%edi
  663831:	77 70                	ja     6638a3 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2f3>
  663833:	47 88 24 30          	mov    %r12b,(%r8,%r14,1)
  663837:	4d 89 de             	mov    %r11,%r14
  66383a:	45 31 db             	xor    %r11d,%r11d
  66383d:	44 89 e3             	mov    %r12d,%ebx
  663840:	4d 85 db             	test   %r11,%r11
  663843:	74 4b                	je     663890 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e0>
  663845:	49 89 d4             	mov    %rdx,%r12
  663848:	4d 29 f4             	sub    %r14,%r12
  66384b:	4d 39 e3             	cmp    %r12,%r11
  66384e:	4d 0f 42 e3          	cmovb  %r11,%r12
  663852:	4f 8d 3c 34          	lea    (%r12,%r14,1),%r15
  663856:	4d 39 fe             	cmp    %r15,%r14
  663859:	4d 0f 47 fe          	cmova  %r14,%r15
  66385d:	49 39 d7             	cmp    %rdx,%r15
  663860:	73 37                	jae    663899 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  663862:	4d 29 dc             	sub    %r11,%r12
  663865:	4e 8d 34 3e          	lea    (%rsi,%r15,1),%r14
  663869:	45 31 db             	xor    %r11d,%r11d
  66386c:	4d 39 dc             	cmp    %r11,%r12
  66386f:	74 0a                	je     66387b <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2cb>
  663871:	49 ff cb             	dec    %r11
  663874:	4d 39 de             	cmp    %r11,%r14
  663877:	75 f3                	jne    66386c <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2bc>
  663879:	eb 1e                	jmp    663899 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  66387b:	4d 29 df             	sub    %r11,%r15
  66387e:	4d 8d 5f 01          	lea    0x1(%r15),%r11
  663882:	4d 89 fe             	mov    %r15,%r14
  663885:	e9 7a ff ff ff       	jmp    663804 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x254>
  66388a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  663890:	4c 39 f2             	cmp    %r14,%rdx
  663893:	0f 87 67 ff ff ff    	ja     663800 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x250>
  663899:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66389e:	c6 00 ff             	movb   $0xff,(%rax)
  6638a1:	eb 29                	jmp    6638cc <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x31c>
  6638a3:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6638a8:	c6 01 10             	movb   $0x10,(%rcx)
  6638ab:	88 59 01             	mov    %bl,0x1(%rcx)
  6638ae:	66 44 89 61 02       	mov    %r12w,0x2(%rcx)
  6638b3:	66 c7 41 04 ff 00    	movw   $0xff,0x4(%rcx)
  6638b9:	48 8d 05 68 87 9e ff 	lea    -0x617898(%rip),%rax        # 4c028 <splot_decode::bitstream::tile_payload::coeff_state::ZERO_QUANT_SIGN+0xa38>
  6638c0:	48 89 41 08          	mov    %rax,0x8(%rcx)
  6638c4:	48 c7 41 10 02 00 00 	movq   $0x2,0x10(%rcx)
  6638cb:	00 
  6638cc:	48 83 c4 38          	add    $0x38,%rsp
  6638d0:	5b                   	pop    %rbx
  6638d1:	41 5c                	pop    %r12
  6638d3:	41 5d                	pop    %r13
  6638d5:	41 5e                	pop    %r14
  6638d7:	41 5f                	pop    %r15
  6638d9:	5d                   	pop    %rbp
  6638da:	c5 f8 77             	vzeroupper
  6638dd:	c3                   	ret
  6638de:	40 84 ed             	test   %bpl,%bpl
  6638e1:	0f 85 10 fd ff ff    	jne    6635f7 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x47>
  6638e7:	bd 01 00 00 00       	mov    $0x1,%ebp
  6638ec:	c4 e2 21 f7 ed       	shlx   %r11d,%ebp,%ebp
  6638f1:	d1 fd                	sar    $1,%ebp
  6638f3:	62 f2 7d 48 7c c5    	vpbroadcastd %ebp,%zmm0
  6638f9:	c5 f9 6e d0          	vmovd  %eax,%xmm2
  6638fd:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
  663901:	c4 c1 79 6e cb       	vmovd  %r11d,%xmm1
  663906:	62 f2 7d 48 58 d2    	vpbroadcastd %xmm2,%zmm2
  66390c:	62 f2 7d 48 58 db    	vpbroadcastd %xmm3,%zmm3
  663912:	4c 8d 7b e0          	lea    -0x20(%rbx),%r15
  663916:	4c 8d 62 e0          	lea    -0x20(%rdx),%r12
  66391a:	4c 8d 6f e0          	lea    -0x20(%rdi),%r13
  66391e:	45 31 db             	xor    %r11d,%r11d
  663921:	62 f1 fd 48 6f 25 15 	vmovdqa64 -0x61c7eb(%rip),%zmm4        # 47140 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0xfc>
  663928:	38 9e ff 
  66392b:	62 f1 fd 48 6f 2d 4b 	vmovdqa64 -0x61c7b5(%rip),%zmm5        # 47180 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0x13c>
  663932:	38 9e ff 
  663935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66393c:	00 00 00 00 
  663940:	62 92 7d 48 31 34 18 	vpmovzxbd (%r8,%r11,1),%zmm6
  663947:	62 92 7d 48 31 7c 18 	vpmovzxbd 0x10(%r8,%r11,1),%zmm7
  66394e:	01 
  66394f:	62 11 fe 48 6f 04 59 	vmovdqu64 (%r9,%r11,2),%zmm8
  663956:	62 11 fe 48 6f 0c 5a 	vmovdqu64 (%r10,%r11,2),%zmm9
  66395d:	62 51 35 48 d5 d0    	vpmullw %zmm8,%zmm9,%zmm10
  663963:	62 51 35 48 e5 c0    	vpmulhw %zmm8,%zmm9,%zmm8
  663969:	62 51 fd 48 6f ca    	vmovdqa64 %zmm10,%zmm9
  66396f:	62 52 dd 48 7d c8    	vpermt2w %zmm8,%zmm4,%zmm9
  663975:	62 51 7d 48 fe c9    	vpaddd %zmm9,%zmm0,%zmm9
  66397b:	62 71 35 48 e2 c9    	vpsrad %xmm1,%zmm9,%zmm9
  663981:	62 52 d5 48 7d d0    	vpermt2w %zmm8,%zmm5,%zmm10
  663987:	62 51 7d 48 fe c2    	vpaddd %zmm10,%zmm0,%zmm8
  66398d:	62 71 3d 48 e2 c1    	vpsrad %xmm1,%zmm8,%zmm8
  663993:	62 f1 35 48 fe f6    	vpaddd %zmm6,%zmm9,%zmm6
  663999:	62 f1 3d 48 fe ff    	vpaddd %zmm7,%zmm8,%zmm7
  66399f:	62 f2 4d 48 3d f2    	vpmaxsd %zmm2,%zmm6,%zmm6
  6639a5:	62 f2 45 48 3d fa    	vpmaxsd %zmm2,%zmm7,%zmm7
  6639ab:	62 f2 45 48 39 fb    	vpminsd %zmm3,%zmm7,%zmm7
  6639b1:	62 f2 4d 48 39 f3    	vpminsd %zmm3,%zmm6,%zmm6
  6639b7:	62 92 7e 48 31 34 18 	vpmovdb %zmm6,(%r8,%r11,1)
  6639be:	62 92 7e 48 31 7c 18 	vpmovdb %zmm7,0x10(%r8,%r11,1)
  6639c5:	01 
  6639c6:	49 83 c3 20          	add    $0x20,%r11
  6639ca:	49 83 ef 20          	sub    $0x20,%r15
  6639ce:	41 0f 92 c6          	setb   %r14b
  6639d2:	49 83 ec 20          	sub    $0x20,%r12
  6639d6:	40 0f 92 c5          	setb   %bpl
  6639da:	49 83 ed 20          	sub    $0x20,%r13
  6639de:	0f 82 16 fc ff ff    	jb     6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6639e4:	4c 39 db             	cmp    %r11,%rbx
  6639e7:	0f 82 0d fc ff ff    	jb     6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6639ed:	45 84 f6             	test   %r14b,%r14b
  6639f0:	0f 85 04 fc ff ff    	jne    6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6639f6:	4c 39 da             	cmp    %r11,%rdx
  6639f9:	0f 82 fb fb ff ff    	jb     6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  6639ff:	40 84 ed             	test   %bpl,%bpl
  663a02:	0f 84 38 ff ff ff    	je     663940 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x390>
  663a08:	e9 ed fb ff ff       	jmp    6635fa <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4a>
  663a0d:	4d 85 db             	test   %r11,%r11
  663a10:	75 52                	jne    663a64 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4b4>
  663a12:	48 85 d2             	test   %rdx,%rdx
  663a15:	0f 84 7e fe ff ff    	je     663899 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  663a1b:	89 44 24 08          	mov    %eax,0x8(%rsp)
  663a1f:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
  663a23:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  663a28:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  663a2d:	48 8d 05 dc 91 1c 00 	lea    0x1c91dc(%rip),%rax        # 82cc10 <<i32 as core::fmt::Debug>::fmt>
  663a34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  663a39:	48 8d 4c 24 0c       	lea    0xc(%rsp),%rcx
  663a3e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  663a43:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  663a48:	48 8d 3d e1 69 9a ff 	lea    -0x65961f(%rip),%rdi        # a430 <anon.42fab95c888da61b1e919ac44bbba854.230.llvm.10426147197465607828>
  663a4f:	48 8d 15 22 e7 55 00 	lea    0x55e722(%rip),%rdx        # bc2178 <anon.d0737aeb7bbf3866d88b3a389feb0b4f.160.llvm.9512836412138272526+0x898>
  663a56:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  663a5b:	c5 f8 77             	vzeroupper
  663a5e:	ff 15 d4 13 57 00    	call   *0x5713d4(%rip)        # bd4e38 <_DYNAMIC+0x290>
  663a64:	49 39 d3             	cmp    %rdx,%r11
  663a67:	0f 83 2c fe ff ff    	jae    663899 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2e9>
  663a6d:	eb ac                	jmp    663a1b <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x46b>
  663a6f:	cc                   	int3

0000000000663a70 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>>:
  663a70:	55                   	push   %rbp
  663a71:	48 89 e5             	mov    %rsp,%rbp
  663a74:	41 57                	push   %r15
  663a76:	41 56                	push   %r14
  663a78:	41 55                	push   %r13
  663a7a:	41 54                	push   %r12
  663a7c:	53                   	push   %rbx
  663a7d:	48 83 e4 c0          	and    $0xffffffffffffffc0,%rsp
  663a81:	48 81 ec c0 02 00 00 	sub    $0x2c0,%rsp
  663a88:	48 8b 47 08          	mov    0x8(%rdi),%rax
  663a8c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  663a91:	48 8b 47 18          	mov    0x18(%rdi),%rax
  663a95:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
  663a99:	0f b6 51 08          	movzbl 0x8(%rcx),%edx
  663a9d:	48 8b 09             	mov    (%rcx),%rcx
  663aa0:	88 54 24 30          	mov    %dl,0x30(%rsp)
  663aa4:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  663aa9:	c6 44 24 31 01       	movb   $0x1,0x31(%rsp)
  663aae:	62 f1 7c 48 10 00    	vmovups (%rax),%zmm0
  663ab4:	62 f1 7c 48 29 44 24 	vmovaps %zmm0,0xc0(%rsp)
  663abb:	03 
  663abc:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
  663ac0:	62 f1 7c 48 10 40 01 	vmovups 0x40(%rax),%zmm0
  663ac7:	62 f1 7c 48 29 44 24 	vmovaps %zmm0,0x100(%rsp)
  663ace:	04 
  663acf:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
  663ad3:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  663ad8:	62 f1 7c 48 10 40 02 	vmovups 0x80(%rax),%zmm0
  663adf:	62 f1 7c 48 29 44 24 	vmovaps %zmm0,0x140(%rsp)
  663ae6:	05 
  663ae7:	48 8b 4f 28          	mov    0x28(%rdi),%rcx
  663aeb:	62 f1 7c 48 10 40 03 	vmovups 0xc0(%rax),%zmm0
  663af2:	62 f1 7c 48 29 44 24 	vmovaps %zmm0,0x180(%rsp)
  663af9:	06 
  663afa:	62 f1 7c 48 28 05 bc 	vmovaps -0x61c944(%rip),%zmm0        # 471c0 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0x17c>
  663b01:	36 9e ff 
  663b04:	62 f1 7c 48 29 44 24 	vmovaps %zmm0,0x1c0(%rsp)
  663b0b:	07 
  663b0c:	48 8d 44 24 17       	lea    0x17(%rsp),%rax
  663b11:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  663b16:	48 8d 84 24 c0 01 00 	lea    0x1c0(%rsp),%rax
  663b1d:	00 
  663b1e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  663b23:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  663b2a:	00 
  663b2b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  663b30:	48 8d 84 24 80 01 00 	lea    0x180(%rsp),%rax
  663b37:	00 
  663b38:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  663b3d:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
  663b44:	00 
  663b45:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  663b4a:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  663b51:	00 
  663b52:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  663b57:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
  663b5c:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  663b61:	41 89 de             	mov    %ebx,%r14d
  663b64:	41 83 e6 3f          	and    $0x3f,%r14d
  663b68:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  663b6d:	48 89 c8             	mov    %rcx,%rax
  663b70:	48 c1 e8 06          	shr    $0x6,%rax
  663b74:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
  663b79:	48 c1 eb 06          	shr    $0x6,%rbx
  663b7d:	48 39 c3             	cmp    %rax,%rbx
  663b80:	48 0f 43 d8          	cmovae %rax,%rbx
  663b84:	48 85 db             	test   %rbx,%rbx
  663b87:	74 35                	je     663bbe <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0x14e>
  663b89:	4c 8d 7c 24 48       	lea    0x48(%rsp),%r15
  663b8e:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
  663b93:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
  663b98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  663b9f:	00 
  663ba0:	4c 89 ff             	mov    %r15,%rdi
  663ba3:	4c 89 e6             	mov    %r12,%rsi
  663ba6:	4c 89 ea             	mov    %r13,%rdx
  663ba9:	c5 f8 77             	vzeroupper
  663bac:	e8 df d8 02 00       	call   691490 <splot_recon::film_grain::wide_luma::add_luma_noise::<fearless_simd::generated::avx512::Avx512>::{closure#1}>
  663bb1:	49 83 ed 80          	sub    $0xffffffffffffff80,%r13
  663bb5:	49 83 c4 40          	add    $0x40,%r12
  663bb9:	48 ff cb             	dec    %rbx
  663bbc:	75 e2                	jne    663ba0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0x130>
  663bbe:	4d 85 f6             	test   %r14,%r14
  663bc1:	0f 84 c2 00 00 00    	je     663c89 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0x219>
  663bc7:	48 b8 c0 ff ff ff ff 	movabs $0x7fffffffffffffc0,%rax
  663bce:	ff ff 7f 
  663bd1:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  663bd6:	48 21 c1             	and    %rax,%rcx
  663bd9:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
  663bde:	41 89 df             	mov    %ebx,%r15d
  663be1:	41 83 e7 3f          	and    $0x3f,%r15d
  663be5:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  663be9:	62 f1 7c 48 29 44 24 	vmovaps %zmm0,0x240(%rsp)
  663bf0:	09 
  663bf1:	62 f1 7c 48 29 44 24 	vmovaps %zmm0,0x200(%rsp)
  663bf8:	08 
  663bf9:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
  663bfe:	49 01 cd             	add    %rcx,%r13
  663c01:	ba 40 00 00 00       	mov    $0x40,%edx
  663c06:	4c 29 f2             	sub    %r14,%rdx
  663c09:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
  663c0d:	48 81 c7 80 00 00 00 	add    $0x80,%rdi
  663c14:	31 f6                	xor    %esi,%esi
  663c16:	c5 f8 77             	vzeroupper
  663c19:	ff 15 21 16 57 00    	call   *0x571621(%rip)        # bd5240 <memset@GLIBC_2.2.5>
  663c1f:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  663c26:	00 
  663c27:	4c 89 ee             	mov    %r13,%rsi
  663c2a:	4c 89 f2             	mov    %r14,%rdx
  663c2d:	ff 15 c5 11 57 00    	call   *0x5711c5(%rip)        # bd4df8 <memcpy@GLIBC_2.14>
  663c33:	4d 39 fe             	cmp    %r15,%r14
  663c36:	75 63                	jne    663c9b <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u8>::{closure#1}::{closure#0}, ()>+0x22b>
  663c38:	48 b8 c0 ff ff ff ff 	movabs $0x3fffffffffffffc0,%rax
  663c3f:	ff ff 3f 
  663c42:	48 21 c3             	and    %rax,%rbx
  663c45:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  663c4a:	48 8d 34 58          	lea    (%rax,%rbx,2),%rsi
  663c4e:	43 8d 14 36          	lea    (%r14,%r14,1),%edx
  663c52:	4c 8d bc 24 00 02 00 	lea    0x200(%rsp),%r15
  663c59:	00 
  663c5a:	48 8b 1d 97 11 57 00 	mov    0x571197(%rip),%rbx        # bd4df8 <memcpy@GLIBC_2.14>
  663c61:	4c 89 ff             	mov    %r15,%rdi
  663c64:	ff d3                	call   *%rbx
  663c66:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  663c6b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
  663c72:	00 
  663c73:	4c 89 e6             	mov    %r12,%rsi
  663c76:	4c 89 fa             	mov    %r15,%rdx
  663c79:	e8 12 d8 02 00       	call   691490 <splot_recon::film_grain::wide_luma::add_luma_noise::<fearless_simd::generated::avx512::Avx512>::{closure#1}>
  663c7e:	4c 89 ef             	mov    %r13,%rdi
  663c81:	4c 89 e6             	mov    %r12,%rsi
  663c84:	4c 89 f2             	mov    %r14,%rdx
  663c87:	ff d3                	call   *%rbx
  663c89:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
  663c8d:	5b                   	pop    %rbx
  663c8e:	41 5c                	pop    %r12
  663c90:	41 5d                	pop    %r13
  663c92:	41 5e                	pop    %r14
  663c94:	41 5f                	pop    %r15
  663c96:	5d                   	pop    %rbp
  663c97:	c5 f8 77             	vzeroupper
  663c9a:	c3                   	ret
  663c9b:	48 8d 15 c6 ef 55 00 	lea    0x55efc6(%rip),%rdx        # bc2c68 <anon.d0737aeb7bbf3866d88b3a389feb0b4f.160.llvm.9512836412138272526+0x1388>
  663ca2:	4c 89 f7             	mov    %r14,%rdi
  663ca5:	4c 89 fe             	mov    %r15,%rsi
  663ca8:	ff 15 92 16 57 00    	call   *0x571692(%rip)        # bd5340 <_DYNAMIC+0x798>
  663cae:	cc                   	int3
  663caf:	cc                   	int3

0000000000663cb0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>>:
  663cb0:	55                   	push   %rbp
  663cb1:	41 57                	push   %r15
  663cb3:	41 56                	push   %r14
  663cb5:	41 55                	push   %r13
  663cb7:	41 54                	push   %r12
  663cb9:	53                   	push   %rbx
  663cba:	48 83 ec 48          	sub    $0x48,%rsp
  663cbe:	4c 8b 46 08          	mov    0x8(%rsi),%r8
  663cc2:	48 8b 5e 10          	mov    0x10(%rsi),%rbx
  663cc6:	4c 8b 4e 18          	mov    0x18(%rsi),%r9
  663cca:	48 8b 56 20          	mov    0x20(%rsi),%rdx
  663cce:	4c 8b 56 28          	mov    0x28(%rsi),%r10
  663cd2:	4c 8b 6e 30          	mov    0x30(%rsi),%r13
  663cd6:	4c 8b 76 38          	mov    0x38(%rsi),%r14
  663cda:	41 8b 06             	mov    (%r14),%eax
  663cdd:	41 8b 4e 04          	mov    0x4(%r14),%ecx
  663ce1:	41 0f b6 76 08       	movzbl 0x8(%r14),%esi
  663ce6:	81 f9 ff ff 00 00    	cmp    $0xffff,%ecx
  663cec:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  663cf1:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  663cf6:	7e 08                	jle    663d00 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x50>
  663cf8:	45 31 db             	xor    %r11d,%r11d
  663cfb:	e9 29 01 00 00       	jmp    663e29 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x179>
  663d00:	45 31 ff             	xor    %r15d,%r15d
  663d03:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
  663d08:	48 83 fb 20          	cmp    $0x20,%rbx
  663d0c:	0f 92 c3             	setb   %bl
  663d0f:	4d 0f 43 f8          	cmovae %r8,%r15
  663d13:	44 0f b6 de          	movzbl %sil,%r11d
  663d17:	48 83 fa 20          	cmp    $0x20,%rdx
  663d1b:	40 0f 92 c5          	setb   %bpl
  663d1f:	49 83 fd 20          	cmp    $0x20,%r13
  663d23:	41 0f 92 c4          	setb   %r12b
  663d27:	41 08 dc             	or     %bl,%r12b
  663d2a:	41 08 ec             	or     %bpl,%r12b
  663d2d:	41 f6 46 09 01       	testb  $0x1,0x9(%r14)
  663d32:	0f 84 e0 00 00 00    	je     663e18 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x168>
  663d38:	45 84 e4             	test   %r12b,%r12b
  663d3b:	0f 85 e0 00 00 00    	jne    663e21 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x171>
  663d41:	41 ff cb             	dec    %r11d
  663d44:	c4 c1 79 6e c3       	vmovd  %r11d,%xmm0
  663d49:	62 f2 7d 48 7b c8    	vpbroadcastw %eax,%zmm1
  663d4f:	62 f2 7d 48 7b d1    	vpbroadcastw %ecx,%zmm2
  663d55:	4c 8d 72 e0          	lea    -0x20(%rdx),%r14
  663d59:	4d 8d 65 e0          	lea    -0x20(%r13),%r12
  663d5d:	4d 8d 68 40          	lea    0x40(%r8),%r13
  663d61:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  663d66:	48 8d 6b e0          	lea    -0x20(%rbx),%rbp
  663d6a:	45 31 db             	xor    %r11d,%r11d
  663d6d:	62 f3 65 48 25 db ff 	vpternlogd $0xff,%zmm3,%zmm3,%zmm3
  663d74:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  663d7b:	00 00 00 00 00 
  663d80:	c4 81 7e 6f 24 58    	vmovdqu (%r8,%r11,2),%ymm4
  663d86:	62 91 fe 48 6f 2c 5a 	vmovdqu64 (%r10,%r11,2),%zmm5
  663d8d:	62 d3 dd 48 3a 67 01 	vinserti64x4 $0x1,0x20(%r15),%zmm4,%zmm4
  663d94:	01 
  663d95:	62 91 55 48 d5 2c 59 	vpmullw (%r9,%r11,2),%zmm5,%zmm5
  663d9c:	62 f1 55 48 e1 e8    	vpsraw %xmm0,%zmm5,%zmm5
  663da2:	62 f1 55 48 f9 eb    	vpsubw %zmm3,%zmm5,%zmm5
  663da8:	62 f1 55 48 71 e5 01 	vpsraw $0x1,%zmm5,%zmm5
  663daf:	62 f1 55 48 fd e4    	vpaddw %zmm4,%zmm5,%zmm4
  663db5:	62 f1 5d 48 ee e1    	vpmaxsw %zmm1,%zmm4,%zmm4
  663dbb:	62 f1 5d 48 ea e2    	vpminsw %zmm2,%zmm4,%zmm4
  663dc1:	c4 81 7e 7f 24 58    	vmovdqu %ymm4,(%r8,%r11,2)
  663dc7:	62 d3 fd 48 3b 67 01 	vextracti64x4 $0x1,%zmm4,0x20(%r15)
  663dce:	01 
  663dcf:	49 83 c3 20          	add    $0x20,%r11
  663dd3:	4c 39 db             	cmp    %r11,%rbx
  663dd6:	0f 92 c3             	setb   %bl
  663dd9:	48 83 ed 20          	sub    $0x20,%rbp
  663ddd:	40 0f 92 c7          	setb   %dil
  663de1:	40 08 df             	or     %bl,%dil
  663de4:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  663dea:	4d 0f 44 fd          	cmove  %r13,%r15
  663dee:	49 83 ee 20          	sub    $0x20,%r14
  663df2:	0f 92 c3             	setb   %bl
  663df5:	49 83 ec 20          	sub    $0x20,%r12
  663df9:	72 29                	jb     663e24 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  663dfb:	40 84 ff             	test   %dil,%dil
  663dfe:	75 24                	jne    663e24 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  663e00:	4c 39 da             	cmp    %r11,%rdx
  663e03:	72 1f                	jb     663e24 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  663e05:	49 83 c5 40          	add    $0x40,%r13
  663e09:	84 db                	test   %bl,%bl
  663e0b:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  663e10:	0f 84 6a ff ff ff    	je     663d80 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0xd0>
  663e16:	eb 11                	jmp    663e29 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x179>
  663e18:	45 84 e4             	test   %r12b,%r12b
  663e1b:	0f 84 c2 01 00 00    	je     663fe3 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x333>
  663e21:	45 31 db             	xor    %r11d,%r11d
  663e24:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  663e29:	48 39 d3             	cmp    %rdx,%rbx
  663e2c:	48 0f 42 d3          	cmovb  %rbx,%rdx
  663e30:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  663e35:	48 39 fa             	cmp    %rdi,%rdx
  663e38:	48 0f 43 d7          	cmovae %rdi,%rdx
  663e3c:	39 c8                	cmp    %ecx,%eax
  663e3e:	0f 8f d8 02 00 00    	jg     66411c <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x46c>
  663e44:	40 84 f6             	test   %sil,%sil
  663e47:	0f 84 d1 00 00 00    	je     663f1e <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x26e>
  663e4d:	8d 7e ff             	lea    -0x1(%rsi),%edi
  663e50:	bb 01 00 00 00       	mov    $0x1,%ebx
  663e55:	c4 e2 41 f7 db       	shlx   %edi,%ebx,%ebx
  663e5a:	40 80 e6 1f          	and    $0x1f,%sil
  663e5e:	49 89 d6             	mov    %rdx,%r14
  663e61:	49 f7 de             	neg    %r14
  663e64:	31 ff                	xor    %edi,%edi
  663e66:	4d 85 db             	test   %r11,%r11
  663e69:	0f 84 a1 00 00 00    	je     663f10 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x260>
  663e6f:	eb 50                	jmp    663ec1 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x211>
  663e71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  663e78:	0f 1f 84 00 00 00 00 
  663e7f:	00 
  663e80:	4c 8d 5f 01          	lea    0x1(%rdi),%r11
  663e84:	41 0f bf 2c 79       	movswl (%r9,%rdi,2),%ebp
  663e89:	45 0f bf 3c 7a       	movswl (%r10,%rdi,2),%r15d
  663e8e:	44 0f af fd          	imul   %ebp,%r15d
  663e92:	41 01 df             	add    %ebx,%r15d
  663e95:	c4 c2 4a f7 ef       	sarx   %esi,%r15d,%ebp
  663e9a:	45 0f b7 3c 78       	movzwl (%r8,%rdi,2),%r15d
  663e9f:	41 01 ef             	add    %ebp,%r15d
  663ea2:	41 39 cf             	cmp    %ecx,%r15d
  663ea5:	89 cd                	mov    %ecx,%ebp
  663ea7:	41 0f 4c ef          	cmovl  %r15d,%ebp
  663eab:	41 39 c7             	cmp    %eax,%r15d
  663eae:	0f 4c e8             	cmovl  %eax,%ebp
  663eb1:	66 41 89 2c 78       	mov    %bp,(%r8,%rdi,2)
  663eb6:	4c 89 df             	mov    %r11,%rdi
  663eb9:	45 31 db             	xor    %r11d,%r11d
  663ebc:	4d 85 db             	test   %r11,%r11
  663ebf:	74 4f                	je     663f10 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x260>
  663ec1:	49 89 d4             	mov    %rdx,%r12
  663ec4:	49 29 fc             	sub    %rdi,%r12
  663ec7:	4d 39 e3             	cmp    %r12,%r11
  663eca:	4d 0f 42 e3          	cmovb  %r11,%r12
  663ece:	4d 8d 3c 3c          	lea    (%r12,%rdi,1),%r15
  663ed2:	4c 39 ff             	cmp    %r15,%rdi
  663ed5:	4c 0f 47 ff          	cmova  %rdi,%r15
  663ed9:	49 39 d7             	cmp    %rdx,%r15
  663edc:	0f 83 e7 00 00 00    	jae    663fc9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663ee2:	4d 29 dc             	sub    %r11,%r12
  663ee5:	4f 8d 1c 3e          	lea    (%r14,%r15,1),%r11
  663ee9:	31 ff                	xor    %edi,%edi
  663eeb:	49 39 fc             	cmp    %rdi,%r12
  663eee:	74 0d                	je     663efd <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x24d>
  663ef0:	48 ff cf             	dec    %rdi
  663ef3:	49 39 fb             	cmp    %rdi,%r11
  663ef6:	75 f3                	jne    663eeb <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x23b>
  663ef8:	e9 cc 00 00 00       	jmp    663fc9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663efd:	49 29 ff             	sub    %rdi,%r15
  663f00:	4d 8d 5f 01          	lea    0x1(%r15),%r11
  663f04:	4c 89 ff             	mov    %r15,%rdi
  663f07:	e9 78 ff ff ff       	jmp    663e84 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x1d4>
  663f0c:	0f 1f 40 00          	nopl   0x0(%rax)
  663f10:	48 39 fa             	cmp    %rdi,%rdx
  663f13:	0f 87 67 ff ff ff    	ja     663e80 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x1d0>
  663f19:	e9 ab 00 00 00       	jmp    663fc9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663f1e:	48 89 d6             	mov    %rdx,%rsi
  663f21:	48 f7 de             	neg    %rsi
  663f24:	31 ff                	xor    %edi,%edi
  663f26:	4d 85 db             	test   %r11,%r11
  663f29:	0f 84 91 00 00 00    	je     663fc0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x310>
  663f2f:	eb 43                	jmp    663f74 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2c4>
  663f31:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  663f38:	0f 1f 84 00 00 00 00 
  663f3f:	00 
  663f40:	4c 8d 5f 01          	lea    0x1(%rdi),%r11
  663f44:	41 0f bf 1c 79       	movswl (%r9,%rdi,2),%ebx
  663f49:	41 0f bf 2c 7a       	movswl (%r10,%rdi,2),%ebp
  663f4e:	0f af eb             	imul   %ebx,%ebp
  663f51:	41 0f b7 1c 78       	movzwl (%r8,%rdi,2),%ebx
  663f56:	01 eb                	add    %ebp,%ebx
  663f58:	39 cb                	cmp    %ecx,%ebx
  663f5a:	89 cd                	mov    %ecx,%ebp
  663f5c:	0f 4c eb             	cmovl  %ebx,%ebp
  663f5f:	39 c3                	cmp    %eax,%ebx
  663f61:	0f 4c e8             	cmovl  %eax,%ebp
  663f64:	66 41 89 2c 78       	mov    %bp,(%r8,%rdi,2)
  663f69:	4c 89 df             	mov    %r11,%rdi
  663f6c:	45 31 db             	xor    %r11d,%r11d
  663f6f:	4d 85 db             	test   %r11,%r11
  663f72:	74 4c                	je     663fc0 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x310>
  663f74:	49 89 d6             	mov    %rdx,%r14
  663f77:	49 29 fe             	sub    %rdi,%r14
  663f7a:	4d 39 f3             	cmp    %r14,%r11
  663f7d:	4d 0f 42 f3          	cmovb  %r11,%r14
  663f81:	49 8d 1c 3e          	lea    (%r14,%rdi,1),%rbx
  663f85:	48 39 df             	cmp    %rbx,%rdi
  663f88:	48 0f 47 df          	cmova  %rdi,%rbx
  663f8c:	48 39 d3             	cmp    %rdx,%rbx
  663f8f:	73 38                	jae    663fc9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663f91:	4d 29 de             	sub    %r11,%r14
  663f94:	4c 8d 1c 1e          	lea    (%rsi,%rbx,1),%r11
  663f98:	31 ff                	xor    %edi,%edi
  663f9a:	49 39 fe             	cmp    %rdi,%r14
  663f9d:	74 0a                	je     663fa9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2f9>
  663f9f:	48 ff cf             	dec    %rdi
  663fa2:	49 39 fb             	cmp    %rdi,%r11
  663fa5:	75 f3                	jne    663f9a <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x2ea>
  663fa7:	eb 20                	jmp    663fc9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  663fa9:	48 29 fb             	sub    %rdi,%rbx
  663fac:	4c 8d 5b 01          	lea    0x1(%rbx),%r11
  663fb0:	48 89 df             	mov    %rbx,%rdi
  663fb3:	eb 8f                	jmp    663f44 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x294>
  663fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  663fbc:	00 00 00 00 
  663fc0:	48 39 fa             	cmp    %rdi,%rdx
  663fc3:	0f 87 77 ff ff ff    	ja     663f40 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x290>
  663fc9:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  663fce:	c6 00 ff             	movb   $0xff,(%rax)
  663fd1:	48 83 c4 48          	add    $0x48,%rsp
  663fd5:	5b                   	pop    %rbx
  663fd6:	41 5c                	pop    %r12
  663fd8:	41 5d                	pop    %r13
  663fda:	41 5e                	pop    %r14
  663fdc:	41 5f                	pop    %r15
  663fde:	5d                   	pop    %rbp
  663fdf:	c5 f8 77             	vzeroupper
  663fe2:	c3                   	ret
  663fe3:	bf 01 00 00 00       	mov    $0x1,%edi
  663fe8:	c4 e2 21 f7 ff       	shlx   %r11d,%edi,%edi
  663fed:	d1 ff                	sar    $1,%edi
  663fef:	62 f2 7d 48 7c c7    	vpbroadcastd %edi,%zmm0
  663ff5:	62 f2 7d 48 7c c8    	vpbroadcastd %eax,%zmm1
  663ffb:	62 f2 7d 48 7c d1    	vpbroadcastd %ecx,%zmm2
  664001:	c4 c1 79 6e db       	vmovd  %r11d,%xmm3
  664006:	4c 8d 62 e0          	lea    -0x20(%rdx),%r12
  66400a:	49 83 c5 e0          	add    $0xffffffffffffffe0,%r13
  66400e:	49 8d 68 40          	lea    0x40(%r8),%rbp
  664012:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  664017:	4c 8d 73 e0          	lea    -0x20(%rbx),%r14
  66401b:	45 31 db             	xor    %r11d,%r11d
  66401e:	62 f1 fd 48 6f 25 d8 	vmovdqa64 -0x61ce28(%rip),%zmm4        # 47200 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0x1bc>
  664025:	31 9e ff 
  664028:	62 f1 fd 48 6f 2d 0e 	vmovdqa64 -0x61cdf2(%rip),%zmm5        # 47240 <anon.c92e8cc03f6cee3785ec359eace39599.1590.llvm.14913374288739006752+0x1fc>
  66402f:	32 9e ff 
  664032:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  664039:	1f 84 00 00 00 00 00 
  664040:	62 92 7d 48 23 34 58 	vpmovsxwd (%r8,%r11,2),%zmm6
  664047:	62 d2 7d 48 23 7f 01 	vpmovsxwd 0x20(%r15),%zmm7
  66404e:	62 11 fe 48 6f 04 59 	vmovdqu64 (%r9,%r11,2),%zmm8
  664055:	62 11 fe 48 6f 0c 5a 	vmovdqu64 (%r10,%r11,2),%zmm9
  66405c:	62 51 35 48 d5 d0    	vpmullw %zmm8,%zmm9,%zmm10
  664062:	62 51 35 48 e5 c0    	vpmulhw %zmm8,%zmm9,%zmm8
  664068:	62 51 fd 48 6f ca    	vmovdqa64 %zmm10,%zmm9
  66406e:	62 52 dd 48 7d c8    	vpermt2w %zmm8,%zmm4,%zmm9
  664074:	62 52 d5 48 7d d0    	vpermt2w %zmm8,%zmm5,%zmm10
  66407a:	62 51 7d 48 fe c1    	vpaddd %zmm9,%zmm0,%zmm8
  664080:	62 71 3d 48 e2 c3    	vpsrad %xmm3,%zmm8,%zmm8
  664086:	62 f1 3d 48 fe f6    	vpaddd %zmm6,%zmm8,%zmm6
  66408c:	62 f2 4d 48 3d f1    	vpmaxsd %zmm1,%zmm6,%zmm6
  664092:	62 f2 4d 48 39 f2    	vpminsd %zmm2,%zmm6,%zmm6
  664098:	62 51 7d 48 fe c2    	vpaddd %zmm10,%zmm0,%zmm8
  66409e:	62 71 3d 48 e2 c3    	vpsrad %xmm3,%zmm8,%zmm8
  6640a4:	62 f1 3d 48 fe ff    	vpaddd %zmm7,%zmm8,%zmm7
  6640aa:	62 f2 45 48 3d f9    	vpmaxsd %zmm1,%zmm7,%zmm7
  6640b0:	62 92 7e 48 33 34 58 	vpmovdw %zmm6,(%r8,%r11,2)
  6640b7:	62 f2 45 48 39 f2    	vpminsd %zmm2,%zmm7,%zmm6
  6640bd:	62 d2 7e 48 33 77 01 	vpmovdw %zmm6,0x20(%r15)
  6640c4:	49 83 c3 20          	add    $0x20,%r11
  6640c8:	4c 39 db             	cmp    %r11,%rbx
  6640cb:	0f 92 c3             	setb   %bl
  6640ce:	49 83 ee 20          	sub    $0x20,%r14
  6640d2:	40 0f 92 c7          	setb   %dil
  6640d6:	40 08 df             	or     %bl,%dil
  6640d9:	41 bf 00 00 00 00    	mov    $0x0,%r15d
  6640df:	4c 0f 44 fd          	cmove  %rbp,%r15
  6640e3:	49 83 ec 20          	sub    $0x20,%r12
  6640e7:	0f 92 c3             	setb   %bl
  6640ea:	49 83 ed 20          	sub    $0x20,%r13
  6640ee:	0f 82 30 fd ff ff    	jb     663e24 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  6640f4:	40 84 ff             	test   %dil,%dil
  6640f7:	0f 85 27 fd ff ff    	jne    663e24 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  6640fd:	4c 39 da             	cmp    %r11,%rdx
  664100:	0f 82 1e fd ff ff    	jb     663e24 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x174>
  664106:	48 83 c5 40          	add    $0x40,%rbp
  66410a:	84 db                	test   %bl,%bl
  66410c:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  664111:	0f 84 29 ff ff ff    	je     664040 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x390>
  664117:	e9 0d fd ff ff       	jmp    663e29 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x179>
  66411c:	4d 85 db             	test   %r11,%r11
  66411f:	75 52                	jne    664173 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x4c3>
  664121:	48 85 d2             	test   %rdx,%rdx
  664124:	0f 84 9f fe ff ff    	je     663fc9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  66412a:	89 44 24 10          	mov    %eax,0x10(%rsp)
  66412e:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
  664132:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
  664137:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  66413c:	48 8d 05 cd 8a 1c 00 	lea    0x1c8acd(%rip),%rax        # 82cc10 <<i32 as core::fmt::Debug>::fmt>
  664143:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  664148:	48 8d 4c 24 14       	lea    0x14(%rsp),%rcx
  66414d:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  664152:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  664157:	48 8d 3d d2 62 9a ff 	lea    -0x659d2e(%rip),%rdi        # a430 <anon.42fab95c888da61b1e919ac44bbba854.230.llvm.10426147197465607828>
  66415e:	48 8d 15 13 e0 55 00 	lea    0x55e013(%rip),%rdx        # bc2178 <anon.d0737aeb7bbf3866d88b3a389feb0b4f.160.llvm.9512836412138272526+0x898>
  664165:	48 8d 74 24 28       	lea    0x28(%rsp),%rsi
  66416a:	c5 f8 77             	vzeroupper
  66416d:	ff 15 c5 0c 57 00    	call   *0x570cc5(%rip)        # bd4e38 <_DYNAMIC+0x290>
  664173:	49 39 d3             	cmp    %rdx,%r11
  664176:	0f 83 4d fe ff ff    	jae    663fc9 <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x319>
  66417c:	eb ac                	jmp    66412a <<fearless_simd::generated::avx512::Avx512 as fearless_simd::generated::simd_trait::Simd>::vectorize::vectorize_avx512::<splot_recon::film_grain::apply_film_grain_into_with<splot_core::simd::Avx512Backend, u16>::{closure#0}::{closure#0}, core::result::Result<(), splot_recon::error::ReconError>>+0x47a>
  66417e:	cc                   	int3
  66417f:	cc                   	int3

