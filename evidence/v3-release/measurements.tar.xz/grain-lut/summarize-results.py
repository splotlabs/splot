"""Validate the experiment's retained sample counts and report paired intervals."""

from collections import defaultdict
import csv
from pathlib import Path
import random
import re
from statistics import median
import sys

EXPECTED = {
    "control": "83566cc2a716603280a8b0773fc026f1fe86676e",
    "candidate": "33b33595447e4798dd29ff36880aad8fccc4ee19",
}


def statistics(rows):
    low, high = zip(*rows, strict=True)
    ratios = [b / a for a, b in rows]
    rng = random.Random(1891)
    samples = sorted(median(rng.choices(ratios, k=len(ratios))) for _ in range(20_000))
    point, left, right = ((value - 1) * 100 for value in (median(ratios), samples[500], samples[19_499]))
    return median(low), median(high), point, left, right


def main(results):
    for key, sha in EXPECTED.items():
        assert (results / f"{key}.sha").read_text().strip() == sha, key
    row_log = (results / "row.log").read_text()
    matches = re.findall(r"^1920,(\d+),([0-9.]+),([0-9.]+)$", row_log, re.M)
    assert [int(index) for index, _, _ in matches] == list(range(1, 25))
    rows = [(float(a), float(b)) for _, a, b in matches]
    playback = defaultdict(list)
    with (results / "paired.csv").open() as file:
        for row in csv.DictReader(file):
            count, round_ = int(row["threads"]), int(row["round"])
            assert count in (1, 7) and round_ == len(playback[count]) + 1
            assert row["order"] == ("control/candidate" if round_ % 2 else "candidate/control")
            playback[count].append((float(row["control_seconds"]), float(row["candidate_seconds"])))
    assert set(playback) == {1, 7} and all(len(samples) == 24 for samples in playback.values())
    log = (results / "playback.log").read_text()
    assert len(re.findall(r"^AVM ", log, re.M)) == 4 and "Grain-off control " in log
    assert re.search(r"\bvperm[ti]2b\b", (results / "wide-grain.asm").read_text())
    print("measurement\tsamples\tcontrol_median\tcandidate_median\tchange_pct\tlow95_pct\thigh95_pct")
    series = {"complete-row-ns": rows, "full-1-worker-s": playback[1], "full-7-workers-s": playback[7]}
    for label, samples in series.items():
        print(label, len(samples), *(f"{value:.5f}" for value in statistics(samples)), sep="\t")


if __name__ == "__main__":
    main(Path(sys.argv[1]))
