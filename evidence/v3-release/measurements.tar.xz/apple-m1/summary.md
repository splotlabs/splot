# Hosted Apple Silicon release comparison

[Completed GitHub Actions run](https://github.com/splotlabs/splot/actions/runs/45670988686). Signed workflow commit `134665a3`. The same GitHub `macos-15` VM built and ran `d171d82416a67140e1f6696eeba8e08e56af5763` and `a55cff38f4d5a5855af54e75aeac25b92a09531f`. It reported Apple M1 (Virtual), VirtualMac2,1, three cores, arm64 and NEON, macOS 15.8.2 (24H232), Xcode 16.4 and Rust 1.100.0 (LLVM 23.1.5).

Both revisions passed the four backend/lifecycle integration tests. The dynamic C example loaded each measured dylib and matched the AVM grained fixture. Both matched all seven complete frozen AVM outputs at 1, 7, and 12 workers (42 total SHA-256 and byte-length checks).

| Product | Baseline file bytes | Candidate file bytes | File delta | `__text` delta |
| --- | ---: | ---: | ---: | ---: |
| CLI | 10,490,528 | 10,495,360 | +4,832 B | −64 B |
| C dylib | 6,867,792 | 6,867,808 | +16 B | +1,024 B |

Eight alternating one-worker process timing pairs per case, frame delay one and null output. Positive deltas mean the candidate ran slower.

| Case | Baseline median | Candidate median | Paired delta with 95% bootstrap interval |
| --- | ---: | ---: | ---: |
| BlueSky first picture | 22.45 ms | 23.74 ms | +2.94% [−13.06, +22.57] |
| RitualDance first picture | 72.11 ms | 80.44 ms | +10.64% [−5.97, +20.02] |
| Noise_Ocean grain, 64 pictures | 666.36 ms | 683.30 ms | +1.29% [−4.87, +7.50] |
| RitualDance, 64 pictures | 1,638.93 ms | 1,564.08 ms | −2.74% [−5.03, +0.04] |

The timing is descriptive. All intervals include zero. The [idle M2 Max follow-up](https://github.com/splotlabs/splot/issues/1993#issuecomment-7170365932) remains open. Raw traces are in `timings.csv`; full validation records are in `avm-hashes.tsv` and `job.log`.
