# Local release qualification

The native build started at `a58794a6` and ended at `a55cff38`. The intervening commit changes one `#[cfg(test)]` CDEF match guard. The candidate used Cargo's release profile, including ThinLTO, one codegen unit, symbol stripping, `target-cpu=x86-64-v3`, and the GNU `DT_RELR` link flag. The build used rustc 1.100.0 and LLD 23.1.5. The hosted `d171d824` comparator used the same Rust and linker versions, its checked-in AVX-512 dispatch cfg, and Ubuntu GCC 13.3 CRT objects. The local build used GCC 15.2 CRT objects. GNU stripping of the comparator preserved its exact `.text` bytes.

## Native AVX2 output

The Core i7-12700H exposed AVX2 and no AVX-512F. The release CLI matched three frozen AVM raw output digests and byte counts. Noise Ocean and the grain variant each emitted 404,352,000 bytes over 130 frames. RitualDance emitted 3,732,480,000 bytes over 600 frames. The grain-on hash `06b6a20f…` also matched the main CLI. Both builds agreed on the distinct grain-off digest `d9c7bcd3…`.

All 21 fixture checks passed. Seven clips cover inter prediction, OPFL, deblocking, grain at both bit depths, and restoration at both bit depths. The CLI used one and three requested workers. A separate C compiler built the repository's C example against the installed header and candidate shared library, with explicit runpath and no library-path override. Each result matched its pinned AVM raw digest.

## Native CLI timing

Twelve alternating pairs on CPU 4 with one worker and frame delay one, after a warmup for each process/clip combination. The null output path synthesizes signalled display grain unless explicitly skipped. The table uses the median of paired wall ratios and a 95% bootstrap interval.

| Input | Frames | Release vs main |
|---|---:|---:|
| Witcher 3 | 40 | −1.13% [−2.24%, +1.31%] |
| TunnelFlag | 40 | +1.57% [−3.78%, +4.03%] |
| Noise Ocean | 64 | −0.18% [−4.85%, +1.31%] |
| RitualDance | 64 | +2.95% [−1.48%, +5.31%] |
| Noise Ocean, with grain | 130 | +1.52% [−0.57%, +2.39%] |
| Noise Ocean, same clip with grain skipped | 130 | −2.01% [−6.59%, +1.88%] |
| Noise Ocean, single output including process startup | 1 | +0.12% [−1.36%, +3.35%] |

Every interval crosses zero and has an upper endpoint above +0.5%. These samples establish neither direction nor a 0.5% upper bound. Child CPU time gave similar ratios.

## Linked code and size

| Artifact | Current stripped bytes | Original local cap delta |
|---|---:|---:|
| CLI | 12,491,672 | +16,672 |
| C library | 8,577,744 | +27,744 |

The hosted main CLI is 12,464,712 bytes stripped. The candidate adds 26,960 file bytes, of which 25,552 are in `.text`. Both binaries retain packed relative relocations. In both candidate artifacts, disassembly shows 32-word ZMM multiply, arithmetic rounding shifts, sample add, and clipping for both grain sample forms. The host ran the AVX2 path. Native AVX-512 execution needs a wide-capable host.

The separate exact-revision hosted pair from Actions run `45671134269` gives 12,464,680 → 12,491,576 bytes for the GNU-stripped CLI and 8,549,296 → 8,577,680 bytes for the GNU-stripped C library. At `45707e9d`, the updated Linux budgets are 12,502,000 and 8,579,000 bytes. Both the local and hosted release artifacts fit those budgets.

## Opt-in baseline CLI and C library

Cargo built the release CLI and C library with `RUSTFLAGS="-C target-cpu=x86-64 -C link-arg=-Wl,-z,pack-relative-relocs"`. The revision changed from `a55cff38` to `45707e9d` during the build. The intervening commit updates the performance size budget data. The resulting stripped CLI and shared library are 17,945,912 and 14,152,000 bytes. Both retain `DT_RELR`.

QEMU 10.2.1 exposed SSE2 and disabled SSE3, SSSE3, SSE4.1, SSE4.2, AVX, AVX2, AVX-512F, FMA, BMI2 and POPCNT, confirmed by an independent CPU feature probe. All 21 of the same CLI and C fixture checks matched the pinned AVM bytes on this emulated CPU.

## Matched hosted artifacts

GitHub Actions run `45671134269` built main `d171d824` and candidate `a55cff38` on Ubuntu 24.04 with the same Rust toolchain, LLD, x86-64-v3, and packed-relative-relocation flags. Main uses its existing Fearless dispatch cfg. Both use `CARGO_PROFILE_RELEASE_STRIP=none`. SHA-256 manifests for the CLI and C library passed before the runs. The later budget-only commit has the same production code.

Callgrind on CPU 3 measured the first 16 outputs with one worker and frame delay one. Separate raw decodes confirmed identical bytes on the two binaries for every measured window. The native host was AVX2-only.

| Input | Main instructions | Candidate instructions | Change |
|---|---:|---:|---:|
| TunnelFlag | 6,725,907,944 | 6,725,842,897 | −0.001% |
| RitualDance | 4,436,322,481 | 4,436,222,742 | −0.002% |
| Noise Ocean | 1,305,689,310 | 1,305,673,197 | −0.001% |
| Noise Ocean, with grain | 2,055,134,434 | 2,047,107,414 | −0.391% |

The grain call edge accounts for 7.98 million of the 8.03 million reduction on the grain clip at 16 calls in both traces. The 1,088 nested stripe fills remain at 308.49 million instructions in each. These are guest-instruction counts for the measured windows.

The focused native wall run used CPU 4 with one worker and frame delay one. Each case had 18 four-run blocks, alternating main–candidate–candidate–main and its reverse to counterbalance within-block drift. This gives 36 timed runs per binary per case. Each block compares geometric means of two runs per binary. The table reports the median of those ratios and a 95% block bootstrap interval.

| Input | Frames | Candidate vs main wall time |
|---|---:|---:|
| TunnelFlag | 40 | −0.07% [−1.49%, +2.70%] |
| RitualDance | 64 | +0.29% [−1.84%, +2.76%] |
| Noise Ocean, with grain | 130 | −2.08% [−3.40%, −0.33%] |

The full grain-bearing clip supports a wall-time change below +0.5% on this host. TunnelFlag and RitualDance remain unresolved against that bound. The four Callgrind windows show instruction counts within 0.5% against byte-identical output. Those counts answer a separate question from wall time.
