# Generic x86 vs x86-64-v3 playback at #2006

Both release executables use `91fbc9218814c1a0eebe73074c03fd35f3a2f932`,
the locked Rust 1.100.0 toolchain, and the default optimized release profile.
The generic build selects `-C target-cpu=x86-64`. The shipped build selects
`-C target-cpu=x86-64-v3`. Both request GNU packed relative relocations.
`compiler-flags.txt` records the Cargo fingerprints for the CLI and SIMD
core. `artifacts.csv` records both CLI and C API artifact sizes and SHA-256.

This measures the full playback cost of the compiler-floor change on an
i7-12700H with AVX2 and without AVX-512, using one decoder worker, frame delay
1, and a process pinned to CPU 4. The CLI constructs the default
`DecodeRuntimeConfig` with Auto policy. The pinned resolver selects
AVX2 when the CPU supports it and the wide qualification check fails. The
CLI has no backend-printing flag. `auto-source.txt` records the source
and `platform.txt` the native CPU probe. The comparison does not run on
pre-AVX2 hardware or force SSE2 on the workstation.

The raw-output oracle here is cross-build SHA-256 parity for the exact
displayed prefixes timed. Timing uses null output, includes CLI startup,
and records ten warmed, alternating pairs per case. Round 0 in
`timings.csv` is the discarded warm-up. Orders alternate within each case
and case order rotates each round. Percent changes are within-pair
generic/v3 ratios, and the descriptive 95% bootstrap interval resamples pairs
with a fixed seed. No hardware-counter data was collected.

Run with `LC_ALL=C taskset -c 4 python3 -B compare.py` after moving any
previous CSVs to an archive directory. The generic build command is in
`build.time`, and the original shipped build command is in
`../final-product/build.time`.

## Results

| Clip | Output frames | v3 median wall | Generic median wall | Paired generic wall change, 95% interval |
|---|---:|---:|---:|---:|
| Noise Ocean | 16 | 102.89 ms | 284.80 ms | +173.16% [162.82%, 179.80%] |
| RitualDance 10-bit | 16 | 360.31 ms | 2,586.42 ms | +619.68% [614.56%, 634.92%] |
| BlueSky | 64 | 175.15 ms | 1,110.72 ms | +535.32% [518.00%, 542.70%] |
| OldTown, tiles 4×2 | 16 | 246.10 ms | 2,199.65 ms | +797.11% [754.62%, 799.77%] |

Generic was slower in every pair. Child CPU time closely matched elapsed
time. Both binaries produced the same raw output byte counts and SHA-256
digests for all four prefixes. The generic CLI was 17,971,192 B and the v3
CLI was 12,508,104 B. See `timings.csv`, `comparison.log`, `hash-parity.csv`,
and `artifacts.csv`.

### Runtime backend

An out-of-tree Rust observer linked directly against each build's existing
`splot_core` and `splot_decode` release archives. On the same workstation,
both the core Auto resolver and the public `DecodeContext::selected_backend()`
reported **AVX2** for both builds. The generic artifact additionally offered
SSE2 and neither build reported AVX-512 capability. The timed runs use CPU 4.
The observer links and runs on CPU 12 to leave the timing core available.
The pinned CPU 4 feature probe also reports AVX2 and no AVX-512.

The observer source, link command and output are in `backend-probe.rs`,
`link-backend-probe.py`, and the two `backend-probe-*.log` files. That
observer is linked separately from the CLI. It queries the public startup
path and does not measure the cost of any individual decoder operation.
