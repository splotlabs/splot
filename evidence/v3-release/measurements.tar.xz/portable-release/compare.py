import csv
import hashlib
import os
from pathlib import Path
import random
from statistics import median
import subprocess
import sys

HERE = Path(__file__).resolve().parent
V3 = HERE.parent
sys.path.insert(0, str(V3))
from qualify import decode, digest_stream, timed

QUAL = V3.parent
CASES = (
    ("Noise Ocean", "Noise_Ocean_1920x1080_60fps_qp135_130f.ivf", 16),
    ("RitualDance 10-bit", "RitualDance_1920x1080_60fps_10bit_420_qp135_600f.ivf", 16),
    ("BlueSky", "BlueSky_360p25_v2_qp110_130f.ivf", 64),
    ("OldTown tiles 4x2", "old_town_cross_1080p50_tiles4x2_qp135_500f.ivf", 16),
)
BINARIES = {
    "v3": V3 / "final-product/target/release/splot",
    "generic": HERE / "target/release/splot",
}
ROUNDS = 10


def checksum(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def paired_change(ratios):
    rng = random.Random(1882)
    samples = sorted(median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return tuple(100 * (value - 1) for value in (median(ratios), samples[250], samples[9749]))


def main():
    assert os.sched_getaffinity(0) == {4}, "Run this benchmark pinned to CPU 4"
    for binary in BINARIES.values():
        subprocess.run([binary, "--version"], check=True, env=os.environ)
    with (HERE / "artifacts.csv").open("x", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("variant", "artifact", "bytes", "sha256"))
        for variant, binary in BINARIES.items():
            for path in (binary, binary.with_name("libsplot_capi.so"), binary.with_name("libsplot_capi.a")):
                writer.writerow((variant, str(path), path.stat().st_size, checksum(path)))

    commands = {}
    with (HERE / "hash-parity.csv").open("x", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("case", "variant", "limit", "input_bytes", "input_sha256", "decoded_bytes", "raw_sha256"))
        for case, filename, limit in CASES:
            source = QUAL / "ci-data" / filename
            sha = checksum(source)
            expected = None
            for variant, binary in BINARIES.items():
                opts = ("--limit", str(limit))
                commands[case, variant] = decode(binary, source, *opts, "--output-format", "null")
                result = digest_stream(decode(binary, source, *opts, "--output-format", "raw", "-o", "-"))
                writer.writerow((case, variant, limit, source.stat().st_size, sha, result[1], result[0]))
                stream.flush()
                if not result[1]:
                    raise RuntimeError(f"Empty decode output on {case} {variant}")
                if expected is None:
                    expected = result
                elif expected != result:
                    raise RuntimeError(f"Raw prefix mismatch for {case}: {expected!r} vs {result!r}")
            print(f"PASS {case}: {expected[1]} raw bytes, {expected[0]}", flush=True)

    with (HERE / "commands.txt").open("x") as stream:
        for (case, variant), command in commands.items():
            print(case, variant, repr(list(map(str, command))), file=stream)
    measurements = {}
    with (HERE / "timings.csv").open("x", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("case", "round", "position", "variant", "wall_seconds", "child_cpu_seconds"))
        for (case, variant), command in commands.items():
            writer.writerow((case, 0, 0, variant, *timed(command)))
        stream.flush()
        for index in range(ROUNDS):
            for offset in range(len(CASES)):
                case_index = (index + offset) % len(CASES)
                case = CASES[case_index][0]
                order = tuple(BINARIES) if (index + case_index) % 2 == 0 else tuple(reversed(BINARIES))
                for position, variant in enumerate(order, 1):
                    result = timed(commands[case, variant])
                    measurements[case, index, variant] = result
                    writer.writerow((case, index + 1, position, variant, *result))
                stream.flush()
            print(f"Completed pair {index + 1}/{ROUNDS} for every case", flush=True)

    print("Case | metric | v3 median ms | generic median ms | generic/v3 paired median change [95% bootstrap interval] | generic slower")
    for case, _, _ in CASES:
        for metric, label in enumerate(("wall", "child CPU")):
            v3, generic = [[measurements[case, index, variant][metric] for index in range(ROUNDS)] for variant in BINARIES]
            ratios = [g / v for g, v in zip(generic, v3)]
            change, low, high = paired_change(ratios)
            print(f"{case} | {label} | {median(v3)*1000:.2f} | {median(generic)*1000:.2f} | "
                  f"{change:+.2f}% [{low:+.2f}%, {high:+.2f}%] | {sum(ratio > 1 for ratio in ratios)}/{ROUNDS}")


if __name__ == "__main__":
    main()
