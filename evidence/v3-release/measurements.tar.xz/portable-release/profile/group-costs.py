"""Count exclusive guest instructions in disjoint named functions."""
from collections import Counter
import csv
from pathlib import Path
import re

root=Path(__file__).resolve().parent
groups={}
leaf_calls = []
def small_wrapper(symbol):
    return symbol.startswith('<fearless_simd::generated::') and '__fearless_simd_kernel' in symbol

for mode,path in [('generic',root/'symbolized-ritual.cg'),('v3',root/'v3-symbolized-ritual.cg')]:
    rows=path.read_text().splitlines()
    names={}
    for line in rows:
        m=re.match(r'c?fn=\((\d+)\) (.+)$',line)
        if m: names[m[1]]=m[2]
    edges=Counter()
    callee=''
    for row in rows:
        if row.startswith('cfn='):
            callee=names[re.match(r'cfn=\((\d+)\)',row)[1]]
        elif row.startswith('calls=') and small_wrapper(callee):
            edges[callee]+=int(row.split()[0][6:])
    leaf_calls.append((mode,sum(edges.values()),len(edges)))
    fn=''
    skip=False
    costs=Counter()
    for line in rows:
        if line.startswith('fn='):
            fn=names[re.match(r'fn=\((\d+)\)',line)[1]]
            skip=False
        elif line.startswith(('calls=','jump=','jcnd=')):
            skip=True
        elif re.match(r'^[+*\d-]',line):
            if not skip: costs[fn]+=int(line.split()[1])
            skip=False
    total=int(next(l.split()[1] for l in rows if l.startswith('summary:')))
    assert sum(costs.values())==total,(mode,sum(costs.values()),total)
    tally=Counter()
    for fn,ir in costs.items():
        if small_wrapper(fn): key='Fearless per-operation kernel bodies'
        elif 'splot_decode::filters::gdf' in fn: key='GDF functions'
        elif 'splot_recon::cdef_filter' in fn: key='CDEF filter functions'
        elif 'splot_recon::warp_prediction' in fn: key='Warp prediction functions'
        else: key='Other functions'
        tally[key]+=ir
    groups[mode]=tally
    with (root/(mode+'-named-costs.tsv')).open('w') as f:
        out=csv.writer(f,delimiter='\t',lineterminator='\n')
        out.writerow(['instructions','symbol'])
        out.writerows((v,k) for k,v in costs.most_common(100))
with (root/'group-costs.tsv').open('w') as f:
    out=csv.writer(f,delimiter='\t',lineterminator='\n')
    out.writerow(['exclusive group','generic guest instructions','v3 guest instructions','generic minus v3'])
    for name in sorted(groups['generic']|groups['v3']):
        gen,narrow=groups['generic'][name],groups['v3'][name]
        out.writerow([name,gen,narrow,gen-narrow])

with (root/'leaf-calls.tsv').open('w') as f:
    out=csv.writer(f,delimiter='\t',lineterminator='\n')
    out.writerow(['mode','calls to generated SIMD primitive wrappers','distinct callees'])
    out.writerows(leaf_calls)
