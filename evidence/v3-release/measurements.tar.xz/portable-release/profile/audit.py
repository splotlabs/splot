"""Validate the symbol map before naming costs from the stripped generic release."""
from bisect import bisect_right
import hashlib
from pathlib import Path
import re
import subprocess

root=Path(__file__).resolve().parent
original=root.parent/'target/release/splot'
labeled=root/'symbol-target/release/splot'
text={}
for mode,exe in [('product',original),('symbolized',labeled)]:
    blob=root/(mode+'.text')
    copy=root/(mode+'.copy')
    subprocess.run(['objcopy','--dump-section','.text='+str(blob),exe,copy],check=True)
    text[mode]=hashlib.sha256(blob.read_bytes()).hexdigest()
    copy.unlink()
    blob.unlink()
(root/'text-identity.txt').write_text('\n'.join(k+' '+v for k,v in text.items())+'\n')
same=text['product']==text['symbolized']
print('Product and symbolized .text identical:',same,flush=True)
if same:
    cg=root/'generic-ritual.cg'
    addresses=[]; names={}
    for line in subprocess.check_output(['nm','-C','-S','-n',labeled],text=True).splitlines():
        m=re.match(r'^([0-9a-f]+) ([0-9a-f]+) [TtWw] (.+)$',line)
        if m:
            a=int(m[1],16); addresses.append(a); names[a]=(int(m[2],16),m[3])
    addresses.sort()
    report=subprocess.check_output(['callgrind_annotate','--inclusive=no','--auto=no','--threshold=95',cg],text=True)
    output=['instructions\tpercent\taddress\tsymbol']
    for line in report.splitlines():
        m=re.match(r'^\s*([\d,]+)\s+\(\s*([\d.]+)%\)\s+\?\?\?:0x([0-9a-f]+).*splot\]',line)
        if not m: continue
        ip=int(m[3],16); i=bisect_right(addresses,ip)-1
        if i<0: continue
        start=addresses[i]; size,name=names[start]
        if ip < start+size:
            output.append('\t'.join([m[1].replace(',',''),m[2],hex(ip),name]))
    (root/'named-costs.tsv').write_text('\n'.join(output)+'\n')
else:
    print('Symbol attribution needs a direct trace of the labeled executable.')
