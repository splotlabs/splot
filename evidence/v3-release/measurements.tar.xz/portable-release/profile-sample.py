"""Profile identical four-frame AVX2 playback commands at both compiler floors."""
import csv
from pathlib import Path
import os
import subprocess
root=Path(__file__).resolve().parent
out=root/'profile'
stream=next((root.parent.parent/'ci-data').glob('RitualDance*.ivf'))
for mode,dirname in [('v3','final-product'),('generic','portable-release')]:
    cli=root.parent/dirname/'target/release/splot'
    prefix=out/(mode+'-ritual')
    subprocess.run(['taskset','-c','4','valgrind','--tool=callgrind','--callgrind-out-file='+str(prefix.with_suffix('.cg')),'--log-file='+str(prefix.with_suffix('.log')),cli,'decode',stream,'--threads','1','--frame-delay','1','--limit','4','--output-format','null'],check=True,stdout=subprocess.DEVNULL)
    text=prefix.with_suffix('.cg').read_text()
    print(mode,next(s for s in text.splitlines() if s.startswith('summary:')),flush=True)
