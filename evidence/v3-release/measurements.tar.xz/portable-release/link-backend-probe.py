from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
for variant, target, cpu in (
    ("generic", here / "target", "x86-64"),
    ("v3", here.parent / "final-product/target", "x86-64-v3"),
):
    out_dirs = sorted((target / "release/build").glob("*/*/out"))
    core, = [path for folder in out_dirs for path in folder.glob("libsplot_core-*.rlib")]
    decode, = [path for folder in out_dirs for path in folder.glob("libsplot_decode-*.rlib")]
    executable = here / f"backend-probe-{variant}"
    command = [
        "taskset", "-c", "12", "rustc", "+1.100.0", "-D", "warnings", "--edition=2024",
        "-C", "panic=abort", "-C", "lto=thin", "-C", "codegen-units=1",
        "-C", "opt-level=3", "-C", f"target-cpu={cpu}",
        "--extern", f"splot_core={core}", "--extern", f"splot_decode={decode}",
        here / "backend-probe.rs", "-o", executable,
    ]
    for folder in out_dirs:
        command.extend(("-L", f"dependency={folder}"))
    with (here / f"backend-probe-{variant}.log").open("w") as log:
        print(repr([str(arg) for arg in command]), file=log, flush=True)
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        subprocess.run(["taskset", "-c", "12", executable], stdout=log, stderr=subprocess.STDOUT, check=True)
