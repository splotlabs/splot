// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// SPDX-FileCopyrightText: 2026 Bartosz Tomczyk <bartekplus@gmail.com>

use splot_core::simd::{SimdPolicy, detect_capabilities, resolve_backend};
use splot_decode::{DecodeContext, DecodeRuntimeConfig};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("CPU capabilities: {:?}", detect_capabilities());
    println!("Core Auto: {}", resolve_backend(SimdPolicy::Auto)?.name());
    let decoder = DecodeContext::new(DecodeRuntimeConfig::default())?;
    println!("Decoder Auto: {}", decoder.selected_backend().as_str());
    Ok(())
}
